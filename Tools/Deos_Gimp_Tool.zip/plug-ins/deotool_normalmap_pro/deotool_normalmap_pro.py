#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# -------- LIBRARIES --------
import gi, sys
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject, Gegl			# Actions
from gi.repository import GimpUi, Gtk 									# UI

# --------- METHODS ----------
def gegl_gaussianblur(layer, radius):
	# Blur geGL
	blur = Gimp.DrawableFilter.new(layer, 'gegl:gaussian-blur', 'Gaussian Blur')

	# Properties
	cfg = blur.get_config()
	cfg.set_property('std-dev-x', float(radius))
	cfg.set_property('std-dev-y', float(radius))
	cfg.set_property('filter', 1)
	cfg.set_property('abyss-policy', 0)
	
	# Non Destructive Filter
	blur.update()
	layer.append_filter(blur)

def gegl_normalmap(layer, scale, flip):
	# Normal Map geGL
	normal = Gimp.DrawableFilter.new(layer, 'gegl:normal-map', 'Normal Map')

	# Properties
	cfg = normal.get_config()
	cfg.set_property('scale', float(scale))
	cfg.set_property('x-component', 0)
	cfg.set_property('y-component', 1)
	cfg.set_property('flip-y', int(flip))
	
	# Non Destructive Filter
	normal.update()
	layer.append_filter(normal)


# --------- PLUGIN ----------
class DeosToolNormalMapPro(Gimp.PlugIn):
	
	def do_query_procedures(self):
		return ["deotool-advancedNormalMap"]

	def do_create_procedure(self, name):
		procedure = Gimp.ImageProcedure.new(
			self,
			name,
			Gimp.PDBProcType.PLUGIN,
			self.deo_uiDialog,
			None,
		)
		
		# Contextual Menu
		procedure.set_sensitivity_mask(Gimp.ProcedureSensitivityMask.DRAWABLE | Gimp.ProcedureSensitivityMask.NO_DRAWABLES)
		procedure.set_image_types("*")																																
		procedure.set_menu_label("Advanced NormalMap")																								
		procedure.add_menu_path("<Image>/Deo's Tools v3.0")																						
		procedure.set_documentation("Create a better Normal map from a Base Color Texture", "", name)  
		procedure.set_attribution("Deo", "Deo's Tools", "2025")																			
		
		# UI Arguments
		procedure.add_double_argument("arg_blur_normal", "Smooth Details: ", None, 0.1, 4.0, 1.0, GObject.ParamFlags.READWRITE)						
		procedure.add_double_argument("arg_scale_normal", "Intensity Detail: ", None, 0.1, 4.0, 1.0, GObject.ParamFlags.READWRITE)		
		procedure.add_boolean_argument("arg_flip_normal", "Invert Direction?", None, False, GObject.ParamFlags.READWRITE)																												

		return procedure

	# ACTIONS
	def deo_actions(self, procedure, run_mode, image, drawables, config, data, get_blur, get_scale, get_flip):
		
		# Parameters			
		base_layer: Gimp.Drawable = drawables[0]														# Selected Layer
		base_color: float 		= (0.5, 0.5, 1.0)															# Base Color (sRGB)
		UI_Smoothness: float 	= get_blur																		# UI Smoothness
		UI_Intensity: float 	= get_scale																		# UI Intensity
		UI_InverDir: float 		= get_flip																		# UI Invert Direction
		
		# Layer Active
		if not base_layer.get_visible():
			Gimp.message("The selected layer Visibility is Disabled")
			return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, GLib.Error())
		else:

			image.undo_group_start()
			try:
				
				# Validate NormalMap Group is Created
				if not image.get_layer_by_name("NormalMap"):

					# ----------- Original Layer -----------
					original_layer = base_layer

					# ----------- Base Color -----------
					base_layer = base_layer.copy()										
					image.insert_layer(base_layer, None, -1)										
					base_layer.set_name("BaseColor")									
					base_layer = image.get_layer_by_name("BaseColor")	

					color = Gegl.Color()
					color.set_rgba(pow (base_color[0], 2.2), pow (base_color[1], 2.2), pow (base_color[2], 2.2), 1.0)
					Gimp.context_set_foreground(color)
					base_layer.fill(Gimp.FillType.FOREGROUND)

					# ----------- Fine Detail -----------
					base_layer = original_layer.copy()												
					image.insert_layer(base_layer, None, -1)					
					base_layer.set_name("FineDetail")											
					base_layer = image.get_layer_by_name("FineDetail")
					gegl_gaussianblur(base_layer, UI_Smoothness * 0.5)
					gegl_normalmap(base_layer, UI_Intensity * 5, UI_InverDir)
					base_layer.set_mode(Gimp.LayerMode.OVERLAY)

					# ----------- Medium Detail -----------
					base_layer = original_layer.copy()												
					image.insert_layer(base_layer, None, -1)
					base_layer.set_name("MediumDetail")											
					base_layer = image.get_layer_by_name("MediumDetail")
					gegl_gaussianblur(base_layer, UI_Smoothness * 2)
					gegl_normalmap(base_layer, UI_Intensity * 4, UI_InverDir)
					base_layer.set_mode(Gimp.LayerMode.OVERLAY)

					# ----------- Large Detail -----------
					base_layer = original_layer.copy()												
					image.insert_layer(base_layer, None, -1)					
					base_layer.set_name("LargeDetail")											
					base_layer = image.get_layer_by_name("LargeDetail")	
					gegl_gaussianblur(base_layer, UI_Smoothness * 4)
					gegl_normalmap(base_layer, UI_Intensity * 8, UI_InverDir)
					base_layer.set_mode(Gimp.LayerMode.OVERLAY)

					
					# ----------- Layer Group -----------
					# Group
					normal_grp = Gimp.GroupLayer.new(image, "NormalMap")
					image.insert_layer(normal_grp, None, -1)				

					# Move Layers
					normal_grp = image.get_layer_by_name("NormalMap")

					move_layer = image.get_layer_by_name("BaseColor")
					image.reorder_item(move_layer, normal_grp, 0)
					fine_layer = image.get_layer_by_name("FineDetail")
					image.reorder_item(fine_layer, normal_grp, 0)
					medium_layer = image.get_layer_by_name("MediumDetail")
					image.reorder_item(medium_layer, normal_grp, 0)
					large_layer = image.get_layer_by_name("LargeDetail")
					image.reorder_item(large_layer, normal_grp, 0)
					
					normal_grp.set_expanded(False)
				else:

					# ----------- Fine Detail -----------
					fine_layer = image.get_layer_by_name("FineDetail")
					fine_layer_fx = fine_layer.get_filters()

					# Blur Fx
					fine_blur_fx = fine_layer_fx[1]
					fine_blur_config = fine_blur_fx.get_config()
					fine_blur_config.set_property('std-dev-x', UI_Smoothness * 0.5)
					fine_blur_config.set_property('std-dev-y', UI_Smoothness * 0.5)
					fine_blur_config.set_property('filter', 1)
					fine_blur_config.set_property('abyss-policy', 0)
					fine_blur_fx.update()

					# Normal Fx
					fine_normal_fx = fine_layer_fx[0]
					fine_normal_config = fine_normal_fx.get_config()
					fine_normal_config.set_property('scale', UI_Intensity * 5)
					fine_normal_config.set_property('x-component', 0)
					fine_normal_config.set_property('y-component', 1)
					fine_normal_config.set_property('flip-y', UI_InverDir)
					fine_normal_fx.update()

					# ----------- Medium Detail -----------
					medium_layer = image.get_layer_by_name("MediumDetail")
					medium_layer_fx = medium_layer.get_filters()

					# Blur Fx
					medium_blur_fx = medium_layer_fx[1]
					medium_blur_config = medium_blur_fx.get_config()
					medium_blur_config.set_property('std-dev-x', UI_Smoothness * 2)
					medium_blur_config.set_property('std-dev-y', UI_Smoothness * 2)
					medium_blur_config.set_property('filter', 1)
					medium_blur_config.set_property('abyss-policy', 0)
					medium_blur_fx.update()

					# Normal Fx
					medium_normal_fx = medium_layer_fx[0]
					medium_normal_config = medium_normal_fx.get_config()
					medium_normal_config.set_property('scale', UI_Intensity * 4)
					medium_normal_config.set_property('x-component', 0)
					medium_normal_config.set_property('y-component', 1)
					medium_normal_config.set_property('flip-y', UI_InverDir)
					medium_normal_fx.update()

					# ----------- Large Detail -----------
					large_layer = image.get_layer_by_name("LargeDetail")
					large_layer_fx = large_layer.get_filters()

					# Blur Fx
					large_blur_fx = large_layer_fx[1]
					large_blur_config = large_blur_fx.get_config()
					large_blur_config.set_property('std-dev-x', UI_Smoothness * 4)
					large_blur_config.set_property('std-dev-y', UI_Smoothness * 4)
					large_blur_config.set_property('filter', 1)
					large_blur_config.set_property('abyss-policy', 0)
					large_blur_fx.update()

					# Normal Fx
					large_normal_fx = large_layer_fx[0]
					large_normal_config = large_normal_fx.get_config()
					large_normal_config.set_property('scale', UI_Intensity * 8)
					large_normal_config.set_property('x-component', 0)
					large_normal_config.set_property('y-component', 1)
					large_normal_config.set_property('flip-y', UI_InverDir)
					large_normal_fx.update()


			except Exception as e:
				Gimp.message(f"Error: {str(e)}")
				image.undo_group_end()
				return procedure.new_return_values(Gimp.PDBStatusType.EXECUTION_ERROR, GLib.Error())

			finally: 
				image.undo_group_end()																					# Undo End														
			
		# End - Success
		Gimp.message("Was Generated Successfully!")
		return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, GLib.Error())

	# # UI
	def deo_uiDialog(self, procedure, run_mode, image, drawables, config, data):
		if run_mode == Gimp.RunMode.INTERACTIVE:
			
			# Initialize Dialog
			GimpUi.init("deotool-advancedNormalMap-ui") 																							
			dialog = GimpUi.ProcedureDialog.new(procedure, config, "Tool: Advanced Normal Map")

			# UI Elements
			box = dialog.fill_box("ui_args", ["arg_blur_normal","arg_scale_normal", "arg_flip_normal"])
			box.set_orientation(Gtk.Orientation.VERTICAL)
			box.set_halign(Gtk.Align.CENTER)
			dialog.fill(["ui_args"])		

			# Instructions
			instructions = Gtk.Label(label=
				"\nINSTRUCTIONS:"
				"\n1. The first time, you need to create the Normal Map layers."
				"\n2. After the creation of Layers if you re-open the tool you"
				"\nwill be able to modify:'Smoothness, Intensity, Invert values,"
				"\nand accept the changes, and see the result, and so on.\n"
				"\nNote: You can create only one Img File to Normal Map."
			)
			instructions.set_line_wrap(False)  							# Fit text to width
			instructions.set_halign(Gtk.Align.START)  			# Left Align
			box.pack_start(instructions, False, False, 5) 	# add Height padding
			instructions.show()  														# Show Label
			
			
			# Buttons (Accept, Cancel)
			if dialog.run():
				dialog.destroy()
				
				# Send Argument deo_actions
				send_blur = config.get_property('arg_blur_normal')
				send_scale = config.get_property('arg_scale_normal')
				send_flip = config.get_property('arg_flip_normal')		
				return self.deo_actions(procedure, run_mode, image, drawables, config, data, send_blur, send_scale, send_flip)
			else:
				dialog.destroy()
				return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, None)

		# End - Success
		return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, None)


# --------REGISTER --------
Gimp.main(DeosToolNormalMapPro.__gtype__, sys.argv)