#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# -------- LIBRARIES --------
import gi, sys
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject, Gegl			# Actions
from gi.repository import GimpUi, Gtk 									# UI

# --------- METHODS ----------
def gegl_gaussianblur(layer, radius, merge):
	# Blur geGL
	blur = Gimp.DrawableFilter.new(layer, 'gegl:gaussian-blur', 'Gaussian Blur')

	# Properties
	cfg = blur.get_config()
	cfg.set_property('std-dev-x', float(radius))
	cfg.set_property('std-dev-y', float(radius))
	cfg.set_property('filter', 1)
	cfg.set_property('abyss-policy', 0)
	
	# Non Destructive Filter
	blur.update()
	layer.append_filter(blur)
	if merge:
		layer.merge_filters()
		# layer.merge_filter(blur)

# --------- PLUGIN ----------
class DeosToolColorEquilizer(Gimp.PlugIn):

	def do_query_procedures(self):
		return ["deotool-colorEquilizer"]

	def do_create_procedure(self, name):
		procedure = Gimp.ImageProcedure.new(
			self,
			name,
			Gimp.PDBProcType.PLUGIN,
			# self.deo_actions,
			self.deo_uiDialog,
			None,
		)

		# Contextual Menu
		procedure.set_sensitivity_mask(Gimp.ProcedureSensitivityMask.DRAWABLE | Gimp.ProcedureSensitivityMask.NO_DRAWABLES)
		procedure.set_image_types("*")
		procedure.set_menu_label("Color Equilizer")
		procedure.add_menu_path("<Image>/Deo's Tools v3.0")
		procedure.set_documentation("Equilize the Color texture to be able to use it as Tileable texture", "", name)
		procedure.set_attribution("Deo", "Deo's Tools", "2025")

		# UI Arguments
		procedure.add_boolean_argument("arg_keep_equilizer", "Keep Original Layer?", None, True, GObject.ParamFlags.READWRITE)																																									# name, label, desc , value, Flags
		procedure.add_double_argument("arg_balance_equilizer", " [%] Color Equilizer: ", None, 0.0, 1.0, 0.8, GObject.ParamFlags.READWRITE)	# name, label, desc, min, max, value, Flags

		return procedure

		# ACTIONS
	
	# Actions
	def deo_actions(self, procedure, run_mode, image, drawables, config, data, get_keepLayer, get_equilizer):
			
		# Parameters
		img_width: int = image.get_width()																		# Image Width
		img_height: int = image.get_height()																	# Image Height
		valid_sizes = [128, 256, 512, 1024, 2048, 4096, 8192]									# Valid Sizes
		
		# Validate Image Square
		if not (img_width == img_height and img_width in valid_sizes):
			Gimp.message("Texture is not [ Square ] or is not using sizes like: \n [ 64, 128, 256, 512, 1024, 2048, 4096, 8192 ]")
			return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, GLib.Error())
		else:
			
			# Parameters			
			base_layer: Gimp.Drawable = drawables[0]														# Selected Layer
			UI_keepLayer: bool = get_keepLayer																	# UI Keep Layer
			UI_equilizer: float = get_equilizer																	# UI Equilizer, Inverse Value
			
			# Layer Active
			if not base_layer.get_visible():
				Gimp.message("The selected layer Visibility is Disabled")
				return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, GLib.Error())
			else:
				
				image.undo_group_start()
				try:

					# ----------- Keep Layer -----------
					if UI_keepLayer:
						base_layer = base_layer.copy()																# Copy Base Layer
						image.insert_layer(base_layer, None, -1)											# Insert Copied Layer on top							
						base_layer.set_name("ColorEquilizer")													# Set Name		
						base_layer = image.get_layer_by_name("ColorEquilizer")				# Select Layer by Name
					else:
						base_layer = base_layer
						base_layer_name = base_layer.get_name()

					# ---

					# Create Blur Layer
					blur_layer = base_layer.copy()	
					image.insert_layer(blur_layer, None, -1)
					blur_layer.set_name("Blur")
					image.get_layer_by_name("Blur")


					# Apply Blur strength according to texture size
					max_img_size = max(img_width, img_height)
					scale = {64: 8, 128: 16, 256: 32, 512: 64, 1024: 128, 2048: 256, 4096: 512, 8192: 1024}[max_img_size]
					radius = scale * (1.0 - max(0.3, min(UI_equilizer, 0.99))) # Inverse Value & Clamp 0.3 and 0.99
					gegl_gaussianblur(blur_layer, radius, True)
					gegl_gaussianblur(blur_layer, radius, True)

					# ---

					# Create Color Layer from Blur Layer
					color_layer = blur_layer.copy()
					image.insert_layer(color_layer, None, -1)
					color_layer.set_name("Color")
					image.get_layer_by_name("Color")

					# Histogram Values (bool, mean, std_dev, median, pixels, count, percentile)
					r_stats = color_layer.histogram(Gimp.HistogramChannel.RED, 0.0, 1.0)
					g_stats = color_layer.histogram(Gimp.HistogramChannel.GREEN, 0.0, 1.0)
					b_stats = color_layer.histogram(Gimp.HistogramChannel.BLUE, 0.0, 1.0)
					
					# RGB Mean Values (0-1.0)
					r_Mean = r_stats[1] / 255.0
					g_Mean = g_stats[1] / 255.0
					b_Mean = b_stats[1] / 255.0
					
					# RGB Mean: Linear to sRGB
					r_sRGB = pow (r_Mean, 2.2)
					g_sRGB = pow (g_Mean, 2.2)
					b_sRGB = pow (b_Mean, 2.2)

					# Set Foreground Color + Blend Mode: Subtract
					color = Gegl.Color()
					color.set_rgba(r_sRGB, g_sRGB, b_sRGB, 1.0)
					Gimp.context_set_foreground(color)
					color_layer.fill(Gimp.FillType.FOREGROUND)
					color_layer.set_mode(Gimp.LayerMode.SUBTRACT)

					# Show values
					# Gimp.message(f"Linear RGB: {r_Mean:.2f}, {g_Mean:.2f}, {b_Mean:.2f}")
					# Gimp.message(f"sRGB RGB: {r_Gm:.2f}, {g_Gm:.2f}, {b_Gm:.2f}")

					# ---

					# Create 'Color Copy' from Color Layer (On top)
					color_copy = color_layer.copy()
					image.insert_layer(color_copy, None, -1)

					# Create 'Blur Copy' from Blur Layer (On top) + Blend mode
					blur_copy = blur_layer.copy()
					image.insert_layer(blur_copy, None, -1)
					blur_copy.set_mode(Gimp.LayerMode.SUBTRACT)

					# ---
					
					# Merges: Color into Blur Layer = Blur
					image.merge_down(color_layer, Gimp.MergeType.CLIP_TO_IMAGE)
					
					# Merge: 'Blur Copy' into 'Color Copy' = Color Copy
					image.merge_down(blur_copy, Gimp.MergeType.CLIP_TO_IMAGE)

					# # ---

					# # Blend Mode: Blur to Subtract
					blur_layer = image.get_layer_by_name("Blur")
					blur_layer.set_mode(Gimp.LayerMode.SUBTRACT)
					
					# # Blend Mode: Color Copy to Add
					color_copy = image.get_layer_by_name("Color copy")
					color_copy.set_mode(Gimp.LayerMode.ADDITION)
					
					# # ---
					
					# Merge: Blur into 'Base layer'
					blur_layer = image.get_layer_by_name("Blur")
					image.merge_down(blur_layer, Gimp.MergeType.CLIP_TO_IMAGE)
					
					# # Merge: Color Copy into 'Base layer'
					color_copy = image.get_layer_by_name("Color copy")
					image.merge_down(color_copy, Gimp.MergeType.CLIP_TO_IMAGE)

					# Set Unique Name To: Base/Keep Layers
					if UI_keepLayer:
						rename_keep_layer = image.get_layer_by_name("ColorEquilizer")
						rename_keep_layer.set_name(f"ColorEquilzierVal: {UI_equilizer:.2f}")
					else:
						rename_base_layer = image.get_layer_by_name(base_layer_name)
						rename_base_layer.set_name(f"ColorEquilzierVal: {UI_equilizer:.2f}")
				
				except Exception as e:
					Gimp.message(f"Error: {str(e)}")
					image.undo_group_end()
					return procedure.new_return_values(Gimp.PDBStatusType.EXECUTION_ERROR, GLib.Error())

				finally: 
					image.undo_group_end()													
			
		# End - Success
		Gimp.message("Was Generated Successfully!")
		return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, GLib.Error())

	# UI
	def deo_uiDialog(self, procedure, run_mode, image, drawables, config, data):
		if run_mode == Gimp.RunMode.INTERACTIVE:
			
			# Initialize Dialog
			GimpUi.init("deotool-ColorEquilizer-ui")
			dialog = GimpUi.ProcedureDialog.new(procedure, config, "Tool: Color Equilizer")

			# UI Elements
			box = dialog.fill_box("ui_args", ["arg_keep_equilizer", "arg_balance_equilizer"])
			box.set_orientation(Gtk.Orientation.VERTICAL)
			box.set_halign(Gtk.Align.FILL)
			dialog.fill(["ui_args"])

			# Instructions
			instructions = Gtk.Label(label=
				"\nINSTRUCTIONS:"
				"\n1. The texture needs to be Totally Square (Same width and height)."
				"\n2. But is mandatory use textures with 'power of 2', this means:"
				"\n         [ 128 | 256 | 512 | 1024 | 2048 | 4096 | 8192 ]\n"
			)
			instructions.set_line_wrap(True)  							# Fit text to width
			instructions.set_halign(Gtk.Align.START)  			# Left Align
			box.pack_start(instructions, False, False, 5) 	# add Height padding
			instructions.show()  

			# Buttons (Accept, Cancel)
			if dialog.run():
				dialog.destroy()
				
				# Send Argument deo_actions
				send_keepLayer = config.get_property("arg_keep_equilizer")
				send_equilizer = config.get_property("arg_balance_equilizer")
				return self.deo_actions(procedure, run_mode, image, drawables, config, data, send_keepLayer, send_equilizer)
			else:
				dialog.destroy()
				return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, None)

		# End - Success
		return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, None)

# -------- REGISTER --------
Gimp.main(DeosToolColorEquilizer.__gtype__, sys.argv)
