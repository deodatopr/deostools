#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# -------- LIBRARIES --------
import gi, sys
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject						# Actions
from gi.repository import GimpUi, Gtk										# UI

# --------- METHODS ---------- 
def gegl_emboss(layer, azim, elev, depth, merge):
	# Emboss geGL
	emboss = Gimp.DrawableFilter.new(layer, 'gegl:emboss', 'Emboss')
	
	# Properties
	cfg = emboss.get_config()
	cfg.set_property('type', 'Emboss')
	cfg.set_property('azimuth', azim)
	cfg.set_property('elevation', elev)
	cfg.set_property('depth', depth)
	
	# Merge Filter
	emboss.update()
	layer.append_filter(emboss)
	if merge:
		layer.merge_filters()
		# Gimp.Drawable.merge_filter (emboss)

def gegl_invert(layer, merge):
	# Invert geGL
	invert = Gimp.DrawableFilter.new(layer, 'gegl:invert-gamma', 'Invert RGB')
	
	# Properties
	cfg = invert.get_config()
	
	# Merge Filter
	invert.update()
	layer.append_filter(invert)
	if merge:
		layer.merge_filters()
		# Gimp.Drawable.merge_filter (invert)	


# --------- PLUGIN ----------
class DeosToolCurvature(Gimp.PlugIn):
	
	def do_query_procedures(self):
		return ["deotool-curvature"]

	def do_create_procedure(self, name):
		procedure = Gimp.ImageProcedure.new(
			self,
			name,
			Gimp.PDBProcType.PLUGIN,
			# self.deo_actions,
			self.deo_uiDialog,
			None,
		)
		
		# Contextual Menu
		procedure.set_sensitivity_mask(Gimp.ProcedureSensitivityMask.DRAWABLE | Gimp.ProcedureSensitivityMask.NO_DRAWABLES)
		procedure.set_image_types("*")																					# Image process (RGB, GRAY.)
		procedure.set_menu_label("Curvature Map")																# Menu name
		procedure.add_menu_path("<Image>/Deo's Tools v3.0")											# Menu path
		procedure.set_documentation("Normal map to Curvature map", "", name)    # Description
		procedure.set_attribution("Deo", "Deo's Tools", "2025")									# Author
		
		# UI Arguments
		procedure.add_boolean_argument ("arg_keeplayer_curvature", "Keep Original Layer?", None, True, GObject.ParamFlags.READWRITE)	#id, text, desc, value, flags

		return procedure

	# ACTIONS
	def deo_actions(self, procedure, run_mode, image, drawables, config, data, get_keepLayer):
		
		# Parameters
		base_layer: Gimp.Drawable = drawables[0]													

		# Layer Active
		if not base_layer.get_visible():
			Gimp.message("The selected layer Visibility is Disabled")
			return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, GLib.Error())
		else:

			image.undo_group_start()
			try:
				
				# ----------- Copy Layer -----------
				cavity_green_copy = base_layer.copy()														# Copy Base Layer	
				image.insert_layer(cavity_green_copy, None, -1)									# Insert Copied Layer on top
				cavity_green_copy.set_name("CavityGreen")												# Set Name	
				
				# ----------- CAVITY (Green) -----------
				cavity_green_layer = image.get_layer_by_name("CavityGreen")			# Select Layer by Name
				cavity_green_layer.extract_component(1, False, False)						# Extract: RGB>0,1,2, invert, linear
				gegl_emboss(cavity_green_layer, 110.0, 30.0, 1.0, True)					# Embos: Azim, Elev, Depth, VfxLayer
				gegl_invert(cavity_green_layer, True)														# Invert Layer	

				# ----------- CAVITY (Red) -----------
				cavity_red_copy = base_layer.copy()
				image.insert_layer(cavity_red_copy, None, -1)
				cavity_red_copy.set_name("CavityRed")

				cavity_red_layer = image.get_layer_by_name("CavityRed")
				cavity_red_layer.extract_component(0, False, False)
				gegl_emboss(cavity_red_layer, 180.0, 30.0, 1.0, True)

				# # ----------- BLEND + MERGE -----------
				cavity_red_layer.set_mode(Gimp.LayerMode.VIVID_LIGHT)
				image.merge_down(cavity_red_layer, Gimp.MergeType.EXPAND_AS_NECESSARY)
				
				if not get_keepLayer:
					keep_layer = image.get_layer_by_name(drawables[0].get_name())
					image.remove_layer(keep_layer)

			except Exception as e:
				Gimp.message(f"Error: {str(e)}")
				image.undo_group_end()
				return procedure.new_return_values(Gimp.PDBStatusType.EXECUTION_ERROR, GLib.Error())

			finally: 
				image.undo_group_end()																					# Undo End														
			
		# End - Success
		Gimp.message("Was Generated Successfully!")
		return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, GLib.Error())

	# # UI
	def deo_uiDialog(self, procedure, run_mode, image, drawables, config, data):
		if run_mode == Gimp.RunMode.INTERACTIVE:
			
			# Initialize Dialog
			GimpUi.init("deotool-curvature-ui") 																							
			dialog = GimpUi.ProcedureDialog.new(procedure, config, "Tool: Curvature Map")

			# UI Elements
			box = dialog.fill_box("ui_args", ["arg_keeplayer_curvature"])
			box.set_orientation(Gtk.Orientation.VERTICAL)
			box.set_halign(Gtk.Align.FILL)
			dialog.fill(["ui_args"])				
			
			# Instructions
			instructions = Gtk.Label(label=
				"\nINSTRUCTIONS:"
				"\nFrom a 'Normal Map' will let you to createa a texture: "
				"\n'Curvature Map' to use it as Mask for PBR Texturing.\n"
			)
			instructions.set_line_wrap(False)  							# Fit text to width
			instructions.set_halign(Gtk.Align.START)  			# Left Align
			box.pack_start(instructions, False, False, 5) 	# add Height padding
			instructions.show()  														# Show Label


			# Buttons (Accept, Cancel)
			if dialog.run():
				dialog.destroy()
				
				# Send Argument deo_actions
				send_keepLayer = config.get_property('arg_keeplayer_curvature')		# Argument to return and use in actions
				return self.deo_actions(procedure, run_mode, image, drawables, config, data, send_keepLayer)
			else:
				dialog.destroy()
				return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, None)

		# End - Success
		return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, None)


# --------REGISTER --------
Gimp.main(DeosToolCurvature.__gtype__, sys.argv)