#!/usr/bin/env python3
# -*- coding: utf-8 -*-

# -------- LIBRARIES --------
import gi, sys
gi.require_version('Gimp', '3.0')
from gi.repository import Gimp, GLib, GObject						# Actions
from gi.repository import GimpUi, Gtk 									# UI

# --------- METHODS ----------
def gegl_gaussianblur(layer, radius, merge):
	# Blur geGL
	blur = Gimp.DrawableFilter.new(layer, 'gegl:gaussian-blur', 'Gaussian Blur')

	# Properties
	cfg = blur.get_config()
	cfg.set_property('std-dev-x', float(radius))
	cfg.set_property('std-dev-y', float(radius))
	cfg.set_property('filter', 1)
	cfg.set_property('abyss-policy', 0)
	
	# Non Destructive Filter
	blur.update()
	layer.append_filter(blur)
	if merge:
		layer.merge_filters()
		# layer.merge_filter(blur)

# --------- PLUGIN ----------
class DeosToolUVPadding(Gimp.PlugIn):

	def do_query_procedures(self):
		return ["deotool-uvpadding"]

	def do_create_procedure(self, name):
		procedure = Gimp.ImageProcedure.new(
			self,
			name,
			Gimp.PDBProcType.PLUGIN,
			# self.deo_actions,
			self.deo_uiDialog,
			None,
		)

		# Contextual Menu
		procedure.set_sensitivity_mask(Gimp.ProcedureSensitivityMask.DRAWABLE | Gimp.ProcedureSensitivityMask.NO_DRAWABLES)
		procedure.set_image_types("*")																															
		procedure.set_menu_label("Edge UVPadding")
		procedure.add_menu_path("<Image>/Deo's Tools v3.0")
		procedure.set_documentation("Add edge padding on transparent textures", "", name)
		procedure.set_attribution("Deo", "Deo's Tools", "2025")
		
		# UI Arguments
		procedure.add_boolean_argument 	("arg_keeplayer_UVpadding", "Keep Original Layer?", None, True, GObject.ParamFlags.READWRITE)	#id, text, desc, value, flags
		procedure.add_int_argument 			("arg_edgePixel_UVpadding", "UV Padding Pixels", "Number of pixels to extend UV padding", 1, 16, 5, GObject.ParamFlags.READWRITE) # name, label, desc, min, max, value, Flags
		
		return procedure

	# ACTIONS
	def deo_actions(self, procedure, run_mode, image, drawables, config, data, get_keeplayer, get_uvpadding):
		
		# Parameters
		base_layer: Gimp.Drawable = drawables[0]	# Select Base Layer
		perPixels: int = 0												# Edge pixels start
		UI_UVPadding: int = get_uvpadding					# UI UVPadding Value from	UI to Actions
		blurPadding: float = 1.0									# Blur Radius
		
		# Layer Active
		if not base_layer.get_visible():
			Gimp.message("The selected layer Visibility is Disabled")
			return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, GLib.Error())
		else:

			image.undo_group_start()
			try:

				# ----------- Keep Layer -----------
				if get_keeplayer:
					base_layer = base_layer.copy()																			# Copy Base Layer	
					image.insert_layer(base_layer, None, -1)														# Insert Copied Layer on top
					base_layer.set_name("UVPadding")																		# Set Name	
					base_layer = image.get_layer_by_name("UVPadding")										# Select Layer by Name

				while perPixels < UI_UVPadding:
					# ----------- Borders -----------
					Gimp.Selection.none(image)																			# Clean Selection
					image.select_item(Gimp.ChannelOps.REPLACE, base_layer)							# Alpha to selection
					Gimp.Selection.sharpen(image)																				# Sharpen selection
					Gimp.Selection.border(image, 2)																			# Border selection

					# ----------- Blur -----------
					if not Gimp.Selection.is_empty(image): 
						gegl_gaussianblur(base_layer, blurPadding, True)
						Gimp.Selection.none(image)															

					# ----------- Pixels: Semi-Alpha to Opaque -----------
					base_layer.levels(4, 0.0, 0.25, True, 1.0, 0.0,1.0, True) 			# (V,R,B,G,A,L), low_in, high_in, clamp_in, Gamma, low_out, high_out, clamp_out

					# ----------- End -----------
					Gimp.displays_flush()																								# Show process	
					blurPadding += 1																										# Increase Blur
					perPixels += 1																											# Increase Pixels

				# ----
				
				Gimp.Selection.none(image)
			
			except Exception as e:
				Gimp.message(f"Error: {str(e)}")
				image.undo_group_end()
				return procedure.new_return_values(Gimp.PDBStatusType.EXECUTION_ERROR, GLib.Error())

			finally:
				image.undo_group_end()
			
		# End - Success
		Gimp.message("Was Generated Successfully!")
		return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, GLib.Error())

	# # UI
	def deo_uiDialog(self, procedure, run_mode, image, drawables, config, data):
		if run_mode == Gimp.RunMode.INTERACTIVE:
			
			# Initialize Dialog
			GimpUi.init("deotool-uvpadding-ui") 																							
			dialog = GimpUi.ProcedureDialog.new(procedure, config, "Tool: Edge UV-Padding")

			box = dialog.fill_box("ui_args", ["arg_keeplayer_UVpadding", "arg_edgePixel_UVpadding"])
			box.set_orientation (Gtk.Orientation.VERTICAL	)
			box.set_halign(Gtk.Align.FILL)			
			dialog.fill(["ui_args"])				
			
			# Instructions
			instructions = Gtk.Label(label=
				"\nINSTRUCTIONS:"
				"\n1. The texture must have an Alpha channel."
				"\n2. All texture islands should be cut out (No Background)."
				"\nThis will result in islands with a transparent background.\n"
			)
			instructions.set_line_wrap(False)  							# Fit text to width
			instructions.set_halign(Gtk.Align.START)  			# Left Align
			box.pack_start(instructions, False, False, 5) 	# add Height padding
			instructions.show()  														# Show Label


			# Buttons (Accept, Cancel)
			if dialog.run():
				dialog.destroy()
				
				send_keeplayer = config.get_property('arg_keeplayer_UVpadding')
				send_uvpadding= config.get_property('arg_edgePixel_UVpadding')
				
				return self.deo_actions(procedure, run_mode, image, drawables, config, data, send_keeplayer, send_uvpadding)
			else:
				dialog.destroy()
				
				return procedure.new_return_values(Gimp.PDBStatusType.CANCEL, None)

		# End - Success
		Gimp.message("Deo's UV-Padding Generated !")
		return procedure.new_return_values(Gimp.PDBStatusType.SUCCESS, None)

# -------- REGISTER --------
Gimp.main(DeosToolUVPadding.__gtype__, sys.argv)