// ----------------------
// DEPTH OF FIELD
// ----------------------

#version 330

#pragma region [VARS] 
	
	// Input
	in vec2 texCoords;     				// ScreenUV 

	// Output
	out vec4 finalColor;   				

	// Screen Texture
	uniform sampler2D texture0;   // Screen Color
	uniform sampler2D texture2;   // Blured
	uniform sampler2D texture3;   // Gbuffer Position
	uniform vec2 screenSize;      // ScreenPxSize

	uniform float DOFintensity;
	uniform int   DOFisDebug;
	uniform float DOFfocus;
	uniform float DOFsize;
	uniform float DOFfade;

	float dofSizeFinal = (DOFsize/10.0)+0.0025;
	float dofFadeFinal = (DOFfade+0.01);

#pragma endregion


void main()	
{
	vec2  texelSize = 1.0 / screenSize;
	vec3  sceneColor   = texture(texture0, texCoords).rgb;
	vec3  bluredColor  = texture(texture2, texCoords).rgb;
	float depthMask    = texture(texture3, texCoords).r;
	
	// Visual Debuger
	if (DOFisDebug == 1){
		float gray = dot(sceneColor, vec3(0.299, 0.587, 0.114));
		sceneColor *= vec3(1.0, 1.0, 1.0);
		bluredColor *= vec3(gray*1.5, 0.0, gray*1.5);
	}
	else if (DOFintensity > 0.0){
		finalColor = vec4( mix( sceneColor, bluredColor, pow( clamp( 1-(dofSizeFinal/abs( DOFfocus-depthMask )), 0.0, 1.0 ), dofFadeFinal ) ), 1.0);
		finalColor.rgb = mix( sceneColor, finalColor.rgb, DOFintensity);
		return;
	}
	else {
		bluredColor = sceneColor;
	}

	float dof = 1-(dofSizeFinal/abs( DOFfocus-depthMask ));
	
	finalColor = vec4( mix( sceneColor, bluredColor, pow( clamp( dof, 0.0, 1.0 ), 1/mix(5, 1, dofFadeFinal) ) ), 1.0);
	finalColor.a = 1.0;
}