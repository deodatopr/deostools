// -------------------------
// POSITION
// -------------------------

#version 330

#pragma region [VARS] 

	in vec4 fragPosView;

	out vec4 finalColor;

#pragma endregion


void main()	
{
	finalColor = vec4(fragPosView.rgb, 1.0);
}