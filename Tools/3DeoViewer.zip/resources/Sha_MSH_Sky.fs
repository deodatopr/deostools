#version 330

#pragma region [SHADER]

	// Input - Vertex Shader
	in vec3 fragPosition;
	in vec2 fragTexCoord;

	// Output - Fragment color
	out vec4 finalColor;

#pragma endregion

#pragma region [UNIFORMS]

	// INPUTS: EXTERNAL
	uniform sampler2D skyDomeMap;
	uniform bool vflipped;
	uniform bool doGamma;

	uniform mat4x4 rotMapAngle;
	uniform float envLight;
	uniform float skyDomeBlur;

#pragma endregion

#pragma region [GAMMA]

	#define GAMMA1 1.0						// 1.0  Render
	#define GAMMA  2.2						// 2.2	Monitor
	#define GAMMAi GAMMA1/GAMMA		// 0.45 BackToRGB

#pragma endregion

void main()
{
   
	// Fetch color from texture map
	vec3 color = vec3(0.0);
	float LightingMin = 0.0025;

	// Rotate 
	vec4 rotatedPosition = vec4(fragPosition, 0.0) * rotMapAngle;
	vec2 reflectDir2D = vec2( 1.0-(atan(rotatedPosition.x, rotatedPosition.z)/(2*3.141592))-0.25, acos(rotatedPosition.y)/3.141592f);		// Cylindrical Projection

	int blurMips = 9;
	color = textureLod(skyDomeMap, reflectDir2D, blurMips * skyDomeBlur).rgb;

	// Final Color
	color = pow( color, vec3(GAMMA) );
	finalColor = vec4 (color * clamp(envLight, LightingMin, 2.0	), 1.0 );
	
}