// -------------------------
// Z-DEPTH
// -------------------------

#version 330

#pragma region [VARS] 
	
	// Input
	in vec4 fragPosition;
	in vec4 fragPosView;

	// Output
	out vec4 finalColor;

#pragma endregion


void main()	
{
	// finalColor = vec4(vec3(fragPosition.z/fragPosition.w), 1.0);		//World Space
	finalColor = vec4(vec3(length(fragPosView.xyz)*0.05), 1.0);				// Screen Space	

}