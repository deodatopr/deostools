// --------------------------------
// MESH AMBIENT OCCLUSION
// --------------------------------

#version 330

#pragma region [VARS]
    // In/Out puts
    in vec2 texCoords;
    out vec4 finalColor;

    // Uniforms
    uniform sampler2D texture0;     //Screen Color
    uniform sampler2D texture2;     //Gbuffer Normals
   
    uniform float AOintensity;
    uniform float AOscale;
    
    float AOfinalScale = (AOscale+0.005);
#pragma endregion

#pragma region [FUNCS]
    vec4 GetPosition(in vec2 uv) { return texture(texture0, uv); }
   
    vec3 GetNormal(in vec2 uv)
    {   
        // Normal
        // return normalize(texture(texture2, uv).xyz); 
        
        // Viewer for Artists
        vec3 textNormal = texture(texture2, uv).xyz;
        textNormal = (textNormal / 4.0) * 5.0;
        if (textNormal == vec3(0.0, 0.0, 0.0)) { return vec3(0.0, 0.0, 1.0); }
        textNormal = textNormal * 2.0 - 1.0;
        return normalize(textNormal);

    }

    vec2 GetRandom(in vec2 uv)
    {
        float noiseX = (fract(sin(dot(uv, vec2(15.8989f, 76.132f)*1.0f))*46336.23745f)); 
        float noiseY = (fract(sin(dot(uv, vec2(11.9899f, 62.223f)*2.0f))*34748.34744f)); 
        float noiseZ = (fract(sin(dot(uv, vec2(13.3238f, 63.122f)*3.0f))*59998.47362f)); 

        return normalize(vec3(noiseX, noiseY, noiseZ)).xy;
    }

    float DoAmbientOcclusion(in vec2 tcoord,in vec2 uv, in vec3 p, in vec3 cnorm)
    {
        vec3 diff = GetPosition(tcoord + uv).xyz - p;
        vec3 v = normalize(diff);
        float d = length(diff)*AOfinalScale;
        return max(0.0f, dot(cnorm,v))*(1.0/(1.0+d))*AOintensity;
    }
#pragma endregion
    

void main() {
		
    finalColor = vec4(1,0,0,1);

    vec2 vec[4];
    vec[0] = vec2(1,0);
    vec[1] = vec2(-1,0);
    vec[2] = vec2(0,1);
    vec[3] = vec2(0,-1);

    vec4 pos = GetPosition(texCoords);

    if(pos.w != 1) { finalColor = vec4(1.0); } //Optimize

    vec3 normal = GetNormal(texCoords);
    vec2 random = GetRandom(texCoords);

    float ao = 0.0f;
    float radius = AOfinalScale/pos.z;

    int iterations = 4;
    for(int i = 0; i < iterations; ++i)
    {
        vec2 coord1 = reflect(vec[i], random)*radius;
        vec2 coord2 = vec2( coord1.x*0.707 - coord1.y*0.707, 
                            coord1.x*0.707 + coord1.y*0.707);

        ao += DoAmbientOcclusion(texCoords, coord1 * 0.25, pos.xyz, normal);
        ao += DoAmbientOcclusion(texCoords, coord2 * 0.5,  pos.xyz, normal);
        ao += DoAmbientOcclusion(texCoords, coord1 * 0.75, pos.xyz, normal);
        ao += DoAmbientOcclusion(texCoords, coord2,        pos.xyz, normal);
    }

    ao /= (iterations*4);
    finalColor.rgb = vec3(1-ao);

}