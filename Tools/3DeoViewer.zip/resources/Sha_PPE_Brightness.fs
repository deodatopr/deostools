// ---------------------
// BLOOM: BRIGHTNESS
// ---------------------

#version 330

#pragma region [VARS] 
	in vec2 texCoords;     				 // ScreenUV 
	out vec4 finalColor;   				

	uniform sampler2D texture0;    // Screen Color
	uniform float	bloomThreshold;

	float bloomThresholdFinal = 0.01+bloomThreshold * 2.0;
#pragma endregion

void main()	
{
	vec4 sceneColor = texture(texture0, texCoords);
	finalColor = vec4( max( sceneColor.rgb - vec3(bloomThresholdFinal), vec3(0.0) ), sceneColor.a);
}