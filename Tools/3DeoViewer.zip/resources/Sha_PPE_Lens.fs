// -----------------------------
// LENS: CHROMATIC/VIGNETTE
// -----------------------------

#version 330 core

#pragma region [VARS]

	// In/Out
	in vec2 texCoords;     				// ScreenUV 
	out vec4 finalColor;       

	// Screen Texture
	uniform sampler2D texture0;   // ScreenTxtr
	uniform vec2 screenSize;      // ScreenPxSize
	uniform float LensIntensity;      

	// Parameters: Chromatic
	uniform float LensCrmtPx;      
	uniform float LensCrmtAmount;

	// Parameters: Vignette
	uniform float LensVgntAmount;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
	uniform float LensVgntSize;
	uniform float LensVgntFade;

#pragma endregion

void main() {
	vec4 sceneColor = texture(texture0, texCoords);
	vec2 texelSize = 1.0 / screenSize;

	// Chromatic
	float r = texture(texture0, texCoords + vec2(texelSize * LensCrmtPx * LensCrmtAmount), 0.0).r;
	float g = sceneColor.g;
	float b = texture(texture0, texCoords + vec2(texelSize * (-LensCrmtPx) * LensCrmtAmount), 0.0).b;
	finalColor.rgb = mix (sceneColor.rgb, vec3(r, g, b), LensCrmtAmount);

	// Vignette
	float distCenter = distance(texCoords, vec2(0.5));
	float mask = smoothstep(LensVgntSize * 0.5, (LensVgntFade * 0.5) + 0.5, distCenter) * LensVgntAmount;
	
	// Final Color
	finalColor.rgb *=vec3(1.0 - mask);
	finalColor.rgb = mix(sceneColor.rgb, finalColor.rgb*vec3(1.0 - mask), LensIntensity);
	finalColor.a = sceneColor.a;								// the 1st pass in PPE

}