// -------------------------
// SHARPENNING
// -------------------------

#version 330 core

#pragma region [VARS]

  // In/Out
  in vec2 texCoords;     				// ScreenUV 
  out vec4 finalColor;   				

  // Screen Texture
  uniform sampler2D texture0;   // ScreenTxtr
  uniform vec2 screenSize;      // ScreenPxSize

  // Parameters
  uniform float sharpenPx;      
  uniform float sharpenVal;

#pragma endregion

void main() {
    
	  vec4 sceneColor = texture(texture0, texCoords);
    vec2 texelSize = 1.0 / screenSize;

    // Define Sharpen's Kernel
    float kernel[9] = float[](
        -1, -1, -1,
        -1,  9, -1,
        -1, -1, -1
    );
		
		// Pixels
    vec2 offsets[9] = vec2[](
        vec2(-sharpenPx,  sharpenPx) * texelSize, 	// Top-left
        vec2( 0.0,  sharpenPx) * texelSize, 				// Top-center
        vec2( sharpenPx,  sharpenPx) * texelSize, 	// Top-right
        vec2(-sharpenPx,  0.0) * texelSize, 				// Middle-left
        vec2( 0.0,  0.0) * texelSize, 							// Center
        vec2( sharpenPx,  0.0) * texelSize, 				// Middle-right
        vec2(-sharpenPx, -sharpenPx) * texelSize, 	// Bottom-left
        vec2( 0.0, -sharpenPx) * texelSize, 				// Bottom-center
        vec2( sharpenPx, -sharpenPx) * texelSize  	// Bottom-right
    );

    // Accumulate colors to apply to kernel
    vec3 color = vec3(0.0);
    for(int i = 0; i < 9; i++) {
        vec3 sample = texture(texture0, texCoords + offsets[i]).rgb;
        color += sample * kernel[i];
    }

		// Final Color
    color = mix(sceneColor.rgb, color, sharpenVal);
    finalColor = vec4(color, sceneColor.a);           //not the 1st pass in the PPE
}