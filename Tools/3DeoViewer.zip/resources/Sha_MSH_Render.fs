// -------------------------
// PHYSICALLY BASED RENDER
// -------------------------

#version 330

#pragma region [VARS]
	
	// Input - Vertex Shader
	in vec4 fragPosition;
	in vec3 fragPosWorld;
	in vec2 fragTexCoord;
	in vec4 fragColor;
	in vec3 fragNormal;
	in vec3 fragTangent;
	in vec3 fragBitangent;

	// Output - Fragment color 
	out vec4 finalColor;

	// INPUTS: EXTERNAL
	uniform vec3 viewPos;

	// Maps
	uniform sampler2D texture0;     		// Albedo+Alpha
	uniform sampler2D texture2;     		// Normal
	uniform sampler2D texture3;     		// O+R+M
	uniform sampler2D texture5;     		// Emission
  uniform sampler2D texture6;   			// SSAO

	// Mat Pass
	uniform int matPass;
	
	// IBL
	uniform samplerCube mapCubeIrradiance;
	uniform sampler2D mapRadiance;
	uniform sampler2D mapBRDF;
	uniform mat4x4 rotMapAngle;
	uniform float skyLight;
	
	// Material Parameters
	uniform int 	isAlbedoMap;
	uniform int 	isAlbedo2bleSided;
	uniform vec4 	tintAlbedo;
	
	uniform int 	isTransmIOR;
	uniform float transmIOR;

	uniform int 	alphaTypeOf;
	uniform float alphaMask;
	uniform float alphaBlend;

	uniform int 	isNormalMap;
	uniform float normalMapIntensity;
	uniform int   normalInvertDirection;

	uniform float occlusionIntensity;
	uniform int 	isRoughnessMap;
	uniform float roughnessIntensity;
	uniform int 	isMetallicMap;
	uniform float metallicIntensity;

	uniform int 	isEmissionMap;
	uniform float emissionIntensity;
	uniform vec4  emissionTint;

	// Light Parameters
	uniform vec4  lightingColor;
	uniform float lightingRotate;
	uniform float lightingTilt;
	uniform float sunLight;

	uniform vec2 screenSize;

#pragma endregion

#pragma region [GAMMA]

	#define GAMMA1 1.0						// 1.0  Render
	#define GAMMA  2.2						// 2.2	Monitor
	#define GAMMAi GAMMA1/GAMMA		// 0.45 BackToRGB

#pragma endregion

#pragma region [FUNC: COOK TORRANCE]

	// Fresnel 
	vec3 SchlickFresnel(vec3 f0, float cosTheta, float bias, float scale, float roughness) {
		vec3 f = ( bias + scale * f0 + (1.0 - f0) * (pow(1.0-cosTheta, 5.0)) ) ;
		float energyFactor = 1.0 / (1.0 + roughness*roughness);
		f *= energyFactor;
		return f;
	}

	// 2 Axis
	float smithGGX (float NdotL, float NdotV, float roughness) {
		float k = pow ( (roughness + 1.0), 2.0 ) * 0.125;
		float ik = 1.0 - k;
		float ggx1 = NdotV / (NdotV * (ik) + k);
		float ggx2 = NdotL / (NdotL * (ik) + k);
		return (ggx1 * ggx2);
	}

	// Light Distribution
	float distributionGGX(vec3 N, vec3 H, float roughness) {
		float a     = roughness*roughness;
		float a2    = a*a;
		float NdH   = dot(N,H);
		float NdH2  = NdH*NdH;
		float nom   = a2;
		float denom = NdH2*(a2-1.0) + 1.0;
		denom = 3.1415926 * denom * denom;
		float multiScatterFactor = 1.0 + a;
		return nom / denom * multiScatterFactor;
	}

#pragma endregion

#pragma region [FUNC: TRANSMISION]
	
	vec3 Refract(vec3 I, vec3 N, float eta)
	{
			float cosI = dot(-I, N);
			float sinT2 = eta * eta * (1.0 - cosI * cosI);
			if (sinT2 > 1.0)
			{
					return vec3(0, 0, 0);
			}
			float cosT = sqrt(1.0 - sinT2);
			return eta * I + (eta * cosI - cosT) * N;
	}
	
	vec3 Transmission(float NdotV, vec3 F0, vec3 albedo, float roughness, float transmission, float ior)
	{
			//Coeficiente de Fresnel para el índice de refracción
			float cosTheta = NdotV;
			float eta = 1.0 / ior; //Asumiendo aire como n1 = 1.0
			float sinThetaT = eta * sqrt(max(0.0, 1.0 - cosTheta * cosTheta));
			
			//Revisa la posibilidad de reflexión total interna
			if (sinThetaT >= 1.0)
			{
					return vec3(0.0, 0.0, 0.0); //Reflexión total interna
			}

			float cosThetaT = sqrt(max(0.0, 1.0 - sinThetaT * sinThetaT));
			
			//Fresnel Schlick para reflejo y transmisión
			vec3 fresnelReflectance = SchlickFresnel(F0, cosTheta, 0.0, 1.0, roughness);
			vec3 reflectance = transmission * fresnelReflectance; //Fracción reflejada

			//La transmitancia es el resto de la luz
			vec3 transmittance = vec3(1.0) - reflectance;

			return transmittance * albedo;
	}

#pragma endregion

void main()	
{

	#pragma region [TEXELS]
		
		vec4 texelFinal;
		
		vec4 texelColor 	  = texture( texture0, fragTexCoord ) * tintAlbedo; 
		vec4 texelNormal    = texture( texture2, fragTexCoord );
		vec4 texelORM		    = texture( texture3, fragTexCoord );
		vec4 texelOcclusion = vec4(vec3(texelORM.r), 1.0);							
		vec4 texelRough     = max( vec4(vec3(texelORM.g), 1.0), vec4(0.106) );
		vec4 texelMetal     = max( vec4(vec3(texelORM.b), 1.0), vec4(0.0)   );		

		vec4 texelEmission = texture( texture5, fragTexCoord );

	# pragma endregion

	#pragma region [PARAMETERS]

		// Albedo ----------------------------------------------
		if (isAlbedoMap == 0 && matPass != 2){
			texelColor.rgb = tintAlbedo.rgb;
		}

		// Alpha ----------------------------------------------	 
		float texelAlphaFinal;

		if (alphaTypeOf == 0 && matPass != 8)					//None
		{				
			texelAlphaFinal = 1.0;
		}
		else if (alphaTypeOf == 1 && matPass != 8)		//Mask
		{		
			texelAlphaFinal = texelColor.a;
			if (texelAlphaFinal <= alphaMask) discard;
			texelAlphaFinal = 1.0;
		}
		else if (alphaTypeOf == 2 && matPass != 8)		//Blend+(A)
		{		
			texelAlphaFinal = texelColor.a;
			if (texelAlphaFinal < 0.01) discard;
				if(texelAlphaFinal < 0.99 && isTransmIOR == 1)
				{
					// Dithering
					vec2 resolution = screenSize;
					vec2 pixelUV = (fragPosition.xy/fragPosition.w)* 0.5 + 0.5;
					vec2 pixelCoord = pixelUV * resolution;
					int pixelIndex = int(pixelCoord.x) + int(pixelCoord.y) ;
					if (pixelIndex % 3 == 0) discard;
					texelAlphaFinal = texelColor.a;
				}
		}
		else if (alphaTypeOf == 3 && matPass != 8)		//Blend
		{		
			texelAlphaFinal = alphaBlend;
			if (texelAlphaFinal < 0.01) discard;
				if(texelAlphaFinal < 0.99 && isTransmIOR == 1)
				{
					// Dithering
					vec2 resolution = screenSize;
					vec2 pixelUV = (fragPosition.xy/fragPosition.w)* 0.5 + 0.5;
					vec2 pixelCoord = pixelUV * resolution;
					int pixelIndex = int(pixelCoord.x) + int(pixelCoord.y) ;
					if (pixelIndex % 3 == 0 && int(pixelCoord.x) % 2 == 0) discard;
					texelAlphaFinal = alphaBlend;
				}
		}

		// Normal ----------------------------------------------
		if (isNormalMap == 0 && matPass != 3){
			texelNormal.rgb = vec3(0.5, 0.5, 1.0);
		}
		texelNormal.rgb = mix ( vec3(0.5, 0.5, 1.0), texelNormal.rgb, normalMapIntensity);

		// ORM  ----------------------------------------------
		if (alphaTypeOf == 2 &&  alphaBlend < 1.0) {
			texelOcclusion = vec4(1);
		}else {
			texelOcclusion = vec4(1-( (1.0 - texelOcclusion.rgb) * mix(1.0, 2.0, occlusionIntensity) ), 1.0);
		}

		if (isRoughnessMap == 0 && matPass != 4){
			texelRough = vec4(clamp(roughnessIntensity, 0.04, 1.0));
		}
		if (isMetallicMap == 0 && matPass != 5){
			texelMetal = vec4(metallicIntensity);
		}
		
		// Emission ----------------------------------------------  
		if (isEmissionMap == 1 && matPass != 7){
			texelEmission.rgb *= vec3(mix(0.0, 10.0, emissionIntensity));
		}
		else if (isEmissionMap == 0){																		
			texelEmission.rgb = emissionTint.rgb;
		}
		texelEmission.rgb *= emissionTint.rgb;

		// Gammas ----------------------------------------------
		vec4 texelColorG    = pow( texelColor, vec4(GAMMA) );
		vec4 texelRoughGi   = pow( texelRough, vec4(GAMMAi) );
		vec4 texelEmissionG = pow( texelEmission, vec4(GAMMAi) );

	#pragma endregion

	#pragma region [NORMALS]

		if (normalInvertDirection == 1){
			texelNormal.g = 1-texelNormal.g;
		}
		vec3 normal = texelNormal.rgb * 2.0 - 1.0;
		mat3 TBN  = transpose ( mat3( fragTangent, fragBitangent, fragNormal ) ); 
		normal    = normalize( normal * TBN );

		vec3 viewDir = normalize(viewPos - fragPosWorld);
		float VdotN = dot( viewDir, normal );
		normal = (VdotN < 0.0) ? -normal : normal;

	#pragma endregion

	#pragma region [LIGHT]
		
		// Rotations: Sphere Position
		float lightAngle = atan(1.0, 1.0);
		lightAngle -= lightingRotate * 3.141592 / 180.0; 				// Rotate: Angle in Rad
		float lightTiltRad = lightingTilt * 3.141592 / 180.0;		// Tilting: Angle in Rad
		vec3 lightPos = vec3( -cos(lightAngle)*0.5, sin(lightTiltRad), -sin(lightAngle)+0.5 );	
		vec3 lightDir = normalize( rotMapAngle * vec4(lightPos, 0.0) ).xyz;
		float NdotL   = max( dot(normal, lightDir), 0.0 );
	
	#pragma endregion

	#pragma region [SPECULAR]

		// SCPULAR: Blinn Phong (Aproximation)
		// float NdotH  = max( dot( normal, normalize(lightDir + viewDir) ), 0.0 );      	// Half: Luz y vista
		// float specular = pow( NdotH, 50.0 );

		float NdotV  = max( dot( normal, viewDir), 0.0 );                            		// Contra la Vista
		float HdotV  = max( dot( viewDir, normalize( lightDir + viewDir ) ), 0.0 );     // Half: Contra vista
		
		// #Note: Index of Reflection (NoMetal:0.03, Metal:0.05 = Prom:0.04)
		float refletance = pow (transmIOR-1, 2) / pow (transmIOR+1, 2);
		
		// Diffuse without metallic >> IBL
		vec3 D0 = (texelColorG.rgb * vec3(1.0 - refletance) ) * vec3(1.0 - texelMetal.r);
		
		// Diffuse with metallics
		vec3 F0 = mix( vec3(refletance), texelColorG.rgb, texelMetal.rgb );

		// Specular Color (SPECULAR: Cook Torrance (Accurate))
		vec3 specularColor = SchlickFresnel( F0, HdotV, 0.0, 1.0, texelRough.r);

		vec3 specular = ( specularColor * smithGGX(NdotL, NdotV, texelRough.r*texelRough.r) * 
											distributionGGX(normal, normalize(lightDir + viewDir), texelRough.r) ) / 
											max( 0.000001, NdotV * NdotL * 4.0 );

	#pragma endregion

	#pragma region [IBL + BRDF]
		
		// LIGHT CONTRIBUTION -----------------
		vec4 irradianceRot = vec4( normal, 0.0 ) * rotMapAngle;
		vec3 irradianceIBL = smoothstep(-0.1, 0.9, pow( texture(mapCubeIrradiance, irradianceRot.xyz).rgb, vec3(GAMMA))) ; 
	
		// REFLECTIONS ------------------------
		
		// Cylindrical Projection
		vec3 reflectDir   = normalize( reflect(-viewDir, normal) );
		vec4 radianceRot  = vec4( reflectDir, 0.0 ) * rotMapAngle;
		vec2 reflectCilindrical = vec2( ( atan(radianceRot.x, radianceRot.z)/(2*3.141592) )+0.5, acos(radianceRot.y)/3.141592f );		
		
		// LODs
		float radianceLod = 11; //2048 > 1024 > 512 > 256 > 128 > 64 > 32 > 16 > 8 > 4 > 2 > 1 = 11 Lods
		float roughCorrection = smoothstep(-0.5, 1.0, texelRough.r);
		vec3 radianceIBL  = pow( textureLod(mapRadiance, reflectCilindrical, (roughCorrection * radianceLod)).rgb, vec3(GAMMA) );
		
		vec3 radianceIBLMatview = radianceIBL;
		vec3 metalSimHDRMult = pow(vec3(10.0), vec3(log(GAMMA))-vec3(GAMMAi));
		radianceIBL *= metalSimHDRMult*specularColor*10.0;
		

		// Diffuse Light
		vec3 diffuseLight = irradianceIBL ;
		
		// Diffuse Color
		// vec3 diffuseColor = (1.0f - specularColor) * (1.0f - texelMetal.r) * texelColorG.rgb;  // With Metallic
		vec3 diffuseColor = (1.0f - specularColor) * D0;  																				// Without Metallic IOR
		
		// Specular Light
		vec3 specularLight = radianceIBL;

		// specularColor >> is above in SPECULAR
		
		// Light Distribution (BRDF)
		vec2 brdf = texture( mapBRDF, vec2(NdotV, 1.0-texelRough.r) ).xy;
		vec3 reflectionBRDF = specularLight * (F0 * brdf.x + brdf.y);
		vec3 ambientLight = diffuseColor * (diffuseLight*metalSimHDRMult) + reflectionBRDF;

	#pragma endregion

	#pragma region [FINAL COLOR]
		
		//SSAO TO SCREEN UV RECT (Out)
		vec2 screenCoord = (fragPosition.xy / fragPosition.w) * 0.5 + 0.5;	
		vec3 finalOcclision = texture(texture6, screenCoord).rgb * ( pow(texelOcclusion.rgb, vec3(GAMMA)) );		
			
		// FULL MATERIAL
		if (matPass == 1){

			// SPECULAR: Blinn Phong
			// finalColor = vec4( (texelColorG.rgb + (texelMetal.rgb*specular) * texelOcclusion.r) * NdotL, 1.0);

			// IOREFLECTION 
			vec3 transmisionColor = Transmission (NdotV, F0, texelColorG.rgb, texelRough.r, transmIOR, 1.5);

			// RENDER
			float LightingMin = 0.0025;
			finalColor = vec4(
				(diffuseColor + specular + transmisionColor)											// Direct Light 
				* (NdotL * lightingColor * sunLight).rgb													// Sun Light
				+ (ambientLight * (clamp(skyLight, LightingMin, skyLight)) ),			// Env Light
				texelAlphaFinal																										// Alpha
			);
			
			// SSAO
			finalColor.rgb *= finalOcclision;
			
			// EMISSION
			finalColor.rgb += (texelEmissionG.rgb);

			// TRANSMISSION
			if (isTransmIOR == 1){
				
				// SkyDome into Cylindrical Projection	
				vec3 refractedDir = Refract (-viewDir, normal, 1.0/transmIOR);
				vec3 refractedRot = (vec4(refractedDir, 0.0) * rotMapAngle).xyz;
				vec2 refractedDirPan = vec2( (atan(refractedRot.z, refractedRot.x)/(2*3.141592) )+0.5, acos(refractedRot.y)/3.141592f );	
				
				// Final Color
				vec3 transmGlass = pow( texture(mapRadiance, refractedDirPan).rgb, vec3(GAMMA) ) * (texelColorG.rgb * tintAlbedo.rgb);
				finalColor.rgb = transmGlass * ( vec3(skyLight + LightingMin) + (sunLight * specular) ) *5;
			}
			
			return;
		}	

		// MAP PASSES
		else if (matPass == 2) { finalColor = vec4( texelColor );    						 } 
		else if (matPass == 3) { finalColor = vec4( texelNormal );   						 }
		else if (matPass == 4) { finalColor = vec4( texelRough );	   						 } 
		else if (matPass == 5) { finalColor = vec4( texelMetal );    						 }
		else if (matPass == 6) { finalColor = vec4( finalOcclision, 1.0 );			 }
		else if (matPass == 7) { finalColor = vec4( texelEmission ); 						 }
		else if (matPass == 8) { finalColor = vec4( vec3(texelColor.a), 1.0f );	 }

		// MAT PASSES
		else if (matPass == 9)  { finalColor = vec4( vec3( texelRough.r * skyLight ) * pow(radianceIBLMatview, vec3(GAMMAi)), 1.0);	 } // Roughness
		else if (matPass == 10) { finalColor = vec4( vec3( texelMetal.r * skyLight ) * pow(radianceIBLMatview, vec3(GAMMAi)), 1.0);	 } // Metallic

		// WIREFRAME
		else if (matPass == 11) { finalColor = vec4( texelColor );	}																												// None
		else if (matPass == 12) { finalColor = vec4( smoothstep(-0.5, 1.0, vec3(irradianceIBL*(skyLight*0.5))), 1.0 ); 		}	// Gray Mode Color
		else if (matPass == 13) { finalColor = vec4( vec3(NdotL), 1.0 );	}																									// Gray Mode Line
	
	#pragma endregion

	finalColor.rgb = pow(finalColor.rgb, vec3(GAMMA));
	
}