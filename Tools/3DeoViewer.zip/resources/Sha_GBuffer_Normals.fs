// -------------------------
// NORMALS
// -------------------------

#version 330

#pragma region [VARS] 
	
	// Input
	in vec3 fragPosWorld;
	in vec2 fragTexCoord;
	in vec3 fragNormal;
	in vec3 fragTangent;
	in vec3 fragBitangent;
	
	// Output
	out vec4 finalColor;
	
	// Uniforms
	uniform sampler2D texture2;     		// NormalMap
	uniform vec3 viewPos;

	uniform float normalMapIntensity;
	uniform int   normalInvertDirection;
	uniform mat4 matView;


#pragma endregion


void main()	
{
	
	vec4 texelNormal = texture( texture2, fragTexCoord );
	vec3 normal = texelNormal.rgb * 2.0 - 1.0;

	if (normalInvertDirection == 1){
		texelNormal.g = 1-texelNormal.g;
	}
	texelNormal.rgb = mix ( vec3(0.5, 0.5, 1.0), texelNormal.rgb, normalMapIntensity);

	vec3 normalView    = normalize( matView * vec4(fragNormal, 0.0) ).xyz;
	vec3 tangentView   = normalize( matView * vec4(fragTangent, 0.0) ).xyz;
	vec3 bitangentView = normalize( matView * vec4(fragBitangent, 0.0) ).xyz;

	// mat3 TBN  = transpose ( mat3( fragTangent, fragBitangent, fragNormal ) ); 		// World Space 
	// vec3 viewDir = normalize(viewPos - fragPosWorld);														// World Space
	mat3 TBN  = transpose ( mat3( tangentView, bitangentView, normalView ) ); 			// Screen Space
	vec3 viewDir = vec3( 0.0, 0.0, 1.0 );																						// Screen Space										

	normal = normalize( normal * TBN );
	float VdotN = dot( viewDir, normal );
	normal = (VdotN < -0.5) ? -normal : normal;
	
	// Normal
	// finalColor = vec4(normal, 1.0); return;

	// Viewer for Artists
	vec3 normalBeauty = (normal+vec3(1.0)*vec3(0.5))*vec3(0.8);	
	finalColor = vec4(normalBeauty, 1.0);

}