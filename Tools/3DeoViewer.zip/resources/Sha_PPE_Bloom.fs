// ---------
// BLOOM
// ---------

#version 330 core

#pragma region [VARS]
	in vec2 texCoords;     				// ScreenUVCoord
	out vec4 finalColor;       

	uniform sampler2D texture0;   		// SceneColor
	uniform sampler2D texture2;   		// SceneBlurred
	uniform sampler2D textureMask;   // SceneBlurred
	uniform float bloomIntensity;
	uniform float bloomRadius;
#pragma endregion


void main() {

	vec4 sceneColor = texture(texture0, texCoords);
	vec4 blurring 	= textureLod(texture2, texCoords, mix(1.5, 3.0, bloomRadius)); //LOD
	vec3 mask 			= texture(textureMask, texCoords).rgb;

	if ( blurring.a <= -0.01) {
		finalColor = vec4(sceneColor.rgb, 0.0);
		return;
	}
	
	finalColor = vec4(sceneColor.rgb + (blurring.rgb * vec3(bloomIntensity)), sceneColor.a);

}
