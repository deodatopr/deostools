// -------------------------
// BLUR GAUSSIAN VERTICAL
// -------------------------

#version 330

#pragma region [VARS] 
	
	in vec2 texCoords;     				// ScreenUV 
  out vec4 finalColor;   				

  uniform sampler2D texture0;   // ScreenTxtr
  uniform vec2 screenSize;      // ScreenPxSize
	uniform float offsetPxDist;

#pragma endregion

void main()	
{

	vec2 texelSize = 1.0 / screenSize;
	float dist0 = (screenSize.y/screenSize.x)*offsetPxDist;

	vec2 OFFSETS[9] = vec2[9]
	( vec2(0, -4-dist0), vec2(0, -3-dist0), vec2(0, -2-dist0),
		vec2(0, -1-dist0), vec2(0,  0+dist0), vec2(0,  1+dist0),
		vec2(0,  2+dist0), vec2(0,  3+dist0), vec2(0,  4+dist0)
	);
	
	float g_BlurWeights[9] = float[9]
	(
		0.004815026f, 0.028716039f, 0.102818575f,
		0.221024189f, 0.28525234f, 0.221024189f,
		0.102818575f, 0.028716039f, 0.004815026f
	);

	vec4 outColor;
	outColor =  texture(texture0, texCoords.xy + OFFSETS[0] * texelSize) * g_BlurWeights[0];
	outColor += texture(texture0, texCoords.xy + OFFSETS[1] * texelSize) * g_BlurWeights[1];
	outColor += texture(texture0, texCoords.xy + OFFSETS[2] * texelSize) * g_BlurWeights[2];
	outColor += texture(texture0, texCoords.xy + OFFSETS[3] * texelSize) * g_BlurWeights[3];
	outColor += texture(texture0, texCoords.xy + OFFSETS[4] * texelSize) * g_BlurWeights[4];
	outColor += texture(texture0, texCoords.xy + OFFSETS[5] * texelSize) * g_BlurWeights[5];
	outColor += texture(texture0, texCoords.xy + OFFSETS[6] * texelSize) * g_BlurWeights[6];
	outColor += texture(texture0, texCoords.xy + OFFSETS[7] * texelSize) * g_BlurWeights[7];
	outColor += texture(texture0, texCoords.xy + OFFSETS[8] * texelSize) * g_BlurWeights[8];
	
	finalColor = outColor;
}