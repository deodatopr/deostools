// -------------------
// COLOR CORRECTION
// -------------------

#version 330

#pragma region [VARS]
  
  in vec2 texCoords;     				// ScreenUV 
  out vec4 finalColor;   				

  uniform sampler2D texture0;   // ScreenTxtr
  // uniform sampler2D texture2;   // SSAO

  // Color Correction
  uniform float colorBrightness;
  uniform float colorContrast;
  uniform float colorSaturation;

  uniform float colorCurveShadows;
  uniform float colorCurveHighlights; 

  // Tonemapping
  uniform int selectedTonemap;
	
	// PPE
  uniform int isPPE;

#pragma endregion

#pragma region [GAMMA]

	#define GAMMA1 1.0						// 1.0  Render
	#define GAMMA  2.2						// 2.2	Monitor
	#define GAMMAi GAMMA1/GAMMA		// 0.45 BackToRGB

#pragma endregion

#pragma region [FUNC TONEMAPPINGS]
	
	// KHRONOS     ------------------------------------------------------
	vec3 PBRNeutralToneMap( vec3 color ) {
		const float startCompression = 0.8 - 0.04;
		const float desaturation = 0.15;

		float x = min(color.r, min(color.g, color.b));
		float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
		color -= offset;

		float peak = max(color.r, max(color.g, color.b));
		if (peak < startCompression) return color;

		const float d = 1. - startCompression;
		float newPeak = 1. - d * d / (peak + d - startCompression);
		color *= newPeak / peak;

		float g = 1. - 1. / (desaturation * (peak - newPeak) + 1.);
		return mix(color, newPeak * vec3(1, 1, 1), g);
	}

	// AGX TONEMAPPING --------------------------------------------------
	vec3 agxDefaultContrastApprox(vec3 x) {
		vec3 x2 = x * x;
		vec3 x4 = x2 * x2;
		
		return + 15.5  * x4 * x2
					- 40.14  * x4 * x
					+ 31.96  * x4
					- 6.868  * x2 * x
					+ 0.4298 * x2
					+ 0.1191 * x
					- 0.00232;
	}
	vec3 agx(vec3 val) {
		const mat3 agx_mat = mat3(
			0.842479062253094,  0.0423282422610123, 0.0423756549057051,
			0.0784335999999992, 0.878468636469772,  0.0784336,
			0.0792237451477643, 0.0791661274605434, 0.879142973793104);
			
		const float min_ev = log2 (pow(2, -10)*0.18);
    const float max_ev = log2 (pow(2, 7.0)*0.18);

		// Input transform (inset)
		val = agx_mat * val;
		
		// Log2 space encoding
		val = clamp(log2(val), min_ev, max_ev);
		val = (val - min_ev) / (max_ev - min_ev);
		
		// Apply sigmoid function approximation
		val = agxDefaultContrastApprox(val);
		val = clamp(val, 0.0, 1.0);	
		return val;
	}
	vec3 agxEotf(vec3 val) {
		const mat3 agx_mat_inv = mat3(
			1.19687900512017, -0.0528968517574562, -0.0529716355144438,
			-0.0980208811401368, 1.15190312990417, -0.0980434501171241,
			-0.0990297440797205, -0.0989611768448433, 1.15107367264116);
			
		// Inverse input transform (outset)
		val = agx_mat_inv * val;
		val = pow(val, vec3(GAMMA));
		return val;
	}
	vec3 agxLook(vec3 val, int AGX_LOOK) {
		const vec3 lw = vec3(0.2126, 0.7152, 0.0722);
		float luma = dot(val, lw);
		
		// Default
		vec3 offset = vec3(0.02);
		vec3 slope  = vec3(1.15);
		vec3 power  = vec3(1.15);
		float sat = 1.15;
	
		if (AGX_LOOK == 1){
			// Punchy
			slope = vec3(1.0);
			power = vec3(1.2);
			sat = 1.15;
		}
		// ASC CDL
		val = pow(val * slope + offset, power);
		return luma + sat * (val - luma);
	}
	vec3 AGX_BaseToneMapping(vec3 val) {
		val = agx(val);
		val = agxLook(val, 0);
		return agxEotf(val);
	}
	vec3 AGX_PunchyToneMapping(vec3 val) {
		val = agx(val);
		val = agxLook(val, 1);
		return agxEotf(val);
	}

	// ACES-FILM TONEMAPPING --------------------------------------------------
	vec3 ACESFilm(vec3 color) {
		const float a = 2.51;
		const float b = 0.03;
		const float c = 2.43;
		const float d = 0.59;
		const float e = 0.14;
		
		color = clamp((color * (a * color + b)) / (color * (c * color + d) + e), 0.0, 1.0);
		return color;
	}

	// REINHARD  --------------------------------------------------
	vec3 ReinhardJodieTonemap(vec3 color)	{
		float l = dot(color, vec3(0.2126, 0.7152, 0.0722));
		vec3 tv = color / (vec3(1.0f) + color);
		return mix(color / vec3(1.0f + l), tv, tv);
	}

#pragma endregion


void main() {

	vec4 sceneColor = texture(texture0, texCoords);
	finalColor = sceneColor;
	
	// PPE OFF
	if (isPPE == 0){
		finalColor.rgb = vec3 ( pow(finalColor.rgb, vec3(GAMMAi)) );		// Tonemapping Base
		return;
	}

	// TONEMAPPING ------------------

	// Standard Tonemapping (sRGB)
	if (selectedTonemap == 0 ){
		finalColor.rgb = vec3 ( pow(finalColor.rgb, vec3(GAMMAi)) );
	}
	// Khronos PBR Neutral Tonemapping
	else if (selectedTonemap == 1){		
		finalColor.rgb = PBRNeutralToneMap (finalColor.rgb);
		finalColor.rgb = vec3 ( pow(finalColor.rgb, vec3(GAMMAi)) );
	}
	// AGX Tonemapping
	else if (selectedTonemap == 2){		
		finalColor.rgb = AGX_BaseToneMapping (finalColor.rgb);
		finalColor.rgb = vec3 ( pow(finalColor.rgb, vec3(GAMMAi)) );
	}
	// ACES Tonemapping
	else if (selectedTonemap == 3){		
		finalColor.rgb = ACESFilm(finalColor.rgb);
		finalColor.rgb = vec3 ( pow(finalColor.rgb, vec3(GAMMAi)) );
	}
	// Reinhard Tonemapping
	else if (selectedTonemap == 4){		
		finalColor.rgb = ReinhardJodieTonemap (finalColor.rgb);
		finalColor.rgb = vec3 ( pow(finalColor.rgb, vec3(GAMMAi)) );
	}

	// COLOR CORRECTIONS -----------

	// Brightness
	finalColor.rgb += clamp(colorBrightness,-1.0,1.0) * 0.25;

	// Contrast
	finalColor.rgb = (finalColor.rgb - 0.5) * (colorContrast+1.0) + 0.5;

	// Saturation
	float luminance = dot(finalColor.rgb, vec3(0.299, 0.587, 0.114));
	finalColor.rgb =  vec3(mix(vec3(luminance), finalColor.rgb, colorSaturation));

	// Curve (Levels)
	vec3 shadows =    mix(finalColor.rgb * pow(finalColor.rgb, vec3(colorCurveShadows)), finalColor.rgb, smoothstep(0.0, 0.5, finalColor.rgb));
	vec3 highlights = mix(pow(finalColor.rgb, vec3(colorCurveHighlights)), finalColor.rgb, smoothstep(0.5, 1.0, finalColor.rgb));
	vec3 midtones =   mix(shadows, highlights, smoothstep(0.25, 0.75, finalColor.rgb));
	
	// FINAL COLOR -----------
	finalColor.rgb = vec3(clamp(midtones, 0.0, 1.0));

}