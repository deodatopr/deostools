# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
import os
import bpy.utils.previews


class DATA_PT_PSD_Layers_UI(bpy.types.Panel):
    bl_label = "PSD Layers"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PSD Layers"

    def draw(self, context):
        ob = context.active_object

        if ob and ob.type != 'MESH':
            layout = self.layout.box()
            row = layout.row()
            row.label(text="Select Mesh Object!", icon="ERROR")


class DATA_PT_PSD_Palette(bpy.types.Panel):
    bl_label = "Palettes"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PSD Layers"
    bl_parent_id = "DATA_PT_PSD_Layers_UI"

    def draw(self, context):
        ob = context.active_object

        if ob and ob.type == 'MESH':
            tool_settings = context.tool_settings.image_paint
            layout = self.layout.box()
            col = layout.column()
            col.template_ID(tool_settings, "palette", new="palette.new")

            # color to add
            brush = context.tool_settings.image_paint.brush
            if not brush:
                col.label(text="Switch to Texture Paint Mode", icon='ERROR')
            else:
                if context.tool_settings.image_paint.palette:
                    if brush.color_type == 'COLOR':
                        row = col.row(align=True)
                        row.scale_y = 1.5
                        row.operator("scene.paste_hex_colors", icon='PASTEDOWN')
                        row.prop(brush, property="color", text="")
            if tool_settings.palette:
                col.template_palette(tool_settings, "palette", color=True)


class DATA_PT_PSD_Materials(bpy.types.Panel):
    bl_label = "Shaders"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PSD Layers"
    bl_parent_id = "DATA_PT_PSD_Layers_UI"

    def draw(self, context):
        ob = context.active_object

        if ob and ob.type == 'MESH':
            layout = self.layout.box()
            row = layout.row()
            row.template_list("MATERIAL_UL_matslots", "", ob, "material_slots", ob, "active_material_index", rows=5)
            is_sortable = len(ob.material_slots) > 1
            col = row.column(align=True)
            col.operator("object.material_slot_add", icon='ADD', text="")
            col.operator("object.material_slot_remove", icon='REMOVE', text="")
            col.separator()
            col.menu("MATERIAL_MT_context_menu", icon='DOWNARROW_HLT', text="")
            if is_sortable:
                col.separator()
                col.operator("object.material_slot_move", icon='TRIA_UP', text="").direction = 'UP'
                col.operator("object.material_slot_move", icon='TRIA_DOWN', text="").direction = 'DOWN'
            row = layout.row()
            row.template_ID(ob, "active_material", new="material.new")

            if ob.mode == 'EDIT':
                row = layout.row(align=True)
                row.enabled = False
                row.enabled = True
                row.operator("object.material_slot_assign", text="Assign")
                row.operator("object.material_slot_select", text="Select")
                row.operator("object.material_slot_deselect", text="Deselect")

            if material := ob.active_material:
                principled_BSDF = None
                for node in material.node_tree.nodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        principled_BSDF = node
                        break

                if principled_BSDF:
                    if material.psd_layers_layers:
                        row = layout.row()
                        row.prop(material.psd_layers_data, property='shading', text='')
                        row.prop(material.psd_layers_data, property='transparent', text='Transparent')

            elif not ob.material_slots:
                layout = self.layout.box()
                row = layout.row()
                row.box().label(text="Add Material Slot!", icon="ERROR")
            else:
                layout = self.layout.box()
                row = layout.row()
                row.box().label(text="Select Material!", icon="ERROR")

class DATA_PT_PSD_Layers(bpy.types.Panel):
    bl_label = "Layers"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "PSD Layers"
    bl_parent_id = "DATA_PT_PSD_Layers_UI"

    def draw(self, context):
        pcoll = PSD_Layers_preview_collections["main"]
        new_layer = pcoll["new_layer"]
        duplicate_layer = pcoll["duplicate_layer"]
        trash = pcoll["trash"]
        brush = pcoll["brush"]

        ob = context.active_object

        if ob and ob.type == 'MESH':
            if material := ob.active_material:
                layout = self.layout.box().column()

                row = layout.row(align=True)
                row.scale_y = 1.5
                row.scale_x = 1.5
                material = context.active_object.active_material
                row = layout.row(align=True)
                row.scale_y = 1.5
                row.scale_x = 1.5
                row.operator("material.psd_layers_add_layer", text='', icon_value=new_layer.icon_id)

                layers = material.psd_layers_layers
                activeLayer = None
                if layers:
                    for layer in layers:
                        if layer.active:
                            activeLayer = layer
                            break

                if layers:
                    row3 = layout.row(align=True)
                    row3.scale_y = 1.5
                    col3 = layout.column(align=True)
                    col3.scale_y = 1.5

                    row.prop(activeLayer, property='name', text='')
                    row2 = row.row(align=True)
                    row2.operator("material.psd_layers_duplicate", text='', icon_value=duplicate_layer.icon_id)
                    row2.operator("material.psd_layers_delete_layer", text='', icon_value=trash.icon_id)
                    row2.operator("material.psd_layers_up", text='', icon='TRIA_UP')
                    row2.operator("material.psd_layers_down", text='', icon='TRIA_DOWN')

                    row3.prop(activeLayer, property='blendMode', text='')
                    row3.prop(activeLayer, property='opacity', text='')

                    if activeLayer:
                        col3.template_ID_preview(layer, property="image", hide_buttons=True, rows=5, cols=8)

                        if not activeLayer.image:
                            col3.label(text="")
                    else:
                        for i in range(0, 7):
                            col3.label(text="")

                    for i in reversed(range(0, len(layers))):
                        layer = None
                        for layer in layers:
                            if layer.index == i:
                                layer = layer
                                break

                        box = layout.row()
                        rowbase = box.row(align=True)
                        rowbase.scale_y = 1.5
                        rowbase.scale_x = 1.5
                        row = rowbase.row(align=True)
                        row2 = rowbase.row(align=True)

                        active_icon = 'RADIOBUT_OFF'
                        hide_icon = 'HIDE_OFF'
                        lock_icon = 'UNLOCKED'

                        if layer.active:
                            active_icon = 'RADIOBUT_ON'

                        if layer.hide:
                            hide_icon = 'HIDE_ON'

                        if layer.lock:
                            lock_icon = 'LOCKED'
                            row.enabled = False
                            row2.enabled = False

                        if layer.active and layer.nodeGroupTree:
                            image = None
                            for node in layer.nodeGroupTree.nodes:
                                if node.name.startswith("IMAGE_"):
                                    image = node.image
                                    break
                            if image:
                                if context.tool_settings.image_paint.canvas and context.tool_settings.image_paint.canvas.name == image.name:
                                    row.label(text='', icon_value=brush.icon_id)
                                else:
                                    row.label(text='', icon='BLANK1')
                            else:
                                row.label(text='', icon='BLANK1')

                        else:
                            row.label(text='', icon='BLANK1')

                        row.prop(layer, property='active', icon=active_icon, text='', emboss=False)
                        row.prop(layer, property='hide', text='', icon=hide_icon)
                        row.prop(layer, property="name", text='')

                        iconPack = "PACKAGE"
                        if layer.image and layer.image.is_dirty:
                            row2.alert = True
                            iconPack = "UGLYPACKAGE"
                        op = row2.operator("material.pack_layer_image", text='', icon=iconPack)
                        op.index = i
                        row3 = rowbase.row(align=True)
                        row3.prop(layer, property='lock', text='', icon=lock_icon)

            elif not ob.material_slots:
                layout = self.layout.box()
                row = layout.row()
                row.box().label(text="Add Material Slot!", icon="ERROR")

            else:
                layout = self.layout.box()
                row = layout.row()
                row.box().label(text="Select Material!", icon="ERROR")


PSD_Layers_preview_collections = {}


def register():

    pcoll = bpy.utils.previews.new()

    absolute_path = os.path.dirname(__file__)
    relative_path = "icons"
    path = os.path.join(absolute_path, relative_path)

    pcoll.load("new_layer", os.path.join(path, "new_layer.png"), 'IMAGE')
    pcoll.load("duplicate_layer", os.path.join(path, "duplicate_layer.png"), 'IMAGE')
    pcoll.load("trash", os.path.join(path, "trash.png"), 'IMAGE')
    pcoll.load("brush", os.path.join(path, "brush.png"), 'IMAGE')
    PSD_Layers_preview_collections["main"] = pcoll

    bpy.utils.register_class(DATA_PT_PSD_Layers_UI)
    bpy.utils.register_class(DATA_PT_PSD_Materials)
    bpy.utils.register_class(DATA_PT_PSD_Palette)
    bpy.utils.register_class(DATA_PT_PSD_Layers)


def unregister():
    for pcoll in PSD_Layers_preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    PSD_Layers_preview_collections.clear()

    bpy.utils.unregister_class(DATA_PT_PSD_Layers_UI)
    bpy.utils.unregister_class(DATA_PT_PSD_Materials)
    bpy.utils.unregister_class(DATA_PT_PSD_Palette)
    bpy.utils.unregister_class(DATA_PT_PSD_Layers)
