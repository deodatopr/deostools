# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
import bpy
import sys
import importlib

bl_info = {
    "name": "PSD_Layers",
    "author": "Split Studios",
    "version": (1, 0),
    "blender": (3, 4, 0),
    "location": "View3D > Sidebar > PSD Paint Layers",
    "description": "Painting PSD Layers in Blender",
    "category": "PSD Layers",
}


modulesNames = ["PSD_Layers", "CustomFunctions", "UI"]

modulesFullNames = {}

for moduleName in modulesNames:
    modulesFullNames[moduleName] = ('{}.{}'.format(__name__, moduleName))

for currentModuleFullName in modulesFullNames.values():
    if currentModuleFullName in sys.modules:
        importlib.reload(sys.modules[currentModuleFullName])
    else:
        globals()[currentModuleFullName] = importlib.import_module(currentModuleFullName)
        setattr(globals()[currentModuleFullName], 'modulesNames', modulesFullNames)


class PSD_Layers_Preferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.operator('wm.url_open', text="Video Tutorials", icon='CAMERA_DATA').url = "https://youtu.be/JVXLsQlCY5g"
        row.operator('wm.url_open', text="Contact Us", icon='QUESTION').url = "mailto:split_studios@outlook.com"
        row.operator('wm.url_open', text="More Addons", icon='BLENDER').url = "https://splitstudios.gumroad.com/"
        row.operator('wm.url_open', text="Donate", icon='FUND').url = "paypal.me/zahyxahmed"


def register():
    for currentModuleName in modulesFullNames.values():
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'register'):
                sys.modules[currentModuleName].register()

    bpy.utils.register_class(PSD_Layers_Preferences)


def unregister():
    for currentModuleName in modulesFullNames.values():
        if currentModuleName in sys.modules:
            if hasattr(sys.modules[currentModuleName], 'unregister'):
                sys.modules[currentModuleName].unregister()

    bpy.utils.unregister_class(PSD_Layers_Preferences)


if __name__ == "__main__":
    register()
