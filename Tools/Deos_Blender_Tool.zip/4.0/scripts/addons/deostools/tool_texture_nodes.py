#------------------------------------------------
# TOOL TEXTURE NODES
#------------------------------------------------

import bpy, mathutils 				# Python, Vector 3, OS
from bpy.types import Operator		# Operadores


#------------------------------------------------
# [DEFINITION UPDATES]
#------------------------------------------------

# ADD TEXTURE NODES
def call_Add_TextureNodes():
	v_FilePath = bpy.utils.resource_path('USER') + "/scripts/addons/deostools/TextureNodes/TextureNodes.blend"

	with bpy.data.libraries.load(v_FilePath, link=False) as (data_from, data_to) : 
		data_to.node_groups = [v_TextureNodes for v_TextureNodes in data_from.node_groups if v_TextureNodes.startswith("[DTN]")]


# ----

# MATERIAL
def update_TextureNodes_Materials(self, context):

	v_AppendFile = "TextureNodes.blend"
	v_isAppendedDTN = False

	for v_lib in bpy.data.libraries:
		if v_lib.name == v_AppendFile:
			v_isAppendedDTN = True
			break

	if not v_isAppendedDTN:
		call_Add_TextureNodes()

	v_enum_Materials = self.enum_TextureNodes_Materials
	v_NodeColor = mathutils.Vector( ( 0.11, 0.11, 0.11 ) )

	if v_enum_Materials == 'Op1':
		v_NodeName = "MATERIAL <Mixer>"
		v_NodeSize = 250

	elif v_enum_Materials == 'Op2':
		v_NodeColor = mathutils.Vector( ( 0.11, 0.11, 0.11 ) )
		v_NodeName = "MATERIAL <Layared>"
		v_NodeSize = 250

# ---------------------------------

	# Crear 
	bpy.ops.node.add_node(use_transform=True, settings=[{"name":"node_tree", "value":"bpy.data.node_groups['[DTN] "+ v_NodeName +"']"}],  type="ShaderNodeGroup")
	v_NodeNew = bpy.context.active_node


	# Propiedades
	v_NodeNew.show_options = False
	v_NodeNew.use_custom_color = True
	v_NodeNew.color = v_NodeColor
	v_NodeNew.width = v_NodeSize

	# Mover
	# v_NodeNew.location = (0,0)
	v_NodeNew.location.x -= 600
	bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

# TOOLS
def update_TextureNodes_Tools(self, context):

	v_AppendFile = "TextureNodes.blend"
	v_isAppendedDTN = False

	for v_lib in bpy.data.libraries:
		if v_lib.name == v_AppendFile:
			v_isAppendedDTN = True
			break

	if not v_isAppendedDTN:
		call_Add_TextureNodes()

	v_enum_Tools = self.enum_TextureNodes_Tools
	v_NodeColor = mathutils.Vector( ( 0.2,0,0 ) )
	v_NodeSize = 200

	if v_enum_Tools == 'Op1':
		v_NodeName = "Tool <ID Color>"

	elif v_enum_Tools == 'Op2':
		v_NodeName = "Tool <Blur>"

# ---------------------------------

	# Crear 
	bpy.ops.node.add_node(use_transform=True, settings=[{"name":"node_tree", "value":"bpy.data.node_groups['[DTN] "+ v_NodeName +"']"}],  type="ShaderNodeGroup")
	v_NodeNew = bpy.context.active_node

	# Propiedades
	v_NodeNew.show_options = False
	v_NodeNew.use_custom_color = True
	v_NodeNew.color = v_NodeColor
	v_NodeNew.width = v_NodeSize

	# Mover
	# v_NodeNew.location = (0,0)
	v_NodeNew.location.x -= 600
	bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

# BLENDS
def update_texturenodes_Blends(self, context):

	v_AppendFile = "TextureNodes.blend"
	v_isAppendedDTN = False

	for v_lib in bpy.data.libraries:
		if v_lib.name == v_AppendFile:
			v_isAppendedDTN = True
			break

	if not v_isAppendedDTN:
		call_Add_TextureNodes()

	v_enum_Blends = self.enum_TextureNodes_Blends
	v_NodeColor = mathutils.Vector( ( 0.15,0.2,0 ) )
	v_NodeSize = 200

	if v_enum_Blends == 'Op1':
		v_NodeName = "Blend <Mixer>"

	elif v_enum_Blends == 'Op2':
		v_NodeName = "Blend <Mask>"

# ---------------------------------

	# Crear 
	bpy.ops.node.add_node(use_transform=True, settings=[{"name":"node_tree", "value":"bpy.data.node_groups['[DTN] "+ v_NodeName +"']"}],  type="ShaderNodeGroup")
	v_NodeNew = bpy.context.active_node

	# Propiedades
	v_NodeNew.show_options = False
	v_NodeNew.use_custom_color = True
	v_NodeNew.color = v_NodeColor
	v_NodeNew.width = v_NodeSize

	# Mover
	# v_NodeNew.location = (0,0)
	v_NodeNew.location.x -= 600
	bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

# EDITORS
def update_TextureNodes_Editors (self, context):

	v_AppendFile = "TextureNodes.blend"
	v_isAppendedDTN = False

	for v_lib in bpy.data.libraries:
		if v_lib.name == v_AppendFile:
			v_isAppendedDTN = True
			break

	if not v_isAppendedDTN:
		call_Add_TextureNodes()
	
	v_enum_Editors = self.enum_TextureNodes_Editors
	v_NodeColor = mathutils.Vector( ( 0,0.4,0.4 ) )
	v_NodeSize = 200

	if v_enum_Editors == 'Op1':
		v_NodeName = "Editor <Properties>"

	elif v_enum_Editors == 'Op2':
		v_NodeName = "Editor <Invert>"
	
	elif v_enum_Editors == 'Op3':
		v_NodeName = "Editor <Intensity>"

# ---------------------------------

	# Crear 
	bpy.ops.node.add_node(use_transform=True, settings=[{"name":"node_tree", "value":"bpy.data.node_groups['[DTN] "+ v_NodeName +"']"}],  type="ShaderNodeGroup")
	v_NodeNew = bpy.context.active_node

	# Propiedades
	v_NodeNew.show_options = False
	v_NodeNew.use_custom_color = True
	v_NodeNew.color = v_NodeColor
	v_NodeNew.width = v_NodeSize

	# Mover
	# v_NodeNew.location = (0,0)
	v_NodeNew.location.x -= 600
	bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

# UVS
def update_TextureNodes_UVs (self, context):

	v_AppendFile = "TextureNodes.blend"
	v_isAppendedDTN = False

	for v_lib in bpy.data.libraries:
		if v_lib.name == v_AppendFile:
			v_isAppendedDTN = True
			break

	if not v_isAppendedDTN:
		call_Add_TextureNodes()

	v_enum_UVs = self.enum_TextureNodes_UVs
	v_NodeColor = mathutils.Vector( ( 0.35,0.2,0 ) )

	if v_enum_UVs == 'Op1':
		v_NodeName = "UV <Tile>"
		v_NodeSize = 200

	elif v_enum_UVs == 'Op2':
		v_NodeName = "UV <By Axis>"
		v_NodeSize = 200
	
	elif v_enum_UVs == 'Op3':
		v_NodeName = "UV <Box Blend>"
		v_NodeSize = 240

	elif v_enum_UVs == 'Op4':
		v_NodeName = "UV <Triplanar>"
		v_NodeSize = 240			

# ---------------------------------

	# Crear 
	bpy.ops.node.add_node(use_transform=True, settings=[{"name":"node_tree", "value":"bpy.data.node_groups['[DTN] "+ v_NodeName +"']"}],  type="ShaderNodeGroup")
	v_NodeNew = bpy.context.active_node

	# Propiedades
	v_NodeNew.show_options = False
	v_NodeNew.use_custom_color = True
	v_NodeNew.color = v_NodeColor
	v_NodeNew.width = v_NodeSize

	# Mover
	# v_NodeNew.location = (0,0)
	v_NodeNew.location.x -= 600
	bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

# NORMALS
def update_TextureNodes_Normals (self, context):

	v_AppendFile = "TextureNodes.blend"
	v_isAppendedDTN = False

	for v_lib in bpy.data.libraries:
		if v_lib.name == v_AppendFile:
			v_isAppendedDTN = True
			break

	if not v_isAppendedDTN:
		call_Add_TextureNodes()

	v_enum_Normals = self.enum_TextureNodes_Normals
	v_NodeColor = mathutils.Vector( ( 0.3,0.2,0.5 ) )

	if v_enum_Normals == 'Op1':
		v_NodeName = "Normal <Baked Detailed>"
		v_NodeSize = 240

	elif v_enum_Normals == 'Op2':
		v_NodeName = "Normal <Combined>"
		v_NodeSize = 200
	
	elif v_enum_Normals == 'Op3':
		v_NodeName = "Normal <+Bump>"
		v_NodeSize = 200

	elif v_enum_Normals == 'Op4':
		v_NodeName = "Bump <Combined>"
		v_NodeSize = 210			

# ---------------------------------

	# Crear 
	bpy.ops.node.add_node(use_transform=True, settings=[{"name":"node_tree", "value":"bpy.data.node_groups['[DTN] "+ v_NodeName +"']"}],  type="ShaderNodeGroup")
	v_NodeNew = bpy.context.active_node

	# Propiedades
	v_NodeNew.show_options = False
	v_NodeNew.use_custom_color = True
	v_NodeNew.color = v_NodeColor
	v_NodeNew.width = v_NodeSize

	# Mover
	# v_NodeNew.location = (0,0)
	v_NodeNew.location.x -= 600
	bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

# GENERATORS
def update_TextureNodes_Generators (self, context):

	v_AppendFile = "TextureNodes.blend"
	v_isAppendedDTN = False

	for v_lib in bpy.data.libraries:
		if v_lib.name == v_AppendFile:
			v_isAppendedDTN = True
			break

	if not v_isAppendedDTN:
		call_Add_TextureNodes()

	v_NodeColor = mathutils.Vector( ( 0.15,0.33,0.55 ) )
	v_enum_Generators = self.enum_TextureNodes_Generators

	if v_enum_Generators == 'Op1':
		v_NodeName = "Generator <AO>"
		v_NodeSize = 180

	elif v_enum_Generators == 'Op2':
		v_NodeName = "Generator <Position>"
		v_NodeSize = 220
	
	elif v_enum_Generators == 'Op3':
		v_NodeName = "Generator <Thickness>"
		v_NodeSize = 220

	elif v_enum_Generators == 'Op4':
		v_NodeName = "Generator <Dust>"
		v_NodeSize = 200	
	
	elif v_enum_Generators == 'Op5':
		v_NodeName = "Generator <Grid>"
		v_NodeSize = 200			

# ---------------------------------

	# Crear 
	bpy.ops.node.add_node(use_transform=True, settings=[{"name":"node_tree", "value":"bpy.data.node_groups['[DTN] "+ v_NodeName +"']"}],  type="ShaderNodeGroup")
	v_NodeNew = bpy.context.active_node

	# Propiedades
	v_NodeNew.show_options = False
	v_NodeNew.use_custom_color = True
	v_NodeNew.color = v_NodeColor
	v_NodeNew.width = v_NodeSize

	# Mover
	# v_NodeNew.location = (0,0)
	v_NodeNew.location.x -= 600
	bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

# SMART MASKS
def update_TextureNodes_Masks (self, context):

	v_AppendFile = "TextureNodes.blend"
	v_isAppendedDTN = False

	for v_lib in bpy.data.libraries:
		if v_lib.name == v_AppendFile:
			v_isAppendedDTN = True
			break

	if not v_isAppendedDTN:
		call_Add_TextureNodes()


	v_enum_Masks = self.enum_TextureNodes_Masks
	v_NodeColor = mathutils.Vector( ( 0.05,0.05,0.05 ) )

	if v_enum_Masks == 'Op1':
		v_NodeName = "Smart Mask <Curvature>"
		v_NodeSize = 240

	elif v_enum_Masks == 'Op2':
		v_NodeName = "Smart Mask <Dirty>"
		v_NodeSize = 240
	
	elif v_enum_Masks == 'Op3':
		v_NodeName = "Smart Mask <Edge Wear>"
		v_NodeSize = 250

# ---------------------------------

	# Crear 
	bpy.ops.node.add_node(use_transform=True, settings=[{"name":"node_tree", "value":"bpy.data.node_groups['[DTN] "+ v_NodeName +"']"}],  type="ShaderNodeGroup")
	v_NodeNew = bpy.context.active_node

	# Propiedades
	v_NodeNew.show_options = False
	v_NodeNew.use_custom_color = True
	v_NodeNew.color = v_NodeColor
	v_NodeNew.width = v_NodeSize

	# Mover
	# v_NodeNew.location = (0,0)
	v_NodeNew.location.x -= 600
	bpy.ops.node.translate_attach_remove_on_cancel('INVOKE_DEFAULT')

	"""
		# [ CREAR TEXTURE NODE ]
			v_ObjMatActv = bpy.context.active_object.active_material
			if v_ObjMatActv:
				
				# Seleccionar MatOut par ainiciar para que funcione 'v_isInsideNodeGrp'
				v_getMatOut = v_ObjMatActv.node_tree.nodes.get("Material Output")		
				v_getMatOut.select = True
				v_ObjMatActv.node_tree.nodes.active = v_getMatOut
			
				# Activar Shader Editor y remover selecciones
				for area in bpy.context.screen.areas:
					if area.type == 'NODE_EDITOR':
						with bpy.context.temp_override(area=area, space_data=area.spaces.active):
							bpy.ops.node.select_all(action='DESELECT')
						break
								
				# Regresar bool si se esta dentro de un NdeGrp
				v_isInsideNodeGrp = bpy.context.active_object.active_material.node_tree.nodes.active.select
				
				if not v_isInsideNodeGrp : 			                        
					print ("Raiz")
				# EN LA RAIZ
					# Seleccionar Material Activo
					bpy.context.object.active_material = v_ObjMatActv

					# Crear Nodo
					v_NodeNew = v_ObjMatActv.node_tree.nodes.new(type='ShaderNodeGroup')
					v_NodeNew.node_tree = bpy.data.node_groups.get("[DTN] " + v_NodeName)
	
					# Propiedades de Nodo
					v_NodeNew.show_options = False
					v_NodeNew.width = v_NodeSize
					v_NodeNew.location = (v_NodePosX, v_NodePosY)
					v_NodeNew.use_custom_color = True
					v_NodeNew.color = v_NodeColor

					self.report({'INFO'}, f"Node '{v_NodeName}' was created")

				else : 
			
				# DENTRO DE GRUPO
					print ("En Grupo")

					v_NodeGrp = None
					for v_InVar in v_ObjMatActv.node_tree.nodes:
						if v_InVar.type == 'GROUP' and v_InVar.node_tree.name == 'MyNodeGroup' :
							v_NodeGrp = v_InVar
							break

					if v_NodeGrp:

						# Crear Nodo
						v_NodeNew = v_ObjMatActv.node_tree.nodes.new(type='ShaderNodeGroup')
						v_NodeNew.node_tree = bpy.data.node_groups.get("[DTN] " + v_NodeName)
		
						# Propiedades de Nodo
						v_NodeNew.show_options = False
						v_NodeNew.width = v_NodeSize
						v_NodeNew.location = (v_NodePosX, v_NodePosY)
						v_NodeNew.use_custom_color = True
						v_NodeNew.color = v_NodeColor
			else : 
				self.report({'WARNING'}, "The Mesh does not have a Material created")
				"""



#------------------------------------------------
# [OPERATORs]
#------------------------------------------------


# UPDATE
class DeosOperTextureNodeUpdate (Operator):
		bl_idname = "deo.texture_nodes_update"
		bl_label = ""
		bl_description = "Update 'Deo's Texture Nodes' Library"

		def execute (self, context) :

			# Path y Nopmbes.	
			FileName_TNodes = "TextureNodes.blend"
			Path_TNodes = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\TextureNodes\\"
		
		# Reload Linked
			bpy.ops.wm.lib_reload(library=FileName_TNodes, directory=Path_TNodes, filename=FileName_TNodes, relative_path=False)
			# bpy.data.libraries[FileName_TNodes].reload()

			# INFO
			self.report({'INFO'}, "[The Deo's Texture Nodes was Updated]")

			return {'FINISHED'}
	
# RE-CONNECT
class DeosOperTextureNodeMaster (Operator):
		
		bl_idname = "deo.texture_nodes_master"
		bl_label = ""
		bl_description = "Will reConnect the 'Principled BSDF' to 'MatOuput'"

		def execute (self, context) :
			
			if bpy.context.active_object :
				# Material Seleccionado
				v_ActiveMaterial = bpy.context.active_object.active_material

				# Obtener del material acitvo nodos
				v_getMatBSDF = v_ActiveMaterial.node_tree.nodes.get("Principled BSDF")
				v_getMatOut  = v_ActiveMaterial.node_tree.nodes.get("Material Output")

				# BSDF>Out a MatOut>Surface
				if v_getMatBSDF : 
					v_ActiveMaterial.node_tree.links.new(v_getMatBSDF.outputs["BSDF"], v_getMatOut.inputs["Surface"])				
					self.report({'INFO'}, "[The Principled BSDF Node is reConnected]")

			else : 
				
				self.report({'INFO'}, "[Select the Mesh that you need to reConnect the Master Node]")

			return {'FINISHED'}