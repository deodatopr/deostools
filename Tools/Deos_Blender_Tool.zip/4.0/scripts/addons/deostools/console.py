import bpy, os

bpy.ops.script.reload()     # Reload system Scripts
#os.system("cls")           # Clear console system

#Read all actions
#bpy.app.debug_wm = True 
#bpy.app.debug_wm = False
