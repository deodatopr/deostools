#-----------------------------------------------------------------------------------------------
# ADD-ON
#-----------------------------------------------------------------------------------------------
bl_info = {
	"category": "Deo's",
	"name": "Kit Tools",
	"description": "Deo's Tools Kit",
	"author": "Deodato Pechir",
	"version": (3, 2),
	"blender": (3, 0, 0),
	"location": "3D View > Sidebars > Item > Deo's Tools",
	"tracker_url": "http://www.3dboxacademy.com",
}


#-----------------------------------------------------------------------------------------------
#  IMPORTS
#-----------------------------------------------------------------------------------------------

import bpy

# [EXTRAS ]
import requests 					# Get Web
from pathlib import Path			# Get Local
from cgitb import text				# Read Line
from re import MULTILINE, split		# Read MiltiLine
from bpy.utils import previews		# Img as Icons

# [PROPS]
from bpy.props import ( StringProperty, BoolProperty, FloatProperty,  EnumProperty, PointerProperty,IntProperty, FloatVectorProperty )

# [TYPES]
from bpy.types import ( PropertyGroup, Panel, Operator, )

# [MY TOOLS]
from.tool_baker_maps import *			# Baker Maps.
from.tool_exporter_maps import *		# Exporter Maps.
from.tool_sculpt_orbrushes import *		# ORB Brushes.
from .tool_texture_nodes import *   	# Texture Nodes.

#-----------------------------------------------------------------------------------------------
#  ICON LIBRARY
#-----------------------------------------------------------------------------------------------
#region

IconLibrary = previews.new()
IconPath = bpy.utils.resource_path('USER') + "/scripts/addons/deostools/TextureNodes/Icons/"

# Materials 
IconLibrary.load(name='MyIcon_Mat_Material', path= (IconPath +'Mat_Material.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Mat_Layared',  path= (IconPath +'Mat_Layared.png'), path_type='IMAGE')

# Tools 
IconLibrary.load(name='MyIcon_Tool_IDColor', path= (IconPath +'Tools_IDColor.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Tool_Blur',  path= (IconPath +'Tools_Blur.png'), path_type='IMAGE')

# Blend 
IconLibrary.load(name='MyIcon_Blend_Mixer', path= (IconPath +'Blend_Mixer.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Blend_Mask',  path= (IconPath +'Blend_Mask.png'), path_type='IMAGE')

# Editor 
IconLibrary.load(name='MyIcon_Editor_Properties', 	path= (IconPath +'Edit_Properties.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Editor_Invert',  	path= (IconPath +'Edit_Invert.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Editor_Intensity',  	path= (IconPath +'Edit_Intensity.png'), path_type='IMAGE')

# UV
IconLibrary.load(name='MyIcon_UV_Tile', path= (IconPath +'UV_Tile.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_UV_ByAxis', path= (IconPath +'UV_ByAxis.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_UV_BoxBlend', path= (IconPath +'UV_BoxBlend.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_UV_Triplanar', path= (IconPath +'UV_Triplanar.png'), path_type='IMAGE')

# NORMALS
IconLibrary.load(name='MyIcon_Normal_Combined', path= (IconPath +'NRM_Combined.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Normal_BakeDetail', path= (IconPath +'NRM_BakeDetail.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Normal_AndBump', path= (IconPath +'NRM_AndBump.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Normal_BumpComb', path= (IconPath +'NRM_BumpComb.png'), path_type='IMAGE')

# GENERATORS
IconLibrary.load(name='MyIcon_Gen_AO', path= (IconPath +'GEN_AO.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Gen_Dust', path= (IconPath +'GEN_Dust.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Gen_Grid', path= (IconPath +'GEN_Grid.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Gen_Position', path= (IconPath +'GEN_Position.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Gen_Thickness', path= (IconPath +'GEN_Thickness.png'), path_type='IMAGE')

# SMART MASK
IconLibrary.load(name='MyIcon_Mask_Curvature', path= (IconPath +'MASK_Curvature.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Mask_Dirty', path= (IconPath +'MASK_Dirty.png'), path_type='IMAGE')
IconLibrary.load(name='MyIcon_Mask_EdgeWear', path= (IconPath +'MASK_EdgeWear.png'), path_type='IMAGE')

#endregion


#-----------------------------------------------------------------------------------------------
#  PROPERTIES (Scene)
#-----------------------------------------------------------------------------------------------
class DeosPropertyGroup(PropertyGroup):

#---------------------------------------#
# BAKER MAPS					
#---------------------------------------#

	# [ ENUMS ]
			
	# Select ToolOptions  
	enumBakerMapToolOptions : EnumProperty (
		name = "",
		description = "Select one the 'Baker Map Options'",
		items = [ ('Op0', "[   BAKER   OPTIONS   ]", ""), 
				('Op1', "1) MAP TO MAP", ""), 
				('Op2', "2) MAP TO VER", ""), 
				('Op3', "3) VER TO MAP", ""), 
				('Op4', "4) MATs TO MAP", ""), 
				('Op5', "5) VERTEX PASSES", ""),
				('Op6', "6) MAP PASSES", "") ],
		update = updateEnumBakermapBaketype,	 #Call_tool_baker_map
	)

	# Map Passes: NormalMap or PassMap
	enumBakerMapToolBakerType : EnumProperty (
		name = "",
		description = "Selec the Type to Bake from 'High to Lowpoly'",
		items = [ ('Op1', "Normal Map", ""), ('Op2', "Pass Map", "") ],
		default = "Op1",
		update = updateEnumBakermapBaketype,	 #Call_tool_baker_map
	)
 
	# Shader Pass Selection
	enumBakerMapPassType : EnumProperty (
		name="",
		description="Select the type of Pass to get bake",
		  items = [ ('Op1', "NONE", ""), 
			 ('Op2', "Curvature (Sculpt)", ""),
			 ('Op3', "Curvature (H.Surface)", ""),
			 ('Op4', "Ambient Occlusion", ""), 
			 ('Op5', "Position (Height)", ""),
			 ('Op6', "Dust (On Top)", ""), 
			 ('Op7', "Thickness (SSS)", ""), 
			 ('Op8', "Cavity", "") ],
		default="Op1",
		update = updateEnumBakermapShaderPassesType,	 #Call_tool_baker_map
	)
	 
	# Map Setting: Size
	enumBakerMapPassMapSettingSize : EnumProperty (
		name = "",
		description = "Select the size of the texture to Bake",
		items = [ ('Op1', "256p x", ""), 
		   ('Op2', "512 px", ""), 
		   ('Op3', "1024 px", ""), 
		   ('Op4', "2048 px", ""), 
		   ('Op5', "4096 px", ""), 
		   ('Op6', "8192 px", "") ],
		  default="Op3",
	)
	
# Map Setting: Name
	
	enumBakerMapPassMapSettingName : EnumProperty (
		name="",
		description="Select the Name of next Map to Bake",
		  items = [ ('Op1', "CURVATURE MAP", ""), 
			 ('Op2', "OCCLUSION MAP", ""), 
			 ('Op3', "POSITION MAP", ""), 
			 ('Op4', "CAVITY MAP", ""), 
			 ('Op5', "DUST MAP", ""), 
			 ('Op6', "THICKNESS MAP", ""), 
			 ('Op7', "TESTING MAP", "") ],
		default="Op1",
	)
	

	# [ PICKERS ]
 
	# Source 
	pickerSource : PointerProperty (
		name = "",
		description = "Load the Source Mesh",
		type = bpy.types.Object,
	)
	
	# Target
	pickerTarget : PointerProperty (
		name = "",
		description = "Load the Target Mesh",
		type = bpy.types.Object,
	)

	# Vertex Mesh
	pickerVertex: PointerProperty (
		name = "",
		description = "Load the Higpoly Vertex Mesh",
		type = bpy.types.Object,
	)
	 
	# Lowpoly
	pickerLow : PointerProperty (
		name = "",
		description = "Load the Lowpoly Mesh",
		type = bpy.types.Object,
	)
	
	# Highpoly (Collection)
	pickerHigh: PointerProperty (
		name = "",
		description = "Load the Mesh(es) from a 'Collection'",
		type = bpy.types.Collection,
	)


	# [ BOOLEANS (Isolate) ]
 
	# Source
	boolIsolateSource : BoolProperty (
		name = "Source",
		description = "Isolate Source Mesh",
		default = False,		
		update = updateIsolateSource,   		  #Call_tool_baker_map
	)
	
	# Target
	boolIsolateTarget : BoolProperty (
		name = "Target",
		description = "Isolate Target Mesh",
		default = False,		
		update = updateIsolateTarget,   			#Call_tool_baker_map
	)
	
	# Lowpoly
	boolIsolateLow : BoolProperty (
		name = "Low",
		description = "Isolate Lowpoly Mesh",
		default = False,		
		update = updateIsolateLow,  			  	#Call_tool_baker_map
	)
	
	# Highpoly
	boolIsolateHigh : BoolProperty (
		name = "High",
		description = "Isolate Highpoly Mesh(es)",
		default = False,		
		update = updateIsolateHigh, 			  	#Call_tool_baker_map
	)

	# Vieport Shading
	boolUseCyclesVieport : BoolProperty (
		name = "",
		description = "Toggle Cycles",
		default = False,		
		update = updateUseClyclesViewport,			 #Call_tool_baker_map
	)
	
 
	# [ VERTEX LAYER ]
 
	# Color
	strLayerMaptoVer : StringProperty (
		name="",
		description="This will be the new Vertex Color Layer name",
		default="MapToVer",
		maxlen=1024,
	)

	# Passes
	strLayerVertexPasses : StringProperty (
		name="",
		description="This will be the new Vertex Color Layer name",
		default="VertexPasses",
		maxlen=1024,
	)


	# [ SLIDERS - SHADER PASSES ] 
 
	# Curvature
	SldrCurvatureIntensity : FloatProperty (
		name="",
		description="",
		 min = 0.0, max = 1.0, precision = 3, default= 0.5,
		update = updateSldrBakermapShaderPassesPropertieCurvature,	 #Call_tool_baker_map
	)
 
	 # AO Distance
	SldrAO_Distance : FloatProperty (
		name="",
		description="",
		 min = 0.0, max = 20.0, precision = 3, default= 1.0,
		update = updateSldrBakermapShaderPassesPropertieAODistance,	 #Call_tool_baker_map
	)
 
	# AO Intensity
	SldrAO_Intensity : FloatProperty (
		name="",
		description="",
		 min = 0.0, max = 1.0, precision = 3, default= 0.05,
		update = updateSldrBakermapShaderPassesPropertieAOIntensity,	 #Call_tool_baker_map
	)
	
	 # Popsition Offset
	SldrPosition_Offset : FloatProperty (
		name="",
		description="",
		 min = 0.0, max = 1.0, precision = 3, default= 0.5,
		update = updateSldrBakermapShaderPassesPropertiePositionOffset,	 #Call_tool_baker_map
	)
	
	# Popsition Add Normals 
	SldrPosition_AddTopNormals : FloatProperty (
		name="",
		description="",
		 min = 0.0, max = 1.0, precision = 3, default= 0.0,
		update = updateSldrBakermapShaderPassesPropertiePositionNormals,	 #Call_tool_baker_map
	)
	
	# Dust (On Top) 
	SldrDustOnTop : FloatProperty (
		name="",
		description="",
		 min = 0.0, max = 1.0, precision = 3, default= 0.0,
		update = updateSldrBakermapShaderPassesPropertieDust,	 #Call_tool_baker_map
	)
 
	# Thickness Distance
	SldrThickness_Distance : FloatProperty (
		name="",
		description="",
		 min = 0.0, max = 1.0, precision = 3, default= 0.5,
		update = updateSldrBakermapShaderPassesPropertieThicknessDistance,	 #Call_tool_baker_map
	)
	
	# Thickness Balance
	SldrThickness_Balance : FloatProperty (
		name="",
		description="",
		 min = 0.0, max = 1.0, precision = 3, default= 0.5,
		update = updateSldrBakermapShaderPassesPropertieThicknessBalance,	 #Call_tool_baker_map
	)
 
	# Cavity
	SldrCavity : FloatProperty (
		name="",
		description="",
		min = 0.0, max = 1.0, precision = 3, default= 0.5,
		update = updateSldrBakermapShaderPassesPropertieCavity,	 #Call_tool_baker_map
	)
 

	#---------------------------------------#
	# EXPORTER MAPS
	#---------------------------------------#
 
	# Picker:  Mesh
	picker_ExporterMap_High : PointerProperty (
		name = "",
		description = "Load the Mesh to expor al the shading to maps",
		type = bpy.types.Object,
	)   	
	

	# Enum: Map Setting: Size
	enum_ExporterMap_ImgSize : EnumProperty (
		name = "",
		description = "Select the texture 'Size' to Export",
		items = [
			('Op1', "256 px", ""),
			('Op2', "512 px", ""), 
			('Op3', "1024 px", ""), 
			('Op4', "2048 px", ""), 
			('Op5', "4096 px", ""), 
			('Op6', "8192 px", "") 
			],
			default="Op3"
	)

	# Enum: Map Setting: Format
	enum_ExporterMap_ImgFormat : EnumProperty (
		name = "",
		description = "Select the texture 'Format' to Export",
		items = [ ('Op1', "JPG", ""), ('Op2', "PNG", ""), ('Op3', "TGA", "") ],
		  default="Op2",
	)

	# Enum: Edge Padding
	enum_ExporterMap_edgePadding : EnumProperty (
		name = "",
		description = "How long will be the 'UV Edge' Map to Export",
		items = [ 
			('Op1', "Dilation Infinite", ""), 
		   ('Op2', "128 px", ""), 
		   ('Op3', "64 px", ""), 
		   ('Op4', "32 px", ""), 
		   ('Op5', "16 px", ""), 
		   ('Op6', "8 px", ""), 
		   ('Op7', "4 px", "") ],
		  default="Op1",
	)

	# Bool: Color
	bool_ExporterMap_Color : BoolProperty (
		name = "",
		description = "Base Color Map",
		default = True,		
	)

	# Bool: Metallic
	bool_ExporterMap_Metallic : BoolProperty (
		name = "",
		description = "Metallic Map",
		default = True,		
	)

	# Bool: Roughness
	bool_ExporterMap_Roughness : BoolProperty (
		name = "",
		description = "Roughness Map",
		default = True,		
	)

	# Bool: Normal
	bool_ExporterMap_Normal : BoolProperty (
		name = "",
		description = "Normal Map",
		default = True,		
	)

	# Bool: Emission
	bool_ExporterMap_Emission : BoolProperty (
		name = "",
		description = "Emission Map",
		default = False,		
	)

	# Bool: Mesh Name
	bool_ExporterMap_MeshName : BoolProperty (
		name = "",
		description = "Use the Mesh Name",
		default = False,		
	)

	# String: File Map Name Enabled
	str_ExporterMap_FileNameCustom: StringProperty (
		name="",
		description="The 'File Name' of the Map to export",
		default="ExporterMap",
	)

	# String: File Map Name Disabled
	str_ExporterMap_FileNameMesh: StringProperty (
		name="",
		description="The 'File Name' of the Map to export",
		default="    [ Mesh Name ]",
	)

	# String: File Map Path
	str_ExporterMap_PathDir: StringProperty (
		name="",
		description='The location to place the exported files',
		subtype='DIR_PATH',  # FILE_PATH / DIR_PATH
		default='Blender File Location',
	)


#---------------------------------------#
# TEXTURE NODES
#---------------------------------------#

	enum_TextureNodes_Materials : EnumProperty(
		name="",
		description="",
		items=[
			('Op1', "[MATERIAL]   MIXER", "Creates the Mixture of 2 Materials", IconLibrary["MyIcon_Mat_Material"].icon_id, 0),
			('Op2', "[MATERIAL]   LAYARED", "Creates the Layared effect of 2 Materials", IconLibrary["MyIcon_Mat_Layared"].icon_id, 1),
		],
		default='Op1',
		update = update_TextureNodes_Materials,	 #Call_tool_texture_nodes
	)

	enum_TextureNodes_Tools : EnumProperty(
	name="",
	description="",
	items=[
		('Op1', "[TOOL]   ID COLOR", "Allows you to pick a 'Color and get from that color a Mask'", IconLibrary["MyIcon_Tool_IDColor"].icon_id, 0),
		('Op2', "[TOOL]   IMAGE BLUR", "Allows you to add 'Blur in a Image using Cycles'", IconLibrary["MyIcon_Tool_Blur"].icon_id, 1),
		],
	default='Op1',
	update = update_TextureNodes_Tools,	 #Call_tool_texture_nodes
	)

	enum_TextureNodes_Blends : EnumProperty(
	name="",
	description="",
	items=[ 
		('Op1', "[BLEND]   MIXER", "Allows you to mix 2 colors using the 'Common Blend Actions'", IconLibrary["MyIcon_Blend_Mixer"].icon_id, 0),
		('Op2', "[BLEND]   MASK", "Allows you to mix 2 colors using a 'Mask'", IconLibrary["MyIcon_Blend_Mask"].icon_id, 1),
		],
	default='Op1',
	update = update_texturenodes_Blends,	 #Call_tool_texture_nodes
	)

	enum_TextureNodes_Editors : EnumProperty(
	name="",
	description="",
	items=[ ('Op1', "[EDITOR]   PROPERTIES", "Allows you to control 'Common Properties on a Image/Procedural Node'", IconLibrary["MyIcon_Editor_Properties"].icon_id, 0),
			('Op2', "[EDITOR]   INVERT", "Allows you to 'Invert by Channels(RGB)' from a Image/TextureArray/NormalMap", IconLibrary["MyIcon_Editor_Invert"].icon_id, 1),
			('Op3', "[EDITOR]   INTENSITY", "Allows you to 'Increase the power of any Color', used to Emission>Bloom", IconLibrary["MyIcon_Editor_Intensity"].icon_id, 2),
			],
	default='Op1',
	update = update_TextureNodes_Editors,	 #Call_tool_texture_nodes
	)

	enum_TextureNodes_UVs : EnumProperty(
	name="",
	description="",
	items=[ ('Op1', "[UV]   TILE", "Allows you to 'Manipulate the Tile' of any Image/procedural node", IconLibrary["MyIcon_UV_Tile"].icon_id, 0),
			('Op2', "[UV]   BY AXIS", "Allows you to 'Manipulate the Tile by Axis projection of an image/procedural node", IconLibrary["MyIcon_UV_ByAxis"].icon_id, 1),
			('Op3', "[UV]   BOX BLEND", "Allows you to 'Remove Seams' of image nodes", IconLibrary["MyIcon_UV_BoxBlend"].icon_id, 2),
			('Op4', "[UV]   TRIPLANAR", "Allows you to 'Project' a Image/procedural node in XYZ without any UV projection", IconLibrary["MyIcon_UV_Triplanar"].icon_id, 3),
			],
	default='Op1',
	update = update_TextureNodes_UVs,	 #Call_tool_texture_nodes
	)

	enum_TextureNodes_Normals : EnumProperty(
	name="",
	description="",
	items=[ 
		('Op1', "[NORMAL]   BAKED DETAILED", "Allows you to 'Add extra fine detail over to a Baked Normal map'", IconLibrary["MyIcon_Normal_BakeDetail"].icon_id, 0),
		('Op2', "[NORMAL]   COMBINED", "Allows you to 'Combine 2 Normal maps'", IconLibrary["MyIcon_Normal_Combined"].icon_id, 1),
		('Op3', "[NORMAL]   +BUMP", "Allows you to 'Mix a Normal and Bump' in one Node", IconLibrary["MyIcon_Normal_AndBump"].icon_id, 2),
		('Op4', "[BUMP]   COMBINED", "Allows you to 'Combine 2 bumps in One Value'", IconLibrary["MyIcon_Normal_BumpComb"].icon_id, 3),
			],
	default='Op1',
	update = update_TextureNodes_Normals,	 #Call_tool_texture_nodes
	)
	
	enum_TextureNodes_Generators : EnumProperty(
	name="",
	description="",
	items=[ ('Op1', "[GENERATOR]   AO", "Allows you to create 'AO from a Normal Map'", IconLibrary["MyIcon_Gen_AO"].icon_id, 0),
			('Op2', "[GENERATOR]   POSITION", "Allows you create a 'Ramp Height Mask'", IconLibrary["MyIcon_Gen_Position"].icon_id, 1),
			('Op3', "[GENERATOR]   THICKNESS", "Allows you create a 'Mask to simulate SSS", IconLibrary["MyIcon_Gen_Thickness"].icon_id, 2),
			('Op4', "[GENERATOR]   DUST", "Allows you create a 'Mask on top using flat faces'", IconLibrary["MyIcon_Gen_Dust"].icon_id, 3),
			('Op5', "[GENERATOR]   GRID", "Allows you create a procedural Grid Lines", IconLibrary["MyIcon_Gen_Grid"].icon_id, 4),
			],
	default='Op1',
	update = update_TextureNodes_Generators,	 #Call_tool_texture_nodes
	)

	enum_TextureNodes_Masks : EnumProperty(
	name="",
	description="",
	items=[ ('Op1', "[SMARTMASK]   CURVATURE", "Allows you to create 'Edges/Cavities' from a Curvature Map", IconLibrary["MyIcon_Mask_Curvature"].icon_id, 0),
			('Op2', "[SMARTMASK]   DIRTY", "Allows you to create 'Dirtiness' on a object from a Ambient Occlusion Map (AO)'", IconLibrary["MyIcon_Mask_Dirty"].icon_id, 1),
			('Op3', "[SMARTMASK]   EDGE WEAR", "Allows you to create 'Procedural variation Edges' using a Curvature Map", IconLibrary["MyIcon_Mask_EdgeWear"].icon_id, 2),
			],
	default='Op1',
	update = update_TextureNodes_Masks,	 #Call_tool_texture_nodes
	)		


#---------------------------------------#
# BLENDER MODE
#---------------------------------------#

	enum_Keymap_Mode : EnumProperty(
	name="",
	description="",
	items=[ 
		('Op1', "Blender's Mode", "Use the Shortcuts / Vieport interaction like: Blender do"),
		('Op2', "Deo's Mode", "Use the Shortcuts / Vieport interaction like: Maya, Max or other Industry program do"),
		],
	default='Op2',
	)		




#-----------------------------------------------------------------------------------------------
# UPDATER - READ FILES
#-----------------------------------------------------------------------------------------------
# region

# [LOCAL VERSION]

# Multi Line
localUserPath = bpy.utils.resource_path('USER')
localFilePath = localUserPath + "/config/version.txt"
localPath = Path( bpy.path.abspath(localFilePath) ) 

localFileOpen = open(localPath, 'r')
localFileRead = localFileOpen.readlines()

LocalList = []
for myLines in localFileRead :
	LocalList.append(myLines.strip())

# [WEB VERSION]

# Multi Line - Get 
try:
	# Formato de Web
	WebRequest = requests.get("https://deodatopr.github.io/deostools/Tools/version.txt", timeout = 2)
	
	# Formato de GoogleDrive (uc?id= 'El puro ID')
	# WebRequest = requests.get("https://drive.google.com/uc?id=1fGiBMknPTJqO3n_YShpVmzmVxJVfw9vp", timeout = 2)
	
	myWebVer = WebRequest.text.splitlines()
	WebList = []

	for myLines in myWebVer :
		WebList.append(myLines)

	CheckingInternetConnection = True

except (requests.ConnectionError, requests.Timeout) as exception :

	CheckingInternetConnection = False


"""
# GDRIVE VERSION

file_url = "https://drive.google.com/uc?id=1fGiBMknPTJqO3n_YShpVmzmVxJVfw9vp"

response = requests.get(file_url)

# Verifica si la solicitud fue exitosa
if response.status_code == 200:
	file_content = response.text
	print(file_content)
else:
	print("No se pudo acceder al archivo.")

# Limpieza de recursos si es necesario
response.close()
"""

"""
# [ LOCAL VERSION ]
# Simple Line
UserPath = bpy.utils.resource_path('USER')
LocalFile = UserPath + "/config/version.txt"
LocalInfo = Path( bpy.path.abspath(LocalFile) ) 
myLocalVer = LocalInfo.read_text()
#LocalInfo.exists() - is Valid?

# [ WEB VERSION ]
# # Simple Line - Get
try:
	#Path 
	WebRequest = requests.get ("https://deodatopr.github.io/deostools/Tools/version.txt", timeout=5)
	myWebVer = WebRequest.text
	ChekingInternetConnection = True
except (requests.ConnectionError, requests.Timeout) as exception:
	ChekingInternetConnection = False
"""

# endregion


#-----------------------------------------------------------------------------------------------
# INTERFACES TOOL
#-----------------------------------------------------------------------------------------------

# [HEADER DEOSTOOL]
class DeosPanelEmpty (Panel) :
	bl_idname = "DEOS_PT_DeosTools"
	bl_label = "[ D E O ' s    T O O L S ] "
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "Deo's"

	def draw (self, context) :
		pass

# [UPDATER UI]
class DeosPanelUpdater (Panel) :
	bl_idname = "DEOS_PT_Updater"
	bl_label = "DEO's TOOLS"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "Deo's Tools"

	def draw (self, context) :
	 
		"""
		# SINGLE LINE
		box.label (text="[ ABOUT DEO'S TOOLS ]", icon='TOOL_SETTINGS')

		if CheckingInternetConnection :  # Internet Connection Stablished 
			
			# No Updated
			if float (myLocalVer) < float (myWebVer)  :
				box.label (text="Installed Version: " + myLocalVer, icon='KEYTYPE_BREAKDOWN_VEC')
				box.label (text="Website Version:  " + myWebVer, icon='KEYTYPE_MOVING_HOLD_VEC')
				box.operator("wm.url_open", text=". : :  Go to Update it  : : .", icon="DECORATE_LINKED").url = "https://deodatopr.github.io/deostools/"
			
			else :  
				# Using Last version
				box.label (text="Installed Version: " + myLocalVer, icon='KEYTYPE_BREAKDOWN_VEC')
				box.label (text="Using the last Version", icon='FUND')
			# -----
			
		else :   # No Internet Connection
			
			box.label (text="Installed Version: " + myLocalVer, icon='KEYTYPE_BREAKDOWN_VEC')
			box.label (text="No Internet Connection", icon='KEYTYPE_EXTREME_VEC')
		"""

		# MULTI LINE
		mytool = context.scene.my_tool
		layout = self.layout
		box = layout.box()
		box.label (text="   [  BLENDER VERSION  ]")

		col = box.column()
		split = col.split()
		
		if CheckingInternetConnection :
			if LocalList[0] <= WebList[0] :
				if LocalList[1] < WebList[1] :
					# Nueva Version
					split.label (text= LocalList[0] + ".X", icon='BLENDER')
					split.label (text="v" + LocalList[1], icon='TOOL_SETTINGS')
					box.alert = True
					box.operator("wm.url_open", text="Download for: " + WebList[0] + ".X | v" + WebList[1]).url = "https://deodatopr.github.io/deostools/"

				else : 
					# Actualizado
					split.label (text= LocalList[0] + ".X", icon='BLENDER')
					split.label (text="v" + LocalList[1], icon='TOOL_SETTINGS')
					box.label (text="Using the latest one", icon='KEYTYPE_JITTER_VEC')
						
		else :
			# Sin Internet
			split.label (text= LocalList[0] + ".X", icon='BLENDER')
			split.label (text="v" + LocalList[1], icon='TOOL_SETTINGS')
			box.label (text="No Internet Connection", icon='KEYTYPE_EXTREME_VEC')
		
		# -----

		# [ Keymap Modes ]
		box.prop (mytool, "enum_Keymap_Mode", text="", icon="RESTRICT_VIEW_OFF")
		
		if bpy.context.scene.my_tool.enum_Keymap_Mode == "Op1" :
			bpy.context.preferences.keymap.active_keyconfig = 'Blender'
		
		elif bpy.context.scene.my_tool.enum_Keymap_Mode == "Op2" :
			bpy.context.preferences.keymap.active_keyconfig = 'Deos Tools'


# [BAKER MAPS]
class DeoPanelBakerMaps (Panel) :
	bl_idname = "DEOS_PT_BakerMap"
	bl_label = "BAKER TOOL"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "Deo's Tools"

	def draw(self, context) :
		mytool = context.scene.my_tool
		layout = self.layout
		box = layout.box()
		
		#enum Render Engine (Cycles/Eevee).
		box.prop (context.scene.render, "engine", text="")  	  
		
		#Enable Cycles
		if context.scene.render.engine == 'CYCLES' :	
			
			#Enum Device (CPU/GPU).
			box.prop(context.scene.cycles, "device", text="")    
			box = layout.box()
			
			# 0) Enum Baker Map Options - Op1
			box.prop (mytool, "enumBakerMapToolOptions", icon = "OPTIONS")

			# 1) Map to Map.
			if bpy.context.scene.my_tool.enumBakerMapToolOptions == 'Op1':  

				# Info 
				box.label (text="     [ Transfer a Map with a diff. 'UV Layout' ]")
				
				# Source / Target
				box.prop (mytool, "pickerSource", text="Source", icon="OBJECT_DATA")
				box.prop (mytool, "pickerTarget", text="Target", icon="NODE_COMPOSITING")

				split = box.column().split()
				split.operator("deo.bakermap_maptomap_shadersource", text="Add Source Mat", icon="MATERIAL_DATA")
				split.operator("deo.bakermap_maptomap_shadertarget", text="Add Target Mat", icon="MATERIAL_DATA")
	 
				# Isolate
				col = box.column()
				split = col.split()
				split.label (text="Isolate:")
				split.prop (mytool, "boolIsolateSource")
				split.prop (mytool, "boolIsolateTarget")
				
				#Baking Settings (Source to Target)
				box = layout.box()
				box.label (text="[ MAP SETTINGS ]", icon = "PREFERENCES")
				
				# UV Edge & Cage
				col = box.column()
				split = col.split()
				split.prop (context.scene.render.bake, "margin", text="Edge:")			#Margin
				split.prop (context.scene.render.bake, "cage_extrusion", text="Cage:")  #Extrusion
				# split.prop (context.scene.render.bake, "use_clear", text=" ", icon = "IMAGE_REFERENCE")	#Toggle Clear Image

				#Baker
				box = layout.box()
				box.scale_y = 1.5
				box.operator("deo.bakermap_maptomap_baker", text="BAKE:  'MAP TO MAP'", icon="TEXTURE")
				
			# 2) Map to Ver.
			if bpy.context.scene.my_tool.enumBakerMapToolOptions == 'Op2':
				
				# Info 
				box.label (text="        [ Transfer a Map to a 'VertexColor' ]")
				
				# Source / Target
				box.prop (mytool, "pickerSource", text="Source", icon="OBJECT_DATA")  
				box.prop (mytool, "pickerTarget", text="Target", icon="NODE_COMPOSITING")
	
				col = box.column()
				split = col.split()
				split.operator ("deo.bakermap_maptover_shadersource", text="Add Source Mat", icon="MATERIAL_DATA")
				split.operator ("deo.bakermap_maptover_shadertarget", text="Add Target Mat", icon="MATERIAL_DATA")

				# Isolate
				col = box.column()
				split = col.split()
				split.label (text="Isolate:")
				split.prop (mytool, "boolIsolateSource")
				split.prop (mytool, "boolIsolateTarget")

				
				# Layer Name + Baker Ver
				box = layout.box()
				box.scale_y = 1.25
				box.label (text="[ VERTEX LAYER ]", icon="FILE_HIDDEN") 
				box.prop (mytool, "strLayerMaptoVer", text="Name", icon="UV_VERTEXSEL")
				box.operator ("deo.bakermap_maptover_baker", text="BAKE:  'MAP TO VER'", icon="TEXTURE")

			# 3) Ver to Map.
			if bpy.context.scene.my_tool.enumBakerMapToolOptions == 'Op3':

				# Source / Target 
				box.label (text="           [ Transfer VertexColor to a 'Map' ]")
				box.prop (mytool, "pickerSource", text="Source", icon="OBJECT_DATA")  
				box.prop (mytool, "pickerTarget", text="Target", icon="NODE_COMPOSITING")
				
				col = box.column()
				split = col.split()  
				split.operator("deo.bakermap_vertomap_shadersource", text="Add Source Mat", icon="MATERIAL_DATA")
				split.operator("deo.bakermap_vertomap_shadertarget", text="Add Target Mat", icon="MATERIAL_DATA")
	
				# Isolate
				col = box.column()
				split = col.split()
				split.label (text="Isolate:")
				split.prop (mytool, "boolIsolateSource")
				split.prop (mytool, "boolIsolateTarget")
				
				#Baking Settings (Source to Target)
				box = layout.box()
				box.label (text="[ MAP SETTINGS ]", icon = "PREFERENCES")
	
				# UV Edge & Cage
				col = box.column()
				split = col.split()
				split.prop (context.scene.render.bake, "margin", text="Edge:")			#Margin
				split.prop (context.scene.render.bake, "cage_extrusion", text="Cage:")  #Extrusion
				# split.prop (context.scene.render.bake, "use_clear", text=" ", icon = "IMAGE_REFERENCE")	#Toggle Clear Image

				#Baker
				box = layout.box()
				box.scale_y = 1.5
				box.operator("deo.bakermap_vertomap_baker", text="BAKE:  'VER TO MAP'", icon="TEXTURE")

			# 4) IDColor to Map.
			if bpy.context.scene.my_tool.enumBakerMapToolOptions == 'Op4':

				# Info 
				box.label (text="   [ Transfer Multi-Mats 'Base Color to a Map' ]")
				
				# Source / Target 
				box.prop (mytool, "pickerSource", text="Source", icon="OBJECT_DATA")  
				box.prop (mytool, "pickerTarget", text="Target", icon="NODE_COMPOSITING")  
				box.operator("deo.bakermap_mattomap_shadertarget", text="Add Target Mat [ Template ]", icon="MATERIAL_DATA")
	
				# Isolate
				col = box.column()
				split = col.split()
				split.label (text="Isolate:")
				split.prop (mytool, "boolIsolateSource")
				split.prop (mytool, "boolIsolateTarget")
				
				#Baking Settings (Source to Target)
				box = layout.box()
				box.label (text="[ MAP SETTINGS ]", icon = "PREFERENCES")

				# UV Edge & Cage
				col = box.column()
				split = col.split()
				split.prop (context.scene.render.bake, "margin", text="Edge:")			#Margin
				split.prop (context.scene.render.bake, "cage_extrusion", text="Cage:")  #Extrusion
				# split.prop (context.scene.render.bake, "use_clear", text=" ", icon = "IMAGE_REFERENCE")	#Toggle Clear Image

				#Baker
				box = layout.box()
				box.scale_y = 1.5
				box.operator("deo.bakermap_mattomap_baker", text="BAKE:  'ID COLOR MAT'", icon="TEXTURE")

			# 5)Vertex Passes.
			if bpy.context.scene.my_tool.enumBakerMapToolOptions == 'Op5':

				# Info 
				box.label (text="    [ Transfer Custom Passes to a 'VertColor' ]")
				
				# Object Picker
				box.prop (mytool, "pickerVertex", text="High", icon="MOD_REMESH")   			
				
				# Botones Shader
				box.operator ("deo.bakermap_vertexpasses_shader", text = "Add Mesh Mat [ Template ]", icon = "SHADING_TEXTURE")
				
				# Layer Name + Baker Ver
				box = layout.box()
				box.label (text="[ VERTEX LAYER ]", icon="FILE_HIDDEN") 
				box.prop (mytool, "strLayerVertexPasses", text="Name", icon="UV_VERTEXSEL")
				
				box = layout.box()
				box.scale_y = 1.5
				box.operator ("deo.bakermap_vertexpasses_baker", text="BAKE:  'PASSES TO VERTEX'", icon="TEXTURE")
	
			# 6)Map Passes.
			if bpy.context.scene.my_tool.enumBakerMapToolOptions == 'Op6':
				
				# Info
				box.label (text="        [ Transfer Custom Passes to a 'Map' ]")

				# [ PICKERS ]
				box.prop (mytool, "enumBakerMapToolBakerType", text="Baker", icon="PROPERTIES")
				box.prop (mytool, "pickerHigh", text="High", icon="FILE_VOLUME")		# Collection Picker
				box.prop (mytool, "pickerLow", text="Low", icon="FILE_3D")  			# Object Picker
				

				# [ BOTON(S) MATERIAL(ES) ]
				if bpy.context.scene.my_tool.enumBakerMapToolBakerType == "Op1" :
					box.operator ("deo.bakermap_passes_shaderlow",  text = "Add Low Mat [ Template ]", icon = "SHADING_TEXTURE")
					imageBakeName = "NORMAL MAP"	# Texture Name default 
				
				if bpy.context.scene.my_tool.enumBakerMapToolBakerType == "Op2" :
					col = box.column()
					split = col.split()
					split.operator ("deo.bakermap_passes_shaderhigh", text = "Add High Mat", icon = "SHADING_RENDERED")
					split.operator ("deo.bakermap_passes_shaderlow",  text = "Add Low Mat", icon = "SHADING_TEXTURE")


				# [ ISOLATES ]
				split = box.column().split()

				split.label (text="Isolate:")
				split.prop (mytool, "boolIsolateHigh")
				split.prop (mytool, "boolIsolateLow")
	

				# [ SHADER PASS SETTINGS ]
				
				if bpy.context.scene.my_tool.enumBakerMapToolBakerType == "Op2" :
					box = layout.box()
					box.label (text="[ SHADER PASS  SETTINGS ]", icon = "SHADING_RENDERED")
					
					# Toggle Cycles
					if bpy.context.scene.my_tool.enumBakerMapPassType == "Op1" :
							box.prop (mytool, "enumBakerMapPassType", text="Pass", icon="RENDERLAYERS")

					elif bpy.context.scene.my_tool.enumBakerMapPassType != "Op1" :
						colSplited = box.column().split(factor = 0.88)
						colSplited.prop (mytool, "enumBakerMapPassType", text="Pass", icon="RENDERLAYERS")
						colSplited.prop (mytool, "boolUseCyclesVieport", text="", icon="MATSHADERBALL")
					

					 # Shader Pass: Properties
					if bpy.context.scene.my_tool.enumBakerMapPassType == "Op1" :
						imageBakeName = ""

					elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op2" :
						box.prop (mytool, "SldrCurvatureIntensity", text="Intensity")
						imageBakeName = "CURVATURE MAP"

					elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op3" :
						box.prop (mytool, "SldrCurvatureIntensity", text="Intensity")
						imageBakeName = "CURVATURE MAP"

					elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op4" :
						box.prop (mytool, "SldrAO_Distance", text="Distance")
						box.prop (mytool, "SldrAO_Intensity", text="Intensity")
						imageBakeName = "AMBIENT OCCLUSION MAP"

					elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op5" :
						box.prop (mytool, "SldrPosition_Offset", text="Offset")
						box.prop (mytool, "SldrPosition_AddTopNormals", text="Add Top Normals")
						imageBakeName = "POSITION MAP"

					elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op6" :
						box.prop (mytool, "SldrDustOnTop", text="Tilt Face")
						imageBakeName = "DUST MAP"

					elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op7" :
						box.prop (mytool, "SldrThickness_Distance", text="Distance")                 
						box.prop (mytool, "SldrThickness_Balance", text="Balance")                 
						imageBakeName = "THICKNESS MAP"

					elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op8" :
						box.prop (mytool, "SldrCavity", text="Intensity") 
						imageBakeName = "CAVITY MAP"


				# [ BAKE NORMAL MAP ]
				if bpy.context.scene.my_tool.enumBakerMapToolBakerType  == "Op1":
					
					# [ MAP SETTINGS ]
					box = layout.box()
					box.label (text="[ MAP  SETTINGS ]", icon = "PREFERENCES")

					# Texture Name
					col = box.column()
					split = col.split(factor = 0.25)
					split.label (text="Name:")		
					split.label (text=imageBakeName)


					# Texture Size
					col.prop (mytool, "enumBakerMapPassMapSettingSize", text='Size', icon = "IMAGE_PLANE")
					
					# UV Edge & Cage
					col = box.column()
					split = col.split()
					split.prop (context.scene.render.bake, "margin", text="Edge:")			#Margin
					split.prop (context.scene.render.bake, "cage_extrusion", text="Cage:")  #Extrusion
					# split.prop (context.scene.render.bake, "use_clear", text=" ", icon = "IMAGE_REFERENCE")	#Toggle Clear Image


					# BAKE: NormalMap / SAVE
					box = layout.box()
					box.scale_y = 1.5
					col = box.column()

					split = col.split(factor = 0.8)
					split.operator ("deo.bakermap_type_normalmap", text="BAKE NORMAL MAP", icon="TEXTURE") 
					split.operator ("deo.bakermap_savemaps", text="", icon="FILE_TICK")


				# [ BAKE PASS MAP ]
				if bpy.context.scene.my_tool.enumBakerMapToolBakerType == "Op2" and bpy.context.scene.my_tool.enumBakerMapPassType != "Op1" :

					# [ MAP SETTINGS ]
					box = layout.box()
					box.label (text="[ MAP  SETTINGS ]", icon = "PREFERENCES")

					# Texture Name
					col = box.column()
					split = col.split(factor = 0.25)
					split.label (text="Name:")		
					split.label (text=imageBakeName)


					# Texture Size
					col.prop (mytool, "enumBakerMapPassMapSettingSize", text='Size', icon = "IMAGE_PLANE")
					
					# UV Edge & Cage
					col = box.column()
					split = col.split()
					split.prop (context.scene.render.bake, "margin", text="Edge:")			#Margin
					split.prop (context.scene.render.bake, "cage_extrusion", text="Cage:")  #Extrusion
					# split.prop (context.scene.render.bake, "use_clear", text=" ", icon = "IMAGE_REFERENCE")	#Toggle Clear Image
				
					# BAKE: NormalMap / SAVE
					box = layout.box()
					box.scale_y = 1.5
					col = box.column()

					split = col.split(factor = 0.8)
					split.operator ("deo.bakermap_type_passmap", text="BAKE PASS MAP", icon="TEXTURE") 
					split.operator ("deo.bakermap_savemaps", text="", icon="FILE_TICK")

		else:
			box.label (text="  [ Enable 'Cycles' to use the Tool ]")

# [EXPORTER MAPS]
class DeoPanelExporterMaps (Panel) :
	bl_idname = "DEOS_PT_ExporterMap"
	bl_label = "EXPORTER MAPS"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "Deo's Tools"

	def draw(self, context) :
		mytool = context.scene.my_tool
		layout = self.layout
		
		#enum Render Engine (Cycles/Eevee).
		box = layout.box()
		box.prop (context.scene.render, "engine", text="")  	  

		#Enable Cycles
		if context.scene.render.engine == 'CYCLES' :	
			
			#Enum Device (CPU/GPU).
			box.prop(context.scene.cycles, "device", text="")    

			# Mesh
			box = layout.box()
			box.label (text="[ MESH TO EXPORT MAPS ]", icon = "CUBE")
			box.prop (mytool, "picker_ExporterMap_High", text="", icon="FILE_3D")					# Picker Mesh + Shading  

			# Settingss
			box = layout.box()
			box.label (text="[ SELECT MAP(S) TO EXPORT ]", icon = "RENDERLAYERS")
			
			col = box.column()
			col.prop (mytool, "bool_ExporterMap_Color", text="Base Color (RGB) + Alpha (A)", icon = "EVENT_B")

			col = box.column().split()
			col.prop (mytool, "bool_ExporterMap_Metallic", text="Metallic", icon = "EVENT_M")
			col.prop (mytool, "bool_ExporterMap_Roughness", text="Roughness", icon = "EVENT_R")
			col = box.column().split()
			col.prop (mytool, "bool_ExporterMap_Normal", text="Normal", icon = "EVENT_N")
			col.prop (mytool, "bool_ExporterMap_Emission", text="Emission", icon = "EVENT_E")

			# Maps
			box = layout.box()
			box.label (text="[ MAP SETTINGS ]", icon = "IMAGE_DATA")
			colFact = box.column().split(factor = 0.87)
			
			if bpy.context.scene.my_tool.bool_ExporterMap_MeshName :
				colFact.prop (mytool, "str_ExporterMap_FileNameMesh", text="Name", emboss=False)			# NameFile: Custom 
				colFact.prop (mytool, "bool_ExporterMap_MeshName", text="", icon='RESTRICT_SELECT_OFF')		# NameFile: Mesh
			else :
				colFact.prop (mytool, "str_ExporterMap_FileNameCustom", text="Name", emboss=True)			# NameFile: Custom 
				colFact.prop (mytool, "bool_ExporterMap_MeshName", text="", icon='RESTRICT_SELECT_OFF')		# NameFile: Mesh

			colFact = box.column().split(factor = 0.75)
			colFact.prop (mytool, "enum_ExporterMap_ImgSize", text="Image")									# Image Size
			colFact.prop (mytool, "enum_ExporterMap_ImgFormat", text="")									# Image Format
			
			box.prop (mytool, "enum_ExporterMap_edgePadding", text="Edge" )									# UV Edge
			
			# File Map(s) Name
			colFact = box.column().split(factor = 1)
			colFact.prop (mytool, "str_ExporterMap_PathDir", text="Path")									# Path Texture

			# Exporter
			box = layout.box()
			box.scale_y = 1.5
			box.operator ("deo.exportermap_batch", text="EXPORT MAPS", icon="EXPORT")


		else:

			box.label (text="  [ Enable 'Cycles' to use the Tool ]")

# [SCULPT ORBRUSHES]
class DeosPanelSculptORBrushes (Panel) :
	bl_idname = "DEOS_PT_SculptORBrushes"
	bl_label = "SCULPT ORBRUSHES"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "Deo's Tools"
	
	def draw(self, context) :
		layout = self.layout

		colFact = layout.box().column().split(factor = 0.8, align=True)
		colFact.operator("deo.sculpt_orbrushes_add",   text="ADD BRUSHES", icon="BRUSH_TEXDRAW")
		colFact.operator("deo.sculpt_orbrushes_del", text="", icon="TRASH")

# [TEXTURING NODES]
class DeosPanelTextureNodes (Panel) :
	bl_idname = "DEOS_PT_TextureNodes"
	bl_label = "TEXTURE NODES"
	bl_space_type = "NODE_EDITOR"
	bl_region_type = "UI"
	bl_category = "Deo's Tools"
	scale_popup=8
	def draw(self, context) :
		mytool = context.scene.my_tool
		layout = self.layout

	# ReConnect BSDF Mat
		box = layout.box()
		box.scale_y = 1.8
		box.operator("deo.texture_nodes_master", text= "RE-CONNECT BSDF MAT", icon="NODE_SEL")
		
	# Library Tools
		box = layout.box()
		cols = box.column().split(factor= 0.8, align=True)
		cols.scale_y=1.5
		cols.label (text='LIBRARY:', icon="NODETREE")
		cols.operator("deo.texture_nodes_update", text= "", icon="DECORATE_LINKED")

		grids = box.grid_flow(row_major=True, columns=2, align=True)
		
		grids.template_icon_view(mytool, "enum_TextureNodes_Materials", show_labels=True, scale=6, scale_popup=8)
		grids.template_icon_view(mytool, "enum_TextureNodes_Tools", show_labels=True, scale=6, scale_popup=8)
		grids.label (text='MATERIALS')
		grids.label (text='TOOLS')

		grids.template_icon_view(mytool, "enum_TextureNodes_Blends", show_labels=True, scale=6, scale_popup=8)
		grids.template_icon_view(mytool, "enum_TextureNodes_Editors", show_labels=True, scale=6, scale_popup=8)
		grids.label (text='BLENDS')
		grids.label (text='EDITORS')

		grids.template_icon_view(mytool, "enum_TextureNodes_UVs", show_labels=True, scale=6, scale_popup=8)
		grids.template_icon_view(mytool, "enum_TextureNodes_Normals", show_labels=True, scale=6, scale_popup=8)
		grids.label (text='UVS')
		grids.label (text='NORMALS')

		grids.template_icon_view(mytool, "enum_TextureNodes_Generators", show_labels=True, scale=6, scale_popup=8)
		grids.template_icon_view(mytool, "enum_TextureNodes_Masks", show_labels=True, scale=6, scale_popup=8)
		grids.label (text='GENERATORS')
		grids.label (text='SMART MASKS')


#-----------------------------------------------------------------------------------------------
# REGISTRATIONS
#-----------------------------------------------------------------------------------------------
	
DeosClasses = (
	# ------------------------
	# PROPERTIES (INIT)  
	# ------------------------
	DeosPropertyGroup, 

	# ------------------------
	# PANELS (INIT)
	# ------------------------
	DeosPanelEmpty,
	DeosPanelUpdater,
	DeoPanelBakerMaps,
	DeoPanelExporterMaps,
	DeosPanelSculptORBrushes,
	DeosPanelTextureNodes,

	# ------------------------
	# OPERATORS (EXTERNAL)
	# ------------------------
	
	# BakerMap: 1) Map to Map
	DeosOperBakermapMaptoMapShaderSource,
	DeosOperBakermapMaptoMapShaderTarget,
	DeosOperBakermapMaptoMapBaker,
	
	# BakerMap: 2) Map to Ver
	DeosOperBakermapMaptoVerShaderSource,
	DeosOperBakermapMaptoVerShaderTarget,
	DeosOperBakermapMaptoVerBaker,

	# BakerMap: 3) Ver to Map
	DeosOperBakermapVertoMapShaderSource,
	DeosOperBakermapVertoMapShaderTarget,
	DeosOperBakermapVertoMapBaker,
	
	# BakerMap: 4) Material Pass
	DeosOperBakermapMattoMapShaderTarget,
	DeosOperBakermapMattoMapBaker,

	# BakerMap: 5) Vertex Passes
	DeosOperBakermapVertexPassesShader,
	DeosOperBakermapVertexPassesBaker,
	
	# BakerMap: 6) Map Passes
	DeosOperBakermapPassesShaderHigh,
	DeosOperBakermapPassesShaderLow,
	DeosOperBakermapTypeNormalMap,
	DeosOperBakermapTypePassMap,
	DeosOperBakermapSaveMaps,

	# Exporter Map
	DeosOperExporterMapBatch,

	# Sculpt ORBrushes
	DeosOperSculptORBrushesAdd,
	DeosOperSculptORBrushesDel,

	# Texture Nodes
	DeosOperTextureNodeUpdate,
	DeosOperTextureNodeMaster,
)


def register(): 

	# Registrar Classes
	from bpy.utils import register_class
	for myClasses in DeosClasses : 
		register_class(myClasses)

	# Registrar propiedades: mytool y custom icons
	bpy.types.Scene.my_tool = PointerProperty(type = DeosPropertyGroup) 

def unregister():
	
	# Desregistrar Classes
	from bpy.utils import unregister_class  
	for myClasses in reversed(DeosClasses) : 
		unregister_class(myClasses)

	# Eliminar propiedades: mytool y custom icons
	del bpy.types.Scene.my_tool
	previews.remove(IconLibrary)

if __name__ == "__main__" : register()	