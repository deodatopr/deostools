import bpy
import functools 	# FuncionsToWait
import time			#time.sleep(2) wait

# Operators
from bpy.types import Operator


#-----------------------------#
#      	 DEFINITIONS  		  #
#-----------------------------#



# [ SELECT BAKER SETTINGS ] -----------------------------------------------

def updateEnumBakermapBaketype(self, context):

	# Combined (1-Map to Map + Alpha)
	if self.enumBakerMapToolOptions == "Op1":  #Get from _init_
		# Activar Sel to Act (High+Low)
		bpy.context.scene.render.bake.use_selected_to_active = True
		bpy.context.scene.cycles.bake_type = 'COMBINED'
		bpy.context.scene.render.bake.use_pass_direct = False
		bpy.context.scene.render.bake.use_pass_indirect = False
		bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
		bpy.context.scene.render.bake.max_ray_distance = 0
		bpy.context.scene.cycles.use_denoising = False


	# Emit & Vertex (2-Map to Ver)
	elif self.enumBakerMapToolOptions == "Op2":  #Get from _init_
		# Activar Sel to Act (High+Low)
		bpy.context.scene.render.bake.use_selected_to_active = True
		bpy.context.scene.cycles.bake_type = 'EMIT'
		bpy.context.scene.render.bake.target = 'VERTEX_COLORS'
		bpy.context.scene.render.bake.max_ray_distance = 0
		bpy.context.scene.cycles.use_denoising = False


	# Emit & Texture (Ver to Map)
	elif self.enumBakerMapToolOptions == "Op3" or self.enumBakerMapToolOptions == "Op0":  #Get from _init_
		# Activar Sel to Act (High+Low)
		bpy.context.scene.render.bake.use_selected_to_active = True
		bpy.context.scene.cycles.bake_type = 'EMIT'
		bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
		bpy.context.scene.render.bake.max_ray_distance = 0
		bpy.context.scene.cycles.use_denoising = False


	# Diffuse (4-IDColors to Map)
	elif self.enumBakerMapToolOptions == "Op4":  #Get from _init_
		# Activar Sel to Act (High+Low)
		bpy.context.scene.render.bake.use_selected_to_active = True
		bpy.context.scene.cycles.bake_type = 'DIFFUSE'
		bpy.context.scene.render.bake.use_pass_direct = False
		bpy.context.scene.render.bake.use_pass_indirect = False
		bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
		bpy.context.scene.render.bake.max_ray_distance = 0
		bpy.context.scene.cycles.use_denoising = False


	# Baker Passes (5-High-Low)
	elif self.enumBakerMapToolOptions == "Op5":
		# Desactivar Sel to Act (Mesh)
		bpy.context.scene.cycles.bake_type = 'EMIT'
		bpy.context.scene.render.bake.use_selected_to_active = True
		bpy.context.scene.render.bake.target = 'VERTEX_COLORS'
		bpy.context.scene.render.bake.max_ray_distance = 0
		bpy.context.scene.cycles.use_denoising = False

	# Baker Mesh (6-Vertex Passes)
	elif self.enumBakerMapToolOptions == "Op6":
		if self.enumBakerMapToolBakerType == "Op1":  #Get from _init_
			# Activar Sel to Act (High+Low)
			bpy.context.scene.cycles.bake_type = 'NORMAL'
			bpy.context.scene.render.bake.use_selected_to_active = True
			bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
			bpy.context.scene.render.bake.max_ray_distance = 0
			bpy.context.scene.cycles.use_denoising = False

		elif self.enumBakerMapToolBakerType == "Op2":  #Get from _init_
			# Activar Sel to Act (High+Low)
			bpy.context.scene.render.bake.use_selected_to_active = True
			bpy.context.scene.cycles.bake_type = 'EMIT'
			bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
			bpy.context.scene.render.bake.max_ray_distance = 0
			bpy.context.scene.cycles.use_denoising = False


									 

# [ ISOLATES ] ----------------------------------------------------------


# Source
def updateIsolateSource(self, context):

	if self.boolIsolateSource:  # Bool de _INIT_

		# Cambiar Toogle TARGET
		self.boolIsolateTarget = False

		# Seleccion Mesh y Activacion en Paneles
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')
		bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)      # Seleccionar Mesh del Picker

		SelObjPicker = bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name]
		# Activar Mesh del Picker en paneles.
		bpy.context.view_layer.objects.active = SelObjPicker
		# SelObjPicker.select_set(True)

		# Isolate Mesh
		# Ahislar seleccion sin mover vista
		bpy.ops.view3d.localview(frame_selected=False)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')

	elif not self.boolIsolateSource:  # Bool de _INIT_

		# Ahislar seleccion sin mover vista
		bpy.ops.view3d.localview(frame_selected=False)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')

# Target
def updateIsolateTarget(self, context):

	if self.boolIsolateTarget:  # Bool de _INIT_

		# Cambiar Toogle TARGET
		self.boolIsolateSource = False

	
		bpy.ops.object.select_all(action='DESELECT')
		
		# Seleccionar Mesh del Picker y activar mesh en la vista del editor shader
		bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)      
		SelObjPicker = bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name]
		bpy.context.view_layer.objects.active = SelObjPicker
		# SelObjPicker.select_set(True)

		# Isolate Mesh
		# Ahislar seleccion sin mover vista
		bpy.ops.view3d.localview(frame_selected=False)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')

	elif not self.boolIsolateTarget:  # Bool de _INIT_

		# Ahislar seleccion sin mover vista
		bpy.ops.view3d.localview(frame_selected=False)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')



# [ BAKER TYPES ] -----------------------------------------------

# Bake Normal
def Call_BakeMap_Normal() :
	bpy.ops.object.bake('INVOKE_DEFAULT', type='NORMAL')
	bpy.ops.object.select_all(action='DESELECT')
	
# Bake Emision
def Call_BakeMap_Emit() :
	bpy.ops.object.bake('INVOKE_DEFAULT', type='EMIT')
	bpy.ops.object.select_all(action='DESELECT')

# Bake Diffuse
def Call_BakeMap_Diffuse() :
	bpy.ops.object.bake('INVOKE_DEFAULT', type='DIFFUSE')
	bpy.ops.object.select_all(action='DESELECT')



# -----------------------------------------------#
# 1) MAP TO MAP (Combined - RBG+A)         		 #
# -----------------------------------------------#

# Shader - Source
class DeosOperBakermapMaptoMapShaderSource (Operator):
	bl_idname = "deo.bakermap_maptomap_shadersource"
	bl_label = ""
	bl_description = "Add the Source Material Template [Map to Map]"

	def execute(self, context):

		# ------------------------
		# SIN SOURCE MESH
		# ------------------------
		if bpy.context.scene.my_tool.pickerSource == None:

			self.report({'WARNING'}, "[There is No Source mesh loaded]")

		else:

			# ------------------------
			# NO EXISTE EL MATERIAL
			# ------------------------
			if bpy.data.materials.get("Deo's [Source - Map to Map]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Source - Map to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Source
				bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Source - Map to Map]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Source Mesh has No material added]")

			else:

				# ------------------------
				# SI EXISTE EL MATERIAL
				# ------------------------

				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(bpy.data.materials.get("Deo's [Source - Map to Map]"))
				bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=False)

				# ------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Source - Map to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Source
				bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Source - Map to Map]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Source Mesh has No material added]")
		
		return {'FINISHED'}


# Shader - Target
class DeosOperBakermapMaptoMapShaderTarget (Operator):
	bl_idname = "deo.bakermap_maptomap_shadertarget"
	bl_label = ""
	bl_description = "Add the Target Material Template [Map to Map]"

	def execute(self, context):

		# ------------------------
		# SIN SOURCE MESH
		# ------------------------
		if bpy.context.scene.my_tool.pickerSource == None:

			self.report({'WARNING'}, "[There is No Target mesh loaded]")
			return {'FINISHED'}

		else:

			# ------------------------
			# NO EXISTE EL MATERIAL
			# ------------------------
			if bpy.data.materials.get("Deo's [Target - Map to Map]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Target - Map to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Target - Map to Map]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Target mesh has No material added]")
				return {'FINISHED'}

			else:

				# ------------------------
				# SI EXISTE EL MATERIAL
				# ------------------------

				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(bpy.data.materials.get("Deo's [Target - Map to Map]"))
				bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
				# ------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Target - Map to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Target - Map to Map]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Target mesh has No material added]")
				return {'FINISHED'}


# Bake: Map to Map
class DeosOperBakermapMaptoMapBaker (Operator):
	bl_idname = "deo.bakermap_maptomap_baker"
	bl_label = ""
	bl_description = "Bake Map(RGBA/R,G,B) to one Map (RGBA)"

	def execute(self, context):

		if bpy.context.scene.my_tool.pickerTarget == None or bpy.context.scene.my_tool.pickerSource == None:

			# Info - Sin Meshes Source o Target
			self.report({'WARNING'}, "[Load the 'Source & Target Meshes]")
		else :
			# Mesh Loaded, mats?
			v_SelectedHighMesh = bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name]
			bpy.context.view_layer.objects.active = v_SelectedHighMesh
		
			if len(bpy.context.active_object.data.materials) == 0:
				self.report({'WARNING'}, "[The loaded 'Meshes has NO Materials' added]")

			else:
				# Bake Settings
				bpy.context.scene.cycles.bake_type = 'EMIT'
				bpy.context.scene.render.bake.use_selected_to_active = True
				bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES' 		# 'VERTEX_COLORS'
				bpy.context.scene.render.bake.margin_type = 'ADJACENT_FACES'  	# 'EXTENDED'
			

				# Limpiar cualquier tipo de seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# Selecionar Source Mesh y Target Mesh al final para dejarlo activo en el visor/panels.
				bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)
				bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)

				# Activar Target en Panel 3D (Muestre opciones).
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				bpy.app.timers.register( Call_BakeMap_Emit )

		return {'FINISHED'}



# -----------------------------------------------#
# 2) MAP TO VER (Emit in Vertex)                 #
# -----------------------------------------------#


# Shader:Source
class DeosOperBakermapMaptoVerShaderSource (Operator):
	bl_idname = "deo.bakermap_maptover_shadersource"
	bl_label = ""
	bl_description = "Add the Source Material Template [Map to Vert]"

	def execute(self, context):

		# ------------------------
		# SIN SOURCE MESH
		# ------------------------
		if bpy.context.scene.my_tool.pickerSource == None:

			self.report({'WARNING'}, "[There is No Source mesh loaded]")
			return {'FINISHED'}

		else:

			# ------------------------
			# NO EXISTE EL MATERIAL
			# ------------------------
			if bpy.data.materials.get("Deo's [Source - Map to Ver]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Source - Map to Ver]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Source
				bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Source - Map to Ver]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Source Mesh has No Material added]")
				return {'FINISHED'}

			else:

				# ------------------------
				# SI EXISTE EL MATERIAL
				# ------------------------

				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(bpy.data.materials.get("Deo's [Source - Map to Ver]"))
				bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=False)

				# ------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Source - Map to Ver]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Source
				bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Source - Map to Ver]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Source Mesh has No Material added]")
				return {'FINISHED'}


# Shader: Target
class DeosOperBakermapMaptoVerShaderTarget (Operator):
	bl_idname = "deo.bakermap_maptover_shadertarget"
	bl_label = ""
	bl_description = "Add the Target Material Template [Map to Vert]"

	def execute(self, context):

		# ------------------------
		# SIN SOURCE MESH
		# ------------------------
		if bpy.context.scene.my_tool.pickerSource == None:

			self.report({'WARNING'}, "[There is No Target mesh loaded]")
			return {'FINISHED'}

		else:

			# ------------------------
			# NO EXISTE EL MATERIAL
			# ------------------------
			if bpy.data.materials.get("Deo's [Target - Map to Ver]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Target - Map to Ver]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Target - Map to Ver]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Target Mesh has No Material added]")
				return {'FINISHED'}

			else:

				# ------------------------
				# SI EXISTE EL MATERIAL
				# ------------------------

				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(
					bpy.data.materials.get("Deo's [Target - Map to Ver]"))
				bpy.ops.outliner.orphans_purge(
					do_local_ids=True, do_linked_ids=True, do_recursive=True)
				# ------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Target - Map to Ver]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path(
					'USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(
					True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get(
					"Deo's [Target - Map to Ver]"))      # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report(
					{'INFO'}, "[The Target Mesh has No Material added]")
				return {'FINISHED'}


# Bake: Map to Ver
class DeosOperBakermapMaptoVerBaker (Operator):
	bl_idname = "deo.bakermap_maptover_baker"
	bl_label = ""
	bl_description = "Bake Map (Suorce) to Vertex Color (Target)"

	def execute(self, context):

		if bpy.context.scene.my_tool.pickerTarget == None or bpy.context.scene.my_tool.pickerSource == None:

			# Info - Sin Meshes Source o Target
			self.report({'WARNING'}, "[Load the 'Source & Target Meshes]")
		else :
			# Mesh Loaded, mats?
			v_SelectedHighMesh = bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name]
			bpy.context.view_layer.objects.active = v_SelectedHighMesh
		
			if len(bpy.context.active_object.data.materials) == 0:
				self.report({'WARNING'}, "[The Target Mesh has No Material added]")

			else:

				# Bake Settings
				bpy.context.scene.cycles.bake_type = 'EMIT'
				bpy.context.scene.render.bake.use_selected_to_active = True
				bpy.context.scene.render.bake.target = 'VERTEX_COLORS'

				# Limpiar cualquier tipo de seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# Seleccionar Target Mesh
				bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]

				# Borrar el ultimo Layer, si existe alguno
				if bpy.context.object.data.color_attributes :
					bpy.ops.geometry.color_attribute_remove()
					# bpy.ops.geometry.attribute_remove()
					
				# Crear Atribute Layer y renombrarlo
				#bpy.context.object.data.attributes['Color'].name = bpy.context.scene.my_tool.strLayerVertexPasses   #Renombrar por nombre
				bpy.ops.geometry.color_attribute_add(name=bpy.context.scene.my_tool.strLayerMaptoVer, domain='CORNER', data_type='BYTE_COLOR')
				

				# Selecion Target Mesh
				bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)

				# Activar Target en Panel 3D (Muestre opciones).
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)


				bpy.app.timers.register( Call_BakeMap_Emit )

		return {'FINISHED'}
				

# -----------------------------------------------#
# 3) VER TO MAP (Emit in Map)                    #
# -----------------------------------------------#


# Shader: Source
class DeosOperBakermapVertoMapShaderSource (Operator):
	bl_idname = "deo.bakermap_vertomap_shadersource"
	bl_label = ""
	bl_description = "Add the Source Material Template [Vert to Map]"

	def execute(self, context):

		# ------------------------
		# SIN SOURCE MESH
		# ------------------------
		if bpy.context.scene.my_tool.pickerSource == None:

			self.report({'WARNING'}, "[There is No Source mesh loaded]")
			return {'FINISHED'}

		else:

			# ------------------------
			# NO EXISTE EL MATERIAL
			# ------------------------
			if bpy.data.materials.get("Deo's [Source - Ver to Map]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Source - Ver to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path(
					'USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Source
				bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(
					True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get(
					"Deo's [Source - Ver to Map]"))      # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report(
					{'INFO'}, "[The Source Mesh has No Material added]")
				return {'FINISHED'}

			else:

				# ------------------------
				# SI EXISTE EL MATERIAL
				# ------------------------

				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(
					bpy.data.materials.get("Deo's [Source - Ver to Map]"))
				bpy.ops.outliner.orphans_purge(
					do_local_ids=True, do_linked_ids=True, do_recursive=False)

				# ------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Source - Ver to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path(
					'USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Source
				bpy.data.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(
					True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get(
					"Deo's [Source - Ver to Map]"))      # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report(
					{'INFO'}, "[The Source Mesh has No Material added]")
				return {'FINISHED'}


# Shader: Target
class DeosOperBakermapVertoMapShaderTarget (Operator):

	bl_idname = "deo.bakermap_vertomap_shadertarget"
	bl_label = ""
	bl_description =  "Add the Target Material Template [Vert to Map]"

	def execute(self, context):

		# ------------------------
		# SIN SOURCE MESH
		# ------------------------
		if bpy.context.scene.my_tool.pickerSource == None:

			self.report({'WARNING'}, "[There is No Target mesh loaded]")
			return {'FINISHED'}

		else:

			# ------------------------
			# NO EXISTE EL MATERIAL
			# ------------------------
			if bpy.data.materials.get("Deo's [Target - Ver to Map]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Target - Ver to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Target - Ver to Map]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Target Mesh has No Material added]")
				return {'FINISHED'}

			else:

				# ------------------------
				# SI EXISTE EL MATERIAL
				# ------------------------

				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(
					bpy.data.materials.get("Deo's [Target - Ver to Map]"))
				bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
				# ------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Target - Ver to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Target - Ver to Map]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Target Mesh has No Material added]")
				return {'FINISHED'}


# Bake: Ver to Map
class DeosOperBakermapVertoMapBaker (Operator):
	bl_idname = "deo.bakermap_vertomap_baker"
	bl_label = ""
	bl_description = "Bake Vertex Color (Information) into a Map(RGB)"

	def execute(self, context):

		if bpy.context.scene.my_tool.pickerTarget == None or bpy.context.scene.my_tool.pickerSource == None:
			self.report({'WARNING'}, "[The Source/Target Mesh(es) are not loaded]")
		else :
			v_SelectedHighMesh = bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name]
			bpy.context.view_layer.objects.active = v_SelectedHighMesh
		
			if len(bpy.context.active_object.data.materials) == 0:
				self.report({'WARNING'}, "[The 'Target Mesh has NO Material' added]")

			else:
				# Bake Settings
				bpy.context.scene.cycles.bake_type = 'EMIT'
				bpy.context.scene.render.bake.use_selected_to_active = True
				bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES' 		# 'VERTEX_COLORS'
				bpy.context.scene.render.bake.margin_type = 'ADJACENT_FACES'  	# 'EXTENDED'


				# Limpiar cualquier tipo de seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# Selecionar Source Mesh y Target Mesh al final para dejarlo activo en el visor/panels.
				bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)
				bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)

				# Activar Target en Panel 3D (Muestre opciones).
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				
				bpy.app.timers.register( Call_BakeMap_Emit )

		return {'FINISHED'}



# -----------------------------------------------#
# 4) IDCOLOR TO MAP (Diffuse>Color in Map)       #
# -----------------------------------------------#


# Shader: Target
 
class DeosOperBakermapMattoMapShaderTarget (Operator):

	bl_idname = "deo.bakermap_mattomap_shadertarget"
	bl_label = ""
	bl_description =  "Add the Target Material Template [ID Color]"

	def execute(self, context):

		# ------------------------
		# SIN SOURCE MESH
		# ------------------------
		if bpy.context.scene.my_tool.pickerSource == None:

			self.report({'WARNING'}, "[There is No Target mesh loaded]")
			return {'FINISHED'}

		else:

			# ------------------------
			# NO EXISTE EL MATERIAL
			# ------------------------
			if bpy.data.materials.get("Deo's [Target - Mat to Map]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Target - Mat to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Target - Mat to Map]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Target Mesh has No Material added]")
				return {'FINISHED'}

			else:

				# ------------------------
				# SI EXISTE EL MATERIAL
				# ------------------------

				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(
					bpy.data.materials.get("Deo's [Target - Mat to Map]"))
				bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
				# ------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [Target - Mat to Map]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(
					True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [Target - Mat to Map]"))    # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The Target Mesh has No Material added]")
				return {'FINISHED'}


# Bake: ID Color
class DeosOperBakermapMattoMapBaker (Operator):
	bl_idname = "deo.bakermap_mattomap_baker"
	bl_label = ""
	bl_description = "Bake Materials Color into a Map (ID)"

	def execute(self, context):

		if bpy.context.scene.my_tool.pickerTarget == None or bpy.context.scene.my_tool.pickerSource == None:
			# Info - Sin Meshes Source o Target
			self.report({'WARNING'}, "[The Source/Target Mesh(es) are not loaded]")

		else :
			# Mesh Loaded, mats?
			v_SelectedHighMesh = bpy.data.objects[bpy.context.scene.my_tool.pickerTarget.name]
			bpy.context.view_layer.objects.active = v_SelectedHighMesh
		
			if len(bpy.context.active_object.data.materials) == 0:
				self.report({'WARNING'}, "[The loaded 'Meshes has NO Materials' applied]")
			
			else:

			# Bake Settings
				bpy.context.scene.cycles.bake_type = 'DIFFUSE'
				bpy.context.scene.render.bake.use_pass_direct = False
				bpy.context.scene.render.bake.use_pass_indirect = False
				bpy.context.scene.render.bake.use_pass_color = True
				bpy.context.scene.render.bake.use_selected_to_active = True
				bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES' 		# 'VERTEX_COLORS'
				bpy.context.scene.render.bake.margin_type = 'ADJACENT_FACES'  	# 'EXTENDED'

				# Limpiar cualquier tipo de seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# Selecionar Source Mesh y Target Mesh al final para dejarlo activo en el visor/panels.
				bpy.context.scene.objects[bpy.context.scene.my_tool.pickerSource.name].select_set(True)
				bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name].select_set(True)

				# Activar Target en Panel 3D (Muestre opciones).
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerTarget.name]
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				bpy.app.timers.register( Call_BakeMap_Diffuse )
	
		return {'FINISHED'}



# -----------------------------------------------#
# 5) BAKER MESH VERTEX (Emit in Vertex)          #
# -----------------------------------------------#

# Shader: Mesh Vertex
class DeosOperBakermapVertexPassesShader (Operator):
	bl_idname = "deo.bakermap_vertexpasses_shader"
	bl_label = ""
	bl_description =  "Add the Mesh Vertex Material [Shader Passes]"

	def execute(self, context):
		# ------------------------
		# SIN MESH VERTEX
		# ------------------------
		if bpy.context.scene.my_tool.pickerVertex == None:

			self.report({'WARNING'}, "[There is No Mesh loaded to add Material]")
			return {'FINISHED'}

		else:

			# ------------------------
			# NO EXISTE EL MATERIAL
			# ------------------------
			if bpy.data.materials.get("Deo's [MeshVertex Passes]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [MeshVertex Passes]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# seleccionar Mesh Vertex desde Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerVertex.name]
				
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				#Agregar y asignarle el Material
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [MeshVertex Passes]"))      # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The MeshVertex was added Material]")
				return {'FINISHED'}

			else:

				# ------------------------
				# SI EXISTE EL MATERIAL
				# ------------------------

				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(bpy.data.materials.get("Deo's [MeshVertex Passes]"))
				bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=False)

				# ------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [MeshVertex Passes]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# Eliminarle sus materiales y asignarle Shader
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerVertex.name]
				
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get("Deo's [MeshVertex Passes]"))      # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				# Info
				self.report({'INFO'}, "[The MeshVertex was added Material]")
				return {'FINISHED'}


# Bake: Mesh Vertex
class DeosOperBakermapVertexPassesBaker (Operator):
	bl_idname = "deo.bakermap_vertexpasses_baker"
	bl_label = ""
	bl_description = "Bake 'Shader Passes' in 'Vertex Color' (Using each RGB Channels for each Pass)"

	def execute(self, context):

		if bpy.context.scene.my_tool.pickerVertex == None :

			# Info - Sin Meshes Source o Target
			self.report({'WARNING'}, "[There is No 'Mesh' Loaded]")

		else:

			# Bake Settings
			bpy.context.scene.cycles.bake_type = 'EMIT'
			bpy.context.scene.render.bake.use_selected_to_active = True
			bpy.context.scene.render.bake.target = 'VERTEX_COLORS'

			# Limpiar cualquier tipo de seleccion de objetos
			bpy.ops.object.select_all(action='DESELECT')

			# Obtener el Vertex Mesh del Picker
			v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerVertex.name]
			
			"""
			# Borrar el ultimo Layer, si existe alguno
			if bpy.context.object.data.color_attributes :
				bpy.ops.geometry.color_attribute_remove()   #Metodo Nuevo
				# bpy.ops.geometry.attribute_remove()       #Metodo Legacy
			"""

			# Crear Atribute Layer y renombrarlo
			#bpy.context.object.data.attributes['Color'].name = bpy.context.scene.my_tool.strLayerVertexPasses   #Renombrar por nombre
			bpy.ops.geometry.color_attribute_add(name=bpy.context.scene.my_tool.strLayerVertexPasses, domain='CORNER', data_type='BYTE_COLOR')
			
			# Dejar activo el mesh en paneles.
			bpy.context.view_layer.objects.active = v_SelObjActive
			v_SelObjActive.select_set(True)
				
			bpy.app.timers.register( Call_BakeMap_Emit )

		return {'FINISHED'}



# -----------------------------------------------#
# 6) MAP PASSES (Normal+Emit in Map)             #
# -----------------------------------------------#

#  ---------------------------------------


# [ ISOLATE ]

# High
def updateIsolateHigh(self, context):

	if self.boolIsolateHigh:  # Bool de _INIT_

		# Cambiar Toogle HIGH
		self.boolIsolateLow = False

		# Seleccion de conjunto de Mesh(es)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')

		# Obtener Mesh(es) de Collection Picker > Desde _INIT_
		for objHigh in context.scene.my_tool.pickerHigh.objects:
			# Seleccionar Objeto(s) del Collection.
			bpy.data.objects[objHigh.name].select_set(True)

		# Activar Mesh del Picker en paneles.
		bpy.context.view_layer.objects.active = objHigh

		# Isolate Mesh(es)
		# Ahislar seleccion sin mover vista
		bpy.ops.view3d.localview(frame_selected=False)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')

	elif not self.boolIsolateHigh:  # Bool de _INIT_

		bpy.ops.view3d.localview(frame_selected=False)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')

# Low
def updateIsolateLow(self, context):

	if self.boolIsolateLow:  # Bool de _INIT_

		# Cambiar Toogle LOW
		self.boolIsolateHigh = False

		# Seleccion  Mesh y Activacion en Paneles
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')
		bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name].select_set(
			True)       # Seleccionar Mesh del Picker

		SelObjPicker = bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name]
		# Activar Mesh del Picker en paneles.
		bpy.context.view_layer.objects.active = SelObjPicker
		# SelObjPicker.select_set(True)

		# Isolate Mesh
		# Ahislar seleccion sin mover vista
		bpy.ops.view3d.localview(frame_selected=False)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')

	elif not self.boolIsolateLow:  # Bool de _INIT_

		# Ahislar seleccion sin mover vista
		bpy.ops.view3d.localview(frame_selected=False)
		# Limpar cualquier seleccion
		bpy.ops.object.select_all(action='DESELECT')



# [ CYCLES TOGGLE ]
def updateUseClyclesViewport(self, context):

	if self.boolUseCyclesVieport:  		# Bool de _INIT_
		bpy.context.space_data.shading.type = 'RENDERED'
	else :
		bpy.context.space_data.shading.type = 'MATERIAL'


# [ SELECT PASS TYPE ]
def updateEnumBakermapShaderPassesType (self, context):

	v_MatHighpolyPass = bpy.data.materials["Deo's [HighPoly Passes]"]
	v_ShaPassMat = v_MatHighpolyPass.node_tree.nodes["Deo's [Shader Passes]"]
	v_MatOut =     v_MatHighpolyPass.node_tree.nodes["Material Output"]

	if self.enumBakerMapPassType == "Op1":  #Get from _init_
		if bpy.context.scene.my_tool.pickerHigh != None: #No esta vacio

			v_MatHighpolyPass.node_tree.links.new(v_ShaPassMat.outputs["None"], v_MatOut.inputs["Surface"])

		"""""
			if v_ShaPassMat :
				# Conectar Nodos
				pass
				v_ShaderPasses = v_ActiveMaterial.node_tree.nodes.get("Deo's [Shader Passes]")
				shaderPassOutput = v_ShaderPasses.outputs.get("None")
				matOutput = v_ActiveMaterial.node_tree.nodes.get('Material Output')
				v_ActiveMaterial.node_tree.links.new(shaderPassOutput, matOutput.inputs['Surface'])
				bpy.ops.object.select_all(action='DESELECT')
		"""""

	elif self.enumBakerMapPassType == "Op2":  #Get from _init_
		if bpy.context.scene.my_tool.pickerHigh != None: #No esta vacio
			
			v_MatHighpolyPass.node_tree.links.new(v_ShaPassMat.outputs["Curvature: Sculpt"], v_MatOut.inputs["Surface"])

	elif self.enumBakerMapPassType == "Op3":  #Get from _init_
		if bpy.context.scene.my_tool.pickerHigh != None: #No esta vacio
			
			v_MatHighpolyPass.node_tree.links.new(v_ShaPassMat.outputs["Curvature: HardSurface"], v_MatOut.inputs["Surface"])

	elif self.enumBakerMapPassType == "Op4":  #Get from _init_
		if bpy.context.scene.my_tool.pickerHigh != None: #No esta vacio
			
			v_MatHighpolyPass.node_tree.links.new(v_ShaPassMat.outputs["Ambient Oclussion"], v_MatOut.inputs["Surface"])

	elif self.enumBakerMapPassType == "Op5":  #Get from _init_
		if bpy.context.scene.my_tool.pickerHigh != None: #No esta vacio
			
			v_MatHighpolyPass.node_tree.links.new(v_ShaPassMat.outputs["Position (Height)"], v_MatOut.inputs["Surface"])
					
	elif self.enumBakerMapPassType == "Op6":  #Get from _init_
		if bpy.context.scene.my_tool.pickerHigh != None: #No esta vacio
			
			v_MatHighpolyPass.node_tree.links.new(v_ShaPassMat.outputs["Dust (On Top)"], v_MatOut.inputs["Surface"])

	elif self.enumBakerMapPassType == "Op7":  #Get from _init_
		if bpy.context.scene.my_tool.pickerHigh != None: #No esta vacio
			
			v_MatHighpolyPass.node_tree.links.new(v_ShaPassMat.outputs["Thickness (SSS)"], v_MatOut.inputs["Surface"])

	elif self.enumBakerMapPassType == "Op8":  #Get from _init_
		if bpy.context.scene.my_tool.pickerHigh != None: #No esta vacio
			
			v_MatHighpolyPass.node_tree.links.new(v_ShaPassMat.outputs["Cavity"], v_MatOut.inputs["Surface"])


# [ SHADER PASS PROPERTIE ]

# Curvature 
def updateSldrBakermapShaderPassesPropertieCurvature (self, context):

	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Curvature: Intensity"].default_value = bpy.context.scene.my_tool.SldrCurvatureIntensity

	"""
	#Seleccionar mesh
	bpy.data.objects[bpy.context.scene.my_tool.pickerHigh.name].select_set(True)
	v_SelectedMesh = bpy.context.selected_objects[0]
	v_ActiveMaterial = v_SelectedMesh.active_material

	if v_ActiveMaterial:
		# Obtener y Asignar valores a inputs
		v_UI_Slider_Curvature = bpy.context.scene.my_tool.SldrCurvatureIntensity
		
		v_ShaderPasses = v_ActiveMaterial.node_tree.nodes.get("Deo's [Shader Passes]")
		v_ShaderPasses.inputs["Curvature: Intensity"].default_value = v_UI_Slider_Curvature
		
		bpy.ops.object.select_all(action='DESELECT')
	"""

# AO Distance
def updateSldrBakermapShaderPassesPropertieAODistance (self, context):
	
	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Ambient Occlusion: Distance"].default_value = bpy.context.scene.my_tool.SldrAO_Distance

# AO Intensity
def updateSldrBakermapShaderPassesPropertieAOIntensity (self, context):
	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Ambient Occlusion: Intensity"].default_value = bpy.context.scene.my_tool.SldrAO_Intensity


# Position offset
def updateSldrBakermapShaderPassesPropertiePositionOffset (self, context):
	
	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Position (Height): Offset"].default_value = bpy.context.scene.my_tool.SldrPosition_Offset

# Position add normals
def updateSldrBakermapShaderPassesPropertiePositionNormals (self, context):
	
	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Position (Height): Add Normals"].default_value = bpy.context.scene.my_tool.SldrPosition_AddTopNormals


# Dust (on top)
def updateSldrBakermapShaderPassesPropertieDust (self, context):
	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Dust: Tilt Face"].default_value = bpy.context.scene.my_tool.SldrDustOnTop
							

# Thickness distance
def updateSldrBakermapShaderPassesPropertieThicknessDistance (self, context):
	
	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Thickness: Distance"].default_value = bpy.context.scene.my_tool.SldrThickness_Distance
	
# Thickness balance
def updateSldrBakermapShaderPassesPropertieThicknessBalance (self, context):

	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Thickness: Balance"].default_value = bpy.context.scene.my_tool.SldrThickness_Balance

	"""
	#Seleccionar mesh
	bpy.data.objects[bpy.context.scene.my_tool.pickerHigh.name].select_set(True)
	v_SelectedMesh = bpy.context.selected_objects[0]
	v_ActiveMaterial = v_SelectedMesh.active_material

	if v_ActiveMaterial:
		# Obtener y Asignar valores a inputs
		v_UI_Slider_Curvature = bpy.context.scene.my_tool.SldrThickness_Balance
		
		v_ShaderPasses = v_ActiveMaterial.node_tree.nodes.get("Deo's [Shader Passes]")
		v_ShaderPasses.inputs["Thickness: Balance"].default_value = v_UI_Slider_Curvature
		
		bpy.ops.object.select_all(action='DESELECT')
	"""


# Cavity
def updateSldrBakermapShaderPassesPropertieCavity (self, context):
	
	v_ShaPassMats = bpy.data.materials["Deo's [HighPoly Passes]"].node_tree.nodes["Deo's [Shader Passes]"]
	v_ShaPassMats.inputs["Cavity: Intensity"].default_value = bpy.context.scene.my_tool.SldrCavity


#  ---------------------------------------


# SHADER: Highpoly (Collection)
class DeosOperBakermapPassesShaderHigh (Operator):
	bl_idname = "deo.bakermap_passes_shaderhigh"
	bl_label = ""
	bl_description =  "Add the HighPoly Material Template [Shader Passes]"

	def execute(self, context):

		# SIN HIGHPOLY
		if bpy.context.scene.my_tool.pickerHigh == None:

			self.report({'WARNING'}, "[Load the High's Collection Mesh(es)]")
			return {'FINISHED'}

		else:

			# SI NO EXISTE EL SHADER
			if bpy.data.materials.get("Deo's [HighPoly Passes]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [HighPoly Passes]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path(
					'USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				bpy.ops.object.select_all(action='DESELECT')

				# Seleccion de Objetos de Highpoly Collection
				# Obtener todos los objetos de la collection
				for objHigh in context.scene.my_tool.pickerHigh.objects:
					# Seleccionar objetos de la Coleccion
					bpy.data.objects[objHigh.name].select_set(True)
					# Eliminarle los materiales que contenga
					objHigh.data.materials.clear()
					objHigh.data.materials.append(bpy.data.materials.get(
						"Deo's [HighPoly Passes]"))  # Asignar Shader
					# ---

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = objHigh
				objHigh.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				self.report({'INFO'}, "[Deo's [HighPoly Passes] material was Added]")
				return {'FINISHED'}

			else:

				# ------------------------------------------------------------
				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove(
					bpy.data.materials.get("Deo's [HighPoly Passes]"))
				bpy.ops.outliner.orphans_purge(
					do_local_ids=True, do_linked_ids=True, do_recursive=True)
				# ------------------------------------------------------------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [HighPoly Passes]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path(
					'USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				bpy.ops.object.select_all(action='DESELECT')

				# Seleccion de Objetos de Highpoly Collection
				# Obtener todos los objetos de la collection
				for objHigh in context.scene.my_tool.pickerHigh.objects:
					# Seleccionar objetos de la Coleccion
					bpy.data.objects[objHigh.name].select_set(True)
					# Eliminarle los materiales que contenga
					objHigh.data.materials.clear()
					objHigh.data.materials.append(bpy.data.materials.get(
						"Deo's [HighPoly Passes]"))   # Asignar Shader
					# ---

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = objHigh
				objHigh.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				self.report({'INFO'}, "[Deo's [HighPoly Passes] material was Added]")

		return {'FINISHED'}

# SHADER: Lowpoly
class DeosOperBakermapPassesShaderLow (Operator):
	bl_idname = "deo.bakermap_passes_shaderlow"
	bl_label = ""
	bl_description = "Add the LowPoly Material [ Template Passes]"

	def execute(self, context):

		# SIN HIGHPOLY
		if bpy.context.scene.my_tool.pickerHigh == None:

			self.report({'WARNING'}, "Load the High's Collection Mesh(es)")
			return {'FINISHED'}

		else:

			# SI NO EXISTE EL SHADER
			if bpy.data.materials.get("Deo's [LowPoly Passes]") == None:

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [LowPoly Passes]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path(
					'USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerLow.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get(
					"Deo's [LowPoly Passes]"))       # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				self.report({'INFO'}, "Deo's [LowPoly Passes] was Applied!")
				return {'FINISHED'}

			else:

				# ------------------------------------------------------------
				# Borrar el Shader actual por si tienen update la tool.
				bpy.data.materials.remove( bpy.data.materials.get("Deo's [LowPoly Passes]") )
				bpy.ops.outliner.orphans_purge( do_local_ids=True, do_linked_ids=True, do_recursive=True )
				# ------------------------------------------------------------

				# Append del Shader a la escena.
				v_AppendMaterial = "Deo's [LowPoly Passes]"
				#v_PathMat = (bpy.utils.user_resource('SCRIPTS', "addons") + "\deostools\BakerMap\BakerMapMats.blend\\Material\\")
				v_PathMat = bpy.utils.resource_path(
					'USER') + "\scripts\\addons\deostools\BakerMap\BakerMapMats.blend\\Material\\"
				bpy.ops.wm.append(filename=v_AppendMaterial, directory=v_PathMat)

				# ------

				# Limpar cualquier seleccion
				# Limpiar selecciones de objetos
				bpy.ops.object.select_all(action='DESELECT')

				#  Seleccionar el Target
				bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name].select_set(True)                   # Desde _INIT_

				# Eliminarle sus materiales y asignarle Shader
				# seleccionar mesh del Picker
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerLow.name]
				# Eliminarle los materiales que contenga
				v_SelObjActive.data.materials.clear()
				v_SelObjActive.data.materials.append(bpy.data.materials.get(
					"Deo's [LowPoly Passes]"))       # Asignar Shader

				# Dejar activo el mesh en paneles.
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				# Limpar cualquier seleccion
				bpy.ops.object.select_all(action='DESELECT')

				# ------

				self.report({'INFO'}, "Deo's [LowPoly Passes] was Applied!")
				return {'FINISHED'}



# BAKER: Normal Map
class DeosOperBakermapTypeNormalMap (Operator):
	bl_idname = "deo.bakermap_type_normalmap"
	bl_label = ""
	bl_description = "Bake Normal Map (HighPoly to LowPoly)"

	def execute(self, context):

		# Modo de Edicion a objeto
		bpy.ops.object.mode_set(mode='OBJECT') 		# OBJECT / EDIT_MESH
		
				
		if bpy.context.scene.my_tool.pickerLow == None or bpy.context.scene.my_tool.pickerHigh == None:
			# Info - Sin Meshes Low / High
			self.report({'WARNING'}, "[There is No 'Source/Target' Mesh(es) loaded]")
		else:
			# Seleccionar mesh
			v_SelectedLowMesh = bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name]
			bpy.context.view_layer.objects.active = v_SelectedLowMesh
		
			if len(bpy.context.active_object.data.materials) > 0:
				# Obtener de Enum la opcion seleccionada
				if bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op1" :
					v_ImgNormalSize = 256
				elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op2" :
					v_ImgNormalSize = 512
				elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op3" :
					v_ImgNormalSize = 1024
				elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op4" :
					v_ImgNormalSize = 2048
				elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op5" :
					v_ImgNormalSize = 4096
				elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op6" :
					v_ImgNormalSize = 8192                        
				
				# Material Seleccionado
				v_ActiveMaterial = bpy.context.active_object.active_material        
				
				# Obtener del material acitvo nodos
				v_getMatBSDF = v_ActiveMaterial.node_tree.nodes.get("Principled BSDF")
				v_getMatOut  = v_ActiveMaterial.node_tree.nodes.get("Material Output")


				# [ CREAR NODOS REUSANDO SLOT ]

				v_CreateNodesToBakeFromScratch = True							# Bool Para validar si se crean nodos desde cero

				for v_Nodes in v_ActiveMaterial.node_tree.nodes :				# Iterar en cada nodo dentro del material
					v_ActiveMaterial.node_tree.nodes.active = v_Nodes			# Dejar nodo activo (Bake)
					
					# Buscar Image
					if v_Nodes.name == "Deos_Normal_Img":    					
						# if v_Nodes.type =="TEX_IMAGE" and node.name =="Name":  # Image Node
						# if v_Nodes.type =="NORMAL_MAP" and node.name =="Name": # NormalMap node

						# Desactivar el crear nodos desde cero
						v_CreateNodesToBakeFromScratch = False							

						if v_Nodes.image == None :
							# Crear TextImage
							v_SlotImg_NormalMap = bpy.data.images.new(name="NORMAL_BAKED", width=v_ImgNormalSize, height=v_ImgNormalSize, float_buffer= True)
							v_SlotImg_NormalMap.colorspace_settings.name = 'Linear'
							v_SlotImg_NormalMap.generated_color = 	[0.5, 0.5, 1, 1]
							v_SlotImg_NormalMap.alpha_mode = 'NONE'
							v_SlotImg_NormalMap.colorspace_settings.is_data = True

							# Sobre el NodeImage aplicarle la nueva TexImage
							v_Nodes.image = v_SlotImg_NormalMap
							v_ActiveMaterial.node_tree.nodes.active = v_Nodes			# Dejar nodo activo (Bake)

							# Conectar nodos
							v_ActiveMaterial.node_tree.links.new(v_getMatBSDF.outputs["BSDF"], v_getMatOut.inputs["Surface"])				#BSDF to Material Output

							break

						else :
							# Eliminar TexImage
							bpy.data.images.remove(v_Nodes.image)							
							v_Nodes.image = None
							
							# Crear TxtImage con nuevo tamaño
							v_SlotImg_NormalMap = bpy.data.images.new(name="NORMAL_BAKED", width=v_ImgNormalSize, height=v_ImgNormalSize, float_buffer= True)
							v_SlotImg_NormalMap.colorspace_settings.name = 'Linear'
							v_SlotImg_NormalMap.generated_color = 	[0.5, 0.5, 1, 1]
							v_SlotImg_NormalMap.alpha_mode = 'NONE'

							# Conectar nodos
							v_ActiveMaterial.node_tree.links.new(v_getMatBSDF.outputs["BSDF"], v_getMatOut.inputs["Surface"])				#BSDF to Material Output

							# Sobre el NodeImage aplicarle la nueva TexImage
							v_Nodes.image = v_SlotImg_NormalMap


				# [ CREAR NODOS DESDE CERO ]
				if v_CreateNodesToBakeFromScratch :
					
					# Crear Slot de Imagen
					v_SlotImg_NormalMap = bpy.data.images.new(name="NORMAL_BAKED", width=v_ImgNormalSize, height=v_ImgNormalSize, float_buffer= True)
					v_SlotImg_NormalMap.colorspace_settings.name = 'Linear'
					v_SlotImg_NormalMap.generated_color = 	[0.5, 0.5, 1, 1]
					v_SlotImg_NormalMap.alpha_mode = 'NONE'

					# Crear Nodo de Imagen y cargarle el Slot anterior
					v_NodeImg_NormalMap = v_ActiveMaterial.node_tree.nodes.new(type='ShaderNodeTexImage')
					v_NodeImg_NormalMap.name = "Deos_Normal_Img"
					v_NodeImg_NormalMap.image = v_SlotImg_NormalMap

					# Crear Nodo de tipo NormalMap
					v_NodeNormalMap = v_ActiveMaterial.node_tree.nodes.new(type='ShaderNodeNormalMap')
					v_NodeNormalMap.name = "Deos_Normal_Node"

					# Conectar: Imagen + Normal Map + Principled BSDF + MatOutput
					v_ActiveMaterial.node_tree.links.new(v_NodeImg_NormalMap.outputs["Color"], v_NodeNormalMap.inputs["Color"]) 	# Img a NormalMap
					v_ActiveMaterial.node_tree.links.new(v_NodeNormalMap.outputs["Normal"], v_getMatBSDF.inputs["Normal"]) 			# NormalMap a BSDF>Normal 
					v_ActiveMaterial.node_tree.links.new(v_getMatBSDF.outputs["BSDF"], v_getMatOut.inputs["Surface"])				# BSDF>Out a MatOut>Surface
					
					# Dejar activo la img de NormalMap
					v_ActiveMaterial.node_tree.nodes.active = v_NodeImg_NormalMap
			
				# ------------------

				# Bake Settings
				bpy.context.scene.cycles.bake_type = 'NORMAL'
				bpy.context.scene.render.bake.use_selected_to_active = True
				bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
				
				# Limpiar cualquier tipo de seleccion en la escena 3D
				bpy.ops.object.select_all(action='DESELECT')

				# Seleccion de Objetos de Highpoly Collection
				for objHigh in context.scene.my_tool.pickerHigh.objects:
					bpy.data.objects[objHigh.name].select_set(True)

				# Selecionar Lowpoly al final para dejarlo Activo
				bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name].select_set(True)

				# Dejar Activo el Lowpoly y se vea en Panel 3D
				v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerLow.name]
				bpy.context.view_layer.objects.active = v_SelObjActive
				v_SelObjActive.select_set(True)

				bpy.app.timers.register( Call_BakeMap_Normal )										# Ejecutar Directo
				# bpy.app.timers.register(functools.partial(Call_BakeMap_Normal), first_interval=1)	# Ejecutar con Delay
			else :
				self.report({'WARNING'}, "[The LowPoly mesh loaded 'has NO Material' added]")

				
		return {'FINISHED'}
		
# BAKER: Pass Map
class DeosOperBakermapTypePassMap (Operator):
	bl_idname = "deo.bakermap_type_passmap"
	bl_label = ""
	bl_description = "Bake Pass Map (HighPoly to LowPoly)"

	def execute(self, context):
		
		# Modo de Edicion a objeto
		bpy.ops.object.mode_set(mode='OBJECT') 		# OBJECT / EDIT_MESH


		# Validar High y Low meshes
		if bpy.context.scene.my_tool.pickerLow == None or bpy.context.scene.my_tool.pickerHigh == None:
			self.report({'WARNING'}, "[The 'Highpoly or Lowpoly has not been loaded]")
		else : 	
	
			# ---

			# Validar Low Material
			v_MatActLow = bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name].active_material
			if not v_MatActLow :
				self.report({'WARNING'}, "[The 'Lowpoly' has Not Material]")
			else :
			# Validar Low Mat Template
				# if v_MatActLow.name != "Deo's [LowPoly Passes]" :
				# 	self.report({'WARNING'}, "The 'Lowpoly' doesn't have the MAT TEMPLATE")
				# else :

			# ---

				# Validar High con su material
				v_CollecttHigh = bpy.data.collections.get(bpy.context.scene.my_tool.pickerHigh.name)

				if v_CollecttHigh.objects[0] :

					v_MatActHigh = v_CollecttHigh.objects[0].active_material
					if not v_MatActHigh :
						self.report({'WARNING'}, "[The 'Highpoly Collection' has Not Material]")
					else :
						if v_MatActHigh.name != "Deo's [HighPoly Passes]" :
							self.report({'WARNING'}, "[The 'Highpoly Collection' doesn't have the Mat Template added]")

						else :
							# Seleccionar Low
							bpy.context.view_layer.objects.active = bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name]
								
							if len(bpy.context.active_object.data.materials) > 0:
								# Obtener el texture size activo
								if bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op1" :
									v_ImgNormalSize = 256
								elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op2" :
									v_ImgNormalSize = 512
								elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op3" :
									v_ImgNormalSize = 1024
								elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op4" :
									v_ImgNormalSize = 2048
								elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op5" :
									v_ImgNormalSize = 4096
								elif bpy.context.scene.my_tool.enumBakerMapPassMapSettingSize == "Op6" :
									v_ImgNormalSize = 8192                        

								# Asignar el nombre del Img: Slot+Nodo del Pass Map
								if bpy.context.scene.my_tool.enumBakerMapPassType == "Op2" :
									v_NodeImgPassName = "CURV.SCULPT_BAKED"
									v_ImgSlotPassName = "Deos_CurvSculpt_Img"
								elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op3" :
									v_NodeImgPassName = "CURV.HSURFACE_BAKED"
									v_ImgSlotPassName = "Deos_CurvHSurface_Img"
								elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op4" :
									v_NodeImgPassName = "AO_BAKED"
									v_ImgSlotPassName = "Deos_AO_Img"
								elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op5" :
									v_NodeImgPassName = "POSITION_BAKED"				
									v_ImgSlotPassName = "Deos_Position_Img"
								elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op6" :
									v_NodeImgPassName = "DUST_BAKED"
									v_ImgSlotPassName = "Deos_Dust_Img"
								elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op7" :
									v_NodeImgPassName = "THICKNESS_BAKED"
									v_ImgSlotPassName = "Deos_Thickness_Img"
								elif bpy.context.scene.my_tool.enumBakerMapPassType == "Op8" :
									v_NodeImgPassName = "CAVITY_BAKED"
									v_ImgSlotPassName = "Deos_Cavity_Img"


								# Material Seleccionado
								v_ActiveMaterial = bpy.context.active_object.active_material        
								

								# [ CREAR NODOS REUSANDO SLOT ]

								v_CreateNodesToBakeFromScratch = True							# Bool Para validar si se crean nodos desde cero

								for v_Nodes in v_ActiveMaterial.node_tree.nodes :				# Iterar en cada nodo dentro del material
									v_ActiveMaterial.node_tree.nodes.active = v_Nodes			# Dejar nodo activo (Bake)

									# Buscar Image Pass
									if v_Nodes.name == v_ImgSlotPassName:
										
										v_CreateNodesToBakeFromScratch = False					# Desactivar el crear nodos desde cero

										# Si el slot esta vacio
										if v_Nodes.image == None :
											# Crear TextImage
											v_SlotImg_PassMap = bpy.data.images.new(name=v_NodeImgPassName, width=v_ImgNormalSize, height=v_ImgNormalSize, float_buffer= True)
											v_SlotImg_PassMap.colorspace_settings.name = 'Linear'
											v_SlotImg_PassMap.generated_color = 	[0, 0, 0, 1]
											v_SlotImg_PassMap.alpha_mode = 'NONE'

											# Sobre el NodeImage aplicarle la nueva TexImage
											v_Nodes.image = v_SlotImg_PassMap

											# Conectar: Imagen al  Material Output
											v_getMaterialout = v_ActiveMaterial.node_tree.nodes.get("Material Output")
											v_ActiveMaterial.node_tree.links.new(v_Nodes.outputs["Color"], v_getMaterialout.inputs["Surface"])
											
											# Dejar nodo activo (Bake)
											v_ActiveMaterial.node_tree.nodes.active = v_Nodes									
											
											break

										else :
											# Eliminar TexImage
											bpy.data.images.remove(v_Nodes.image)							
											v_Nodes.image = None
											
											# Crear TxtImage con nuevo tamaño
											v_SlotImg_PassMap = bpy.data.images.new(name=v_NodeImgPassName, width=v_ImgNormalSize, height=v_ImgNormalSize, float_buffer= True)
											v_SlotImg_PassMap.colorspace_settings.name = 'Linear'
											v_SlotImg_PassMap.generated_color = 	[0, 0, 0, 1]
											v_SlotImg_PassMap.alpha_mode = 'NONE'

											# Asignar el TxtImage al Nodo de Img
											v_Nodes.image = v_SlotImg_PassMap

											# Conectar: Imagen al  Material Output
											v_getMaterialout = v_ActiveMaterial.node_tree.nodes.get("Material Output")
											v_ActiveMaterial.node_tree.links.new(v_Nodes.outputs["Color"], v_getMaterialout.inputs["Surface"])
									

								# # [ CREAR NODOS DESDE CERO ]
								if v_CreateNodesToBakeFromScratch :
								
									# Crear TxtImage con nuevo tamaño
									v_SlotImg_PassMap = bpy.data.images.new(name=v_NodeImgPassName, width=v_ImgNormalSize, height=v_ImgNormalSize, float_buffer= True)
									v_SlotImg_PassMap.colorspace_settings.name = 'Linear'
									v_SlotImg_PassMap.generated_color = 	[0, 0, 0, 1]
									v_SlotImg_PassMap.alpha_mode = 'NONE'

									# Crear Nodo de Imagen y cargarle el Slot anterior
									v_NodeImg_PassMap = v_ActiveMaterial.node_tree.nodes.new(type='ShaderNodeTexImage')
									v_NodeImg_PassMap.name = v_ImgSlotPassName
									v_NodeImg_PassMap.image = v_SlotImg_PassMap

									# Conectar: Imagen al  Material Output
									v_getMaterialout = v_ActiveMaterial.node_tree.nodes.get("Material Output")
									v_ActiveMaterial.node_tree.links.new(v_NodeImg_PassMap.outputs["Color"], v_getMaterialout.inputs["Surface"])
								
									# Dejar activo la img de NormalMap
									v_ActiveMaterial.node_tree.nodes.active = v_NodeImg_PassMap
							
								#  --------------------------

								# Bake Settings
								bpy.context.scene.cycles.bake_type = 'EMIT'
								bpy.context.scene.render.bake.use_selected_to_active = True
								bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES' 		# 'VERTEX_COLORS'
								bpy.context.scene.render.bake.margin_type = 'ADJACENT_FACES'  	# 'EXTENDED'

								# Limpiar cualquier tipo de seleccion en la escena 3D
								bpy.ops.object.select_all(action='DESELECT')

								# Seleccion de Objetos de Highpoly Collection
								for objHigh in context.scene.my_tool.pickerHigh.objects:
									bpy.data.objects[objHigh.name].select_set(True)

								# Selecionar Lowpoly al final para dejarlo Activo
								bpy.data.objects[bpy.context.scene.my_tool.pickerLow.name].select_set(True)

								# Dejar Activo el Lowpoly y se vea en Panel 3D
								v_SelObjActive = bpy.context.scene.objects[bpy.context.scene.my_tool.pickerLow.name]
								bpy.context.view_layer.objects.active = v_SelObjActive
								v_SelObjActive.select_set(True)

								bpy.app.timers.register( Call_BakeMap_Emit )											# Ejecutar Directo
								# bpy.app.timers.register(functools.partial(Call_BakeMap_Emit), first_interval=1)		# Ejecutar con Delay

							else :
								self.report({'WARNING'}, "[The loaded 'Meshes has NO Materials' applied]")
				
				else : 
					self.report({'WARNING'}, "[There is NO Object inside the Collection]")

		return {'FINISHED'}



# SAVE MAPS
class DeosOperBakermapSaveMaps(Operator):
	bl_idname = "deo.bakermap_savemaps"
	bl_label = ""
	bl_description = "Baked Maps will be save into the Blender File"

	def execute(self, context):

		# Salvar mapas
		bpy.ops.file.pack_all()

		return {'FINISHED'}