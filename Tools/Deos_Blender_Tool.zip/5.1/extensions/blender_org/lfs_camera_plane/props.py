# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later

import addon_utils
import bpy
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    StringProperty,
)

from .utils.properties import (
    get_distance,
    set_distance,
    update_distance,
    get_scale,
    set_scale,
    get_hide,
    set_hide,
    get_lock,
    set_lock,
    get_select,
    set_select,
)

module_name = addon_utils.modules().mapping[__package__]
bl_info = addon_utils.module_bl_info(module_name)
BLENDER_VERSION = "{}.{}.{}".format(*bl_info.get("version"))


def get_camera(obj):
    cam = None
    if obj.type == "CAMERA":
        cam = obj
    elif obj.parent is not None and obj.parent.type == "CAMERA":
        cam = obj.parent
    return cam


def get_planes(obj, selected=False):
    if obj.type == "CAMERA":
        cam = obj
    elif obj.parent is not None and obj.parent.type == "CAMERA":
        cam = obj.parent

    # Get planes camera's plane children
    planes = [
        child for child in cam.children if (
            "camera_plane" in child
            and "distance" in child["camera_plane"])
    ]
    if selected:
        planes_selected = [plane for plane in planes if plane.select_get()]
        if planes_selected:
            planes = planes_selected
    return planes


class CameraPlaneSettings(bpy.types.PropertyGroup):
    sort_type: EnumProperty(
        name="Sort Type",
        items=[
            ('ALPHABETICAL', "Alphabetical", "Alphabetical sort", 'SORTALPHA', 1),
            ('DISTANCE', "Distance", "Sort by distance to camera", 'DRIVER_DISTANCE', 2),
        ],
        default='DISTANCE',
    )
    show_selected: BoolProperty(
        name="Selected Only", description="Show selected planes only", default=False
    )
    filter: StringProperty(name="Plane Filter", maxlen=1024, options={'TEXTEDIT_UPDATE'})
    show_scale: bpy.props.BoolProperty(
        name="Show Scale", description="Show plane scale in the UI", default=False
    )
    show_opacity: BoolProperty(
        name="Show Opacity", description="Show plane opacity in the UI", default=False
    )


class CameraPlaneProperties(bpy.types.PropertyGroup):
    distance: FloatProperty(
        name="Camera Plane Distance",
        description="Distance to the camera",
        subtype="DISTANCE",
        unit="LENGTH",
        step=10.0,
        precision=3,
        get=get_distance,
        set=set_distance,
        update=update_distance,
    )
    scale: FloatProperty(
        name="Camera Plane Scale",
        description="Extra scale applied after distance calculation",
        default=100.0,
        soft_max=500.0,
        min=0.0,
        subtype="PERCENTAGE",
        get=get_scale,
        set=set_scale,
    )
    select: BoolProperty(
        name="Select",
        description="Select plane",
        get=get_select,
        set=set_select,
    )
    hide: BoolProperty(
        name="Disable",
        description="Disable plane in both viewport and render",
        get=get_hide,
        set=set_hide,
    )
    lock: BoolProperty(
        name="Lock",
        description="Lock plane transforms",
        get=get_lock,
        set=set_lock,
    )
    show_group: BoolProperty(
        name="Show Group",
        description="Show settings for planes inside this group",
        default=False,
    )
    version: StringProperty(name="Version", default=BLENDER_VERSION)
