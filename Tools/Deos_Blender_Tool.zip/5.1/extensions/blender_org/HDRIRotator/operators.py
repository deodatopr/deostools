import bpy
import math
import mathutils
from . import draw_handler
from .utils import (
    get_addon_prefs,
    get_area_safe,
    update_status_bar,
    clear_status_bar,
    safe_redraw,
    find_sun_lamp,
    enter_sun_mode,
    exit_sun_mode,
    find_sky_texture_node,
    find_rotation_input,
    find_mapping_node,
    set_sky_texture_rotation,
    set_sky_texture_elevation,
    set_custom_hdri_rotation,
    set_mapping_node_rotation,
    set_mapping_node_z_location,
    get_builtin_hdr_rotation,
    set_builtin_hdr_rotation,
    set_studio_world_space_rotation,
    should_sync_hdri_rotation,
    sync_world_rotation_to_builtin,
    sync_builtin_rotation_to_world,
    handle_mode_switch_sync,
    get_current_rotation,
    find_controllable_light,
    detect_hdri_power_backend,
    detect_power_available,
    get_power_value,
    set_power_value,
    has_hdri_height_context,
    # Mode constants
    MODE_ID_HDRI,
    MODE_ID_SUN,
    MODE_ID_WORLD_SPACE_LIGHTING,
    MODE_ID_SHADOWS,
    ROT_MODE_SHADOW,
    ROT_MODE_STUDIO_WORLD_SPACE,
    ROT_MODE_CUSTOM_HDRI,
    ROT_MODE_MAPPING_NODE,
    ROT_MODE_MAPPING_Z_LOCATION,
    ROT_MODE_SKY_TEXTURE,
    ROT_MODE_SKY_TEXTURE_ELEVATION,
    ROT_MODE_HDRI,
    ROT_MODE_SUN,
    ROT_MODE_POWER,
    POWER_MODE_BUILTIN,
    POWER_MODE_CUSTOM_EV,
    POWER_MODE_WORLD_BACKGROUND,
    POWER_MODE_LIGHT,
)


class HDRI_Rotator(bpy.types.Operator):
    """Rotate HDRI or Light Direction with your mouse"""
    bl_idname = "view3d.hdri_rotator"
    bl_label = "HDRI Rotator"
    bl_description = "Rotate HDRI or Light Direction with your mouse. Hold {SHIFT} for precision."
    bl_options = {'REGISTER', 'BLOCKING'}
    
    # Sun rotation axis toggle (Z by default, X when toggled)
    sun_rotate_x: bpy.props.BoolProperty(
        name="Sun Rotate X",
        description="Rotate sun on X axis instead of Z",
        default=False
    )
    
    def get_shading_category(self):
        """Get the category for storing last used mode"""
        if self.shading_type == 'WIREFRAME':
            return 'wireframe'
        elif self.shading_type == 'SOLID':
            return 'solid'
        elif self.shading_type == 'RENDERED' and self.scene.render.engine == 'BLENDER_WORKBENCH':
            return 'solid'  # Workbench shares with Solid
        else:
            return 'material_rendered'  # Material Preview and Rendered share
    
    def get_last_mode(self, context):
        """Get the last used mode for the current shading category"""
        wm = context.window_manager
        category = self.get_shading_category()
        
        if category == 'wireframe':
            return getattr(wm, 'hdri_rotator_last_mode_wireframe', 'SUN')
        elif category == 'solid':
            return getattr(wm, 'hdri_rotator_last_mode_solid', '')
        else:
            return getattr(wm, 'hdri_rotator_last_mode_material', '')
    
    def save_last_mode(self, context):
        """Save the current mode as the last used mode for this shading category"""
        wm = context.window_manager
        category = self.get_shading_category()
        
        if category == 'wireframe':
            wm.hdri_rotator_last_mode_wireframe = self.active_mode
        elif category == 'solid':
            wm.hdri_rotator_last_mode_solid = self.active_mode
        else:
            wm.hdri_rotator_last_mode_material = self.active_mode
    
    def normalize_rotation_rate(self, delta, mode, axis='horizontal'):
        """Normalize rotation rate across different HDRI control methods.
        
        axis: 'horizontal' uses invert_rotation (skipped for Sun),
              'vertical'   uses invert_height_direction.
        """
        if delta == 0:
            return 0.0
            
        # Base constants for normalization
        BASE_RANGE = 360.0
        MOUSE_PIXELS_FOR_FULL_ROTATION = 1000.0
        
        addon_prefs = get_addon_prefs()
        user_sensitivity = addon_prefs.sensitivity if addon_prefs else 0.8
        precision_enabled = addon_prefs.enable_precision if addon_prefs else True
        
        user_sensitivity = max(0.1, min(1.0, user_sensitivity))
        precision_multiplier = 0.1 if (self.shift_held and precision_enabled) else 1.0
        
        # Choose the right invert preference based on axis
        if axis == 'vertical':
            invert = addon_prefs.invert_height_direction if addon_prefs else False
            invert_multiplier = -1.0 if invert else 1.0
        else:
            invert = addon_prefs.invert_rotation if addon_prefs else False
            is_sun_mode = (self.active_mode == MODE_ID_SUN) if hasattr(self, 'active_mode') else False
            invert_multiplier = 1.0 if is_sun_mode else (-1.0 if invert else 1.0)
        
        base_rotation = (delta / MOUSE_PIXELS_FOR_FULL_ROTATION) * BASE_RANGE
        
        # Mode-specific scaling
        if mode == ROT_MODE_SHADOW:
            scale_factor = 0.5
        else:
            scale_factor = 1.0
        
        return base_rotation * scale_factor * user_sensitivity * precision_multiplier * invert_multiplier

    def normalize_power_rate(self, delta_x):
        """Normalize strength/power adjustment rate for Power mode."""
        if delta_x == 0:
            return 0.0

        POWER_PIXELS_FOR_FULL_RANGE = 1000.0

        addon_prefs = get_addon_prefs()
        user_sensitivity = addon_prefs.sensitivity if addon_prefs else 0.8
        precision_enabled = addon_prefs.enable_precision if addon_prefs else True
        invert_rotation = addon_prefs.invert_rotation if addon_prefs else False

        power_mode_type = getattr(self, 'power_mode_type', None)
        if power_mode_type == POWER_MODE_CUSTOM_EV:
            full_range = 20.0
        elif power_mode_type == POWER_MODE_LIGHT:
            full_range = 10.0
        else:
            full_range = 2.0

        user_sensitivity = max(0.1, min(1.0, user_sensitivity))
        precision_multiplier = 0.1 if (self.shift_held and precision_enabled) else 1.0
        invert_multiplier = -1.0 if invert_rotation else 1.0

        return ((delta_x / POWER_PIXELS_FOR_FULL_RANGE) * full_range
                * user_sensitivity * precision_multiplier * invert_multiplier)

    def modal(self, context, event):
        try:
            if event.type == 'MOUSEMOVE':
                addon_prefs = get_addon_prefs()
                precision_enabled = addon_prefs.enable_precision if addon_prefs else True

                # Update shift state
                if event.shift != self.shift_held and precision_enabled:
                    self.shift_held = event.shift
                    self.start_x = event.mouse_x
                    self.start_y = event.mouse_y
                    if self.mode == ROT_MODE_SHADOW:
                        self.start_light_direction = self.scene.display.light_direction.copy()
                    elif self._is_vertical_adjust_mode():
                        self._capture_vertical_start()
                    elif self.mode == ROT_MODE_POWER:
                        self.start_power = get_power_value(self)
                    elif self.active_mode == MODE_ID_SUN:
                        if hasattr(self, 'sun_lamp') and self.sun_lamp:
                            self.sun_start_rotation = self.sun_lamp.rotation_euler.copy()
                    else:
                        self.start_rotation = get_current_rotation(self)
                    update_status_bar(context, self)
                elif not precision_enabled:
                    self.shift_held = False

                delta_x = event.mouse_x - self.start_x
                delta_y = event.mouse_y - self.start_y
                rotation_change = self.normalize_rotation_rate(delta_x, self.mode)

                if self.mode == ROT_MODE_SHADOW:
                    rot_x = (-delta_y / delta_x) * rotation_change * math.pi / 180.0 if delta_x != 0 else 0
                    rot_z = -rotation_change * math.pi / 180.0
                    
                    new_light_direction = self.calculate_new_direction(
                        self.start_light_direction, rot_x, rot_z
                    )
                    self.scene.display.light_direction = new_light_direction
                    draw_handler.update_rotation_value(self.mode, new_light_direction)
                
                elif self.mode == ROT_MODE_STUDIO_WORLD_SPACE:
                    new_rotation = self.start_rotation + rotation_change
                    new_rotation = ((new_rotation + 180) % 360) - 180
                    set_studio_world_space_rotation(self, new_rotation)
                    draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == ROT_MODE_CUSTOM_HDRI:
                    if isinstance(self.start_rotation, (mathutils.Euler, mathutils.Vector)):
                        new_rotation = self.start_rotation.copy()
                        new_rotation.z = self.start_rotation.z + math.radians(rotation_change)
                    elif isinstance(self.start_rotation, (float, int)):
                        new_rotation = self.start_rotation + rotation_change
                    set_custom_hdri_rotation(self, new_rotation)
                    draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == ROT_MODE_MAPPING_NODE:
                    if isinstance(self.start_rotation, (mathutils.Euler, mathutils.Vector)):
                        new_rotation = self.start_rotation.copy()
                        new_rotation.z = self.start_rotation.z + math.radians(rotation_change)
                    set_mapping_node_rotation(self, new_rotation)
                    draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == ROT_MODE_MAPPING_Z_LOCATION:
                    # Vertical mouse movement drives Z location; reuse rotation
                    # normalization (deg) and convert to a Blender unit scale.
                    location_change = self.normalize_rotation_rate(delta_y, self.mode, axis='vertical') / 360.0
                    new_z = self.start_z_location + location_change
                    set_mapping_node_z_location(self, new_z)
                    draw_handler.update_rotation_value(self.mode, new_z)
                
                elif self.mode == ROT_MODE_SKY_TEXTURE_ELEVATION:
                    # Flip vertical delta so elevation follows the same convention as
                    # Mapping Z Location; invert_height still applies via normalize.
                    elevation_change = math.radians(
                        self.normalize_rotation_rate(-delta_y, self.mode, axis='vertical')
                    )
                    new_elevation = self.start_sun_elevation + elevation_change
                    set_sky_texture_elevation(self, new_elevation)
                    draw_handler.update_rotation_value(self.mode, new_elevation)
                
                elif self.mode == ROT_MODE_SKY_TEXTURE:
                    if isinstance(self.start_rotation, (float, int)):
                        new_rotation = self.start_rotation + math.radians(rotation_change)
                        set_sky_texture_rotation(self, new_rotation)
                        draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == ROT_MODE_HDRI:
                    new_rotation = self.start_rotation + rotation_change
                    new_rotation = ((new_rotation + 180) % 360) - 180
                    set_builtin_hdr_rotation(self, new_rotation)
                    draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == ROT_MODE_POWER:
                    power_change = self.normalize_power_rate(delta_x)
                    new_power = self.start_power + power_change
                    set_power_value(self, new_power)
                    draw_handler.update_rotation_value(self.power_mode_type, new_power)
                
                # Handle Sun Mode rotation
                elif self.active_mode == MODE_ID_SUN and hasattr(self, 'sun_lamp') and self.sun_lamp:
                    sun_rotation_change = math.radians(rotation_change)
                    new_rotation = self.sun_start_rotation.copy()
                    
                    if self.sun_rotate_x:
                        new_rotation.x = self.sun_start_rotation.x + sun_rotation_change
                        current_degrees = math.degrees(new_rotation.x)
                    else:
                        new_rotation.z = self.sun_start_rotation.z + sun_rotation_change
                        current_degrees = math.degrees(new_rotation.z)
                    
                    self.sun_lamp.rotation_euler = new_rotation
                    sun_axis = 'X' if self.sun_rotate_x else 'Z'
                    draw_handler.update_rotation_value(ROT_MODE_SUN, current_degrees, sun_axis=sun_axis)
                
                safe_redraw()
                return {'RUNNING_MODAL'}

            # TAB: Cycle through available modes (all shading types with multiple modes)
            elif event.type == 'TAB' and event.value == 'PRESS':
                if len(self.available_modes) > 1:
                    self.cycle_mode(context, event)
                return {'RUNNING_MODAL'}
            
            # H: Switch to HDRI mode (Material/Rendered only)
            elif event.type == 'H' and event.value == 'PRESS':
                if MODE_ID_HDRI in self.available_modes and self.active_mode != MODE_ID_HDRI:
                    self.switch_to_mode(context, MODE_ID_HDRI, event)
                return {'RUNNING_MODAL'}
            
            # S: Switch to Sun mode (all shading types where available)
            elif event.type == 'S' and event.value == 'PRESS':
                if MODE_ID_SUN in self.available_modes and self.active_mode != MODE_ID_SUN:
                    self.switch_to_mode(context, MODE_ID_SUN, event)
                return {'RUNNING_MODAL'}
            
            # W: Switch to World Space Lighting mode (Solid/Workbench only)
            elif event.type == 'W' and event.value == 'PRESS':
                if MODE_ID_WORLD_SPACE_LIGHTING in self.available_modes and self.active_mode != MODE_ID_WORLD_SPACE_LIGHTING:
                    self.switch_to_mode(context, MODE_ID_WORLD_SPACE_LIGHTING, event)
                return {'RUNNING_MODAL'}
            
            # D: Switch to Shadows mode (Solid/Workbench only)
            elif event.type == 'D' and event.value == 'PRESS':
                if MODE_ID_SHADOWS in self.available_modes and self.active_mode != MODE_ID_SHADOWS:
                    self.switch_to_mode(context, MODE_ID_SHADOWS, event)
                return {'RUNNING_MODAL'}
            
            # X: Switch to Local X rotation (when in Sun mode)
            elif event.type == 'X' and event.value == 'PRESS' and self.active_mode == MODE_ID_SUN:
                if not self.sun_rotate_x or self.mode == ROT_MODE_POWER:
                    self.sun_rotate_x = True
                    self.mode = ROT_MODE_SUN
                    self.start_x = event.mouse_x
                    self.start_y = event.mouse_y
                    if hasattr(self, 'sun_lamp') and self.sun_lamp:
                        self.sun_start_rotation = self.sun_lamp.rotation_euler.copy()
                    self.window.cursor_modal_set('SCROLL_X')
                    update_status_bar(context, self)
                return {'RUNNING_MODAL'}
            
            # Z: Switch to Local Z rotation (when in Sun mode)
            elif event.type == 'Z' and event.value == 'PRESS' and self.active_mode == MODE_ID_SUN:
                if self.sun_rotate_x or self.mode == ROT_MODE_POWER:
                    self.sun_rotate_x = False
                    self.mode = ROT_MODE_SUN
                    self.start_x = event.mouse_x
                    self.start_y = event.mouse_y
                    if hasattr(self, 'sun_lamp') and self.sun_lamp:
                        self.sun_start_rotation = self.sun_lamp.rotation_euler.copy()
                    self.window.cursor_modal_set('SCROLL_X')
                    update_status_bar(context, self)
                return {'RUNNING_MODAL'}
            
            # Z: HDRI height sub-control (requires HDRI mode active)
            elif (event.type == 'Z' and event.value == 'PRESS'
                    and self.active_mode == MODE_ID_HDRI
                    and has_hdri_height_context(self)):
                if not self._is_vertical_adjust_mode():
                    self._enter_hdri_height_submode(context, event)
                return {'RUNNING_MODAL'}
            
            # P: Power sub-control (within any mode that supports it)
            elif (event.type == 'P' and event.value == 'PRESS'
                    and getattr(self, 'power_available', False)):
                if self.mode != ROT_MODE_POWER:
                    self._enter_power_submode(context, event)
                return {'RUNNING_MODAL'}
            
            # R: Return to default rotation from height or power sub-control
            elif event.type == 'R' and event.value == 'PRESS':
                if self.mode == ROT_MODE_POWER or self._is_vertical_adjust_mode():
                    self._return_to_rotation(context, event)
                return {'RUNNING_MODAL'}
            
            elif event.type == 'RIGHTMOUSE' and event.value == 'RELEASE':
                # Save the current mode as the last used mode for this shading category
                self.save_last_mode(context)
                self.cleanup()
                return {'FINISHED'}
            
            elif event.type in {'ESC'}:
                self._restore_original_state()
                self.cleanup()
                return {'CANCELLED'}
            
            return {'RUNNING_MODAL'}

        except Exception as e:
            self.report({'ERROR'}, f"An error occurred: {e}")
            self.cleanup()
            return {'CANCELLED'}

    def _vertical_adjust_mode(self):
        """Return the vertical sub-mode rotation constant for the active backend"""
        if (self.hdri_mode_type == ROT_MODE_SKY_TEXTURE
                and getattr(self, 'sky_texture_node', None)):
            return ROT_MODE_SKY_TEXTURE_ELEVATION
        return ROT_MODE_MAPPING_Z_LOCATION

    def _is_vertical_adjust_mode(self):
        """Check if the operator is currently in a vertical adjust sub-mode"""
        return self.mode in (ROT_MODE_MAPPING_Z_LOCATION, ROT_MODE_SKY_TEXTURE_ELEVATION)

    def _enter_hdri_height_submode(self, context, event):
        """Switch mouse control to HDRI vertical height adjustment."""
        self.mode = self._vertical_adjust_mode()
        self._capture_vertical_start()
        self.start_x = event.mouse_x
        self.start_y = event.mouse_y
        self.window.cursor_modal_set('SCROLL_Y')
        draw_handler.update_rotation_value(self.mode, get_current_rotation(self))
        update_status_bar(context, self)

    def _enter_power_submode(self, context, event):
        """Switch mouse control to power/strength adjustment within the active mode."""
        if not self._resolve_power_backend(context, self.active_mode):
            self.report({'WARNING'}, "No controllable strength source found")
            return
        self.mode = ROT_MODE_POWER
        self.start_power = get_power_value(self)
        self.start_x = event.mouse_x
        self.start_y = event.mouse_y
        self.window.cursor_modal_set('SCROLL_X')
        draw_handler.update_rotation_value(self.power_mode_type, self.start_power)
        update_status_bar(context, self)

    def _return_to_rotation(self, context, event):
        """Return from height or power sub-control to the mode's default rotation."""
        if self.active_mode == MODE_ID_HDRI:
            self.mode = self.hdri_mode_type
            self.start_rotation = get_current_rotation(self)
            self.window.cursor_modal_set('SCROLL_X')
            draw_handler.update_rotation_value(self.mode, self.start_rotation)
        elif self.active_mode == MODE_ID_SUN:
            self.mode = ROT_MODE_SUN
            if hasattr(self, 'sun_lamp') and self.sun_lamp:
                self.sun_start_rotation = self.sun_lamp.rotation_euler.copy()
            self.window.cursor_modal_set('SCROLL_X')
        elif self.active_mode == MODE_ID_WORLD_SPACE_LIGHTING:
            self.mode = ROT_MODE_STUDIO_WORLD_SPACE
            self.start_rotation = math.degrees(self.shading.studiolight_rotate_z)
            self.window.cursor_modal_set('SCROLL_X')
            draw_handler.update_rotation_value(self.mode, self.start_rotation)
        elif self.active_mode == MODE_ID_SHADOWS:
            self.mode = ROT_MODE_SHADOW
            self.start_light_direction = self.scene.display.light_direction.copy()
            self.window.cursor_modal_set('SCROLL_XY')
            draw_handler.update_rotation_value(self.mode, self.start_light_direction)
        self.start_x = event.mouse_x
        self.start_y = event.mouse_y
        update_status_bar(context, self)

    def _capture_vertical_start(self):
        """Capture the baseline value for the active vertical sub-mode"""
        if self.mode == ROT_MODE_SKY_TEXTURE_ELEVATION:
            self.start_sun_elevation = self.sky_texture_node.sun_elevation
        else:
            self.start_z_location = self.mapping_node.inputs['Location'].default_value[2]

    def detect_available_modes(self, context):
        """Detect which modes are available for the current shading type"""
        available = []
        
        # Check for sun once, reuse result
        sun, _ = find_sun_lamp(context)
        has_sun = sun is not None
        
        if self.shading_type == 'WIREFRAME':
            # Wireframe: Only Sun mode
            if has_sun:
                available.append(MODE_ID_SUN)
        
        elif (self.shading_type == 'SOLID'
              or (self.shading_type == 'RENDERED' and context.scene.render.engine == 'BLENDER_WORKBENCH')):
            # Solid / Workbench Rendered: Sun, World Space Lighting, Shadows
            if has_sun:
                available.append(MODE_ID_SUN)
            if self.shading.use_world_space_lighting:
                available.append(MODE_ID_WORLD_SPACE_LIGHTING)
            if self.shading.show_shadows:
                available.append(MODE_ID_SHADOWS)
        
        elif self.shading_type in {'MATERIAL', 'RENDERED'}:
            # Material Preview / Rendered: HDRI and Sun
            hdri_found = self._detect_hdri_mode(context)
            if hdri_found:
                available.append(MODE_ID_HDRI)
            if has_sun:
                available.append(MODE_ID_SUN)
        
        # Power is a sub-control, not a top-level mode. Detect availability
        # once and store as a flag for status bar and [P] key gating.
        self.power_available = detect_power_available(self, context)
        
        return available
    
    def _detect_hdri_mode(self, context):
        """Detect if HDRI control is available and set up the appropriate mode"""
        if self.shading_type == 'MATERIAL':
            use_scene_world = self.shading.use_scene_world
        else:
            use_scene_world = self.shading.use_scene_world_render
        
        self.use_scene_world = use_scene_world
        
        if use_scene_world:
            # Always look for a Mapping node connected to the Environment Texture.
            # This is independent of which rotation backend is selected below, so
            # the Z Location sub-mode can work even in Custom HDRI / Sky modes.
            self.mapping_node = find_mapping_node(self.scene)
            
            # Check for Sky Texture node
            self.sky_texture_node = find_sky_texture_node(self.scene)
            if self.sky_texture_node:
                self.hdri_mode_type = ROT_MODE_SKY_TEXTURE
                return True
            
            # Check for Rotation input
            self.rotation_input = find_rotation_input(self.scene)
            if self.rotation_input is not None:
                default_value = self.rotation_input.default_value
                if isinstance(default_value, (mathutils.Euler, mathutils.Vector, float, int)):
                    self.hdri_mode_type = ROT_MODE_CUSTOM_HDRI
                    return True
            
            # Check for Mapping node (already located above)
            if self.mapping_node:
                default_value = self.mapping_node.inputs['Rotation'].default_value
                if isinstance(default_value, (mathutils.Vector, mathutils.Euler)):
                    self.hdri_mode_type = ROT_MODE_MAPPING_NODE
                    return True
            
            return False
        else:
            # Built-in HDRI is always available
            self.hdri_mode_type = ROT_MODE_HDRI
            return True
    
    def _resolve_power_backend(self, context, source_mode=None):
        """Set power_mode_type and related references. Returns True on success."""
        source_mode = source_mode or getattr(self, 'active_mode', None)

        self.strength_ev_input = None
        self.world_strength_input = None
        self.power_light = None

        if source_mode == MODE_ID_SUN:
            light, _ = find_controllable_light(context)
            if light:
                self.power_light = light
                self.power_mode_type = POWER_MODE_LIGHT
                return True
            return False

        if source_mode == MODE_ID_HDRI:
            backend = detect_hdri_power_backend(self)
            if backend:
                self.power_mode_type = backend
                return True
            return False

        backend = detect_hdri_power_backend(self)
        if backend:
            self.power_mode_type = backend
            return True

        light, _ = find_controllable_light(context)
        if light:
            self.power_light = light
            self.power_mode_type = POWER_MODE_LIGHT
            return True
        return False

    def switch_to_mode(self, context, new_mode, event):
        """Switch to a new control mode"""
        # Exit current mode if in Sun mode
        if self.active_mode == MODE_ID_SUN and hasattr(self, 'sun_lamp') and self.sun_lamp:
            exit_sun_mode(context, self)
        
        self.active_mode = new_mode
        self.start_x = event.mouse_x
        self.start_y = event.mouse_y
        
        if new_mode == MODE_ID_SUN:
            self._last_mouse_x = event.mouse_x
            self._last_mouse_y = event.mouse_y
            if not enter_sun_mode(context, self):
                # Fallback to first available mode if Sun mode fails
                if len(self.available_modes) > 1:
                    fallback = [m for m in self.available_modes if m != MODE_ID_SUN][0]
                    self.switch_to_mode(context, fallback, event)
                return
            self.mode = ROT_MODE_SUN
        
        elif new_mode == MODE_ID_WORLD_SPACE_LIGHTING:
            self.mode = ROT_MODE_STUDIO_WORLD_SPACE
            self.start_rotation = math.degrees(self.shading.studiolight_rotate_z)
            self.window.cursor_modal_set('SCROLL_X')
            draw_handler.update_rotation_value(self.mode, self.start_rotation)
        
        elif new_mode == MODE_ID_SHADOWS:
            self.mode = ROT_MODE_SHADOW
            self.start_light_direction = self.scene.display.light_direction.copy()
            self.window.cursor_modal_set('SCROLL_XY')
            draw_handler.update_rotation_value(self.mode, self.start_light_direction)
        
        elif new_mode == MODE_ID_HDRI:
            self.mode = self.hdri_mode_type
            self._init_hdri_rotation()
            self.window.cursor_modal_set('SCROLL_X')
        
        update_status_bar(context, self)
    
    def _init_hdri_rotation(self):
        """Initialize HDRI rotation based on the detected HDRI mode type"""
        if self.hdri_mode_type == ROT_MODE_SKY_TEXTURE:
            self.start_rotation = self.sky_texture_node.sun_rotation
            draw_handler.update_rotation_value(self.mode, self.start_rotation)
        
        elif self.hdri_mode_type == ROT_MODE_CUSTOM_HDRI:
            default_value = self.rotation_input.default_value
            if isinstance(default_value, (mathutils.Euler, mathutils.Vector)):
                self.start_rotation = default_value.copy()
            elif isinstance(default_value, (float, int)):
                self.start_rotation = default_value
            if should_sync_hdri_rotation(self):
                sync_builtin_rotation_to_world(self)
            draw_handler.update_rotation_value(self.mode, self.start_rotation)
        
        elif self.hdri_mode_type == ROT_MODE_MAPPING_NODE:
            default_value = self.mapping_node.inputs['Rotation'].default_value
            if isinstance(default_value, (mathutils.Vector, mathutils.Euler)):
                self.start_rotation = default_value.copy()
            if should_sync_hdri_rotation(self):
                sync_builtin_rotation_to_world(self)
            draw_handler.update_rotation_value(self.mode, self.start_rotation)
        
        elif self.hdri_mode_type == ROT_MODE_HDRI:
            self.start_rotation = get_builtin_hdr_rotation(self.shading)
            if should_sync_hdri_rotation(self):
                sync_world_rotation_to_builtin(self)
            draw_handler.update_rotation_value(self.mode, self.start_rotation)
    
    def cycle_mode(self, context, event):
        """Cycle to the next available mode"""
        if len(self.available_modes) <= 1:
            return
        
        current_index = self.available_modes.index(self.active_mode) if self.active_mode in self.available_modes else 0
        new_index = (current_index + 1) % len(self.available_modes)
        new_mode = self.available_modes[new_index]
        
        self.switch_to_mode(context, new_mode, event)

    def invoke(self, context, event):
        try:
            self.start_x = event.mouse_x
            self.start_y = event.mouse_y
            self.shift_held = event.shift
            self.hdri_mode_type = None

            self.window = context.window
            self.space = context.space_data
            self.scene = context.scene

            self.area = get_area_safe()
            if not self.area:
                self.report({'WARNING'}, "Operator must be run in a 3D Viewport")
                return {'CANCELLED'}

            self.shading = self.space.shading
            self.shading_type = self.shading.type
            
            # Detect available modes for this shading type
            self.available_modes = self.detect_available_modes(context)
            
            if not self.available_modes:
                if self.shading_type == 'WIREFRAME':
                    self.report({'WARNING'}, "No Sun Light found in scene")
                elif self.shading_type == 'SOLID':
                    self.report({'WARNING'}, "Enable Shadows or World Space Lighting, or add a Sun Light")
                else:
                    self.report({'WARNING'}, "No controllable rotation source found")
                return {'CANCELLED'}
            
            # Try to restore last used mode, otherwise use the first available
            last_mode = self.get_last_mode(context)
            if last_mode and last_mode in self.available_modes:
                self.active_mode = last_mode
            else:
                self.active_mode = self.available_modes[0]
            
            # Initialize the first mode
            if self.active_mode == MODE_ID_SUN:
                self._last_mouse_x = event.mouse_x
                self._last_mouse_y = event.mouse_y
                if not enter_sun_mode(context, self):
                    self.report({'WARNING'}, "Failed to enter Sun mode")
                    return {'CANCELLED'}
                self.mode = ROT_MODE_SUN
                self.window.cursor_modal_set('SCROLL_X')
            
            elif self.active_mode == MODE_ID_WORLD_SPACE_LIGHTING:
                self.mode = ROT_MODE_STUDIO_WORLD_SPACE
                self.start_rotation = math.degrees(self.shading.studiolight_rotate_z)
                self.window.cursor_modal_set('SCROLL_X')
                draw_handler.update_rotation_value(self.mode, self.start_rotation)
            
            elif self.active_mode == MODE_ID_SHADOWS:
                self.mode = ROT_MODE_SHADOW
                self.start_light_direction = self.scene.display.light_direction.copy()
                self.window.cursor_modal_set('SCROLL_XY')
                draw_handler.update_rotation_value(self.mode, self.start_light_direction)
            
            elif self.active_mode == MODE_ID_HDRI:
                self.mode = self.hdri_mode_type
                self._init_hdri_rotation()
                self.window.cursor_modal_set('SCROLL_X')
                if self.shading_type in {'MATERIAL', 'RENDERED'}:
                    handle_mode_switch_sync(self)

            context.window_manager.modal_handler_add(self)
            update_status_bar(context, self)
            
            return {'RUNNING_MODAL'}

        except Exception as e:
            self.report({'ERROR'}, f"Initialization failed: {str(e)}")
            self.cleanup()
            return {'CANCELLED'}

    def cleanup(self):
        if hasattr(self, 'window') and self.window:
            self.window.cursor_modal_restore()
        
        try:
            clear_status_bar(bpy.context)
        except (AttributeError, ReferenceError):
            pass
        
        try:
            if hasattr(self, 'active_mode') and self.active_mode == MODE_ID_SUN:
                exit_sun_mode(bpy.context, self)
        except (AttributeError, ReferenceError):
            pass
        
        for attr in ['shift_held', 'start_rotation', 'start_light_direction', 'start_z_location',
                    'start_sun_elevation', 'start_power',
                    'rotation_input', 'mapping_node', 'sky_texture_node', 'mode', 'start_x', 'start_y',
                    'sun_lamp', 'original_selection', 'original_active',
                    'sun_start_rotation',
                    '_last_mouse_x', '_last_mouse_y', 'available_modes', 'active_mode',
                    'hdri_mode_type', 'power_mode_type', 'power_available',
                    'strength_ev_input', 'world_strength_input',
                    'power_light', 'use_scene_world']:
            if hasattr(self, attr):
                try:
                    delattr(self, attr)
                except AttributeError:
                    pass
        

    def calculate_new_direction(self, start_direction, rot_x, rot_z):
        """Calculate new light direction based on mouse movement"""
        rot_x_mat = mathutils.Matrix.Rotation(rot_x, 4, 'X')
        rot_z_mat = mathutils.Matrix.Rotation(rot_z, 4, 'Z')
        
        new_direction = start_direction.copy()
        new_direction.rotate(rot_z_mat)
        new_direction.rotate(rot_x_mat)
        
        if new_direction.length_squared != 0:
            new_direction.normalize()
        else:
            new_direction = mathutils.Vector((0.0, 0.0, -1.0))
            
        return new_direction

    def execute(self, context):
        self.cleanup()
        return {'FINISHED'}

    def _restore_original_state(self):
        """Restore original state when cancelling - shared by ESC and cancel()"""
        # Restore Sun Light if in Sun Mode
        if hasattr(self, 'active_mode') and self.active_mode == MODE_ID_SUN and hasattr(self, 'sun_lamp') and self.sun_lamp:
            if hasattr(self, 'sun_start_rotation'):
                self.sun_lamp.rotation_euler = self.sun_start_rotation.copy()
        
        if hasattr(self, 'mode'):
            if self.mode == ROT_MODE_SHADOW:
                self.scene.display.light_direction = self.start_light_direction
            elif self.mode == ROT_MODE_STUDIO_WORLD_SPACE:
                set_studio_world_space_rotation(self, self.start_rotation)
            elif self.mode == ROT_MODE_CUSTOM_HDRI:
                set_custom_hdri_rotation(self, self.start_rotation)
            elif self.mode == ROT_MODE_MAPPING_NODE:
                set_mapping_node_rotation(self, self.start_rotation)
            elif self.mode == ROT_MODE_MAPPING_Z_LOCATION:
                if hasattr(self, 'start_z_location'):
                    set_mapping_node_z_location(self, self.start_z_location)
            elif self.mode == ROT_MODE_SKY_TEXTURE_ELEVATION:
                if hasattr(self, 'start_sun_elevation'):
                    set_sky_texture_elevation(self, self.start_sun_elevation)
            elif self.mode == ROT_MODE_SKY_TEXTURE:
                set_sky_texture_rotation(self, self.start_rotation)
            elif self.mode == ROT_MODE_HDRI:
                set_builtin_hdr_rotation(self, self.start_rotation)
            elif self.mode == ROT_MODE_POWER:
                if hasattr(self, 'start_power'):
                    set_power_value(self, self.start_power)

    def cancel(self, context):
        self._restore_original_state()
        self.cleanup()
        return {'CANCELLED'}


def register():
    bpy.utils.register_class(HDRI_Rotator)
    
    # Register WindowManager properties to remember last used modes
    bpy.types.WindowManager.hdri_rotator_last_mode_wireframe = bpy.props.StringProperty(
        name="Last Wireframe Mode",
        default="SUN"
    )
    bpy.types.WindowManager.hdri_rotator_last_mode_solid = bpy.props.StringProperty(
        name="Last Solid/Workbench Mode",
        default=""
    )
    bpy.types.WindowManager.hdri_rotator_last_mode_material = bpy.props.StringProperty(
        name="Last Material/Rendered Mode",
        default=""
    )


def unregister():
    bpy.utils.unregister_class(HDRI_Rotator)
    
    # Safely unregister WindowManager properties
    if hasattr(bpy.types.WindowManager, 'hdri_rotator_last_mode_wireframe'):
        del bpy.types.WindowManager.hdri_rotator_last_mode_wireframe
    if hasattr(bpy.types.WindowManager, 'hdri_rotator_last_mode_solid'):
        del bpy.types.WindowManager.hdri_rotator_last_mode_solid
    if hasattr(bpy.types.WindowManager, 'hdri_rotator_last_mode_material'):
        del bpy.types.WindowManager.hdri_rotator_last_mode_material
