import bpy
import math
import mathutils
import os


# ─── Key Binding Labels for Status Bar ───────────────────────────────────────
# Centralized definitions for all keyboard shortcuts shown in the status bar.
# Update these when changing keybindings in operators.py modal().

KEY_SHIFT = "[Shift]"
KEY_TAB = "[Tab]"
KEY_H = "[H]"
KEY_S = "[S]"
KEY_W = "[W]"
KEY_D = "[D]"
KEY_X = "[X]"
KEY_Z = "[Z]"
KEY_R = "[R]"
KEY_P = "[P]"

# Mode display names (for UI)
MODE_HDRI = "HDRI"
MODE_SUN = "Sun"
MODE_POWER = "Power"
MODE_STUDIO_LIGHT = "Studio Light"
MODE_SHADOWS = "Shadows"

# Mode identifiers (internal constants)
MODE_ID_HDRI = 'HDRI'
MODE_ID_SUN = 'SUN'
MODE_ID_WORLD_SPACE_LIGHTING = 'WORLD_SPACE_LIGHTING'
MODE_ID_SHADOWS = 'SHADOWS'

# Rotation mode identifiers
ROT_MODE_SHADOW = 'SHADOW_ROTATION'
ROT_MODE_STUDIO_WORLD_SPACE = 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION'
ROT_MODE_CUSTOM_HDRI = 'CUSTOM_HDRI_ROTATION'
ROT_MODE_MAPPING_NODE = 'MAPPING_NODE_ROTATION'
ROT_MODE_MAPPING_Z_LOCATION = 'MAPPING_Z_LOCATION'
ROT_MODE_SKY_TEXTURE = 'SKY_TEXTURE_ROTATION'
ROT_MODE_SKY_TEXTURE_ELEVATION = 'SKY_TEXTURE_ELEVATION'
ROT_MODE_HDRI = 'HDRI_ROTATION'
ROT_MODE_SUN = 'SUN_ROTATION'
ROT_MODE_POWER = 'POWER'

# Power backend identifiers
POWER_MODE_BUILTIN = 'POWER_BUILTIN'
POWER_MODE_CUSTOM_EV = 'POWER_CUSTOM_EV'
POWER_MODE_WORLD_BACKGROUND = 'POWER_WORLD_BACKGROUND'
POWER_MODE_LIGHT = 'POWER_LIGHT'

# Power value ranges used when clamping is enabled
POWER_RANGE_BUILTIN_MIN = 0.0
POWER_RANGE_EV_MIN = -10.0
POWER_RANGE_EV_MAX = 10.0
POWER_RANGE_LIGHT_MIN = 0.0
POWER_RANGE_LIGHT_MAX = 10.0


# ═══════════════════════════════════════════════════════════════════════════════
# CORE UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_addon_prefs():
    """Get addon preferences"""
    addon_name = __package__
    try:
        return bpy.context.preferences.addons[addon_name].preferences
    except KeyError:
        return None


def get_area_safe():
    """Safely get a 3D View area reference"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            return area
    return None


def safe_redraw():
    """Safely redraw the 3D viewport"""
    area = get_area_safe()
    if area:
        area.tag_redraw()


def has_hdri_height_context(operator):
    """True when scene World HDRI supports a vertical (height) adjustment control."""
    if not getattr(operator, 'use_scene_world', False):
        return False
    if (getattr(operator, 'hdri_mode_type', None) == ROT_MODE_SKY_TEXTURE
            and getattr(operator, 'sky_texture_node', None)):
        return True
    mapping_node = getattr(operator, 'mapping_node', None)
    return mapping_node is not None and 'Location' in mapping_node.inputs


_MODE_DISPLAY_NAMES = {
    MODE_ID_HDRI: MODE_HDRI,
    MODE_ID_SUN: MODE_SUN,
    MODE_ID_WORLD_SPACE_LIGHTING: MODE_STUDIO_LIGHT,
    MODE_ID_SHADOWS: MODE_SHADOWS,
}

_MODE_SWITCH_KEYS = {
    MODE_ID_HDRI: KEY_H,
    MODE_ID_SUN: KEY_S,
    MODE_ID_WORLD_SPACE_LIGHTING: KEY_W,
    MODE_ID_SHADOWS: KEY_D,
}


def _format_current_mode_section(operator, active_mode):
    """Build the 'Current Mode' section with in-mode sub-shortcuts."""
    name = _MODE_DISPLAY_NAMES.get(active_mode, active_mode)
    current_mode = getattr(operator, 'mode', None)
    in_power = current_mode == ROT_MODE_POWER
    has_power = getattr(operator, 'power_available', False)

    if active_mode == MODE_ID_HDRI:
        parts = []
        in_height = current_mode in (
            ROT_MODE_MAPPING_Z_LOCATION, ROT_MODE_SKY_TEXTURE_ELEVATION)
        has_height = has_hdri_height_context(operator)

        rot_marker = "●" if not in_height and not in_power else "○"
        parts.append(f"{KEY_R} {rot_marker} Rotation")
        if has_height:
            height_marker = "●" if in_height else "○"
            parts.append(f"{KEY_Z} {height_marker} Height")
        if has_power:
            power_marker = "●" if in_power else "○"
            parts.append(f"{KEY_P} {power_marker} {MODE_POWER}")
        return f"{name} — " + " · ".join(parts)

    if active_mode == MODE_ID_SUN:
        parts = []
        z_marker = "●" if not operator.sun_rotate_x and not in_power else "○"
        x_marker = "●" if operator.sun_rotate_x and not in_power else "○"
        parts.append(f"{KEY_Z} {z_marker} Local Z Rotation")
        parts.append(f"{KEY_X} {x_marker} Local X Rotation")
        if has_power:
            power_marker = "●" if in_power else "○"
            parts.append(f"{KEY_P} {power_marker} {MODE_POWER}")
        return f"{name} — " + " · ".join(parts)

    if has_power:
        power_marker = "●" if in_power else "○"
        return f"{name} — {KEY_P} {power_marker} {MODE_POWER}"

    return name


def _format_other_modes_section(available_modes, active_mode):
    """Build the 'Other Modes' section listing non-active mode switch keys."""
    parts = []
    for mode_id in available_modes:
        if mode_id == active_mode:
            continue
        key = _MODE_SWITCH_KEYS.get(mode_id)
        name = _MODE_DISPLAY_NAMES.get(mode_id, mode_id)
        if key:
            parts.append(f"{key} {name}")
    return " · ".join(parts)


def update_status_bar(context, operator):
    """Update the status bar with a 3-section layout:
    Global (Shift, Tab) | Current Mode: ... | Other Modes: ...
    """
    addon_prefs = get_addon_prefs()
    precision_enabled = addon_prefs.enable_precision if addon_prefs else True

    available_modes = getattr(operator, 'available_modes', [])
    active_mode = getattr(operator, 'active_mode', None)

    # ── Section 1: Global controls ──
    global_parts = []
    if precision_enabled:
        precision_state = "ON" if operator.shift_held else "OFF"
        global_parts.append(f"{KEY_SHIFT} Precision: {precision_state}")
    if len(available_modes) > 1:
        global_parts.append(f"{KEY_TAB} Cycle Mode")

    # ── Section 2: Current Mode ──
    current_part = _format_current_mode_section(operator, active_mode)

    # ── Section 3: Other Modes ──
    other_part = _format_other_modes_section(available_modes, active_mode)

    # ── Assemble ──
    sections = []
    if global_parts:
        sections.append("  ".join(global_parts))
    sections.append(f"Current Mode: {current_part}")
    if other_part:
        sections.append(f"Other Modes: {other_part}")

    context.workspace.status_text_set("  |  ".join(sections))


def clear_status_bar(context):
    """Clear the status bar text"""
    try:
        context.workspace.status_text_set(None)
    except (AttributeError, ReferenceError):
        pass


# ═══════════════════════════════════════════════════════════════════════════════
# SUN MODE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def _is_object_in_excluded_collection(obj, layer_collection):
    """Check if object is in an excluded collection (recursive helper)"""
    for child in layer_collection.children:
        if child.exclude:
            obj_names = {o.name for o in child.collection.objects}
            if obj.name in obj_names:
                return True
        if _is_object_in_excluded_collection(obj, child):
            return True
    return False


def find_sun_lamp(context):
    """Find and validate the Sun Light in the scene. Returns (sun_object, error_message)"""
    scene = context.scene
    view_layer = context.view_layer
    
    # Find all Sun Lights in the scene
    sun_lamps = [obj for obj in scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SUN']
    
    if len(sun_lamps) == 0:
        return None, "No Sun Light found in scene"
    
    if len(sun_lamps) > 1:
        return None, f"Multiple Sun Lights found ({len(sun_lamps)}). Please have only one Sun Light in the scene"
    
    sun = sun_lamps[0]
    
    # Check if hidden from viewport
    if sun.hide_viewport:
        return None, f"Sun Light '{sun.name}' is hidden from viewport"
    
    # Check if disabled from viewport (eye icon)
    if sun.hide_get():
        return None, f"Sun Light '{sun.name}' is disabled in viewport"
    
    # Check if in an excluded collection
    if _is_object_in_excluded_collection(sun, view_layer.layer_collection):
        return None, f"Sun Light '{sun.name}' is in an excluded collection"
    
    # Check if selectable (not hidden from selection)
    if sun.hide_select:
        return None, f"Sun Light '{sun.name}' is not selectable (hidden from selection)"
    
    # Check if rotation axes are locked
    locked_axes = []
    if sun.lock_rotation[0]:
        locked_axes.append('X')
    if sun.lock_rotation[2]:
        locked_axes.append('Z')
    
    if locked_axes:
        return None, f"Sun Light '{sun.name}' has locked rotation axes: {', '.join(locked_axes)}"
    
    return sun, None


def enter_sun_mode(context, operator):
    """Enter Sun Mode - setup Sun Light control. Returns True on success, False on failure."""
    sun, error = find_sun_lamp(context)
    
    if error:
        operator.report({'WARNING'}, error)
        return False
    
    # Store the Sun Light reference
    operator.sun_lamp = sun
    
    # Store original selection and active object
    operator.original_selection = [obj for obj in context.selected_objects]
    operator.original_active = context.view_layer.objects.active
    
    # Deselect all and select only the Sun Light
    # Use direct object manipulation instead of bpy.ops to work in any mode (Edit, Sculpt, etc.)
    for obj in context.selected_objects:
        obj.select_set(False)
    sun.select_set(True)
    context.view_layer.objects.active = sun
    
    operator.sun_start_rotation = sun.rotation_euler.copy()
    
    # Reset mouse position for fresh movement tracking
    operator.start_x = operator._last_mouse_x if hasattr(operator, '_last_mouse_x') else operator.start_x
    operator.start_y = operator._last_mouse_y if hasattr(operator, '_last_mouse_y') else operator.start_y
    
    return True


def exit_sun_mode(context, operator):
    """Exit Sun Mode - restore original selection state"""
    # Restore original selection
    # Use direct object manipulation instead of bpy.ops to work in any mode (Edit, Sculpt, etc.)
    for obj in context.selected_objects:
        try:
            obj.select_set(False)
        except:
            pass
    if hasattr(operator, 'original_selection'):
        for obj in operator.original_selection:
            try:
                obj.select_set(True)
            except:
                pass
    
    # Restore original active object
    if hasattr(operator, 'original_active') and operator.original_active:
        try:
            context.view_layer.objects.active = operator.original_active
        except:
            pass


# ═══════════════════════════════════════════════════════════════════════════════
# HDRI NODE FINDER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def find_node_by_type(node_tree, node_type, visited=None):
    """Generic node finder that traverses node tree including nested groups"""
    if visited is None:
        visited = set()
    if node_tree in visited:
        return None
    visited.add(node_tree)
    
    for node in node_tree.nodes:
        if node.type == node_type:
            return node
        elif node.type == 'GROUP' and node.node_tree:
            result = find_node_by_type(node.node_tree, node_type, visited)
            if result:
                return result
    return None


def find_sky_texture_node(scene):
    """Find a Sky Texture node in the World node tree"""
    world = scene.world
    if world is None or not world.use_nodes:
        return None
    return find_node_by_type(world.node_tree, 'TEX_SKY')


def find_rotation_input(scene, node_tree=None, visited=None):
    """Find a Rotation input in the World node tree"""
    if visited is None:
        visited = set()
    if node_tree is None:
        world = scene.world
        if world is None or not world.use_nodes:
            return None
        node_tree = world.node_tree

    if node_tree in visited:
        return None
    visited.add(node_tree)

    for node in node_tree.nodes:
        if node.type == 'GROUP':
            if 'Rotation' in node.inputs:
                rotation_input = node.inputs['Rotation']
                if rotation_input.is_linked or rotation_input.default_value is not None:
                    return rotation_input
            # Recursively check inside the node group's node tree
            rotation_input = find_rotation_input(scene, node.node_tree, visited)
            if rotation_input:
                return rotation_input
        elif 'Rotation' in node.inputs:
            rotation_input = node.inputs['Rotation']
            if rotation_input.is_linked or rotation_input.default_value is not None:
                return rotation_input
    return None


def find_mapping_node(scene):
    """Find a Mapping node connected to an Environment Texture in the World"""
    world = scene.world
    if world is None or not world.use_nodes:
        return None
    node_tree = world.node_tree

    visited_groups = set()
    nodes_to_check = list(node_tree.nodes)

    while nodes_to_check:
        node = nodes_to_check.pop()
        if node.type == 'GROUP':
            if node.node_tree and node.node_tree not in visited_groups:
                visited_groups.add(node.node_tree)
                nodes_to_check.extend(node.node_tree.nodes)
        elif node.type == 'MAPPING':
            # Check if this Mapping node is connected to an Environment Texture node
            if _is_mapping_connected_to_env_texture(node):
                return node
    return None


def _is_mapping_connected_to_env_texture(mapping_node):
    """Check if a mapping node is connected to an Environment Texture (helper)"""
    nodes_to_check = [mapping_node]
    visited_nodes = set()

    while nodes_to_check:
        node = nodes_to_check.pop()
        visited_nodes.add(node)

        if node.type == 'TEX_ENVIRONMENT':
            return True

        for output in node.outputs:
            for link in output.links:
                next_node = link.to_node
                if next_node not in visited_nodes:
                    nodes_to_check.append(next_node)
                if next_node.type == 'GROUP':
                    # Include nodes inside the group
                    if next_node.node_tree:
                        nodes_to_check.extend(next_node.node_tree.nodes)

    return False


def find_environment_texture_node(node_tree, visited=None):
    """Find Environment Texture node in a node tree, including nested groups"""
    return find_node_by_type(node_tree, 'TEX_ENVIRONMENT', visited)


def find_strength_ev_input(scene, node_tree=None, visited=None):
    """Find a Strength (EVs) input in the World node tree (e.g. Polyhaven HDRI groups)"""
    if visited is None:
        visited = set()
    if node_tree is None:
        world = scene.world
        if world is None or not world.use_nodes:
            return None
        node_tree = world.node_tree

    if node_tree in visited:
        return None
    visited.add(node_tree)

    for node in node_tree.nodes:
        if node.type == 'GROUP':
            if 'Strength (EVs)' in node.inputs:
                strength_input = node.inputs['Strength (EVs)']
                if strength_input.is_linked or strength_input.default_value is not None:
                    return strength_input
            strength_input = find_strength_ev_input(scene, node.node_tree, visited)
            if strength_input:
                return strength_input
        elif 'Strength (EVs)' in node.inputs:
            strength_input = node.inputs['Strength (EVs)']
            if strength_input.is_linked or strength_input.default_value is not None:
                return strength_input
    return None


def find_world_background_strength_input(scene):
    """Find the Strength input on a Background shader node in the World"""
    world = scene.world
    if world is None or not world.use_nodes:
        return None

    for node in world.node_tree.nodes:
        if node.type == 'BACKGROUND' and 'Strength' in node.inputs:
            strength_input = node.inputs['Strength']
            if strength_input.is_linked or strength_input.default_value is not None:
                return strength_input
    return None


def find_controllable_light(context):
    """Find and validate a single controllable Light in the scene. Returns (light_object, error_message)"""
    scene = context.scene
    view_layer = context.view_layer

    lights = [obj for obj in scene.objects if obj.type == 'LIGHT']

    if len(lights) == 0:
        return None, "No Light found in scene"

    if len(lights) > 1:
        return None, f"Multiple Lights found ({len(lights)}). Please have only one Light in the scene"

    light = lights[0]

    if light.hide_viewport:
        return None, f"Light '{light.name}' is hidden from viewport"

    if light.hide_get():
        return None, f"Light '{light.name}' is disabled in viewport"

    if _is_object_in_excluded_collection(light, view_layer.layer_collection):
        return None, f"Light '{light.name}' is in an excluded collection"

    if light.hide_select:
        return None, f"Light '{light.name}' is not selectable (hidden from selection)"

    return light, None


def detect_hdri_power_backend(operator):
    """Detect which HDRI/world strength backend is available. Returns backend id or None."""
    if operator.shading_type not in {'MATERIAL', 'RENDERED'}:
        return None

    if operator.shading_type == 'MATERIAL':
        use_scene_world = operator.shading.use_scene_world
    else:
        use_scene_world = operator.shading.use_scene_world_render

    if not use_scene_world:
        if hasattr(operator.shading, 'studiolight_intensity'):
            return POWER_MODE_BUILTIN
        return None

    strength_ev = find_strength_ev_input(operator.scene)
    if strength_ev is not None:
        operator.strength_ev_input = strength_ev
        return POWER_MODE_CUSTOM_EV

    bg_strength = find_world_background_strength_input(operator.scene)
    if bg_strength is not None:
        operator.world_strength_input = bg_strength
        return POWER_MODE_WORLD_BACKGROUND

    return None


def detect_power_available(operator, context):
    """Check if any power control backend is available for the current shading setup."""
    if detect_hdri_power_backend(operator):
        return True
    light, _ = find_controllable_light(context)
    return light is not None


def _clamp_power_value(power_mode_type, value):
    """Clamp a power value when clamping is enabled in preferences."""
    addon_prefs = get_addon_prefs()
    if not addon_prefs or not addon_prefs.clamp_power_values:
        return value

    if power_mode_type == POWER_MODE_BUILTIN:
        return max(POWER_RANGE_BUILTIN_MIN, value)
    if power_mode_type == POWER_MODE_CUSTOM_EV:
        return max(POWER_RANGE_EV_MIN, min(POWER_RANGE_EV_MAX, value))
    if power_mode_type == POWER_MODE_WORLD_BACKGROUND:
        return max(POWER_RANGE_BUILTIN_MIN, value)
    if power_mode_type == POWER_MODE_LIGHT:
        return max(POWER_RANGE_LIGHT_MIN, min(POWER_RANGE_LIGHT_MAX, value))
    return value


def get_power_value(operator):
    """Read the current power/strength value for the active power backend."""
    power_mode_type = getattr(operator, 'power_mode_type', None)
    if power_mode_type == POWER_MODE_BUILTIN:
        return operator.shading.studiolight_intensity
    if power_mode_type == POWER_MODE_CUSTOM_EV:
        return operator.strength_ev_input.default_value
    if power_mode_type == POWER_MODE_WORLD_BACKGROUND:
        return operator.world_strength_input.default_value
    if power_mode_type == POWER_MODE_LIGHT and getattr(operator, 'power_light', None):
        return operator.power_light.data.energy
    return None


def set_power_value(operator, value):
    """Set power/strength for the active power backend."""
    power_mode_type = getattr(operator, 'power_mode_type', None)
    value = _clamp_power_value(power_mode_type, value)

    if power_mode_type == POWER_MODE_BUILTIN:
        operator.shading.studiolight_intensity = value
    elif power_mode_type == POWER_MODE_CUSTOM_EV:
        if getattr(operator, 'strength_ev_input', None):
            operator.strength_ev_input.default_value = value
    elif power_mode_type == POWER_MODE_WORLD_BACKGROUND:
        if getattr(operator, 'world_strength_input', None):
            operator.world_strength_input.default_value = value
    elif power_mode_type == POWER_MODE_LIGHT:
        if getattr(operator, 'power_light', None):
            operator.power_light.data.energy = value
    else:
        return

    bpy.context.view_layer.update()
    safe_redraw()


# ═══════════════════════════════════════════════════════════════════════════════
# HDRI ROTATION SETTER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def _finalize_rotation_update(operator, rotation_rad=None):
    """Common finalization for rotation updates with optional sync"""
    if rotation_rad is not None and should_sync_hdri_rotation(operator):
        sync_world_to_builtin_rotation(operator, rotation_rad)
    bpy.context.view_layer.update()
    safe_redraw()


def set_sky_texture_rotation(operator, rotation_value):
    """Set the Sun Rotation value for a Sky Texture node"""
    if not operator.sky_texture_node:
        return
    
    # Sky Texture sun_rotation is in radians
    if isinstance(rotation_value, (float, int)):
        # Convert to radians if the value is in degrees
        if rotation_value > math.pi * 2:  # If value is likely in degrees
            rotation_rad = math.radians(rotation_value)
        else:
            rotation_rad = rotation_value
    else:
        rotation_rad = rotation_value
    
    # Don't force wrapping to make behavior consistent with custom HDRI
    operator.sky_texture_node.sun_rotation = rotation_rad
    _finalize_rotation_update(operator, rotation_rad)


def set_sky_texture_elevation(operator, elevation_rad):
    """Set the Sun Elevation value for a Sky Texture node (in radians)"""
    if not operator.sky_texture_node:
        return

    operator.sky_texture_node.sun_elevation = elevation_rad
    bpy.context.view_layer.update()
    safe_redraw()


def set_custom_hdri_rotation(operator, rotation_value):
    """Set rotation for custom HDRI setup"""
    # Handle different rotation input types
    if isinstance(operator.rotation_input.default_value, (mathutils.Euler, mathutils.Vector)):
        operator.rotation_input.default_value = rotation_value
        rotation_rad = rotation_value.z if hasattr(rotation_value, 'z') else rotation_value[2]
    elif isinstance(operator.rotation_input.default_value, (float, int)):
        operator.rotation_input.default_value = rotation_value
        rotation_rad = math.radians(rotation_value)
    else:
        operator.report({'ERROR'}, "Unsupported rotation input type.")
        return
    
    _finalize_rotation_update(operator, rotation_rad)


def set_mapping_node_rotation(operator, rotation_value):
    """Set rotation for Mapping node"""
    rotation_input = operator.mapping_node.inputs['Rotation']
    current_value = rotation_input.default_value
    
    if isinstance(current_value, mathutils.Vector):
        rotation = current_value.copy()
        rotation[2] = rotation_value[2] if isinstance(rotation_value, mathutils.Vector) else rotation_value
        rotation_input.default_value = rotation
        rotation_rad = rotation[2] if isinstance(rotation_value, mathutils.Vector) else math.radians(rotation_value)
    elif isinstance(current_value, mathutils.Euler):
        rotation = current_value.copy()
        rotation.z = rotation_value.z if isinstance(rotation_value, mathutils.Euler) else rotation_value
        rotation_input.default_value = rotation
        rotation_rad = rotation.z if isinstance(rotation_value, mathutils.Euler) else math.radians(rotation_value)
    elif isinstance(current_value, (float, int)):
        rotation_input.default_value = rotation_value
        rotation_rad = math.radians(rotation_value)
    else:
        operator.report({'ERROR'}, "Unsupported rotation input type in mapping node.")
        return
    
    _finalize_rotation_update(operator, rotation_rad)


def set_mapping_node_z_location(operator, z_value):
    """Set the Z component of a Mapping node's Location input"""
    if not getattr(operator, 'mapping_node', None):
        return
    location_input = operator.mapping_node.inputs['Location']
    current_value = location_input.default_value

    if isinstance(current_value, mathutils.Vector):
        location = current_value.copy()
        location[2] = z_value
        location_input.default_value = location
    else:
        location_input.default_value[2] = z_value

    bpy.context.view_layer.update()
    safe_redraw()


def get_builtin_hdr_rotation(shading):
    """Get the built-in HDRI rotation in degrees"""
    return math.degrees(shading.studiolight_rotate_z)


def _set_studiolight_rotate_z(operator, rotation_value):
    """Shared implementation for setting studiolight_rotate_z with sync."""
    rotation_rad = math.radians(rotation_value)
    rotation_rad_wrapped = (rotation_rad + math.pi) % (2 * math.pi) - math.pi
    operator.shading.studiolight_rotate_z = rotation_rad_wrapped
    
    if should_sync_hdri_rotation(operator):
        sync_builtin_to_world_rotation(operator, rotation_rad_wrapped)
    
    safe_redraw()


def set_builtin_hdr_rotation(operator, rotation_value):
    """Set the built-in HDRI rotation"""
    _set_studiolight_rotate_z(operator, rotation_value)


def set_studio_world_space_rotation(operator, rotation_value):
    """Set the Studio World Space Lighting rotation value"""
    _set_studiolight_rotate_z(operator, rotation_value)


# ═══════════════════════════════════════════════════════════════════════════════
# HDRI SYNC FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def should_sync_hdri_rotation(operator):
    """Check if HDRI rotation sync should be enabled"""
    addon_prefs = get_addon_prefs()
    if not addon_prefs or not addon_prefs.enable_hdri_sync:
        return False
    
    # Check if we have a World with nodes enabled
    world = operator.scene.world
    if not world or not world.use_nodes:
        return False
    
    # Check if the World uses the same HDRI as the built-in
    return _is_same_hdri_texture(operator)


def _is_same_hdri_texture(operator):
    """Check if the World HDRI uses the same texture as the current built-in HDRI"""
    try:
        # Get current built-in HDRI name
        current_builtin_hdri = operator.shading.studio_light
        if not current_builtin_hdri:
            return False
        
        # Get World HDRI texture
        world = operator.scene.world
        if not world or not world.use_nodes:
            return False
        
        # Find environment texture node in world
        env_texture_node = find_environment_texture_node(world.node_tree)
        if not env_texture_node or not env_texture_node.image:
            return False
        
        # Get the image name from the environment texture node
        world_image = env_texture_node.image
        if not world_image:
            return False
        
        # Compare file names (case-insensitive)
        world_hdri_name = os.path.basename(world_image.filepath).lower()
        builtin_hdri_name = current_builtin_hdri.lower()
        world_image_name = world_image.name.lower()
        
        # Flexible matching - check if the built-in HDRI name is contained in the world image name
        # or vice versa, to handle cases where Shading Plus might add prefixes/suffixes
        return (world_hdri_name == builtin_hdri_name or 
               world_image_name == builtin_hdri_name or
               builtin_hdri_name in world_hdri_name or
               builtin_hdri_name in world_image_name or
               world_hdri_name in builtin_hdri_name or
               world_image_name in builtin_hdri_name)
    except:
        return False


def sync_builtin_to_world_rotation(operator, rotation_rad):
    """Sync built-in HDRI rotation to World HDRI rotation"""
    world = operator.scene.world
    if not world or not world.use_nodes:
        return
    
    mapping_node = find_mapping_node(operator.scene)
    if mapping_node:
        # Set the Z rotation (Yaw) in the mapping node
        mapping_node.inputs['Rotation'].default_value[2] = rotation_rad


def sync_world_to_builtin_rotation(operator, rotation_rad):
    """Sync World HDRI rotation to built-in HDRI rotation"""
    operator.shading.studiolight_rotate_z = rotation_rad


def sync_world_rotation_to_builtin(operator):
    """Sync World HDRI rotation to built-in HDRI when switching to built-in mode"""
    world = operator.scene.world
    if not world or not world.use_nodes:
        return
    
    mapping_node = find_mapping_node(operator.scene)
    if mapping_node:
        # Get the Z rotation from the mapping node
        rotation_value = mapping_node.inputs['Rotation'].default_value
        if isinstance(rotation_value, (mathutils.Vector, mathutils.Euler)):
            rotation_rad = rotation_value[2] if isinstance(rotation_value, mathutils.Vector) else rotation_value.z
            # Sync to built-in HDRI
            operator.shading.studiolight_rotate_z = rotation_rad


def sync_builtin_rotation_to_world(operator):
    """Sync built-in HDRI rotation to World HDRI when switching to world mode"""
    world = operator.scene.world
    if not world or not world.use_nodes:
        return
    
    builtin_rotation_rad = operator.shading.studiolight_rotate_z
    
    mapping_node = find_mapping_node(operator.scene)
    if mapping_node:
        # Set the Z rotation in the mapping node
        rotation_value = mapping_node.inputs['Rotation'].default_value
        if isinstance(rotation_value, (mathutils.Vector, mathutils.Euler)):
            if isinstance(rotation_value, mathutils.Vector):
                rotation_value[2] = builtin_rotation_rad
            else:
                rotation_value.z = builtin_rotation_rad
            mapping_node.inputs['Rotation'].default_value = rotation_value


def handle_mode_switch_sync(operator):
    """Handle sync when switching between Material and Rendered modes"""
    # Only handle sync if it's enabled
    if not should_sync_hdri_rotation(operator):
        return
    
    # Get current mode info
    if operator.shading_type == 'MATERIAL':
        use_scene_world = operator.shading.use_scene_world
    else:  # RENDERED
        use_scene_world = operator.shading.use_scene_world_render
    
    # If switching to scene world mode, sync from built-in to world
    if use_scene_world:
        sync_builtin_rotation_to_world(operator)
    else:
        # If switching to built-in mode, sync from world to built-in
        sync_world_rotation_to_builtin(operator)


def get_current_rotation(operator):
    """Get current rotation value based on mode"""
    try:
        if operator.mode == ROT_MODE_SHADOW:
            return operator.scene.display.light_direction.copy()
        elif operator.mode == ROT_MODE_STUDIO_WORLD_SPACE:
            return math.degrees(operator.shading.studiolight_rotate_z)
        elif operator.mode == ROT_MODE_CUSTOM_HDRI:
            if isinstance(operator.start_rotation, (mathutils.Euler, mathutils.Vector)):
                return operator.rotation_input.default_value.copy()
            elif isinstance(operator.start_rotation, (float, int)):
                return operator.rotation_input.default_value
            return None
        elif operator.mode == ROT_MODE_MAPPING_NODE:
            return operator.mapping_node.inputs['Rotation'].default_value.copy()
        elif operator.mode == ROT_MODE_MAPPING_Z_LOCATION:
            return operator.mapping_node.inputs['Location'].default_value[2]
        elif operator.mode == ROT_MODE_SKY_TEXTURE:
            return operator.sky_texture_node.sun_rotation
        elif operator.mode == ROT_MODE_SKY_TEXTURE_ELEVATION:
            return operator.sky_texture_node.sun_elevation
        elif operator.mode == ROT_MODE_HDRI:
            return get_builtin_hdr_rotation(operator.shading)
        return None
    except Exception as e:
        operator.report({'WARNING'}, f"Error getting rotation: {str(e)}")
        return None
