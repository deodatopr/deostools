import bpy
import math
import mathutils
import os


# ─── Key Binding Labels for Status Bar ───────────────────────────────────────
# Centralized definitions for all keyboard shortcuts shown in the status bar.
# Update these when changing keybindings in operators.py modal().

KEY_SHIFT = "[Shift]"
KEY_TAB = "[Tab]"
KEY_H = "[H]"
KEY_S = "[S]"
KEY_W = "[W]"
KEY_D = "[D]"
KEY_X = "[X]"
KEY_Z = "[Z]"

# Mode display names (for UI)
MODE_HDRI = "HDRI"
MODE_SUN = "Sun"
MODE_STUDIO_LIGHT = "Studio Light"
MODE_SHADOWS = "Shadows"

# Mode identifiers (internal constants)
MODE_ID_HDRI = 'HDRI'
MODE_ID_SUN = 'SUN'
MODE_ID_WORLD_SPACE_LIGHTING = 'WORLD_SPACE_LIGHTING'
MODE_ID_SHADOWS = 'SHADOWS'

# Rotation mode identifiers
ROT_MODE_SHADOW = 'SHADOW_ROTATION'
ROT_MODE_STUDIO_WORLD_SPACE = 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION'
ROT_MODE_CUSTOM_HDRI = 'CUSTOM_HDRI_ROTATION'
ROT_MODE_MAPPING_NODE = 'MAPPING_NODE_ROTATION'
ROT_MODE_SKY_TEXTURE = 'SKY_TEXTURE_ROTATION'
ROT_MODE_HDRI = 'HDRI_ROTATION'
ROT_MODE_SUN = 'SUN_ROTATION'


# ═══════════════════════════════════════════════════════════════════════════════
# CORE UTILITY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def get_addon_prefs():
    """Get addon preferences"""
    addon_name = __package__
    try:
        return bpy.context.preferences.addons[addon_name].preferences
    except KeyError:
        return None


def get_area_safe():
    """Safely get a 3D View area reference"""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            return area
    return None


def safe_redraw():
    """Safely redraw the 3D viewport"""
    area = get_area_safe()
    if area:
        area.tag_redraw()


def _is_workbench(context):
    """Check if the current render engine is Workbench"""
    try:
        return context.scene.render.engine == 'BLENDER_WORKBENCH'
    except (AttributeError, ReferenceError):
        return False


def update_status_bar(context, operator):
    """Update the status bar with available actions based on current shading mode"""
    addon_prefs = get_addon_prefs()
    precision_enabled = addon_prefs.enable_precision if addon_prefs else True
    
    # Build status text with key hints
    status_items = []
    
    # For all shading modes: SHIFT for precision (if enabled)
    if precision_enabled:
        precision_state = "ON" if operator.shift_held else "OFF"
        status_items.append(f"{KEY_SHIFT} Precision: {precision_state}")
    
    # Get available modes and active mode
    available_modes = getattr(operator, 'available_modes', [])
    active_mode = getattr(operator, 'active_mode', None)
    
    # Show cycle hint if multiple modes available
    if len(available_modes) > 1:
        status_items.append(f"{KEY_TAB} Cycle Mode")
    
    # Mode-specific status items based on shading type
    shading_type = getattr(operator, 'shading_type', None)
    
    if shading_type == 'WIREFRAME':
        # Wireframe: Sun mode only
        if MODE_ID_SUN in available_modes:
            status_items.append(f"● {MODE_SUN} Mode")
    
    elif shading_type == 'SOLID' or (shading_type == 'RENDERED' and _is_workbench(context)):
        # Solid / Rendered (Workbench): Sun, World Space Lighting, Shadows
        if MODE_ID_SUN in available_modes:
            marker = "●" if active_mode == MODE_ID_SUN else "○"
            status_items.append(f"{KEY_S} {marker} {MODE_SUN}")
        if MODE_ID_WORLD_SPACE_LIGHTING in available_modes:
            marker = "●" if active_mode == MODE_ID_WORLD_SPACE_LIGHTING else "○"
            status_items.append(f"{KEY_W} {marker} {MODE_STUDIO_LIGHT}")
        if MODE_ID_SHADOWS in available_modes:
            marker = "●" if active_mode == MODE_ID_SHADOWS else "○"
            status_items.append(f"{KEY_D} {marker} {MODE_SHADOWS}")
    
    elif shading_type in {'MATERIAL', 'RENDERED'}:
        # Material Preview / Rendered: HDRI and Sun (only show available options)
        if MODE_ID_HDRI in available_modes:
            marker = "●" if active_mode == MODE_ID_HDRI else "○"
            status_items.append(f"{KEY_H} {marker} {MODE_HDRI}")
        if MODE_ID_SUN in available_modes:
            marker = "●" if active_mode == MODE_ID_SUN else "○"
            status_items.append(f"{KEY_S} {marker} {MODE_SUN}")
    
    # Sun rotation axis selection: X (local) and Z (cursor pivot)
    if active_mode == MODE_ID_SUN:
        z_marker = "○" if operator.sun_rotate_x else "●"
        x_marker = "●" if operator.sun_rotate_x else "○"
        status_items.append(f"{KEY_Z} {z_marker} 3D Cursor Orbit")
        status_items.append(f"{KEY_X} {x_marker} Local X Rotation")
    
    # Join all items with separator
    status_text = "    |    ".join(status_items)
    
    # Set the status bar text
    context.workspace.status_text_set(status_text)


def clear_status_bar(context):
    """Clear the status bar text"""
    try:
        context.workspace.status_text_set(None)
    except (AttributeError, ReferenceError):
        pass


# ═══════════════════════════════════════════════════════════════════════════════
# SUN MODE FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def _is_object_in_excluded_collection(obj, layer_collection):
    """Check if object is in an excluded collection (recursive helper)"""
    for child in layer_collection.children:
        if child.exclude:
            obj_names = {o.name for o in child.collection.objects}
            if obj.name in obj_names:
                return True
        if _is_object_in_excluded_collection(obj, child):
            return True
    return False


def find_sun_lamp(context):
    """Find and validate the Sun Light in the scene. Returns (sun_object, error_message)"""
    scene = context.scene
    view_layer = context.view_layer
    
    # Find all Sun Lights in the scene
    sun_lamps = [obj for obj in scene.objects if obj.type == 'LIGHT' and obj.data.type == 'SUN']
    
    if len(sun_lamps) == 0:
        return None, "No Sun Light found in scene"
    
    if len(sun_lamps) > 1:
        return None, f"Multiple Sun Lights found ({len(sun_lamps)}). Please have only one Sun Light in the scene"
    
    sun = sun_lamps[0]
    
    # Check if hidden from viewport
    if sun.hide_viewport:
        return None, f"Sun Light '{sun.name}' is hidden from viewport"
    
    # Check if disabled from viewport (eye icon)
    if sun.hide_get():
        return None, f"Sun Light '{sun.name}' is disabled in viewport"
    
    # Check if in an excluded collection
    if _is_object_in_excluded_collection(sun, view_layer.layer_collection):
        return None, f"Sun Light '{sun.name}' is in an excluded collection"
    
    # Check if selectable (not hidden from selection)
    if sun.hide_select:
        return None, f"Sun Light '{sun.name}' is not selectable (hidden from selection)"
    
    # Check if rotation axes are locked
    locked_axes = []
    if sun.lock_rotation[0]:
        locked_axes.append('X')
    if sun.lock_rotation[2]:
        locked_axes.append('Z')
    
    if locked_axes:
        return None, f"Sun Light '{sun.name}' has locked rotation axes: {', '.join(locked_axes)}"
    
    return sun, None


def enter_sun_mode(context, operator):
    """Enter Sun Mode - setup Sun Light control. Returns True on success, False on failure."""
    sun, error = find_sun_lamp(context)
    
    if error:
        operator.report({'WARNING'}, error)
        # Revert to HDRI mode
        operator.control_mode = MODE_ID_HDRI
        return False
    
    # Store the Sun Light reference
    operator.sun_lamp = sun
    
    # Store original selection and active object
    operator.original_selection = [obj for obj in context.selected_objects]
    operator.original_active = context.view_layer.objects.active
    
    # Note: Pivot is already set to CURSOR in invoke() since we can't change it during modal
    
    # Deselect all and select only the Sun Light
    # Use direct object manipulation instead of bpy.ops to work in any mode (Edit, Sculpt, etc.)
    for obj in context.selected_objects:
        obj.select_set(False)
    sun.select_set(True)
    context.view_layer.objects.active = sun
    
    # Store the starting rotation and location for rotation around 3D cursor
    operator.sun_start_rotation = sun.rotation_euler.copy()
    operator.sun_start_location = sun.location.copy()
    
    # Store the 3D cursor position as the pivot point
    operator.sun_pivot_point = context.scene.cursor.location.copy()
    
    # Reset mouse position for fresh movement tracking
    operator.start_x = operator._last_mouse_x if hasattr(operator, '_last_mouse_x') else operator.start_x
    operator.start_y = operator._last_mouse_y if hasattr(operator, '_last_mouse_y') else operator.start_y
    
    return True


def exit_sun_mode(context, operator):
    """Exit Sun Mode - restore original selection state"""
    # Note: Pivot restoration is handled in cleanup() since it was set in invoke()
    
    # Restore original selection
    # Use direct object manipulation instead of bpy.ops to work in any mode (Edit, Sculpt, etc.)
    for obj in context.selected_objects:
        try:
            obj.select_set(False)
        except:
            pass
    if hasattr(operator, 'original_selection'):
        for obj in operator.original_selection:
            try:
                obj.select_set(True)
            except:
                pass
    
    # Restore original active object
    if hasattr(operator, 'original_active') and operator.original_active:
        try:
            context.view_layer.objects.active = operator.original_active
        except:
            pass


# ═══════════════════════════════════════════════════════════════════════════════
# HDRI NODE FINDER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def find_node_by_type(node_tree, node_type, visited=None):
    """Generic node finder that traverses node tree including nested groups"""
    if visited is None:
        visited = set()
    if node_tree in visited:
        return None
    visited.add(node_tree)
    
    for node in node_tree.nodes:
        if node.type == node_type:
            return node
        elif node.type == 'GROUP' and node.node_tree:
            result = find_node_by_type(node.node_tree, node_type, visited)
            if result:
                return result
    return None


def find_sky_texture_node(scene):
    """Find a Sky Texture node in the World node tree"""
    world = scene.world
    if world is None or not world.use_nodes:
        return None
    return find_node_by_type(world.node_tree, 'TEX_SKY')


def find_rotation_input(scene, node_tree=None, visited=None, depth=0):
    """Find a Rotation input in the World node tree"""
    if visited is None:
        visited = set()
    if node_tree is None:
        world = scene.world
        if world is None or not world.use_nodes:
            return None
        node_tree = world.node_tree

    if node_tree in visited:
        return None
    visited.add(node_tree)

    for node in node_tree.nodes:
        if node.type == 'GROUP':
            if 'Rotation' in node.inputs:
                rotation_input = node.inputs['Rotation']
                if rotation_input.is_linked or rotation_input.default_value is not None:
                    return rotation_input
            # Recursively check inside the node group's node tree
            rotation_input = find_rotation_input(scene, node.node_tree, visited, depth + 1)
            if rotation_input:
                return rotation_input
        elif 'Rotation' in node.inputs:
            rotation_input = node.inputs['Rotation']
            if rotation_input.is_linked or rotation_input.default_value is not None:
                return rotation_input
    return None


def find_mapping_node(scene):
    """Find a Mapping node connected to an Environment Texture in the World"""
    world = scene.world
    if world is None or not world.use_nodes:
        return None
    node_tree = world.node_tree

    visited_groups = set()
    nodes_to_check = list(node_tree.nodes)

    while nodes_to_check:
        node = nodes_to_check.pop()
        if node.type == 'GROUP':
            if node.node_tree and node.node_tree not in visited_groups:
                visited_groups.add(node.node_tree)
                nodes_to_check.extend(node.node_tree.nodes)
        elif node.type == 'MAPPING':
            # Check if this Mapping node is connected to an Environment Texture node
            if _is_mapping_connected_to_env_texture(node):
                return node
    return None


def _is_mapping_connected_to_env_texture(mapping_node):
    """Check if a mapping node is connected to an Environment Texture (helper)"""
    nodes_to_check = [mapping_node]
    visited_nodes = set()

    while nodes_to_check:
        node = nodes_to_check.pop()
        visited_nodes.add(node)

        if node.type == 'TEX_ENVIRONMENT':
            return True

        for output in node.outputs:
            for link in output.links:
                next_node = link.to_node
                if next_node not in visited_nodes:
                    nodes_to_check.append(next_node)
                if next_node.type == 'GROUP':
                    # Include nodes inside the group
                    if next_node.node_tree:
                        nodes_to_check.extend(next_node.node_tree.nodes)

    return False


def find_environment_texture_node(node_tree, visited=None):
    """Find Environment Texture node in a node tree, including nested groups"""
    return find_node_by_type(node_tree, 'TEX_ENVIRONMENT', visited)


def find_mapping_node_in_world(node_tree, visited=None):
    """Find Mapping node in world node tree, including nested groups"""
    return find_node_by_type(node_tree, 'MAPPING', visited)


# ═══════════════════════════════════════════════════════════════════════════════
# HDRI ROTATION SETTER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def _finalize_rotation_update(operator, rotation_rad=None):
    """Common finalization for rotation updates with optional sync"""
    if rotation_rad is not None and should_sync_hdri_rotation(operator):
        sync_world_to_builtin_rotation(operator, rotation_rad)
    bpy.context.view_layer.update()
    safe_redraw()


def set_sky_texture_rotation(operator, rotation_value):
    """Set the Sun Rotation value for a Sky Texture node"""
    if not operator.sky_texture_node:
        return
    
    # Sky Texture sun_rotation is in radians
    if isinstance(rotation_value, (float, int)):
        # Convert to radians if the value is in degrees
        if rotation_value > math.pi * 2:  # If value is likely in degrees
            rotation_rad = math.radians(rotation_value)
        else:
            rotation_rad = rotation_value
    else:
        rotation_rad = rotation_value
    
    # Don't force wrapping to make behavior consistent with custom HDRI
    operator.sky_texture_node.sun_rotation = rotation_rad
    _finalize_rotation_update(operator, rotation_rad)


def set_custom_hdri_rotation(operator, rotation_value):
    """Set rotation for custom HDRI setup"""
    # Handle different rotation input types
    if isinstance(operator.rotation_input.default_value, (mathutils.Euler, mathutils.Vector)):
        operator.rotation_input.default_value = rotation_value
        rotation_rad = rotation_value.z if hasattr(rotation_value, 'z') else rotation_value[2]
    elif isinstance(operator.rotation_input.default_value, (float, int)):
        operator.rotation_input.default_value = rotation_value
        rotation_rad = math.radians(rotation_value)
    else:
        operator.report({'ERROR'}, "Unsupported rotation input type.")
        return
    
    _finalize_rotation_update(operator, rotation_rad)


def set_mapping_node_rotation(operator, rotation_value):
    """Set rotation for Mapping node"""
    rotation_input = operator.mapping_node.inputs['Rotation']
    current_value = rotation_input.default_value
    
    if isinstance(current_value, mathutils.Vector):
        rotation = current_value.copy()
        rotation[2] = rotation_value[2] if isinstance(rotation_value, mathutils.Vector) else rotation_value
        rotation_input.default_value = rotation
        rotation_rad = rotation[2] if isinstance(rotation_value, mathutils.Vector) else math.radians(rotation_value)
    elif isinstance(current_value, mathutils.Euler):
        rotation = current_value.copy()
        rotation.z = rotation_value.z if isinstance(rotation_value, mathutils.Euler) else rotation_value
        rotation_input.default_value = rotation
        rotation_rad = rotation.z if isinstance(rotation_value, mathutils.Euler) else math.radians(rotation_value)
    elif isinstance(current_value, (float, int)):
        rotation_input.default_value = rotation_value
        rotation_rad = math.radians(rotation_value)
    else:
        operator.report({'ERROR'}, "Unsupported rotation input type in mapping node.")
        return
    
    _finalize_rotation_update(operator, rotation_rad)


def get_builtin_hdr_rotation(shading):
    """Get the built-in HDRI rotation in degrees"""
    return math.degrees(shading.studiolight_rotate_z)


def set_builtin_hdr_rotation(operator, rotation_value):
    """Set the built-in HDRI rotation"""
    rotation_rad = math.radians(rotation_value)
    # Wrap rotation to -pi to pi
    rotation_rad_wrapped = (rotation_rad + math.pi) % (2 * math.pi) - math.pi
    operator.shading.studiolight_rotate_z = rotation_rad_wrapped
    
    # Sync to World HDRI if enabled and same texture detected
    if should_sync_hdri_rotation(operator):
        sync_builtin_to_world_rotation(operator, rotation_rad_wrapped)
    
    safe_redraw()


def set_studio_world_space_rotation(operator, rotation_value):
    """Set the Studio World Space Lighting rotation value"""
    # Convert to radians for Blender's internal representation
    rotation_rad = math.radians(rotation_value)
    # Wrap rotation to -pi to pi
    rotation_rad_wrapped = (rotation_rad + math.pi) % (2 * math.pi) - math.pi
    # Apply the rotation
    operator.shading.studiolight_rotate_z = rotation_rad_wrapped
    
    # Sync to World HDRI if enabled and same texture detected
    if should_sync_hdri_rotation(operator):
        sync_builtin_to_world_rotation(operator, rotation_rad_wrapped)
    
    # Force update
    safe_redraw()


# ═══════════════════════════════════════════════════════════════════════════════
# HDRI SYNC FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════════

def should_sync_hdri_rotation(operator):
    """Check if HDRI rotation sync should be enabled"""
    addon_prefs = get_addon_prefs()
    if not addon_prefs or not addon_prefs.enable_hdri_sync:
        return False
    
    # Check if we have a World with nodes enabled
    world = operator.scene.world
    if not world or not world.use_nodes:
        return False
    
    # Check if the World uses the same HDRI as the built-in
    return _is_same_hdri_texture(operator)


def _is_same_hdri_texture(operator):
    """Check if the World HDRI uses the same texture as the current built-in HDRI"""
    try:
        # Get current built-in HDRI name
        current_builtin_hdri = operator.shading.studio_light
        if not current_builtin_hdri:
            return False
        
        # Get World HDRI texture
        world = operator.scene.world
        if not world or not world.use_nodes:
            return False
        
        # Find environment texture node in world
        env_texture_node = find_environment_texture_node(world.node_tree)
        if not env_texture_node or not env_texture_node.image:
            return False
        
        # Get the image name from the environment texture node
        world_image = env_texture_node.image
        if not world_image:
            return False
        
        # Compare file names (case-insensitive)
        world_hdri_name = os.path.basename(world_image.filepath).lower()
        builtin_hdri_name = current_builtin_hdri.lower()
        world_image_name = world_image.name.lower()
        
        # Flexible matching - check if the built-in HDRI name is contained in the world image name
        # or vice versa, to handle cases where Shading Plus might add prefixes/suffixes
        return (world_hdri_name == builtin_hdri_name or 
               world_image_name == builtin_hdri_name or
               builtin_hdri_name in world_hdri_name or
               builtin_hdri_name in world_image_name or
               world_hdri_name in builtin_hdri_name or
               world_image_name in builtin_hdri_name)
    except:
        return False


def sync_builtin_to_world_rotation(operator, rotation_rad):
    """Sync built-in HDRI rotation to World HDRI rotation"""
    world = operator.scene.world
    if not world or not world.use_nodes:
        return
    
    # Find mapping node in world
    mapping_node = find_mapping_node_in_world(world.node_tree)
    if mapping_node:
        # Set the Z rotation (Yaw) in the mapping node
        mapping_node.inputs['Rotation'].default_value[2] = rotation_rad


def sync_world_to_builtin_rotation(operator, rotation_rad):
    """Sync World HDRI rotation to built-in HDRI rotation"""
    operator.shading.studiolight_rotate_z = rotation_rad


def sync_world_rotation_to_builtin(operator):
    """Sync World HDRI rotation to built-in HDRI when switching to built-in mode"""
    world = operator.scene.world
    if not world or not world.use_nodes:
        return
    
    # Find mapping node in world
    mapping_node = find_mapping_node_in_world(world.node_tree)
    if mapping_node:
        # Get the Z rotation from the mapping node
        rotation_value = mapping_node.inputs['Rotation'].default_value
        if isinstance(rotation_value, (mathutils.Vector, mathutils.Euler)):
            rotation_rad = rotation_value[2] if isinstance(rotation_value, mathutils.Vector) else rotation_value.z
            # Sync to built-in HDRI
            operator.shading.studiolight_rotate_z = rotation_rad


def sync_builtin_rotation_to_world(operator):
    """Sync built-in HDRI rotation to World HDRI when switching to world mode"""
    world = operator.scene.world
    if not world or not world.use_nodes:
        return
    
    # Get current built-in HDRI rotation
    builtin_rotation_rad = operator.shading.studiolight_rotate_z
    
    # Find mapping node in world
    mapping_node = find_mapping_node_in_world(world.node_tree)
    if mapping_node:
        # Set the Z rotation in the mapping node
        rotation_value = mapping_node.inputs['Rotation'].default_value
        if isinstance(rotation_value, (mathutils.Vector, mathutils.Euler)):
            if isinstance(rotation_value, mathutils.Vector):
                rotation_value[2] = builtin_rotation_rad
            else:
                rotation_value.z = builtin_rotation_rad
            mapping_node.inputs['Rotation'].default_value = rotation_value


def handle_mode_switch_sync(operator):
    """Handle sync when switching between Material and Rendered modes"""
    # Only handle sync if it's enabled
    if not should_sync_hdri_rotation(operator):
        return
    
    # Get current mode info
    if operator.shading_type == 'MATERIAL':
        use_scene_world = operator.shading.use_scene_world
    else:  # RENDERED
        use_scene_world = operator.shading.use_scene_world_render
    
    # If switching to scene world mode, sync from built-in to world
    if use_scene_world:
        sync_builtin_rotation_to_world(operator)
    else:
        # If switching to built-in mode, sync from world to built-in
        sync_world_rotation_to_builtin(operator)


def get_current_rotation(operator):
    """Get current rotation value based on mode"""
    try:
        if operator.mode == ROT_MODE_SHADOW:
            return operator.scene.display.light_direction.copy()
        elif operator.mode == ROT_MODE_STUDIO_WORLD_SPACE:
            return math.degrees(operator.shading.studiolight_rotate_z)
        elif operator.mode == ROT_MODE_CUSTOM_HDRI:
            if isinstance(operator.start_rotation, (mathutils.Euler, mathutils.Vector)):
                return operator.rotation_input.default_value.copy()
            elif isinstance(operator.start_rotation, (float, int)):
                return operator.rotation_input.default_value
            return None
        elif operator.mode == ROT_MODE_MAPPING_NODE:
            return operator.mapping_node.inputs['Rotation'].default_value.copy()
        elif operator.mode == ROT_MODE_SKY_TEXTURE:
            return operator.sky_texture_node.sun_rotation
        elif operator.mode == ROT_MODE_HDRI:
            return get_builtin_hdr_rotation(operator.shading)
        return None
    except Exception as e:
        operator.report({'WARNING'}, f"Error getting rotation: {str(e)}")
        return None
