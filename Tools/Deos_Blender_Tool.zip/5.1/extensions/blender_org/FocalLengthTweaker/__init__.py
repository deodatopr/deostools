import bpy
from . import operators, preferences, draw_handler

def register():
    operators.register()
    preferences.register()
    draw_handler.register()

def unregister():
    draw_handler.unregister()
    operators.unregister()
    preferences.unregister()

if __name__ == "__main__":
    register()
