'''
Focal Length Tweaker Preferences
Author: 1P2D - Felix Pierron (me@1p2d.com)
Website: https://1p2d.com

This module defines the preferences for the Focal Length Tweaker addon.

License: GNU General Public License v3 (GPLv3)
'''

import bpy
import rna_keymap_ui
from . import draw_handler

class FocalLengthTweakerPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__  # Use __package__ to refer to the addon module name

    sensitivity: bpy.props.FloatProperty(
        name="Sensitivity",
        description="Adjust the focal length change sensitivity",
        default=0.8,
        min=0.1,
        max=2.0,
    )

    enable_precision: bpy.props.BoolProperty(
        name="Enable Precision Mode",
        description="Hold SHIFT for precise focal length adjustment (slower change)",
        default=True,
    )
    
    # Mouse drag direction setting
    mouse_drag_direction: bpy.props.EnumProperty(
        name="Mouse Drag Direction",
        description="Direction of mouse drag to control focal length",
        items=[
            ('HORIZONTAL', "Horizontal", "Drag mouse left/right to adjust focal length", 'ARROW_LEFTRIGHT', 0),
            ('VERTICAL', "Vertical", "Drag mouse up/down to adjust focal length", 'EMPTY_SINGLE_ARROW', 1),
        ],
        default='HORIZONTAL',
    )
    
    # Focal length value overlay settings
    display_focal_length_overlay: bpy.props.BoolProperty(
        name="Display Focal Length Overlay",
        description="Show the current focal length value in the 3D viewport you are adjusting (not in other open 3D views)",
        default=True,
        update=lambda self, context: self.update_focal_length_overlay_state()
    )
    
    overlay_text_size: bpy.props.IntProperty(
        name="Text Size",
        description="Size of the overlay text",
        default=20,
        min=10,
        max=50,
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_display_duration: bpy.props.FloatProperty(
        name="Display Duration",
        description="How long to display the overlay (seconds)",
        default=2.0,
        min=0.5,
        max=10.0,
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_fade_duration: bpy.props.FloatProperty(
        name="Fade Duration",
        description="How long to fade out the overlay (seconds)",
        default=0.5,
        min=0.1,
        max=5.0,
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_text_color: bpy.props.FloatVectorProperty(
        name="Text Color",
        description="Color of the overlay text",
        default=(1.0, 1.0, 1.0, 1.0),
        size=4,
        min=0.0,
        max=1.0,
        subtype='COLOR',
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_vertical_position: bpy.props.FloatProperty(
        name="Vertical Position",
        description="Vertical position of the overlay (percentage from bottom)",
        default=85.0,
        min=0.0,
        max=100.0,
        subtype='PERCENTAGE',
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_horizontal_position: bpy.props.FloatProperty(
        name="Horizontal Position",
        description="Horizontal position of the overlay (percentage from left)",
        default=50.0,
        min=0.0,
        max=100.0,
        subtype='PERCENTAGE',
        update=lambda self, context: self.update_overlay_settings()
    )

    def has_shift_in_keymap(self, context):
        wm = context.window_manager
        kc = wm.keyconfigs.user

        # Only check the 3D View keymap instead of all keymaps
        km = kc.keymaps.get('3D View')
        if km:
            for kmi in km.keymap_items:
                if kmi.idname == 'view3d.focal_length_tweaker' and kmi.shift:
                    return True
        return False
    
    def update_focal_length_overlay_state(self):
        """Update the focal length overlay state based on the preference"""
        # The actual overlay state is handled in draw_handler.py by checking preferences
        pass
    
    def update_overlay_settings(self):
        """Update the draw handler settings when preferences change"""
        draw_handler.draw_data["size"] = self.overlay_text_size
        draw_handler.draw_data["duration"] = self.overlay_display_duration
        draw_handler.draw_data["fade_duration"] = self.overlay_fade_duration
        draw_handler.draw_data["color"] = list(self.overlay_text_color)
        draw_handler.draw_data["vertical_position"] = self.overlay_vertical_position
        draw_handler.draw_data["horizontal_position"] = self.overlay_horizontal_position

    def draw(self, context):
        layout = self.layout

        # Sensitivity Settings
        box = layout.box()
        box.label(text="Sensitivity:")
        box.prop(self, "sensitivity")
        
        # Check for SHIFT in keymap
        shift_in_keymap = self.has_shift_in_keymap(context)
        
        # Draw precision mode toggle
        row = box.row()
        row.enabled = not shift_in_keymap
        row.prop(self, "enable_precision")
        
        # Show warning if SHIFT is in keymap
        if shift_in_keymap:
            warning_row = box.row()
            warning_row.alert = True
            warning_row.label(text="SHIFT key detected in Keymap - Precision mode disabled")
            self.enable_precision = False

        # Draw mouse drag direction in a box
        box = layout.box()
        row = box.row()
        row.label(text="Drag Direction:")
        row.prop(self, "mouse_drag_direction", expand=True)    
        
        # Focal Length Value Overlay Settings
        box = layout.box()
        box.label(text="Focal Length Overlay:")
        box.prop(self, "display_focal_length_overlay")
        
        # Only show settings if overlay is enabled
        if self.display_focal_length_overlay:
            sub_box = box.box()
            
            row = sub_box.row()
            row.prop(self, "overlay_text_size")
            row.prop(self, "overlay_text_color")
            
            row = sub_box.row()
            row.prop(self, "overlay_display_duration")
            row.prop(self, "overlay_fade_duration")
            
            row = sub_box.row()
            row.prop(self, "overlay_vertical_position")
            row.prop(self, "overlay_horizontal_position")
        
        # Keymap Settings
        box = layout.box()
        box.label(text="Keymaps:")
        self.draw_keymaps(context, box)

    def draw_keymaps(self, context, layout):
        wm = context.window_manager
        kc = wm.keyconfigs.user

        # Keymap info specific to your addon
        keymaps_info = [
            {
                'km_name': '3D View',
                'space_type': 'VIEW_3D',
                'region_type': 'WINDOW',
                'operator_idname': 'view3d.focal_length_tweaker',
                'label': '',
            },
            {
                'km_name': '3D View',
                'space_type': 'VIEW_3D',
                'region_type': 'WINDOW',
                'operator_idname': 'view3d.view_persportho',
                'label': '',
            },
        ]

        for km_info in keymaps_info:
            km = kc.keymaps.get(km_info['km_name'])
            if not km:
                continue

            for kmi in km.keymap_items:
                if kmi.idname == km_info['operator_idname']:
                    # Draw the keymap item directly without extra spacing
                    rna_keymap_ui.draw_kmi([], kc, km, kmi, layout, 0)
                    break

addon_keymaps = []

def register_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')

        # Add the keymap for the operator with CTRL+ALT+MMB
        kmi = km.keymap_items.new('view3d.focal_length_tweaker', 'MIDDLEMOUSE', 'PRESS', alt=True, ctrl=True)
        kmi.active = True

        # Add the keymap for ortho/perspective toggle with CTRL+ALT+MMB double click
        kmi_ortho = km.keymap_items.new('view3d.view_persportho', 'MIDDLEMOUSE', 'DOUBLE_CLICK', alt=True, ctrl=True)
        kmi_ortho.active = True

        addon_keymaps.append((km, kmi))
        addon_keymaps.append((km, kmi_ortho))

def unregister_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        for km, kmi in addon_keymaps:
            km.keymap_items.remove(kmi)
        addon_keymaps.clear()

def register():
    bpy.utils.register_class(FocalLengthTweakerPreferences)
    register_keymap()

def unregister():
    unregister_keymap()
    bpy.utils.unregister_class(FocalLengthTweakerPreferences)
