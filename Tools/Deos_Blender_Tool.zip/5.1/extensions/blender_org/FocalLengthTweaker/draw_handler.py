import bpy
import blf
import time

# Store the current drawing data
draw_data = {
    "text": "",
    "start_time": 0,
    "duration": 2.0,  # Display duration in seconds
    "fade_duration": 0.5,  # Fade out duration in seconds
    "color": [1.0, 1.0, 1.0, 1.0],  # RGBA
    "size": 20,
    "position": (100, 100),  # Default position
    "vertical_position": 85.0,  # Default vertical position (percentage from bottom)
    "horizontal_position": 50.0,  # Default horizontal position (percentage from left)
    "handler": None,
    "is_enabled": False,
    "timer": None,  # Timer for continuous redraws
    "mode": None,  # Current focal length mode
    "value": None,  # Current focal length value
    "target_region_ptr": None,  # Pointer of the region that should receive the overlay
    "target_area_ptr": None,  # Pointer of the area that should be tagged for redraw
}

def draw_callback_px():
    """Draw the text in the viewport"""
    try:
        # Check if viewport overlay is enabled in preferences
        try:
            addon_prefs = bpy.context.preferences.addons[__package__].preferences
            if not addon_prefs.display_focal_length_overlay:
                # Focal length overlay is disabled, don't draw
                return
        except (AttributeError, KeyError):
            # If we can't access preferences, default to enabled
            pass

        # Only draw in the region that originated the overlay. Blender invokes
        # this callback once per 3D View region; comparing pointers keeps the
        # text confined to the active viewport. Handler cleanup lives in the
        # timer so it runs whether or not the target region is redrawing.
        target_region_ptr = draw_data.get("target_region_ptr")
        if target_region_ptr is not None:
            current_region = bpy.context.region
            if current_region is None or current_region.as_pointer() != target_region_ptr:
                return

        # Nothing to draw outside the display + fade window.
        if draw_data["value"] is None and time.time() >= draw_data["start_time"] + draw_data["duration"] + draw_data["fade_duration"]:
            return

        # Calculate time elapsed since start
        elapsed = time.time() - draw_data["start_time"]

        # Calculate alpha based on fade timing
        if elapsed > draw_data["duration"]:
            # Fade out phase
            fade_progress = (elapsed - draw_data["duration"]) / draw_data["fade_duration"]
            alpha = max(0.0, 1.0 - fade_progress)  # Ensure alpha doesn't go negative
        else:
            alpha = 1.0

        # Only draw if alpha is meaningful
        if alpha > 0.01:
            # Set text properties
            font_id = 0  # Default font
            blf.position(font_id, draw_data["position"][0], draw_data["position"][1], 0)
            blf.size(font_id, draw_data["size"])

            # Set color with current alpha
            color = draw_data["color"].copy()
            color[3] = alpha * color[3]
            blf.color(font_id, *color)

            # Draw the text
            blf.draw(font_id, draw_data["text"])
    except Exception as e:
        # If drawing fails, remove the handler to prevent continuous errors
        print(f"Focal Length Tweaker: Error in draw callback: {e}")
        _remove_handler()

def timer_update():
    """Timer callback to force redraw during fading"""
    try:
        # Redraw only the area that originated the overlay.
        _tag_target_area_redraw()

        # Calculate time elapsed
        elapsed = time.time() - draw_data["start_time"]

        # Once we've finished fading and nothing new is being shown, tear
        # the handler down from here. Doing it in the timer guarantees the
        # handler is removed even though draw_callback_px now early-returns
        # for non-target regions.
        if elapsed > draw_data["duration"] + draw_data["fade_duration"] and draw_data["value"] is None:
            _remove_handler()
            return None

        return 0.033  # ~30 fps refresh rate instead of 100 fps
    except Exception as e:
        # If timer fails, remove it to prevent continuous errors
        print(f"Focal Length Tweaker: Error in timer update: {e}")
        _remove_timer()
        return None

def _remove_handler():
    """Internal function to remove the draw handler if it exists"""
    if draw_data["handler"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(draw_data["handler"], 'WINDOW')
        draw_data["handler"] = None
        draw_data["is_enabled"] = False
    
    # Also remove the timer
    _remove_timer()
    
    # Reset the value and clear stored target pointers so a fresh invocation
    # can re-capture the viewport that invoked it.
    draw_data["value"] = None
    draw_data["target_region_ptr"] = None
    draw_data["target_area_ptr"] = None


def _tag_target_area_redraw():
    """Tag only the area that originated the overlay for redraw."""
    try:
        context = bpy.context
        screen = context.screen
        if not screen:
            return
        target_ptr = draw_data.get("target_area_ptr")
        if target_ptr is not None:
            for area in screen.areas:
                if area.type == 'VIEW_3D' and area.as_pointer() == target_ptr:
                    area.tag_redraw()
                    return
        # Fallback: if we never captured a target (e.g. called outside a
        # 3D View context), refresh the first 3D View so the overlay stays
        # responsive instead of freezing mid-fade.
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
                return
    except Exception as e:
        print(f"Focal Length Tweaker: Error tagging target area redraw: {e}")

def _remove_timer():
    """Internal function to remove the timer if it exists"""
    if draw_data["timer"] is not None:
        try:
            bpy.app.timers.remove(draw_data["timer"])
        except Exception as e:
            # Timer might already be removed or invalid
            print(f"Focal Length Tweaker: Warning - Could not remove timer: {e}")
        finally:
            draw_data["timer"] = None

def remove_handler():
    """Public function to remove the draw handler, for use by other modules"""
    _remove_handler()

def format_focal_length_value(mode, value):
    """Format the focal length value based on the mode"""
    if mode == 'CAMERA_FOCAL_LENGTH':
        # For camera focal length
        return f"Camera Focal Length: {value:.1f}mm"
    
    elif mode == 'VIEWPORT_FOCAL_LENGTH':
        # For viewport focal length
        return f"Viewport Focal Length: {value:.1f}mm"
    
    else:
        # Default fallback
        return f"Focal Length: {value:.1f}mm"

def update_focal_length_value(mode, value):
    """Update the focal length value to be displayed in the viewport"""
    # Format the text based on the mode and value
    formatted_text = format_focal_length_value(mode, value)
    if not formatted_text:
        return
    
    # Update the focal length value and mode
    draw_data["mode"] = mode
    draw_data["value"] = value
    draw_data["text"] = formatted_text
    
    # Update the start time for fading
    draw_data["start_time"] = time.time()
    
    # Get the region dimensions
    region = bpy.context.region
    if region:
        # Calculate vertical position based on preference (percentage from bottom)
        vertical_pos = int(region.height * (draw_data["vertical_position"] / 100.0))
        
        # Calculate horizontal position based on preference (percentage from left)
        text_width = int(len(draw_data["text"]) * draw_data["size"] * 0.50)  # Approximate text width
        horizontal_pos = int(region.width * (draw_data["horizontal_position"] / 100.0)) - (text_width // 2)
        
        draw_data["position"] = (horizontal_pos, vertical_pos)

    # Remember which region/area triggered this update so the overlay is drawn
    # only in the active viewport, not in every 3D View on screen.
    active_region = bpy.context.region
    active_area = bpy.context.area
    draw_data["target_region_ptr"] = active_region.as_pointer() if active_region else None
    draw_data["target_area_ptr"] = (
        active_area.as_pointer() if active_area and active_area.type == 'VIEW_3D' else None
    )
    
    # Add the draw handler if not already enabled
    if not draw_data["is_enabled"]:
        draw_data["handler"] = bpy.types.SpaceView3D.draw_handler_add(
            draw_callback_px, (), 'WINDOW', 'POST_PIXEL')
        draw_data["is_enabled"] = True
    
    # Start the timer for continuous redraws if not already running
    if draw_data["timer"] is None:
        draw_data["timer"] = bpy.app.timers.register(timer_update)
    
    # Force initial redraw of the target 3D VIEW area only
    _tag_target_area_redraw()

def register():
    pass

def unregister():
    # Make sure to remove any active handlers on addon unregister
    _remove_handler() 