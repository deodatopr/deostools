bl_info = {
	"name": "Link File Manager",
	"author": "Pani's Tool",
	"version": (1, 0),
	"blender": (5, 0, 0),
	"location": "View3D > Sidebar > Link File Manager",
	"description": "List linked files with relocate, reload and remove options",
	"category": "Object",
}

# ===================================================================================

import bpy
import os
import subprocess

from bpy.app.handlers import persistent
from bpy_extras.io_utils import ImportHelper
from bpy.types import (Operator, PropertyGroup, UIList, Library, Panel, Scene)
from bpy.props import StringProperty, BoolProperty, IntProperty, CollectionProperty,PointerProperty

# ===================================================================================

librariesFound = False

settings = {
	"original_file": "",
	"linked_file": ""
	}

# ===================================================================================


# (UI LIST) Custom List
class PANI_UL_CustomList_Libraries(UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			scene = context.scene
			isBroken = False

			# Icons (Warning / Broken)
			if not os.path.exists(item.itemList_PathAbs) or item.itemList_HasMissingData:
				layout.label(text="",icon="LIBRARY_DATA_BROKEN")
				isBroken = True
			elif item.itemList_NeedsResync:
				layout.label(text="",icon="ERROR")

			#Icon cannot be relative
			if item.itemList_CannotBeRelative:
				layout.operator(
				"pani.drive_info",
				text="",
				icon="WARNING_LARGE",
				emboss=False
				)
			
			# Name / Full path
			if scene.show_library_full_path:
				if item.itemList_UsingRelativePaths:
					layout.label(text=item.itemList_PathRel)
				else:
					layout.label(text=item.itemList_PathAbs)
			else:
				layout.label(text=item.itemList_FileName)

			# ----- Buttons
			#Edit
			layout.operator("pani.edit_linked", text="", icon="CURRENT_FILE").linkedFileAbsPath = item.itemList_PathAbs

			#Relocate
			layout.operator("pani.relocate", text="", icon="FILEBROWSER").original_filepath = item.itemList_PathAbs
			
			#Reload
			if isBroken:
				layout.operator("pani.not_reloaded", text="", icon="FILE_REFRESH",emboss = False)
			else:
				layout.operator("pani.reload", text="", icon="FILE_REFRESH").filePath = item.itemList_PathAbs

			#Remove
			layout.operator("pani.remove", text="", icon="X").filepath = item.itemList_PathAbs


# (PROPERTY GROUP) Custom Properties
class PANI_PG_Libraries(PropertyGroup):
	itemList_FileName: StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore

	itemList_UsingRelativePaths : BoolProperty(
		name="",
		description="",
		default=False,
	) # type: ignore

	itemList_PathAbs: StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore

	itemList_PathRel: StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore

	itemList_Library: PointerProperty(
		name="",
		type=Library,
		description=""
	)# type: ignore

	itemList_NeedsResync : BoolProperty(
		name="",
		description="",
		default=False,
	) # type: ignore

	itemList_HasMissingData : BoolProperty(
		name="",
		description="",
		default=False,
	) # type: ignore

	itemList_CannotBeRelative : BoolProperty(
	name="",
	description="This library is on a different drive and cannot use relative paths",
	default=False,
	) # type: ignore

# ===================================================================================
# 				DEFINITIONS
# ===================================================================================

def PANI_DoesItNeedResync(library_name: str) -> bool:
	for lib in bpy.data.libraries:
		if os.path.basename(lib.filepath) == library_name:
			return lib.needs_liboverride_resync
		
	return False

def PANI_IsUsingRelativePath(_filePath) -> bool:
	return _filePath.startswith("//")


def PANI_AreInDifferentDrives(_currentBlendPath: str, _linkedFilePath: str) -> bool:
	#Check if current blend and linked file are in differents drives (Ex. C: and D:)

	path_a = os.path.abspath(_currentBlendPath)
	path_b = os.path.abspath(_linkedFilePath)

	drive_a = os.path.splitdrive(path_a)[0].lower()
	drive_b = os.path.splitdrive(path_b)[0].lower()

	if not drive_a or not drive_b:
		return False

	return drive_a != drive_b
	
	
def PANI_UpdateLibraryList(_scene):
	global librariesFound
	_scene.coll_Library_List.clear()

	librariesFound = len(bpy.data.libraries) > 0
	currentBlendPath = bpy.context.blend_data.filepath

	# Add items to list
	for lib in bpy.data.libraries:
		absolutePath = bpy.path.abspath(lib.filepath)

		#Force to use absolute path if it's in different drives
		areUsingDifferentDrives = PANI_AreInDifferentDrives(currentBlendPath, absolutePath)			
		relativePath = absolutePath if areUsingDifferentDrives else bpy.path.relpath(lib.filepath)

		item = _scene.coll_Library_List.add()
		item.itemList_FileName = os.path.basename(absolutePath)
		item.itemList_UsingRelativePaths = PANI_IsUsingRelativePath(lib.filepath)
		item.itemList_CannotBeRelative = areUsingDifferentDrives
		item.itemList_PathAbs = absolutePath
		item.itemList_PathRel = relativePath
		item.itemList_Library = lib
		item.itemList_NeedsResync = PANI_DoesItNeedResync(item.itemList_FileName)
		item.itemList_HasMissingData = lib.is_missing

# ===================================================================================
# 				OPERATORS
# ===================================================================================

# -------------------------------------------------
# Operator: Drive info (Only to show tooltip message)
# -------------------------------------------------

class PANI_OT_DriveInfo(Operator):
	bl_idname = "pani.drive_info"
	bl_label = ""
	bl_description = "Library is on a different drive and cannot use relative paths"

	def execute(self, context):
		return {'FINISHED'}

# -------------------------------------------------
# Operator: Get Libraries
# -------------------------------------------------

class PANI_OT_GetLibraries(Operator):
	bl_idname = "pani.get_libraries"
	bl_label = ""
	bl_description = "Get all libraries linked on the scene"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		if len(bpy.data.libraries) == 0:
			_self.report({'WARNING'}, "There are no libraries linked on the scene.")
			return {'CANCELLED'}
		else:
			scene = _context.scene
			PANI_UpdateLibraryList(scene)
			_self.report({'INFO'}, f"{len(scene.coll_Library_List)} Libraries found.")
			return {'FINISHED'}
		
# -------------------------------------------------
# Operator: Edit Original File
# -------------------------------------------------

class PANI_OT_EditLinkedFile(Operator):
	"""Edit Linked Library"""
	bl_idname = "pani.edit_linked"
	bl_label = "Edit Linked Library"

	# Variable filled by the operator
	linkedFileAbsPath : StringProperty()

	def execute(self, context):	

		scene = context.scene

		# Check if master file is saved
		if not bpy.data.filepath:
			self.report({'WARNING'}, "Please save the file before editing a linked file.")
			bpy.ops.wm.save_mainfile('INVOKE_DEFAULT')
			return {'CANCELLED'}

		# Check if the file has been modified and needs to be saved
		if bpy.data.is_dirty:
			bpy.ops.wm.save_mainfile()
	
		# Open linked file
		if scene.open_in_new_instance:
			# Open file in new Blender instance  (USE INSTANCE)
			try:
				subprocess.Popen([bpy.app.binary_path, self.linkedFileAbsPath])
				self.report({'INFO'}, "File opened in new Blender instance")
			except Exception as e:
				self.report({'ERROR'}, f"Error opening file: {e}")
		else:
			# Save current file to back later
			settings["original_file"] = bpy.data.filepath
			settings["linked_file"] = self.linkedFileAbsPath

			# Open file in current Blender instance
			bpy.ops.wm.open_mainfile(filepath=self.linkedFileAbsPath)
			self.report({'INFO'},"File: " + os.path.basename(self.linkedFileAbsPath) + " opened")

		return {'FINISHED'}

# -------------------------------------------------
# Operator: Return to Original File
# -------------------------------------------------

class PANI_OT_ReturnToOriginal(Operator):
	"""Load the original file"""
	bl_idname = "pani.return_to_original"
	bl_label = "Return to Original File"

	@classmethod
	def poll(cls, context):
		return (settings["original_file"] != "")

	def execute(self, context):
		# Save current file
		bpy.ops.wm.save_mainfile()

		bpy.ops.wm.open_mainfile(filepath=settings["original_file"])
		self.report({'INFO'},"Back to initial file: " + settings["original_file"])

		# Reset last original file
		settings["original_file"] = ""
		settings["linked_file"] = ""

		return {'FINISHED'}

# -------------------------------------------------
# Operator: Relocate
# -------------------------------------------------
	
class PANI_OT_Relocate(Operator, ImportHelper):
	bl_idname = "pani.relocate"
	bl_label = "Relocate Linked File"
	filter_glob: StringProperty(default="*.blend", options={'HIDDEN'})
	original_filepath: StringProperty()

	def execute(self, context):
		fileName = os.path.basename(self.original_filepath)

		# Update library
		for lib in bpy.data.libraries:
			if lib.name == fileName:
				newPath = self.filepath
				lib.filepath = newPath
				lib.reload()
				break

		# Refresh library list
		PANI_UpdateLibraryList(context.scene)

		self.report({'INFO'}, f"Library [ {fileName} ] was relocated")
		return {'FINISHED'}

# -------------------------------------------------
# Operator: Reload
# -------------------------------------------------

class PANI_OT_Reload(Operator):
	bl_idname = "pani.reload"
	bl_label = "Reload"
	bl_description = "Reload Linked File"

	filePath : StringProperty()

	def execute(self, context):
		fileName = os.path.basename(self.filePath)
		bpy.data.libraries[fileName].reload()

		# Refresh library list
		PANI_UpdateLibraryList(context.scene)

		self.report({'INFO'}, f"Library [ {fileName} ] was reloaded")
		return {'FINISHED'}
	
class PANI_OT_AvoidReload(Operator):
	bl_idname = "pani.not_reloaded"
	bl_label = ""
	bl_description = "Library cant be reloaded, it's broken."
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		_self.report({'WARNING'}, "Relocate / Remove library, its broken.")
		return {'FINISHED'}

# -------------------------------------------------
# Operator: Remove
# -------------------------------------------------

class PANI_OT_Remove(Operator):
	bl_idname = "pani.remove"
	bl_label = "Delete Linked File"
	filepath: StringProperty()

	def execute(self, context):
		fileName = os.path.basename(self.filepath)

		try:
			currScnIsLinked = context.scene.library is not None
				
			for lib in bpy.data.libraries:
				# Check if the library is not the current Scene
				if currScnIsLinked:
					currScnNameIsTheSame = os.path.basename(context.scene.library.name) == fileName
					if currScnNameIsTheSame:
						self.report({'WARNING'}, f"[{fileName}] can't be deleted because the scene is active.")
						return {'CANCELLED'}
				
				# Remove it
				if lib.name == fileName:
					bpy.data.libraries.remove(lib)
					break
		except RuntimeError as e:
			self.report({'ERROR'}, f"Could not delete library: {e}")
			return {'CANCELLED'}


		# Refresh library list
		PANI_UpdateLibraryList(context.scene)

		self.report({'INFO'}, f"Library [ {fileName} ] was removed")
		return {'FINISHED'}

# ===================================================================================
# 				PANEL
# ===================================================================================

class PANI_PT_Panel(Panel):
	bl_label = "PANI's Link File Manager"
	bl_idname = "PANI_PT_Panel"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	bl_category = "Deo's Tools"

	def draw(self, context):
		global librariesFound

		layout = self.layout
		scene = context.scene

		aLinkedFileWasOpened = settings["original_file"] != ""

		# ---------------- BUTTON --------------------------------

		if not aLinkedFileWasOpened or (aLinkedFileWasOpened and scene.open_in_new_instance):
			# Add Link
			row = layout.row()
			row.operator("wm.link", text="Add Link", icon="ADD")

			# Get Linked
			row = layout.row()
			iconToUse = "FILE_REFRESH" if librariesFound else "ASSET_MANAGER"
			titleToUse = "Refresh List" if librariesFound else "Get Linked files"
			row.operator("pani.get_libraries", text=titleToUse, icon=iconToUse)
		elif settings["original_file"] != "":
			# Back to original File
			row = layout.row()
			row.operator("pani.return_to_original", text="Back to initial file", icon="FILE_PARENT")			
	
		# ---------------- SCROLL LIST LIBRARIES --------------------------------
		if len(scene.coll_Library_List) > 0:

			# Buttons Make (relative/absolute)
			layout.separator(factor=0.5) 
			row = layout.row()
			row.label(text=f"Make Paths: ")
			row = layout.row()
			row.operator("file.make_paths_relative", text="// Relative", icon = "DECORATE_LIBRARY_OVERRIDE")
			row.operator("file.make_paths_absolute", text="\ Absolute", icon = "LOCKVIEW_ON")
			
			# Label total linked files
			layout.separator(factor=1.0) 
			row = layout.row()
			row.alignment='CENTER'
			row.label(text=f"Linked Files: {len(scene.coll_Library_List)}")

			# Toogle open in a new instance.
			row = layout.row()
			row.prop(scene, "open_in_new_instance", text="New Instance (BLENDER)")

			# Toogle Name/Full Path.
			row = layout.row()
			row.prop(scene, "show_library_full_path", toggle=False, text="Show Path")
			
			row = layout.row()
			numOfRow = 4
			if len(scene.coll_Library_List) < numOfRow:
				numOfRow = len(scene.coll_Library_List)
			
			# Draw list
			row.template_list(
				listtype_name = "PANI_UL_CustomList_Libraries",
				list_id = "",
				dataptr = scene,
				propname = "coll_Library_List",
				active_dataptr =scene,
				active_propname = "int_Library_ListActiveIdx",
				rows=numOfRow
			)

# ===================================================================================
# 				REGISTER
# ===================================================================================

# ============ SIGNALS
@persistent
def OnBlendFileLoaded(dummy):
	# Signal when a new .blend is loaded

	global librariesFound
	librariesFound = False

	bpy.context.scene.coll_Library_List.clear()
	bpy.context.scene.int_Library_ListActiveIdx = 0


@persistent
def OnLibrariesUpdate(_scene):
	# Signal when a library is updated

	PANI_UpdateLibraryList(_scene)


classes = (
	PANI_UL_CustomList_Libraries,
	PANI_PG_Libraries,
	PANI_OT_DriveInfo,
	PANI_OT_GetLibraries,

	PANI_OT_EditLinkedFile,
	PANI_OT_ReturnToOriginal,

	PANI_OT_Reload,
	PANI_OT_AvoidReload,
	PANI_OT_Relocate,
	PANI_OT_Remove,

	PANI_PT_Panel,
)

def register():
	for c in classes:
		bpy.utils.register_class(c)

	# Suscription to signals
	bpy.app.handlers.load_post.append(OnBlendFileLoaded)
	bpy.app.handlers.depsgraph_update_post.append(OnLibrariesUpdate)


	# Custom properties

	Scene.open_in_new_instance = BoolProperty(
		name="",
		description="Open the linked file in a new Blender instance",
		default=False,
	)

	Scene.show_library_full_path = BoolProperty(
		name="",
		description="",
		default=False,
	)

	# Library List
	Scene.coll_Library_List = CollectionProperty(type=PANI_PG_Libraries)
	Scene.int_Library_ListActiveIdx = IntProperty(
		name="",
		description="",
		default=0,
	)

def unregister():
	for c in reversed(classes):
		bpy.utils.unregister_class(c)

	# Remove signals
	for handler in bpy.app.handlers.load_post[:]:
		if handler.__name__ == 'OnBlendFileLoaded':
			bpy.app.handlers.load_post.remove(handler)

	for handler in bpy.app.handlers.depsgraph_update_post[:]:
		if handler.__name__ == 'OnLibrariesUpdate':
			bpy.app.handlers.depsgraph_update_post.remove(handler)

	# Custom properties

	del Scene.open_in_new_instance
	del Scene.show_library_full_path
	del Scene.coll_Library_List
	del Scene.int_Library_ListActiveIdx

if __name__ == "__main__":
	unregister()
	register()