





<!DOCTYPE html>
<html
  lang="en"
  
  data-color-mode="auto" data-light-theme="light" data-dark-theme="dark"
  data-a11y-animated-images="system" data-a11y-link-underlines="true"
  
  >

    <style>
:root {
  --fontStack-monospace: "Monaspace Neon", ui-monospace, SFMono-Regular, SF Mono, Menlo, Consolas, Liberation Mono, monospace !important;
}
</style>




  <head>
    <meta charset="utf-8">
  <link rel="dns-prefetch" href="https://github.githubassets.com">
  <link rel="dns-prefetch" href="https://avatars.githubusercontent.com">
  <link rel="dns-prefetch" href="https://github-cloud.s3.amazonaws.com">
  <link rel="dns-prefetch" href="https://user-images.githubusercontent.com/">
  <link rel="preconnect" href="https://github.githubassets.com" crossorigin>
  <link rel="preconnect" href="https://avatars.githubusercontent.com">

  


  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/light-44e67b0cd5d5.css" /><link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/dark-cb035ed575b8.css" /><link data-color-theme="light_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_high_contrast-b51c2fae25e8.css" /><link data-color-theme="light_colorblind" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_colorblind-dadcba82130c.css" /><link data-color-theme="light_colorblind_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_colorblind_high_contrast-cdc36145225e.css" /><link data-color-theme="light_tritanopia" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_tritanopia-0ca195e3b5f3.css" /><link data-color-theme="light_tritanopia_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/light_tritanopia_high_contrast-f9fb5556a83f.css" /><link data-color-theme="dark_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_high_contrast-99e9b1169976.css" /><link data-color-theme="dark_colorblind" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_colorblind-9541c4141757.css" /><link data-color-theme="dark_colorblind_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_colorblind_high_contrast-bc604fc65912.css" /><link data-color-theme="dark_tritanopia" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_tritanopia-384776200fd7.css" /><link data-color-theme="dark_tritanopia_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_tritanopia_high_contrast-489c70dedd0a.css" /><link data-color-theme="dark_dimmed" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_dimmed-1545a2e9e540.css" /><link data-color-theme="dark_dimmed_high_contrast" crossorigin="anonymous" media="all" rel="stylesheet" data-href="https://github.githubassets.com/assets/dark_dimmed_high_contrast-4c1792a987c3.css" />

  <style type="text/css">
    :root {
      --tab-size-preference: 4;
    }

    pre, code {
      tab-size: var(--tab-size-preference);
    }
  </style>

    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-primitives-15839d47b75d.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-4badbb48d792.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/global-4d11e88b2383.css" />
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/github-73fd10e24e0c.css" />
  <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/repository-5d735668c600.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/code-9c9b8dc61e74.css" />

  

  <script type="application/json" id="client-env">{"locale":"en","featureFlags":["alternate_user_config_repo","api_insights_show_missing_data_banner","attestations_filtering","attestations_sorting","billing_hard_budget_limits_for_licenses","billing_premium_requests_usage_report","billing_unfiltered_discounts","client_version_header","codespaces_prebuild_region_target_update","contact_sales_locale_utm_medium","contentful_lp_enterprise","contentful_lp_footnotes","copilot_agent_cli_public_preview","copilot_agent_tasks_btn_code_nav","copilot_agent_tasks_btn_code_view","copilot_agent_tasks_btn_code_view_lines","copilot_agent_tasks_btn_repo","copilot_api_agentic_issue_marshal_yaml","copilot_api_github_draft_update_issue_skill","copilot_bing_search_use_azure_ai_agent_service","copilot_bing_search_use_grounding_ui","copilot_chat_attach_multiple_images","copilot_chat_disable_model_picker_while_streaming","copilot_chat_file_redirect","copilot_chat_opening_thread_switch","copilot_chat_reduce_quota_checks","copilot_chat_search_bar_redirect","copilot_chat_selection_attachments","copilot_chat_vision_in_claude","copilot_chat_vision_skip_thread_create","copilot_custom_copilots","copilot_custom_copilots_feature_preview","copilot_duplicate_thread","copilot_extensions_deprecation_notice","copilot_features_raycast_logo","copilot_file_block_ref_matching","copilot_free_to_paid_telem","copilot_ftp_hyperspace_upgrade_prompt","copilot_ftp_settings_upgrade","copilot_ftp_upgrade_to_pro_from_models","copilot_ftp_your_copilot_settings","copilot_generate_commit_message_blob_public_preview","copilot_generate_commit_message_custom_instructions","copilot_generate_commit_message_regenerate","copilot_immersive_planning_agent_aggregate_task","copilot_immersive_planning_agent_questions_form","copilot_immersive_structured_model_picker","copilot_issue_list_show_more","copilot_no_floating_button","copilot_pipes_github_graphql_nodes","copilot_premium_request_quotas","copilot_read_shared_conversation","copilot_share_active_subthread","copilot_show_copilot_sub_issues_button_on_issues_page","copilot_spaces_as_attachments","copilot_spaces_ga","copilot_spark_loading_webgl","copilot_spark_progressive_error_handling","copilot_spark_read_iteration_history_from_git_v2","copilot_spark_single_user_iteration","copilot_spark_use_billing_headers","copilot_spark_write_iteration_history_to_git","copilot_stable_conversation_view","copilot_workbench_agent_seed_tool","copilot_workbench_agent_sonnet45","copilot_workbench_cache","copilot_workbench_connection_reload_banner","copilot_workbench_preview_analytics","copilot_workbench_refresh_on_wsod","copilot_workbench_use_single_prompt","direct_to_salesforce","dotcom_chat_client_side_skills","failbot_report_error_react_apps_on_page","fgpat_permissions_selector_redesign","ghost_pilot_confidence_truncation_25","ghost_pilot_confidence_truncation_40","global_nav_copilot_a11y_fix","global_search_multi_orgs","global_sso_banner","hpc_improve_dom_insertion_observer","inp_reduced_threshold","insert_before_patch","issue_fields_report_usage","issues_copilot_cross_repo_assign","issues_expanded_file_types","issues_react_blur_item_picker_on_close","issues_react_bots_timeline_pagination","issues_react_include_bots_in_pickers","issues_react_prohibit_title_fallback","issues_react_remove_placeholders","issues_sticky_sidebar","item_picker_milestone_tsq_migration","kb_convert_to_space","kb_semantic_api_migration","lifecycle_label_name_updates","link_contact_sales_swp_marketo","marketing_pages_search_explore_provider","mcp_registry_install","memex_mwl_filter_field_delimiter","memex_roadmap_drag_style","migrate_toasts_to_banners_web_notifications","new_traffic_page_banner","override_pulse_legacy_url","pinned_issue_fields","primer_react_segmented_control_tooltip","primer_react_unified_portal_root","pru_billing_page","record_sso_banner_metrics","releases_update_ref_selector","remove_child_patch","report_hydro_web_vitals","repos_insights_remove_new_url","repository_suggester_elastic_search","sample_network_conn_type","scheduled_reminders_updated_limits","site_homepage_collaborate_video","site_homepage_contentful","site_msbuild_webgl_hero","spark_commit_on_default_branch","spark_force_push_after_checkout","spark_show_data_access_on_publish","spark_sync_repository_after_iteration","viewscreen_sandbox","webp_support","workbench_store_readonly"],"login":"deodatopr","copilotApiOverrideUrl":"https://api.individual.githubcopilot.com"}</script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/wp-runtime-29bc8c128300.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_oddbird_popover-polyfill_dist_popover-fn_js-468bf7cab607.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_stacktrace-parser_dist_stack-trace-parser_esm_js-node_modules_github_bro-2f4e04-280c10ec004d.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_arianotify-polyfill_ariaNotify-polyfill_js-node_modules_github_mi-c8eeba-e1423d1b436e.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/environment-9c87d298dd17.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_primer_behaviors_dist_esm_index_mjs-7e8c9c5d642d.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_selector-observer_dist_index_esm_js-9ab93471824e.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_relative-time-element_dist_index_js-c98257dc79a7.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_auto-complete-element_dist_index_js-node_modules_github_catalyst_-0d7d60-bc926dd5105c.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_text-expander-element_dist_index_js-754f5b5e9e7e.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_filter-input-element_dist_index_js-node_modules_github_remote-inp-665e70-ac788066c220.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_markdown-toolbar-element_dist_index_js-d41270eb61be.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_file-attachment-element_dist_index_js-node_modules_primer_view-co-777ce2-9ec8c103bf42.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/github-elements-9e1d42c09c62.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/element-registry-60814aca193b.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_braintree_browser-detection_dist_browser-detection_js-node_modules_githu-bb80ec-f11c694928ba.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_lit-html_lit-html_js-9012bef51135.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_index_js-node_modules_morphdom_dist_morphdom-e-c1896e-ba47f43192a8.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_remote-form_dist_index_js-node_modules_delegated-events_dist_inde-893f9f-9ba0881c72fb.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_turbo_dist_turbo_es2017-esm_js-8eb9b2209bcd.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_hotkey_dist_index_js-node_modules_github_hydro-analytics-client_d-dd3ec8-1f3d5f90de2b.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_quote-selection_dist_index_js-node_modules_github_session-resume_-31b9f3-e00a737a5ea6.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_document-metadata_document-metadata_ts-packages_failbot_failbot_ts-06156f7d8d1a.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_updatable-content_updatable-content_ts-38f5e2f7c2a7.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_ajax-error_ts-app_assets_modules_github_behaviors_details-6493f1-12a3c58321de.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_task-list_ts-app_assets_modules_github_throttled-input_ts-047775-cfe8770908d1.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_github_behaviors_commenting_edit_ts-app_assets_modules_github_behaviors_ht-83c235-4b5e481df5f9.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/behaviors-2350a5db3477.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_delegated-events_dist_index_js-node_modules_github_catalyst_lib_index_js-ef6d0f-a79564979cd1.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/notifications-global-d89a4ddd4532.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_index_js-node_modules_github_catalyst_lib_inde-96937f-7ba220cfd331.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/code-menu-614eb4e0c016.js" defer="defer"></script>
  
  <script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/primer-react-1943c99654e6.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/react-core-a354dea033a4.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/react-lib-25ef56e89e94.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/octicons-react-dfcd3f5e8531.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_emotion_is-prop-valid_dist_emotion-is-prop-valid_esm_js-node_modules_emo-72b3fd-5521741890a4.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_index_js-node_modules_github_hydro-analytics-c-c228f9-e9af1d9bff76.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_tanstack_query-core_build_modern_mutation_js-node_modules_tanstack_query-9bf7e4-2866c135221a.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_swc_helpers_esm__class_private_method_get_js-node_modules_swc_helpers_es-d6b1a6-ea538d0fdafa.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_dompurify_dist_purify_es_mjs-0294cfa498e7.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_lodash-es__Stack_js-node_modules_lodash-es__Uint8Array_js-node_modules_l-4faaa6-fa61bd48d446.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_hydro-analytics-client_dist_analytics-client_js-node_modules_gith-c7919d-d7252e512966.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_tanstack_react-virtual_dist_esm_index_js-4f7c027617ef.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_object-assign_index_js-node_modules_styled-system_dist_index_esm_js-node-4229d3-eb3da3773b04.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_catalyst_lib_index_js-node_modules_swc_helpers_esm__class_static_-b16468-050f5e71fe81.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_decorators_js-node_modules_focus-visible_dist_-e259e4-1c4bfdb2c33c.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_paths_index_ts-a268c077eba2.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_history_history_ts-packages_promise-with-resolvers-polyfill_promise-with-resolvers-p-2cdd04-2cd618ced02a.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_ref-selector_RefSelector_tsx-b4debb53e90e.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_copilot-chat_utils_copilot-local-storage_ts-861758938cea.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_commit-attribution_index_ts-packages_commit-checks-status_index_ts-packages_current--18e2dc-28daf9561ec6.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_code-view-shared_hooks_use-canonical-object_ts-packages_code-view-shared_hooks_use-f-37800a-cb86c7bb3d3a.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_app-uuid_app-uuid_ts-packages_repos-file-tree-view_repos-file-tree-view_ts-96e49dad377b.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/app_assets_modules_react-code-view_utilities_lines_ts-788016ef2e16.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_code-view-shared_utilities_web-worker_ts-packages_code-view-shared_worker-jobs_debou-a85645-bbe404d83990.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/react-code-view-6ce500022b50.js" defer="defer"></script>
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-react.fc68d0bc2c0aeb3e3bdd.module.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/react-code-view.7df2411cee3c63dfdebf.module.css" />


  <title>BlenderRenderPasses/render_layers_setup.py at main · dimitripaiva/BlenderRenderPasses</title>



  <meta name="route-pattern" content="/:user_id/:repository/blob/*name(/*path)" data-turbo-transient>
  <meta name="route-controller" content="blob" data-turbo-transient>
  <meta name="route-action" content="show" data-turbo-transient>
  <meta name="fetch-nonce" content="v2:ed13d639-dc6a-0642-6aa0-841fad1c8ed8">

    
  <meta name="current-catalog-service-hash" content="f3abb0cc802f3d7b95fc8762b94bdcb13bf39634c40c357301c4aa1d67a256fb">


  <meta name="request-id" content="D1BA:3596C8:10613D8:17297F5:68EE629E" data-turbo-transient="true" /><meta name="html-safe-nonce" content="b68d55132e7493814a3ddef34d3e96d04793f3ae00de717b30315ba8c78a939c" data-turbo-transient="true" /><meta name="visitor-payload" content="eyJyZWZlcnJlciI6Imh0dHBzOi8vZ2l0aHViLmNvbS9kaW1pdHJpcGFpdmEvQmxlbmRlclJlbmRlclBhc3NlcyIsInJlcXVlc3RfaWQiOiJEMUJBOjM1OTZDODoxMDYxM0Q4OjE3Mjk3RjU6NjhFRTYyOUUiLCJ2aXNpdG9yX2lkIjoiODkzMzYyMzA3MzY5NTQ1NzgxMCIsInJlZ2lvbl9lZGdlIjoiaWFkIiwicmVnaW9uX3JlbmRlciI6ImlhZCJ9" data-turbo-transient="true" /><meta name="visitor-hmac" content="9dc21657f8006694abba9e1d74300f929891a2bbe9eb0094c585d6f8991ee6d7" data-turbo-transient="true" />


    <meta name="hovercard-subject-tag" content="repository:932755268" data-turbo-transient>


  <meta name="github-keyboard-shortcuts" content="repository,source-code,file-tree,copilot" data-turbo-transient="true" />
  

  <meta name="selected-link" value="repo_source" data-turbo-transient>
  <link rel="assets" href="https://github.githubassets.com/">

    <meta name="google-site-verification" content="Apib7-x98H0j5cPqHWwSMm6dNU4GmODRoqxLiDzdx9I">

<meta name="octolytics-url" content="https://collector.github.com/github/collect" /><meta name="octolytics-actor-id" content="16979750" /><meta name="octolytics-actor-login" content="deodatopr" /><meta name="octolytics-actor-hash" content="2ed3bce4cdd6fa4cbf3014ad647cbb4efff0704389ee167cb8765ce7361c4eba" />

  <meta name="analytics-location" content="/&lt;user-name&gt;/&lt;repo-name&gt;/blob/show" data-turbo-transient="true" />

  




    <meta name="user-login" content="deodatopr">

  <link rel="sudo-modal" href="/sessions/sudo_modal">

    <meta name="viewport" content="width=device-width">

    

      <meta name="description" content="Creates a setup of Render Passes ready for post production.  - BlenderRenderPasses/render_layers_setup.py at main · dimitripaiva/BlenderRenderPasses">

      <link rel="search" type="application/opensearchdescription+xml" href="/opensearch.xml" title="GitHub">

    <link rel="fluid-icon" href="https://github.com/fluidicon.png" title="GitHub">
    <meta property="fb:app_id" content="1401488693436528">
    <meta name="apple-itunes-app" content="app-id=1477376905, app-argument=https://github.com/dimitripaiva/BlenderRenderPasses/blob/main/render_layers_setup.py" />

      <meta name="twitter:image" content="https://opengraph.githubassets.com/42396804b05edb527eb06eb3d27400615d1b9de664b460cda5a18a336c85550d/dimitripaiva/BlenderRenderPasses" /><meta name="twitter:site" content="@github" /><meta name="twitter:card" content="summary_large_image" /><meta name="twitter:title" content="BlenderRenderPasses/render_layers_setup.py at main · dimitripaiva/BlenderRenderPasses" /><meta name="twitter:description" content="Creates a setup of Render Passes ready for post production.  - dimitripaiva/BlenderRenderPasses" />
  <meta property="og:image" content="https://opengraph.githubassets.com/42396804b05edb527eb06eb3d27400615d1b9de664b460cda5a18a336c85550d/dimitripaiva/BlenderRenderPasses" /><meta property="og:image:alt" content="Creates a setup of Render Passes ready for post production.  - dimitripaiva/BlenderRenderPasses" /><meta property="og:image:width" content="1200" /><meta property="og:image:height" content="600" /><meta property="og:site_name" content="GitHub" /><meta property="og:type" content="object" /><meta property="og:title" content="BlenderRenderPasses/render_layers_setup.py at main · dimitripaiva/BlenderRenderPasses" /><meta property="og:url" content="https://github.com/dimitripaiva/BlenderRenderPasses/blob/main/render_layers_setup.py" /><meta property="og:description" content="Creates a setup of Render Passes ready for post production.  - dimitripaiva/BlenderRenderPasses" />
  


      <link rel="shared-web-socket" href="wss://alive.github.com/_sockets/u/16979750/ws?session=eyJ2IjoiVjMiLCJ1IjoxNjk3OTc1MCwicyI6MTgxNDQ1MDY3MiwiYyI6MTM4MzI0OTAyNywidCI6MTc2MDQ1MzI4MX0=--86d7355bf1e9f438c716d0483ebc72543cc8a13e3e74df10ccb6a335dab73b5a" data-refresh-url="/_alive" data-session-id="46d300813c834526410440585cb8edf6312ad438f1325da1ac8c617d317b8436">
      <link rel="shared-web-socket-src" href="/assets-cdn/worker/socket-worker-7db934acff24.js">


      <meta name="hostname" content="github.com">


      <meta name="keyboard-shortcuts-preference" content="all">
      <meta name="hovercards-preference" content="true">
      <meta name="announcement-preference-hovercard" content="true">

        <meta name="expected-hostname" content="github.com">


  <meta http-equiv="x-pjax-version" content="0acfdd0585c8cdc7d65d540bbf1cfdffa68cf958fca185b4e385e6207808a77b" data-turbo-track="reload">
  <meta http-equiv="x-pjax-csp-version" content="c922ef32c4ab94f8b870c62883f3e41755ec705db76ec4efb0d343458f1e28c7" data-turbo-track="reload">
  <meta http-equiv="x-pjax-css-version" content="5628891e8d823be718bdb08de36c05339aea96fab18ddf649db4944c6ab6681e" data-turbo-track="reload">
  <meta http-equiv="x-pjax-js-version" content="e89488baa2b114b56c93ddba25bf50e0f2e35a3fc2d4859af2e1774a908be844" data-turbo-track="reload">

  <meta name="turbo-cache-control" content="no-preview" data-turbo-transient="">

      <meta name="turbo-cache-control" content="no-cache" data-turbo-transient>

    <meta data-hydrostats="publish">

  <meta name="go-import" content="github.com/dimitripaiva/BlenderRenderPasses git https://github.com/dimitripaiva/BlenderRenderPasses.git">

  <meta name="octolytics-dimension-user_id" content="50772360" /><meta name="octolytics-dimension-user_login" content="dimitripaiva" /><meta name="octolytics-dimension-repository_id" content="932755268" /><meta name="octolytics-dimension-repository_nwo" content="dimitripaiva/BlenderRenderPasses" /><meta name="octolytics-dimension-repository_public" content="true" /><meta name="octolytics-dimension-repository_is_fork" content="false" /><meta name="octolytics-dimension-repository_network_root_id" content="932755268" /><meta name="octolytics-dimension-repository_network_root_nwo" content="dimitripaiva/BlenderRenderPasses" />



    

    <meta name="turbo-body-classes" content="logged-in env-production page-responsive">


  <meta name="browser-stats-url" content="https://api.github.com/_private/browser/stats">

  <meta name="browser-errors-url" content="https://api.github.com/_private/browser/errors">

  <meta name="release" content="9336991c4188771fcade33747e1ec751a678fa6e">
  <meta name="ui-target" content="full">

  <link rel="mask-icon" href="https://github.githubassets.com/assets/pinned-octocat-093da3e6fa40.svg" color="#000000">
  <link rel="alternate icon" class="js-site-favicon" type="image/png" href="https://github.githubassets.com/favicons/favicon.png">
  <link rel="icon" class="js-site-favicon" type="image/svg+xml" href="https://github.githubassets.com/favicons/favicon.svg" data-base-href="https://github.githubassets.com/favicons/favicon">

<meta name="theme-color" content="#1e2327">
<meta name="color-scheme" content="light dark" />


  <link rel="manifest" href="/manifest.json" crossOrigin="use-credentials">

  </head>

  <body class="logged-in env-production page-responsive" style="word-wrap: break-word;">
    <div data-turbo-body class="logged-in env-production page-responsive" style="word-wrap: break-word;">
        <div id="__primerPortalRoot__" role="region" style="z-index: 1000; position: absolute; width: 100%;" data-turbo-permanent></div>
      



    <div class="position-relative header-wrapper js-header-wrapper ">
      <a href="#start-of-content" data-skip-target-assigned="false" class="p-3 color-bg-accent-emphasis color-fg-on-emphasis show-on-focus js-skip-to-content">Skip to content</a>

      <span data-view-component="true" class="progress-pjax-loader Progress position-fixed width-full">
    <span style="width: 0%;" data-view-component="true" class="Progress-item progress-pjax-loader-bar left-0 top-0 color-bg-accent-emphasis"></span>
</span>      
      
      <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-react.fc68d0bc2c0aeb3e3bdd.module.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/keyboard-shortcuts-dialog.2de9c7d6456a311fce49.module.css" />

<react-partial
  partial-name="keyboard-shortcuts-dialog"
  data-ssr="false"
  data-attempted-ssr="false"
  data-react-profiling="false"
>
  
  <script type="application/json" data-target="react-partial.embeddedData">{"props":{"docsUrl":"https://docs.github.com/get-started/accessibility/keyboard-shortcuts"}}</script>
  <div data-target="react-partial.reactRoot"></div>
</react-partial>





      

          

                  <header class="AppHeader" role="banner">
      <h2 class="sr-only">Navigation Menu</h2>


        

        <div class="AppHeader-globalBar pb-2 cls-fix js-global-bar">
          <div class="AppHeader-globalBar-start responsive-context-region">
            <div class="">
                  <deferred-side-panel data-url="/_side-panels/global">
  <include-fragment data-target="deferred-side-panel.fragment" data-nonce="v2:ed13d639-dc6a-0642-6aa0-841fad1c8ed8" data-view-component="true">
  
          <button aria-label="Open global navigation menu" data-action="click:deferred-side-panel#loadPanel click:deferred-side-panel#panelOpened" data-show-dialog-id="dialog-ad6c3f1f-d2e5-42de-bf3e-acfc5e0ae075" id="dialog-show-dialog-ad6c3f1f-d2e5-42de-bf3e-acfc5e0ae075" type="button" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button p-0 color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-three-bars Button-visual">
    <path d="M1 2.75A.75.75 0 0 1 1.75 2h12.5a.75.75 0 0 1 0 1.5H1.75A.75.75 0 0 1 1 2.75Zm0 5A.75.75 0 0 1 1.75 7h12.5a.75.75 0 0 1 0 1.5H1.75A.75.75 0 0 1 1 7.75ZM1.75 12h12.5a.75.75 0 0 1 0 1.5H1.75a.75.75 0 0 1 0-1.5Z"></path>
</svg>
</button>

<dialog-helper>
  <dialog data-target="deferred-side-panel.panel" id="dialog-ad6c3f1f-d2e5-42de-bf3e-acfc5e0ae075" aria-modal="true" aria-labelledby="dialog-ad6c3f1f-d2e5-42de-bf3e-acfc5e0ae075-title" aria-describedby="dialog-ad6c3f1f-d2e5-42de-bf3e-acfc5e0ae075-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-small-portrait Overlay--motion-scaleFade Overlay--placement-left SidePanel Overlay--disableScroll">
    <div styles="flex-direction: row;" data-view-component="true" class="Overlay-header">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title sr-only" id="dialog-ad6c3f1f-d2e5-42de-bf3e-acfc5e0ae075-title">
        Global navigation
      </h1>
            <div data-view-component="true" class="d-flex">
      <div data-view-component="true" class="AppHeader-logo position-relative">
        <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-mark-github">
    <path d="M12 1C5.923 1 1 5.923 1 12c0 4.867 3.149 8.979 7.521 10.436.55.096.756-.233.756-.522 0-.262-.013-1.128-.013-2.049-2.764.509-3.479-.674-3.699-1.292-.124-.317-.66-1.293-1.127-1.554-.385-.207-.936-.715-.014-.729.866-.014 1.485.797 1.691 1.128.99 1.663 2.571 1.196 3.204.907.096-.715.385-1.196.701-1.471-2.448-.275-5.005-1.224-5.005-5.432 0-1.196.426-2.186 1.128-2.956-.111-.275-.496-1.402.11-2.915 0 0 .921-.288 3.024 1.128a10.193 10.193 0 0 1 2.75-.371c.936 0 1.871.123 2.75.371 2.104-1.43 3.025-1.128 3.025-1.128.605 1.513.221 2.64.111 2.915.701.77 1.127 1.747 1.127 2.956 0 4.222-2.571 5.157-5.019 5.432.399.344.743 1.004.743 2.035 0 1.471-.014 2.654-.014 3.025 0 .289.206.632.756.522C19.851 20.979 23 16.854 23 12c0-6.077-4.922-11-11-11Z"></path>
</svg>
</div></div>
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="dialog-ad6c3f1f-d2e5-42de-bf3e-acfc5e0ae075" aria-label="Close" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
  
</div>
      <scrollable-region data-labelled-by="dialog-ad6c3f1f-d2e5-42de-bf3e-acfc5e0ae075-title">
        <div data-view-component="true" class="Overlay-body d-flex flex-column px-2">    <div data-view-component="true" class="d-flex flex-column mb-3">
        <nav aria-label="Site navigation" data-view-component="true" class="ActionList">
  
  <nav-list>
    <ul data-target="nav-list.topLevelList" data-view-component="true" class="ActionListWrap">
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-hotkey="g d" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;HOME&quot;,&quot;label&quot;:null}" id="item-1e344872-cfc1-4325-8949-88ec53f56733" href="/dashboard" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-home">
    <path d="M6.906.664a1.749 1.749 0 0 1 2.187 0l5.25 4.2c.415.332.657.835.657 1.367v7.019A1.75 1.75 0 0 1 13.25 15h-3.5a.75.75 0 0 1-.75-.75V9H7v5.25a.75.75 0 0 1-.75.75h-3.5A1.75 1.75 0 0 1 1 13.25V6.23c0-.531.242-1.034.657-1.366l5.25-4.2Zm1.25 1.171a.25.25 0 0 0-.312 0l-5.25 4.2a.25.25 0 0 0-.094.196v7.019c0 .138.112.25.25.25H5.5V8.25a.75.75 0 0 1 .75-.75h3.5a.75.75 0 0 1 .75.75v5.25h2.75a.25.25 0 0 0 .25-.25V6.23a.25.25 0 0 0-.094-.195Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Home
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-hotkey="g i" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;ISSUES&quot;,&quot;label&quot;:null}" id="item-0bfe2d2a-90c7-42fe-9d90-b189a7c07382" href="/issues" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Issues
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-hotkey="g p" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;PULL_REQUESTS&quot;,&quot;label&quot;:null}" id="item-baffca7c-5fa1-4310-a5f3-6e8beb4ae00b" href="/pulls" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Pull requests
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-item-id="projects" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;PROJECTS&quot;,&quot;label&quot;:null}" id="item-e7162adf-bab5-426d-a65f-9dee7e8097a4" href="/projects" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-table">
    <path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25ZM6.5 6.5v8h7.75a.25.25 0 0 0 .25-.25V6.5Zm8-1.5V1.75a.25.25 0 0 0-.25-.25H6.5V5Zm-13 1.5v7.75c0 .138.112.25.25.25H5v-8ZM5 5V1.5H1.75a.25.25 0 0 0-.25.25V5Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Projects
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;DISCUSSIONS&quot;,&quot;label&quot;:null}" id="item-370e3a1e-8608-47bb-b642-a7a9f2ed53f7" href="/discussions" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion">
    <path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Discussions
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;CODESPACES&quot;,&quot;label&quot;:null}" id="item-98bc05e4-1d42-4fcb-b130-1868903499b8" href="https://github.com/codespaces" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-codespaces">
    <path d="M0 11.25c0-.966.784-1.75 1.75-1.75h12.5c.966 0 1.75.784 1.75 1.75v3A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm2-9.5C2 .784 2.784 0 3.75 0h8.5C13.216 0 14 .784 14 1.75v5a1.75 1.75 0 0 1-1.75 1.75h-8.5A1.75 1.75 0 0 1 2 6.75Zm1.75-.25a.25.25 0 0 0-.25.25v5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5a.25.25 0 0 0-.25-.25Zm-2 9.5a.25.25 0 0 0-.25.25v3c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-3a.25.25 0 0 0-.25-.25Z"></path><path d="M7 12.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm-4 0a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1-.75-.75Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Codespaces
</span>      
</a>
  
</li>

        
          <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider hide-whenRegular"></li>
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;COPILOT&quot;,&quot;label&quot;:null}" id="item-65f594a9-57f7-45d7-b3e3-0052ae8cc5d8" href="/copilot" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copilot">
    <path d="M7.998 15.035c-4.562 0-7.873-2.914-7.998-3.749V9.338c.085-.628.677-1.686 1.588-2.065.013-.07.024-.143.036-.218.029-.183.06-.384.126-.612-.201-.508-.254-1.084-.254-1.656 0-.87.128-1.769.693-2.484.579-.733 1.494-1.124 2.724-1.261 1.206-.134 2.262.034 2.944.765.05.053.096.108.139.165.044-.057.094-.112.143-.165.682-.731 1.738-.899 2.944-.765 1.23.137 2.145.528 2.724 1.261.566.715.693 1.614.693 2.484 0 .572-.053 1.148-.254 1.656.066.228.098.429.126.612.012.076.024.148.037.218.924.385 1.522 1.471 1.591 2.095v1.872c0 .766-3.351 3.795-8.002 3.795Zm0-1.485c2.28 0 4.584-1.11 5.002-1.433V7.862l-.023-.116c-.49.21-1.075.291-1.727.291-1.146 0-2.059-.327-2.71-.991A3.222 3.222 0 0 1 8 6.303a3.24 3.24 0 0 1-.544.743c-.65.664-1.563.991-2.71.991-.652 0-1.236-.081-1.727-.291l-.023.116v4.255c.419.323 2.722 1.433 5.002 1.433ZM6.762 2.83c-.193-.206-.637-.413-1.682-.297-1.019.113-1.479.404-1.713.7-.247.312-.369.789-.369 1.554 0 .793.129 1.171.308 1.371.162.181.519.379 1.442.379.853 0 1.339-.235 1.638-.54.315-.322.527-.827.617-1.553.117-.935-.037-1.395-.241-1.614Zm4.155-.297c-1.044-.116-1.488.091-1.681.297-.204.219-.359.679-.242 1.614.091.726.303 1.231.618 1.553.299.305.784.54 1.638.54.922 0 1.28-.198 1.442-.379.179-.2.308-.578.308-1.371 0-.765-.123-1.242-.37-1.554-.233-.296-.693-.587-1.713-.7Z"></path><path d="M6.25 9.037a.75.75 0 0 1 .75.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 .75-.75Zm4.25.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 1.5 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Copilot
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem hide-whenRegular">
    
    
    <a id="item-90dbf5fc-9cf9-4374-b628-628009904654" href="/copilot/spaces" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-space">
    <path d="M0 13.25V2.75C0 1.784.784 1 1.75 1H5c.551 0 1.07.26 1.4.7l.9 1.2a.25.25 0 0 0 .2.1h6.75c.966 0 1.75.784 1.75 1.75v3.638a.75.75 0 0 1-1.5 0V4.75a.25.25 0 0 0-.25-.25H7.5a1.75 1.75 0 0 1-1.4-.7l-.9-1.2a.25.25 0 0 0-.2-.1H1.75a.25.25 0 0 0-.25.25v10.5c0 .138.112.25.25.25h5.663l.076.004a.75.75 0 0 1 0 1.492L7.413 15H1.75A1.75 1.75 0 0 1 0 13.25Z"></path><path d="M12.265 9.16a.248.248 0 0 1 .467 0l.237.649a3.726 3.726 0 0 0 2.219 2.218l.649.238a.249.249 0 0 1 0 .467l-.649.237a3.728 3.728 0 0 0-2.219 2.219l-.237.649a.249.249 0 0 1-.467 0l-.238-.649a3.726 3.726 0 0 0-2.218-2.219l-.649-.237a.248.248 0 0 1 0-.467l.649-.238a3.725 3.725 0 0 0 2.218-2.218l.238-.649Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Spaces
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem ActionListItem--hasSubItem hide-whenRegular">
    
    
    <button id="item-156409a3-038d-42a4-b431-debe28457550" type="button" aria-expanded="false" data-action="
            click:nav-list#handleItemWithSubItemClick
            keydown:nav-list#handleItemWithSubItemKeydown
          " data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-download">
    <path d="M2.75 14A1.75 1.75 0 0 1 1 12.25v-2.5a.75.75 0 0 1 1.5 0v2.5c0 .138.112.25.25.25h10.5a.25.25 0 0 0 .25-.25v-2.5a.75.75 0 0 1 1.5 0v2.5A1.75 1.75 0 0 1 13.25 14Z"></path><path d="M7.25 7.689V2a.75.75 0 0 1 1.5 0v5.689l1.97-1.969a.749.749 0 1 1 1.06 1.06l-3.25 3.25a.749.749 0 0 1-1.06 0L4.22 6.78a.749.749 0 1 1 1.06-1.06l1.97 1.969Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Download Copilot
</span>      
        <span class="ActionListItem-visual ActionListItem-action--trailing">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-chevron-down ActionListItem-collapseIcon">
    <path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path>
</svg>
        </span>
</button>
        <ul role="list" data-action="keydown:nav-list#handleItemWithSubItemKeydown" aria-labelledby="item-156409a3-038d-42a4-b431-debe28457550" data-view-component="true" class="ActionList ActionList--subGroup">
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem--subItem ActionListItem">
    
    
    <a id="item-c14f6f74-ca42-465f-9238-29e087c98348" href="https://marketplace.visualstudio.com/items?itemName=GitHub.copilot" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          Visual Studio Code
</span>      
</a>
  
</li>

          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem--subItem ActionListItem">
    
    
    <a id="item-86514ac2-1da7-459f-b49e-93d2ac37f643" href="https://visualstudio.microsoft.com/github-copilot/" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          Visual Studio
</span>      
</a>
  
</li>

          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem--subItem ActionListItem">
    
    
    <a id="item-48e02fd4-d865-4f8e-8063-5dfd6ab2119d" href="https://github.com/github/CopilotForXcode" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          Xcode
</span>      
</a>
  
</li>

          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem--subItem ActionListItem">
    
    
    <a id="item-97012163-464f-45e5-ab58-94062d5aa097" href="https://plugins.jetbrains.com/plugin/17718-github-copilot" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          JetBrains
</span>      
</a>
  
</li>

          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem--subItem ActionListItem">
    
    
    <a id="item-3c8e4f90-20d5-4355-98bf-903e53fddb28" href="https://github.com/github/copilot.vim" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          Neovim
</span>      
</a>
  
</li>

          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem--subItem ActionListItem">
    
    
    <a id="item-ab6b07f4-4236-4ef1-8b13-ebd2aa0e2331" href="https://docs.github.com/en/copilot/how-tos/set-up/installing-github-copilot-in-the-cli" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          CLI
</span>      
</a>
  
</li>

</ul>
</li>

        
          <li role="presentation" aria-hidden="true" data-view-component="true" class="ActionList-sectionDivider"></li>
        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;EXPLORE&quot;,&quot;label&quot;:null}" id="item-6d36ccae-2643-4f2b-bd5a-ad8720454fa1" href="/explore" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-telescope">
    <path d="M14.184 1.143v-.001l1.422 2.464a1.75 1.75 0 0 1-.757 2.451L3.104 11.713a1.75 1.75 0 0 1-2.275-.702l-.447-.775a1.75 1.75 0 0 1 .53-2.32L11.682.573a1.748 1.748 0 0 1 2.502.57Zm-4.709 9.32h-.001l2.644 3.863a.75.75 0 1 1-1.238.848l-1.881-2.75v2.826a.75.75 0 0 1-1.5 0v-2.826l-1.881 2.75a.75.75 0 1 1-1.238-.848l2.049-2.992a.746.746 0 0 1 .293-.253l1.809-.87a.749.749 0 0 1 .944.252ZM9.436 3.92h-.001l-4.97 3.39.942 1.63 5.42-2.61Zm3.091-2.108h.001l-1.85 1.26 1.505 2.605 2.016-.97a.247.247 0 0 0 .13-.151.247.247 0 0 0-.022-.199l-1.422-2.464a.253.253 0 0 0-.161-.119.254.254 0 0 0-.197.038ZM1.756 9.157a.25.25 0 0 0-.075.33l.447.775a.25.25 0 0 0 .325.1l1.598-.769-.83-1.436-1.465 1Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Explore
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;MARKETPLACE&quot;,&quot;label&quot;:null}" id="item-6e30f686-dedc-454f-b5e8-126676eb6208" href="/marketplace" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-gift">
    <path d="M2 2.75A2.75 2.75 0 0 1 4.75 0c.983 0 1.873.42 2.57 1.232.268.318.497.668.68 1.042.183-.375.411-.725.68-1.044C9.376.42 10.266 0 11.25 0a2.75 2.75 0 0 1 2.45 4h.55c.966 0 1.75.784 1.75 1.75v2c0 .698-.409 1.301-1 1.582v4.918A1.75 1.75 0 0 1 13.25 16H2.75A1.75 1.75 0 0 1 1 14.25V9.332C.409 9.05 0 8.448 0 7.75v-2C0 4.784.784 4 1.75 4h.55c-.192-.375-.3-.8-.3-1.25ZM7.25 9.5H2.5v4.75c0 .138.112.25.25.25h4.5Zm1.5 0v5h4.5a.25.25 0 0 0 .25-.25V9.5Zm0-4V8h5.5a.25.25 0 0 0 .25-.25v-2a.25.25 0 0 0-.25-.25Zm-7 0a.25.25 0 0 0-.25.25v2c0 .138.112.25.25.25h5.5V5.5h-5.5Zm3-4a1.25 1.25 0 0 0 0 2.5h2.309c-.233-.818-.542-1.401-.878-1.793-.43-.502-.915-.707-1.431-.707ZM8.941 4h2.309a1.25 1.25 0 0 0 0-2.5c-.516 0-1 .205-1.43.707-.337.392-.646.975-.879 1.793Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Marketplace
</span>      
</a>
  
</li>

        
          
<li data-item-id="" data-targets="nav-list.items" data-view-component="true" class="ActionListItem">
    
    
    <a data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;MCP_REGISTRY&quot;,&quot;label&quot;:null}" id="item-e8d8e15f-2ea4-47d6-9bf0-879c1d104fb9" href="https://github.com/mcp" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-mcp">
    <path d="M5.52 1.12a3.578 3.578 0 0 1 6.078 2.98 3.578 3.578 0 0 1 2.982 6.08l-3.292 3.293a.252.252 0 0 0 0 .354l.843.843a.749.749 0 1 1-1.06 1.06l-.844-.843a1.75 1.75 0 0 1 0-2.474L13.52 9.12a2.08 2.08 0 0 0 0-2.94 2.08 2.08 0 0 0-2.94 0L7.731 9.03A.75.75 0 0 1 6.67 7.97l2.85-2.85a2.08 2.08 0 0 0 0-2.94 2.08 2.08 0 0 0-2.94 0l-4.799 4.8A.75.75 0 0 1 .72 5.92Z"></path><path d="M7.52 3.12a.749.749 0 1 1 1.06 1.06L5.731 7.03A2.079 2.079 0 0 0 8.67 9.97l2.85-2.85a.749.749 0 1 1 1.06 1.06l-2.849 2.85A3.578 3.578 0 0 1 4.67 5.97Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          MCP Registry
</span>      
</a>
  
</li>

</ul>  </nav-list>
</nav>

        <div data-view-component="true" class="my-3 d-flex flex-justify-center height-full">
          <span data-view-component="true">
  <svg style="box-sizing: content-box; color: var(--color-icon-primary);" width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true" data-view-component="true" class="anim-rotate">
    <circle cx="8" cy="8" r="7" stroke="currentColor" stroke-opacity="0.25" stroke-width="2" vector-effect="non-scaling-stroke" fill="none" />
    <path d="M15 8a7.002 7.002 0 00-7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" vector-effect="non-scaling-stroke" />
</svg>    <span class="sr-only">Loading</span>
</span>
</div>
</div>
      <div data-view-component="true" class="flex-1"></div>


      <div data-view-component="true" class="px-2">          <p class="color-fg-subtle text-small text-light">&copy; 2025 GitHub, Inc.</p>

          <div data-view-component="true" class="d-flex flex-wrap text-small text-light">
              <a target="_blank" href="https://github.com/about" data-view-component="true" class="Link mr-2">About</a>
              <a target="_blank" href="https://github.blog" data-view-component="true" class="Link mr-2">Blog</a>
              <a target="_blank" href="https://docs.github.com/site-policy/github-terms/github-terms-of-service" data-view-component="true" class="Link mr-2">Terms</a>
              <a target="_blank" href="https://docs.github.com/site-policy/privacy-policies/github-privacy-statement" data-view-component="true" class="Link mr-2">Privacy</a>
              <a target="_blank" href="https://github.com/security" data-view-component="true" class="Link mr-2">Security</a>
              <a target="_blank" href="https://www.githubstatus.com/" data-view-component="true" class="Link mr-3">Status</a>

</div></div>
</div>
      </scrollable-region>
      
</dialog></dialog-helper>


  <div data-show-on-forbidden-error hidden>
    <div class="Box">
  <div class="blankslate-container">
    <div data-view-component="true" class="blankslate blankslate-spacious color-bg-default rounded-2">
      

      <h3 data-view-component="true" class="blankslate-heading">        Uh oh!
</h3>
      <p data-view-component="true">        <p class="color-fg-muted my-2 mb-2 ws-normal">There was an error while loading. <a class="Link--inTextBlock" data-turbo="false" href="" aria-label="Please reload this page">Please reload this page</a>.</p>
</p>

</div>  </div>
</div>  </div>
</include-fragment></deferred-side-panel>
            </div>

            <a class="AppHeader-logo ml-1 "
              href="https://github.com/"
              data-hotkey="g d"
              aria-label="Homepage "
              data-turbo="false"
              data-analytics-event="{&quot;category&quot;:&quot;Header&quot;,&quot;action&quot;:&quot;go to dashboard&quot;,&quot;label&quot;:&quot;icon:logo&quot;}"
            >
              <svg height="32" aria-hidden="true" viewBox="0 0 24 24" version="1.1" width="32" data-view-component="true" class="octicon octicon-mark-github v-align-middle">
    <path d="M12 1C5.923 1 1 5.923 1 12c0 4.867 3.149 8.979 7.521 10.436.55.096.756-.233.756-.522 0-.262-.013-1.128-.013-2.049-2.764.509-3.479-.674-3.699-1.292-.124-.317-.66-1.293-1.127-1.554-.385-.207-.936-.715-.014-.729.866-.014 1.485.797 1.691 1.128.99 1.663 2.571 1.196 3.204.907.096-.715.385-1.196.701-1.471-2.448-.275-5.005-1.224-5.005-5.432 0-1.196.426-2.186 1.128-2.956-.111-.275-.496-1.402.11-2.915 0 0 .921-.288 3.024 1.128a10.193 10.193 0 0 1 2.75-.371c.936 0 1.871.123 2.75.371 2.104-1.43 3.025-1.128 3.025-1.128.605 1.513.221 2.64.111 2.915.701.77 1.127 1.747 1.127 2.956 0 4.222-2.571 5.157-5.019 5.432.399.344.743 1.004.743 2.035 0 1.471-.014 2.654-.014 3.025 0 .289.206.632.756.522C19.851 20.979 23 16.854 23 12c0-6.077-4.922-11-11-11Z"></path>
</svg>
            </a>

              <context-region-controller
  class="AppHeader-context responsive-context-region"
  data-max-items="5"
  
>
  <div class="AppHeader-context-full">
    <nav role="navigation" aria-label="GitHub Breadcrumb">
      
<context-region data-target="context-region-controller.contextRegion" role="list"  data-action="context-region-changed:context-region-controller#crumbsChanged">
    <context-region-crumb
      data-crumb-id="contextregion-usercrumb-dimitripaiva"
      data-targets="context-region.crumbs"
      data-label="dimitripaiva"
      data-href="/dimitripaiva"
      data-pre-rendered
      role="listitem"
      
    >
      <a data-target="context-region-crumb.linkElement" data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;context_region_crumb&quot;,&quot;label&quot;:&quot;dimitripaiva&quot;,&quot;screen_size&quot;:&quot;full&quot;}" data-hovercard-type="user" data-hovercard-url="/users/dimitripaiva/hovercard" data-octo-click="hovercard-link-click" data-octo-dimensions="link_type:self" href="/dimitripaiva" id="contextregion-usercrumb-dimitripaiva-link" data-view-component="true" class="AppHeader-context-item">
        <span data-target="context-region-crumb.labelElement" class="AppHeader-context-item-label ">
          dimitripaiva
        </span>

</a>
      <context-region-divider data-target="context-region-crumb.dividerElement" data-pre-rendered >
  <span class="AppHeader-context-item-separator">
    <span class="sr-only">/</span>
    <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M10.956 1.27994L6.06418 14.7201L5 14.7201L9.89181 1.27994L10.956 1.27994Z" fill="currentcolor" />
    </svg>
  </span>
</context-region-divider>

    </context-region-crumb>

      <li data-target="context-region-controller.overflowMenuContainer context-region.overflowMenuContainer" role="listitem" hidden>
        <action-menu data-target="context-region-controller.overflowActionMenu" data-select-variant="none" data-view-component="true">
  <focus-group direction="vertical" mnemonics retain>
    <button id="action-menu-eec49a22-c23f-43cb-a03a-cd1aa95c158e-button" popovertarget="action-menu-eec49a22-c23f-43cb-a03a-cd1aa95c158e-overlay" aria-controls="action-menu-eec49a22-c23f-43cb-a03a-cd1aa95c158e-list" aria-haspopup="true" aria-labelledby="tooltip-8b5c0f29-74b2-4c35-9903-1be8a93ada79" type="button" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal Button-visual">
    <path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path>
</svg>
</button><tool-tip id="tooltip-8b5c0f29-74b2-4c35-9903-1be8a93ada79" for="action-menu-eec49a22-c23f-43cb-a03a-cd1aa95c158e-button" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Show more breadcrumb items</tool-tip>


<anchored-position data-target="action-menu.overlay" id="action-menu-eec49a22-c23f-43cb-a03a-cd1aa95c158e-overlay" anchor="action-menu-eec49a22-c23f-43cb-a03a-cd1aa95c158e-button" align="start" side="outside-bottom" anchor-offset="normal" popover="auto" data-view-component="true">
  <div data-view-component="true" class="Overlay Overlay--size-auto">
    
      <div data-view-component="true" class="Overlay-body Overlay-body--paddingNone">          <action-list>
  <div data-view-component="true">
    <ul aria-labelledby="action-menu-eec49a22-c23f-43cb-a03a-cd1aa95c158e-button" id="action-menu-eec49a22-c23f-43cb-a03a-cd1aa95c158e-list" role="menu" data-view-component="true" class="ActionListWrap--inset ActionListWrap">
        <li hidden="hidden" data-crumb-id="contextregion-usercrumb-dimitripaiva" data-targets="context-region.overflowCrumbs action-list.items" data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;context_region_overflow_menu_crumb&quot;,&quot;label&quot;:&quot;global-navigation&quot;}" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-526b0f5c-f311-4c75-acc0-445b8cb32365" href="/dimitripaiva" role="menuitem" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          dimitripaiva
</span>      
</a>
  
</li>
        <li hidden="hidden" data-crumb-id="contextregion-repositorycrumb-blenderrenderpasses" data-targets="context-region.overflowCrumbs action-list.items" data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;context_region_overflow_menu_crumb&quot;,&quot;label&quot;:&quot;global-navigation&quot;}" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-f9b78dc7-3cd5-4681-bc7f-f2aecf1743cf" href="/dimitripaiva/BlenderRenderPasses" role="menuitem" data-view-component="true" class="ActionListContent">
      
        <span data-view-component="true" class="ActionListItem-label">
          BlenderRenderPasses
</span>      
</a>
  
</li>
</ul>    
</div></action-list>


</div>
      
</div></anchored-position>  </focus-group>
</action-menu>
  <context-region-divider data-target="context-region-crumb.dividerElement" data-pre-rendered >
  <span class="AppHeader-context-item-separator">
    <span class="sr-only">/</span>
    <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M10.956 1.27994L6.06418 14.7201L5 14.7201L9.89181 1.27994L10.956 1.27994Z" fill="currentcolor" />
    </svg>
  </span>
</context-region-divider>


      </li>
    <context-region-crumb
      data-crumb-id="contextregion-repositorycrumb-blenderrenderpasses"
      data-targets="context-region.crumbs"
      data-label="BlenderRenderPasses"
      data-href="/dimitripaiva/BlenderRenderPasses"
      data-pre-rendered
      role="listitem"
      
    >
      <a data-target="context-region-crumb.linkElement" data-analytics-event="{&quot;category&quot;:&quot;SiteHeaderComponent&quot;,&quot;action&quot;:&quot;context_region_crumb&quot;,&quot;label&quot;:&quot;BlenderRenderPasses&quot;,&quot;screen_size&quot;:&quot;full&quot;}" href="/dimitripaiva/BlenderRenderPasses" id="contextregion-repositorycrumb-blenderrenderpasses-link" data-view-component="true" class="AppHeader-context-item">
        <span data-target="context-region-crumb.labelElement" class="AppHeader-context-item-label ">
          BlenderRenderPasses
        </span>

</a>
      <context-region-divider data-target="context-region-crumb.dividerElement" data-pre-rendered >
  <span class="AppHeader-context-item-separator">
    <span class="sr-only">/</span>
    <svg width="16" height="16" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <path d="M10.956 1.27994L6.06418 14.7201L5 14.7201L9.89181 1.27994L10.956 1.27994Z" fill="currentcolor" />
    </svg>
  </span>
</context-region-divider>

    </context-region-crumb>

</context-region>

    </nav>
  </div>
</context-region-controller>

          </div>
          <div class="AppHeader-globalBar-end">
              <div class="AppHeader-search" >
                  


<qbsearch-input class="search-input" data-scope="repo:dimitripaiva/BlenderRenderPasses" data-custom-scopes-path="/search/custom_scopes" data-delete-custom-scopes-csrf="au1PaHo_PyggQUHM5eGZhk_aiscJbVQowQ3746gR2OwjHqMdFbkgP_2eoWDDzLCECxZ5zTUKzIM1817Xnvqq3Q" data-max-custom-scopes="10" data-header-redesign-enabled="true" data-initial-value="" data-blackbird-suggestions-path="/search/suggestions" data-jump-to-suggestions-path="/_graphql/GetSuggestedNavigationDestinations" data-current-repository="dimitripaiva/BlenderRenderPasses" data-current-org="" data-current-owner="dimitripaiva" data-logged-in="true" data-copilot-chat-enabled="true" data-nl-search-enabled="false">
  <div
    class="search-input-container search-with-dialog position-relative d-flex flex-row flex-items-center height-auto color-bg-transparent border-0 color-fg-subtle mx-0"
    data-action="click:qbsearch-input#searchInputContainerClicked"
  >
      
            <button type="button" data-action="click:qbsearch-input#handleExpand" class="AppHeader-button AppHeader-search-whenNarrow" aria-label="Search or jump to…" aria-expanded="false" aria-haspopup="dialog">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
          </button>


<div class="AppHeader-search-whenRegular">
  <div class="AppHeader-search-wrap AppHeader-search-wrap--hasTrailing">
    <div class="AppHeader-search-control AppHeader-search-control-overflow">
      <label
        for="AppHeader-searchInput"
        aria-label="Search or jump to…"
        class="AppHeader-search-visual--leading"
      >
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
      </label>

                <button
            type="button"
            data-target="qbsearch-input.inputButton"
            data-action="click:qbsearch-input#handleExpand"
            class="AppHeader-searchButton form-control text-left color-fg-subtle no-wrap"
            data-hotkey="s,/"
            data-analytics-event="{&quot;location&quot;:&quot;navbar&quot;,&quot;action&quot;:&quot;searchbar&quot;,&quot;context&quot;:&quot;global&quot;,&quot;tag&quot;:&quot;input&quot;,&quot;label&quot;:&quot;searchbar_input_global_navbar&quot;}"
            aria-describedby="search-error-message-flash"
          >
            <div class="overflow-hidden">
              <span id="qb-input-query" data-target="qbsearch-input.inputButtonText">
                  Type <kbd class="AppHeader-search-kbd">/</kbd> to search
              </span>
            </div>
          </button>

    </div>


  </div>
</div>

    <input type="hidden" name="type" class="js-site-search-type-field">

    
<div class="Overlay--hidden " data-modal-dialog-overlay>
  <modal-dialog data-action="close:qbsearch-input#handleClose cancel:qbsearch-input#handleClose" data-target="qbsearch-input.searchSuggestionsDialog" role="dialog" id="search-suggestions-dialog" aria-modal="true" aria-labelledby="search-suggestions-dialog-header" data-view-component="true" class="Overlay Overlay--width-medium Overlay--height-auto">
      <h1 id="search-suggestions-dialog-header" class="sr-only">Search code, repositories, users, issues, pull requests...</h1>
    <div class="Overlay-body Overlay-body--paddingNone">
      
          <div data-view-component="true">        <div class="search-suggestions position-absolute width-full color-shadow-large border color-fg-default color-bg-default overflow-hidden d-flex flex-column query-builder-container"
          style="border-radius: 12px;"
          data-target="qbsearch-input.queryBuilderContainer"
          hidden
        >
          <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="query-builder-test-form" action="" accept-charset="UTF-8" method="get">
  <query-builder data-target="qbsearch-input.queryBuilder" id="query-builder-query-builder-test" data-filter-key=":" data-view-component="true" class="QueryBuilder search-query-builder">
    <div class="FormControl FormControl--fullWidth">
      <label id="query-builder-test-label" for="query-builder-test" class="FormControl-label sr-only">
        Search
      </label>
      <div
        class="QueryBuilder-StyledInput width-fit "
        data-target="query-builder.styledInput"
      >
          <span id="query-builder-test-leadingvisual-wrap" class="FormControl-input-leadingVisualWrap QueryBuilder-leadingVisualWrap">
            <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search FormControl-input-leadingVisual">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
          </span>
        <div data-target="query-builder.styledInputContainer" class="QueryBuilder-StyledInputContainer">
          <div
            aria-hidden="true"
            class="QueryBuilder-StyledInputContent"
            data-target="query-builder.styledInputContent"
          ></div>
          <div class="QueryBuilder-InputWrapper">
            <div aria-hidden="true" class="QueryBuilder-Sizer" data-target="query-builder.sizer"></div>
            <input id="query-builder-test" name="query-builder-test" value="" autocomplete="off" type="text" role="combobox" spellcheck="false" aria-expanded="false" aria-describedby="validation-1d98581d-33fe-43ee-a38c-cf7bd00b8e9e" data-target="query-builder.input" data-action="
          input:query-builder#inputChange
          blur:query-builder#inputBlur
          keydown:query-builder#inputKeydown
          focus:query-builder#inputFocus
        " data-view-component="true" class="FormControl-input QueryBuilder-Input FormControl-medium" />
          </div>
        </div>
          <span class="sr-only" id="query-builder-test-clear">Clear</span>
          <button role="button" id="query-builder-test-clear-button" aria-labelledby="query-builder-test-clear query-builder-test-label" data-target="query-builder.clearButton" data-action="
                click:query-builder#clear
                focus:query-builder#clearButtonFocus
                blur:query-builder#clearButtonBlur
              " variant="small" hidden="hidden" type="button" data-view-component="true" class="Button Button--iconOnly Button--invisible Button--medium mr-1 px-2 py-0 d-flex flex-items-center rounded-1 color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x-circle-fill Button-visual">
    <path d="M2.343 13.657A8 8 0 1 1 13.658 2.343 8 8 0 0 1 2.343 13.657ZM6.03 4.97a.751.751 0 0 0-1.042.018.751.751 0 0 0-.018 1.042L6.94 8 4.97 9.97a.749.749 0 0 0 .326 1.275.749.749 0 0 0 .734-.215L8 9.06l1.97 1.97a.749.749 0 0 0 1.275-.326.749.749 0 0 0-.215-.734L9.06 8l1.97-1.97a.749.749 0 0 0-.326-1.275.749.749 0 0 0-.734.215L8 6.94Z"></path>
</svg>
</button>

      </div>
      <template id="search-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-search">
    <path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path>
</svg>
</template>

<template id="code-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
</template>

<template id="file-code-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-file-code">
    <path d="M4 1.75C4 .784 4.784 0 5.75 0h5.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v8.586A1.75 1.75 0 0 1 14.25 15h-9a.75.75 0 0 1 0-1.5h9a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 10 4.25V1.5H5.75a.25.25 0 0 0-.25.25v2.5a.75.75 0 0 1-1.5 0Zm1.72 4.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734l1.47-1.47-1.47-1.47a.75.75 0 0 1 0-1.06ZM3.28 7.78 1.81 9.25l1.47 1.47a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018l-2-2a.75.75 0 0 1 0-1.06l2-2a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Zm8.22-6.218V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"></path>
</svg>
</template>

<template id="history-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-history">
    <path d="m.427 1.927 1.215 1.215a8.002 8.002 0 1 1-1.6 5.685.75.75 0 1 1 1.493-.154 6.5 6.5 0 1 0 1.18-4.458l1.358 1.358A.25.25 0 0 1 3.896 6H.25A.25.25 0 0 1 0 5.75V2.104a.25.25 0 0 1 .427-.177ZM7.75 4a.75.75 0 0 1 .75.75v2.992l2.028.812a.75.75 0 0 1-.557 1.392l-2.5-1A.751.751 0 0 1 7 8.25v-3.5A.75.75 0 0 1 7.75 4Z"></path>
</svg>
</template>

<template id="repo-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-repo">
    <path d="M2 2.5A2.5 2.5 0 0 1 4.5 0h8.75a.75.75 0 0 1 .75.75v12.5a.75.75 0 0 1-.75.75h-2.5a.75.75 0 0 1 0-1.5h1.75v-2h-8a1 1 0 0 0-.714 1.7.75.75 0 1 1-1.072 1.05A2.495 2.495 0 0 1 2 11.5Zm10.5-1h-8a1 1 0 0 0-1 1v6.708A2.486 2.486 0 0 1 4.5 9h8ZM5 12.25a.25.25 0 0 1 .25-.25h3.5a.25.25 0 0 1 .25.25v3.25a.25.25 0 0 1-.4.2l-1.45-1.087a.249.249 0 0 0-.3 0L5.4 15.7a.25.25 0 0 1-.4-.2Z"></path>
</svg>
</template>

<template id="bookmark-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-bookmark">
    <path d="M3 2.75C3 1.784 3.784 1 4.75 1h6.5c.966 0 1.75.784 1.75 1.75v11.5a.75.75 0 0 1-1.227.579L8 11.722l-3.773 3.107A.751.751 0 0 1 3 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v9.91l3.023-2.489a.75.75 0 0 1 .954 0l3.023 2.49V2.75a.25.25 0 0 0-.25-.25Z"></path>
</svg>
</template>

<template id="plus-circle-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-plus-circle">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm7.25-3.25v2.5h2.5a.75.75 0 0 1 0 1.5h-2.5v2.5a.75.75 0 0 1-1.5 0v-2.5h-2.5a.75.75 0 0 1 0-1.5h2.5v-2.5a.75.75 0 0 1 1.5 0Z"></path>
</svg>
</template>

<template id="circle-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-dot-fill">
    <path d="M8 4a4 4 0 1 1 0 8 4 4 0 0 1 0-8Z"></path>
</svg>
</template>

<template id="trash-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-trash">
    <path d="M11 1.75V3h2.25a.75.75 0 0 1 0 1.5H2.75a.75.75 0 0 1 0-1.5H5V1.75C5 .784 5.784 0 6.75 0h2.5C10.216 0 11 .784 11 1.75ZM4.496 6.675l.66 6.6a.25.25 0 0 0 .249.225h5.19a.25.25 0 0 0 .249-.225l.66-6.6a.75.75 0 0 1 1.492.149l-.66 6.6A1.748 1.748 0 0 1 10.595 15h-5.19a1.75 1.75 0 0 1-1.741-1.575l-.66-6.6a.75.75 0 1 1 1.492-.15ZM6.5 1.75V3h3V1.75a.25.25 0 0 0-.25-.25h-2.5a.25.25 0 0 0-.25.25Z"></path>
</svg>
</template>

<template id="team-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-people">
    <path d="M2 5.5a3.5 3.5 0 1 1 5.898 2.549 5.508 5.508 0 0 1 3.034 4.084.75.75 0 1 1-1.482.235 4 4 0 0 0-7.9 0 .75.75 0 0 1-1.482-.236A5.507 5.507 0 0 1 3.102 8.05 3.493 3.493 0 0 1 2 5.5ZM11 4a3.001 3.001 0 0 1 2.22 5.018 5.01 5.01 0 0 1 2.56 3.012.749.749 0 0 1-.885.954.752.752 0 0 1-.549-.514 3.507 3.507 0 0 0-2.522-2.372.75.75 0 0 1-.574-.73v-.352a.75.75 0 0 1 .416-.672A1.5 1.5 0 0 0 11 5.5.75.75 0 0 1 11 4Zm-5.5-.5a2 2 0 1 0-.001 3.999A2 2 0 0 0 5.5 3.5Z"></path>
</svg>
</template>

<template id="project-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-project">
    <path d="M1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25V1.75C0 .784.784 0 1.75 0ZM1.5 1.75v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25ZM11.75 3a.75.75 0 0 1 .75.75v7.5a.75.75 0 0 1-1.5 0v-7.5a.75.75 0 0 1 .75-.75Zm-8.25.75a.75.75 0 0 1 1.5 0v5.5a.75.75 0 0 1-1.5 0ZM8 3a.75.75 0 0 1 .75.75v3.5a.75.75 0 0 1-1.5 0v-3.5A.75.75 0 0 1 8 3Z"></path>
</svg>
</template>

<template id="pencil-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-pencil">
    <path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61Zm.176 4.823L9.75 4.81l-6.286 6.287a.253.253 0 0 0-.064.108l-.558 1.953 1.953-.558a.253.253 0 0 0 .108-.064Zm1.238-3.763a.25.25 0 0 0-.354 0L10.811 3.75l1.439 1.44 1.263-1.263a.25.25 0 0 0 0-.354Z"></path>
</svg>
</template>

<template id="copilot-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copilot">
    <path d="M7.998 15.035c-4.562 0-7.873-2.914-7.998-3.749V9.338c.085-.628.677-1.686 1.588-2.065.013-.07.024-.143.036-.218.029-.183.06-.384.126-.612-.201-.508-.254-1.084-.254-1.656 0-.87.128-1.769.693-2.484.579-.733 1.494-1.124 2.724-1.261 1.206-.134 2.262.034 2.944.765.05.053.096.108.139.165.044-.057.094-.112.143-.165.682-.731 1.738-.899 2.944-.765 1.23.137 2.145.528 2.724 1.261.566.715.693 1.614.693 2.484 0 .572-.053 1.148-.254 1.656.066.228.098.429.126.612.012.076.024.148.037.218.924.385 1.522 1.471 1.591 2.095v1.872c0 .766-3.351 3.795-8.002 3.795Zm0-1.485c2.28 0 4.584-1.11 5.002-1.433V7.862l-.023-.116c-.49.21-1.075.291-1.727.291-1.146 0-2.059-.327-2.71-.991A3.222 3.222 0 0 1 8 6.303a3.24 3.24 0 0 1-.544.743c-.65.664-1.563.991-2.71.991-.652 0-1.236-.081-1.727-.291l-.023.116v4.255c.419.323 2.722 1.433 5.002 1.433ZM6.762 2.83c-.193-.206-.637-.413-1.682-.297-1.019.113-1.479.404-1.713.7-.247.312-.369.789-.369 1.554 0 .793.129 1.171.308 1.371.162.181.519.379 1.442.379.853 0 1.339-.235 1.638-.54.315-.322.527-.827.617-1.553.117-.935-.037-1.395-.241-1.614Zm4.155-.297c-1.044-.116-1.488.091-1.681.297-.204.219-.359.679-.242 1.614.091.726.303 1.231.618 1.553.299.305.784.54 1.638.54.922 0 1.28-.198 1.442-.379.179-.2.308-.578.308-1.371 0-.765-.123-1.242-.37-1.554-.233-.296-.693-.587-1.713-.7Z"></path><path d="M6.25 9.037a.75.75 0 0 1 .75.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 .75-.75Zm4.25.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 1.5 0Z"></path>
</svg>
</template>

<template id="copilot-error-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copilot-error">
    <path d="M16 11.24c0 .112-.072.274-.21.467L13 9.688V7.862l-.023-.116c-.49.21-1.075.291-1.727.291-.198 0-.388-.009-.571-.029L6.833 5.226a4.01 4.01 0 0 0 .17-.782c.117-.935-.037-1.395-.241-1.614-.193-.206-.637-.413-1.682-.297-.683.076-1.115.231-1.395.415l-1.257-.91c.579-.564 1.413-.877 2.485-.996 1.206-.134 2.262.034 2.944.765.05.053.096.108.139.165.044-.057.094-.112.143-.165.682-.731 1.738-.899 2.944-.765 1.23.137 2.145.528 2.724 1.261.566.715.693 1.614.693 2.484 0 .572-.053 1.148-.254 1.656.066.228.098.429.126.612.012.076.024.148.037.218.924.385 1.522 1.471 1.591 2.095Zm-5.083-8.707c-1.044-.116-1.488.091-1.681.297-.204.219-.359.679-.242 1.614.091.726.303 1.231.618 1.553.299.305.784.54 1.638.54.922 0 1.28-.198 1.442-.379.179-.2.308-.578.308-1.371 0-.765-.123-1.242-.37-1.554-.233-.296-.693-.587-1.713-.7Zm2.511 11.074c-1.393.776-3.272 1.428-5.43 1.428-4.562 0-7.873-2.914-7.998-3.749V9.338c.085-.628.677-1.686 1.588-2.065.013-.07.024-.143.036-.218.029-.183.06-.384.126-.612-.18-.455-.241-.963-.252-1.475L.31 4.107A.747.747 0 0 1 0 3.509V3.49a.748.748 0 0 1 .625-.73c.156-.026.306.047.435.139l14.667 10.578a.592.592 0 0 1 .227.264.752.752 0 0 1 .046.249v.022a.75.75 0 0 1-1.19.596Zm-1.367-.991L5.635 7.964a5.128 5.128 0 0 1-.889.073c-.652 0-1.236-.081-1.727-.291l-.023.116v4.255c.419.323 2.722 1.433 5.002 1.433 1.539 0 3.089-.505 4.063-.934Z"></path>
</svg>
</template>

<template id="workflow-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-workflow">
    <path d="M0 1.75C0 .784.784 0 1.75 0h3.5C6.216 0 7 .784 7 1.75v3.5A1.75 1.75 0 0 1 5.25 7H4v4a1 1 0 0 0 1 1h4v-1.25C9 9.784 9.784 9 10.75 9h3.5c.966 0 1.75.784 1.75 1.75v3.5A1.75 1.75 0 0 1 14.25 16h-3.5A1.75 1.75 0 0 1 9 14.25v-.75H5A2.5 2.5 0 0 1 2.5 11V7h-.75A1.75 1.75 0 0 1 0 5.25Zm1.75-.25a.25.25 0 0 0-.25.25v3.5c0 .138.112.25.25.25h3.5a.25.25 0 0 0 .25-.25v-3.5a.25.25 0 0 0-.25-.25Zm9 9a.25.25 0 0 0-.25.25v3.5c0 .138.112.25.25.25h3.5a.25.25 0 0 0 .25-.25v-3.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
</template>

<template id="book-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-book">
    <path d="M0 1.75A.75.75 0 0 1 .75 1h4.253c1.227 0 2.317.59 3 1.501A3.743 3.743 0 0 1 11.006 1h4.245a.75.75 0 0 1 .75.75v10.5a.75.75 0 0 1-.75.75h-4.507a2.25 2.25 0 0 0-1.591.659l-.622.621a.75.75 0 0 1-1.06 0l-.622-.621A2.25 2.25 0 0 0 5.258 13H.75a.75.75 0 0 1-.75-.75Zm7.251 10.324.004-5.073-.002-2.253A2.25 2.25 0 0 0 5.003 2.5H1.5v9h3.757a3.75 3.75 0 0 1 1.994.574ZM8.755 4.75l-.004 7.322a3.752 3.752 0 0 1 1.992-.572H14.5v-9h-3.495a2.25 2.25 0 0 0-2.25 2.25Z"></path>
</svg>
</template>

<template id="code-review-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code-review">
    <path d="M1.75 1h12.5c.966 0 1.75.784 1.75 1.75v8.5A1.75 1.75 0 0 1 14.25 13H8.061l-2.574 2.573A1.458 1.458 0 0 1 3 14.543V13H1.75A1.75 1.75 0 0 1 0 11.25v-8.5C0 1.784.784 1 1.75 1ZM1.5 2.75v8.5c0 .138.112.25.25.25h2a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h6.5a.25.25 0 0 0 .25-.25v-8.5a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25Zm5.28 1.72a.75.75 0 0 1 0 1.06L5.31 7l1.47 1.47a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018l-2-2a.75.75 0 0 1 0-1.06l2-2a.75.75 0 0 1 1.06 0Zm2.44 0a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L10.69 7 9.22 5.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
</template>

<template id="codespaces-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-codespaces">
    <path d="M0 11.25c0-.966.784-1.75 1.75-1.75h12.5c.966 0 1.75.784 1.75 1.75v3A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm2-9.5C2 .784 2.784 0 3.75 0h8.5C13.216 0 14 .784 14 1.75v5a1.75 1.75 0 0 1-1.75 1.75h-8.5A1.75 1.75 0 0 1 2 6.75Zm1.75-.25a.25.25 0 0 0-.25.25v5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25v-5a.25.25 0 0 0-.25-.25Zm-2 9.5a.25.25 0 0 0-.25.25v3c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-3a.25.25 0 0 0-.25-.25Z"></path><path d="M7 12.75a.75.75 0 0 1 .75-.75h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1-.75-.75Zm-4 0a.75.75 0 0 1 .75-.75h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1-.75-.75Z"></path>
</svg>
</template>

<template id="comment-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment">
    <path d="M1 2.75C1 1.784 1.784 1 2.75 1h10.5c.966 0 1.75.784 1.75 1.75v7.5A1.75 1.75 0 0 1 13.25 12H9.06l-2.573 2.573A1.458 1.458 0 0 1 4 13.543V12H2.75A1.75 1.75 0 0 1 1 10.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h2a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h4.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
</template>

<template id="comment-discussion-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-comment-discussion">
    <path d="M1.75 1h8.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 10.25 10H7.061l-2.574 2.573A1.458 1.458 0 0 1 2 11.543V10h-.25A1.75 1.75 0 0 1 0 8.25v-5.5C0 1.784.784 1 1.75 1ZM1.5 2.75v5.5c0 .138.112.25.25.25h1a.75.75 0 0 1 .75.75v2.19l2.72-2.72a.749.749 0 0 1 .53-.22h3.5a.25.25 0 0 0 .25-.25v-5.5a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25Zm13 2a.25.25 0 0 0-.25-.25h-.5a.75.75 0 0 1 0-1.5h.5c.966 0 1.75.784 1.75 1.75v5.5A1.75 1.75 0 0 1 14.25 12H14v1.543a1.458 1.458 0 0 1-2.487 1.03L9.22 12.28a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l2.22 2.22v-2.19a.75.75 0 0 1 .75-.75h1a.25.25 0 0 0 .25-.25Z"></path>
</svg>
</template>

<template id="organization-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-organization">
    <path d="M1.75 16A1.75 1.75 0 0 1 0 14.25V1.75C0 .784.784 0 1.75 0h8.5C11.216 0 12 .784 12 1.75v12.5c0 .085-.006.168-.018.25h2.268a.25.25 0 0 0 .25-.25V8.285a.25.25 0 0 0-.111-.208l-1.055-.703a.749.749 0 1 1 .832-1.248l1.055.703c.487.325.779.871.779 1.456v5.965A1.75 1.75 0 0 1 14.25 16h-3.5a.766.766 0 0 1-.197-.026c-.099.017-.2.026-.303.026h-3a.75.75 0 0 1-.75-.75V14h-1v1.25a.75.75 0 0 1-.75.75Zm-.25-1.75c0 .138.112.25.25.25H4v-1.25a.75.75 0 0 1 .75-.75h2.5a.75.75 0 0 1 .75.75v1.25h2.25a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25ZM3.75 6h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5ZM3 3.75A.75.75 0 0 1 3.75 3h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 3.75Zm4 3A.75.75 0 0 1 7.75 6h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 7 6.75ZM7.75 3h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5ZM3 9.75A.75.75 0 0 1 3.75 9h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 9.75ZM7.75 9h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5Z"></path>
</svg>
</template>

<template id="rocket-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-rocket">
    <path d="M14.064 0h.186C15.216 0 16 .784 16 1.75v.186a8.752 8.752 0 0 1-2.564 6.186l-.458.459c-.314.314-.641.616-.979.904v3.207c0 .608-.315 1.172-.833 1.49l-2.774 1.707a.749.749 0 0 1-1.11-.418l-.954-3.102a1.214 1.214 0 0 1-.145-.125L3.754 9.816a1.218 1.218 0 0 1-.124-.145L.528 8.717a.749.749 0 0 1-.418-1.11l1.71-2.774A1.748 1.748 0 0 1 3.31 4h3.204c.288-.338.59-.665.904-.979l.459-.458A8.749 8.749 0 0 1 14.064 0ZM8.938 3.623h-.002l-.458.458c-.76.76-1.437 1.598-2.02 2.5l-1.5 2.317 2.143 2.143 2.317-1.5c.902-.583 1.74-1.26 2.499-2.02l.459-.458a7.25 7.25 0 0 0 2.123-5.127V1.75a.25.25 0 0 0-.25-.25h-.186a7.249 7.249 0 0 0-5.125 2.123ZM3.56 14.56c-.732.732-2.334 1.045-3.005 1.148a.234.234 0 0 1-.201-.064.234.234 0 0 1-.064-.201c.103-.671.416-2.273 1.15-3.003a1.502 1.502 0 1 1 2.12 2.12Zm6.94-3.935c-.088.06-.177.118-.266.175l-2.35 1.521.548 1.783 1.949-1.2a.25.25 0 0 0 .119-.213ZM3.678 8.116 5.2 5.766c.058-.09.117-.178.176-.266H3.309a.25.25 0 0 0-.213.119l-1.2 1.95ZM12 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
</template>

<template id="shield-check-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield-check">
    <path d="m8.533.133 5.25 1.68A1.75 1.75 0 0 1 15 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.697 1.697 0 0 1-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 0 1 1.217-1.667l5.25-1.68a1.748 1.748 0 0 1 1.066 0Zm-.61 1.429.001.001-5.25 1.68a.251.251 0 0 0-.174.237V7c0 1.36.275 2.666 1.057 3.859.784 1.194 2.121 2.342 4.366 3.298a.196.196 0 0 0 .154 0c2.245-.957 3.582-2.103 4.366-3.297C13.225 9.666 13.5 8.358 13.5 7V3.48a.25.25 0 0 0-.174-.238l-5.25-1.68a.25.25 0 0 0-.153 0ZM11.28 6.28l-3.5 3.5a.75.75 0 0 1-1.06 0l-1.5-1.5a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l.97.97 2.97-2.97a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
</template>

<template id="heart-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-heart">
    <path d="m8 14.25.345.666a.75.75 0 0 1-.69 0l-.008-.004-.018-.01a7.152 7.152 0 0 1-.31-.17 22.055 22.055 0 0 1-3.434-2.414C2.045 10.731 0 8.35 0 5.5 0 2.836 2.086 1 4.25 1 5.797 1 7.153 1.802 8 3.02 8.847 1.802 10.203 1 11.75 1 13.914 1 16 2.836 16 5.5c0 2.85-2.045 5.231-3.885 6.818a22.066 22.066 0 0 1-3.744 2.584l-.018.01-.006.003h-.002ZM4.25 2.5c-1.336 0-2.75 1.164-2.75 3 0 2.15 1.58 4.144 3.365 5.682A20.58 20.58 0 0 0 8 13.393a20.58 20.58 0 0 0 3.135-2.211C12.92 9.644 14.5 7.65 14.5 5.5c0-1.836-1.414-3-2.75-3-1.373 0-2.609.986-3.029 2.456a.749.749 0 0 1-1.442 0C6.859 3.486 5.623 2.5 4.25 2.5Z"></path>
</svg>
</template>

<template id="server-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-server">
    <path d="M1.75 1h12.5c.966 0 1.75.784 1.75 1.75v4c0 .372-.116.717-.314 1 .198.283.314.628.314 1v4a1.75 1.75 0 0 1-1.75 1.75H1.75A1.75 1.75 0 0 1 0 12.75v-4c0-.358.109-.707.314-1a1.739 1.739 0 0 1-.314-1v-4C0 1.784.784 1 1.75 1ZM1.5 2.75v4c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-4a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25Zm.25 5.75a.25.25 0 0 0-.25.25v4c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-4a.25.25 0 0 0-.25-.25ZM7 4.75A.75.75 0 0 1 7.75 4h4.5a.75.75 0 0 1 0 1.5h-4.5A.75.75 0 0 1 7 4.75ZM7.75 10h4.5a.75.75 0 0 1 0 1.5h-4.5a.75.75 0 0 1 0-1.5ZM3 4.75A.75.75 0 0 1 3.75 4h.5a.75.75 0 0 1 0 1.5h-.5A.75.75 0 0 1 3 4.75ZM3.75 10h.5a.75.75 0 0 1 0 1.5h-.5a.75.75 0 0 1 0-1.5Z"></path>
</svg>
</template>

<template id="globe-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-globe">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM5.78 8.75a9.64 9.64 0 0 0 1.363 4.177c.255.426.542.832.857 1.215.245-.296.551-.705.857-1.215A9.64 9.64 0 0 0 10.22 8.75Zm4.44-1.5a9.64 9.64 0 0 0-1.363-4.177c-.307-.51-.612-.919-.857-1.215a9.927 9.927 0 0 0-.857 1.215A9.64 9.64 0 0 0 5.78 7.25Zm-5.944 1.5H1.543a6.507 6.507 0 0 0 4.666 5.5c-.123-.181-.24-.365-.352-.552-.715-1.192-1.437-2.874-1.581-4.948Zm-2.733-1.5h2.733c.144-2.074.866-3.756 1.58-4.948.12-.197.237-.381.353-.552a6.507 6.507 0 0 0-4.666 5.5Zm10.181 1.5c-.144 2.074-.866 3.756-1.58 4.948-.12.197-.237.381-.353.552a6.507 6.507 0 0 0 4.666-5.5Zm2.733-1.5a6.507 6.507 0 0 0-4.666-5.5c.123.181.24.365.353.552.714 1.192 1.436 2.874 1.58 4.948Z"></path>
</svg>
</template>

<template id="issue-opened-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
</template>

<template id="device-mobile-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-device-mobile">
    <path d="M3.75 0h8.5C13.216 0 14 .784 14 1.75v12.5A1.75 1.75 0 0 1 12.25 16h-8.5A1.75 1.75 0 0 1 2 14.25V1.75C2 .784 2.784 0 3.75 0ZM3.5 1.75v12.5c0 .138.112.25.25.25h8.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25h-8.5a.25.25 0 0 0-.25.25ZM8 13a1 1 0 1 1 0-2 1 1 0 0 1 0 2Z"></path>
</svg>
</template>

<template id="package-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-package">
    <path d="m8.878.392 5.25 3.045c.54.314.872.89.872 1.514v6.098a1.75 1.75 0 0 1-.872 1.514l-5.25 3.045a1.75 1.75 0 0 1-1.756 0l-5.25-3.045A1.75 1.75 0 0 1 1 11.049V4.951c0-.624.332-1.201.872-1.514L7.122.392a1.75 1.75 0 0 1 1.756 0ZM7.875 1.69l-4.63 2.685L8 7.133l4.755-2.758-4.63-2.685a.248.248 0 0 0-.25 0ZM2.5 5.677v5.372c0 .09.047.171.125.216l4.625 2.683V8.432Zm6.25 8.271 4.625-2.683a.25.25 0 0 0 .125-.216V5.677L8.75 8.432Z"></path>
</svg>
</template>

<template id="credit-card-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-credit-card">
    <path d="M10.75 9a.75.75 0 0 0 0 1.5h1.5a.75.75 0 0 0 0-1.5h-1.5Z"></path><path d="M0 3.75C0 2.784.784 2 1.75 2h12.5c.966 0 1.75.784 1.75 1.75v8.5A1.75 1.75 0 0 1 14.25 14H1.75A1.75 1.75 0 0 1 0 12.25ZM14.5 6.5h-13v5.75c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25Zm0-2.75a.25.25 0 0 0-.25-.25H1.75a.25.25 0 0 0-.25.25V5h13Z"></path>
</svg>
</template>

<template id="play-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"></path>
</svg>
</template>

<template id="gift-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-gift">
    <path d="M2 2.75A2.75 2.75 0 0 1 4.75 0c.983 0 1.873.42 2.57 1.232.268.318.497.668.68 1.042.183-.375.411-.725.68-1.044C9.376.42 10.266 0 11.25 0a2.75 2.75 0 0 1 2.45 4h.55c.966 0 1.75.784 1.75 1.75v2c0 .698-.409 1.301-1 1.582v4.918A1.75 1.75 0 0 1 13.25 16H2.75A1.75 1.75 0 0 1 1 14.25V9.332C.409 9.05 0 8.448 0 7.75v-2C0 4.784.784 4 1.75 4h.55c-.192-.375-.3-.8-.3-1.25ZM7.25 9.5H2.5v4.75c0 .138.112.25.25.25h4.5Zm1.5 0v5h4.5a.25.25 0 0 0 .25-.25V9.5Zm0-4V8h5.5a.25.25 0 0 0 .25-.25v-2a.25.25 0 0 0-.25-.25Zm-7 0a.25.25 0 0 0-.25.25v2c0 .138.112.25.25.25h5.5V5.5h-5.5Zm3-4a1.25 1.25 0 0 0 0 2.5h2.309c-.233-.818-.542-1.401-.878-1.793-.43-.502-.915-.707-1.431-.707ZM8.941 4h2.309a1.25 1.25 0 0 0 0-2.5c-.516 0-1 .205-1.43.707-.337.392-.646.975-.879 1.793Z"></path>
</svg>
</template>

<template id="code-square-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code-square">
    <path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25Zm7.47 3.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L10.69 8 9.22 6.53a.75.75 0 0 1 0-1.06ZM6.78 6.53 5.31 8l1.47 1.47a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215l-2-2a.75.75 0 0 1 0-1.06l2-2a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
</template>

<template id="device-desktop-icon">
  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-device-desktop">
    <path d="M14.25 1c.966 0 1.75.784 1.75 1.75v7.5A1.75 1.75 0 0 1 14.25 12h-3.727c.099 1.041.52 1.872 1.292 2.757A.752.752 0 0 1 11.25 16h-6.5a.75.75 0 0 1-.565-1.243c.772-.885 1.192-1.716 1.292-2.757H1.75A1.75 1.75 0 0 1 0 10.25v-7.5C0 1.784.784 1 1.75 1ZM1.75 2.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25ZM9.018 12H6.982a5.72 5.72 0 0 1-.765 2.5h3.566a5.72 5.72 0 0 1-.765-2.5Z"></path>
</svg>
</template>

        <div class="position-relative">
                <ul
                  role="listbox"
                  class="ActionListWrap QueryBuilder-ListWrap"
                  aria-label="Suggestions"
                  data-action="
                    combobox-commit:query-builder#comboboxCommit
                    mousedown:query-builder#resultsMousedown
                  "
                  data-target="query-builder.resultsList"
                  data-persist-list=false
                  id="query-builder-test-results"
                  tabindex="-1"
                ></ul>
        </div>
      <div class="FormControl-inlineValidation" id="validation-1d98581d-33fe-43ee-a38c-cf7bd00b8e9e" hidden="hidden">
        <span class="FormControl-inlineValidation--visual">
          <svg aria-hidden="true" height="12" viewBox="0 0 12 12" version="1.1" width="12" data-view-component="true" class="octicon octicon-alert-fill">
    <path d="M4.855.708c.5-.896 1.79-.896 2.29 0l4.675 8.351a1.312 1.312 0 0 1-1.146 1.954H1.33A1.313 1.313 0 0 1 .183 9.058ZM7 7V3H5v4Zm-1 3a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z"></path>
</svg>
        </span>
        <span></span>
</div>    </div>
    <div data-target="query-builder.screenReaderFeedback" aria-live="polite" aria-atomic="true" class="sr-only"></div>
</query-builder></form>
          <div class="d-flex flex-row color-fg-muted px-3 text-small color-bg-default search-feedback-prompt">
            <a target="_blank" href="https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax" data-view-component="true" class="Link color-fg-accent text-normal ml-2">Search syntax tips</a>            <div class="d-flex flex-1"></div>
              <button data-action="click:qbsearch-input#showFeedbackDialog" type="button" data-view-component="true" class="Button--link Button--medium Button color-fg-accent text-normal ml-2">  <span class="Button-content">
    <span class="Button-label">Give feedback</span>
  </span>
</button>
          </div>
        </div>
</div>

    </div>
</modal-dialog></div>
  </div>
  <div data-action="click:qbsearch-input#retract" class="dark-backdrop position-fixed" hidden data-target="qbsearch-input.darkBackdrop"></div>
  <div class="color-fg-default">
    
<dialog-helper>
  <dialog data-target="qbsearch-input.feedbackDialog" data-action="close:qbsearch-input#handleDialogClose cancel:qbsearch-input#handleDialogClose" id="feedback-dialog" aria-modal="true" aria-labelledby="feedback-dialog-title" aria-describedby="feedback-dialog-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-medium Overlay--motion-scaleFade Overlay--disableScroll">
    <div data-view-component="true" class="Overlay-header">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title " id="feedback-dialog-title">
        Provide feedback
      </h1>
        
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="feedback-dialog" aria-label="Close" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
  
</div>
      <scrollable-region data-labelled-by="feedback-dialog-title">
        <div data-view-component="true" class="Overlay-body">        <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="code-search-feedback-form" data-turbo="false" action="/search/feedback" accept-charset="UTF-8" method="post"><input type="hidden" name="authenticity_token" value="o7T0o7XNsP3hkLsjHozvaIlgq7u-rOwXgqY6ADu53k_NKhlfZSbzaUB-3lVLGdd5PXyk_wPVox1EG0TiZuLWbA" />
          <p>We read every piece of feedback, and take your input very seriously.</p>
          <textarea name="feedback" class="form-control width-full mb-2" style="height: 120px" id="feedback"></textarea>
          <input name="include_email" id="include_email" aria-label="Include my email address so I can be contacted" class="form-control mr-2" type="checkbox">
          <label for="include_email" style="font-weight: normal">Include my email address so I can be contacted</label>
</form></div>
      </scrollable-region>
      <div data-view-component="true" class="Overlay-footer Overlay-footer--alignEnd">          <button data-close-dialog-id="feedback-dialog" type="button" data-view-component="true" class="btn">    Cancel
</button>
          <button form="code-search-feedback-form" data-action="click:qbsearch-input#submitFeedback" type="submit" data-view-component="true" class="btn-primary btn">    Submit feedback
</button>
</div>
</dialog></dialog-helper>

    <custom-scopes data-target="qbsearch-input.customScopesManager">
    
<dialog-helper>
  <dialog data-target="custom-scopes.customScopesModalDialog" data-action="close:qbsearch-input#handleDialogClose cancel:qbsearch-input#handleDialogClose" id="custom-scopes-dialog" aria-modal="true" aria-labelledby="custom-scopes-dialog-title" aria-describedby="custom-scopes-dialog-description" data-view-component="true" class="Overlay Overlay-whenNarrow Overlay--size-medium Overlay--motion-scaleFade Overlay--disableScroll">
    <div data-view-component="true" class="Overlay-header Overlay-header--divided">
  <div class="Overlay-headerContentWrap">
    <div class="Overlay-titleWrap">
      <h1 class="Overlay-title " id="custom-scopes-dialog-title">
        Saved searches
      </h1>
        <h2 id="custom-scopes-dialog-description" class="Overlay-description">Use saved searches to filter your results more quickly</h2>
    </div>
    <div class="Overlay-actionWrap">
      <button data-close-dialog-id="custom-scopes-dialog" aria-label="Close" aria-label="Close" type="button" data-view-component="true" class="close-button Overlay-closeButton"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg></button>
    </div>
  </div>
  
</div>
      <scrollable-region data-labelled-by="custom-scopes-dialog-title">
        <div data-view-component="true" class="Overlay-body">        <div data-target="custom-scopes.customScopesModalDialogFlash"></div>

        <div hidden class="create-custom-scope-form" data-target="custom-scopes.createCustomScopeForm">
        <!-- '"` --><!-- </textarea></xmp> --></option></form><form id="custom-scopes-dialog-form" data-turbo="false" action="/search/custom_scopes" accept-charset="UTF-8" method="post"><input type="hidden" name="authenticity_token" value="PlaUAjk6_ITrb32Ss1Lcg1JS0w9O962caQL-JF02dyGctZJzwcj9BLxjDjGGdwBXNhCD4onq6gmrbRv_LvSnaQ" />
          <div data-target="custom-scopes.customScopesModalDialogFlash"></div>

          <input type="hidden" id="custom_scope_id" name="custom_scope_id" data-target="custom-scopes.customScopesIdField">

          <div class="form-group">
            <label for="custom_scope_name">Name</label>
            <auto-check src="/search/custom_scopes/check_name" required>
              <input
                type="text"
                name="custom_scope_name"
                id="custom_scope_name"
                data-target="custom-scopes.customScopesNameField"
                class="form-control"
                autocomplete="off"
                placeholder="github-ruby"
                required
                maxlength="50">
              <input type="hidden" value="NRmOfs8QJvkmuV1MrBt8c8SdycLd2WLi9HYRJEyRUUmsglJ3dccYI_fSljT4Ip8QKPZwNIgFruQo90EQCiLBuQ" data-csrf="true" />
            </auto-check>
          </div>

          <div class="form-group">
            <label for="custom_scope_query">Query</label>
            <input
              type="text"
              name="custom_scope_query"
              id="custom_scope_query"
              data-target="custom-scopes.customScopesQueryField"
              class="form-control"
              autocomplete="off"
              placeholder="(repo:mona/a OR repo:mona/b) AND lang:python"
              required
              maxlength="500">
          </div>

          <p class="text-small color-fg-muted">
            To see all available qualifiers, see our <a class="Link--inTextBlock" href="https://docs.github.com/search-github/github-code-search/understanding-github-code-search-syntax">documentation</a>.
          </p>
</form>        </div>

        <div data-target="custom-scopes.manageCustomScopesForm">
          <div data-target="custom-scopes.list"></div>
        </div>

</div>
      </scrollable-region>
      <div data-view-component="true" class="Overlay-footer Overlay-footer--alignEnd Overlay-footer--divided">          <button data-action="click:custom-scopes#customScopesCancel" type="button" data-view-component="true" class="btn">    Cancel
</button>
          <button form="custom-scopes-dialog-form" data-action="click:custom-scopes#customScopesSubmit" data-target="custom-scopes.customScopesSubmitButton" type="submit" data-view-component="true" class="btn-primary btn">    Create saved search
</button>
</div>
</dialog></dialog-helper>
    </custom-scopes>
  </div>
</qbsearch-input>  <input type="hidden" value="-8x8dPWtHrgGfE0TVT4Q0obeny-7e5sYxkYV5Dx6fp1gFRwbnTMuCGSHk-wZXTl1H0L3sSzfTxo9OnPw3Nuf5A" data-csrf="true" class="js-data-jump-to-suggestions-path-csrf" />


              </div>

            
              <div class="AppHeader-CopilotChat hide-sm hide-md">
  <div class="d-flex">
    <react-partial-anchor>
        <a href="/copilot" data-target="react-partial-anchor.anchor" id="copilot-chat-header-button" aria-labelledby="tooltip-99882520-3150-48dd-9b6f-014efeee23bf" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button AppHeader-buttonLeft cursor-wait">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copilot Button-visual">
    <path d="M7.998 15.035c-4.562 0-7.873-2.914-7.998-3.749V9.338c.085-.628.677-1.686 1.588-2.065.013-.07.024-.143.036-.218.029-.183.06-.384.126-.612-.201-.508-.254-1.084-.254-1.656 0-.87.128-1.769.693-2.484.579-.733 1.494-1.124 2.724-1.261 1.206-.134 2.262.034 2.944.765.05.053.096.108.139.165.044-.057.094-.112.143-.165.682-.731 1.738-.899 2.944-.765 1.23.137 2.145.528 2.724 1.261.566.715.693 1.614.693 2.484 0 .572-.053 1.148-.254 1.656.066.228.098.429.126.612.012.076.024.148.037.218.924.385 1.522 1.471 1.591 2.095v1.872c0 .766-3.351 3.795-8.002 3.795Zm0-1.485c2.28 0 4.584-1.11 5.002-1.433V7.862l-.023-.116c-.49.21-1.075.291-1.727.291-1.146 0-2.059-.327-2.71-.991A3.222 3.222 0 0 1 8 6.303a3.24 3.24 0 0 1-.544.743c-.65.664-1.563.991-2.71.991-.652 0-1.236-.081-1.727-.291l-.023.116v4.255c.419.323 2.722 1.433 5.002 1.433ZM6.762 2.83c-.193-.206-.637-.413-1.682-.297-1.019.113-1.479.404-1.713.7-.247.312-.369.789-.369 1.554 0 .793.129 1.171.308 1.371.162.181.519.379 1.442.379.853 0 1.339-.235 1.638-.54.315-.322.527-.827.617-1.553.117-.935-.037-1.395-.241-1.614Zm4.155-.297c-1.044-.116-1.488.091-1.681.297-.204.219-.359.679-.242 1.614.091.726.303 1.231.618 1.553.299.305.784.54 1.638.54.922 0 1.28-.198 1.442-.379.179-.2.308-.578.308-1.371 0-.765-.123-1.242-.37-1.554-.233-.296-.693-.587-1.713-.7Z"></path><path d="M6.25 9.037a.75.75 0 0 1 .75.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 .75-.75Zm4.25.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 1.5 0Z"></path>
</svg>
</a><tool-tip id="tooltip-99882520-3150-48dd-9b6f-014efeee23bf" for="copilot-chat-header-button" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Chat with Copilot</tool-tip>

      <template data-target="react-partial-anchor.template">
        <script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_tanstack_query-core_build_modern_queryObserver_js-node_modules_tanstack_-defd52-b021f9f0d92e.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_react-relay_index_js-0bf1cccebb74.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_comma-separated-tokens_index_js-node_modules_mdast-util-from-markdown_li-6db53e-2aa79dca0c05.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_hastscript_lib_index_js-node_modules_mdast-util-gfm_lib_index_js-node_mo-2895d2-1abd1bdb0499.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_tanstack_react-query_build_modern_useQuery_js-node_modules_diff_lib_index_mjs-4cd0e22e18f5.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_remark-parse_lib_index_js-node_modules_unified_lib_index_js-b8fc42bb86ed.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_lowlight_lib_all_js-node_modules_react-markdown_lib_index_js-node_module-5ac2ea-78b399f7edf8.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_github_mini-throttle_dist_decorators_js-node_modules_accname_dist_access-ce77c7-cc21daefe75c.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_fzy_js_index_js-node_modules_primer_styled-react_dist_deprecated_js-node-558e1e-42fa43ff3ebc.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/vendors-node_modules_emoji-regex_index_js-node_modules_focus-visible_dist_focus-visible_js-no-d498ed-1835a8861a03.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_copilot-chat_components_tracing_TraceProvider_tsx-e6f5793cb4e7.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_copilot-chat_utils_CopilotChatContext_tsx-packages_safe-html_VerifiedHTML_tsx-38af39873bd0.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_item-picker_components_RepositoryPicker_tsx-3f764f343972.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_copilot-markdown_MarkdownRenderer_tsx-f22f68c0aeae.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_code-view-shared_hooks_use-repos-analytics_ts-packages_code-view-shared_hooks_use-tr-fbe81a-14cb1fb14a44.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_copilot-chat_components_ModelPicker_tsx-e763dd883614.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_copilot-chat_components_CopilotIconAnimation_tsx-4f0dd006fa0a.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_noop_noop_ts-packages_promise-with-resolvers-polyfill_promise-with-resolvers-polyfil-c444d9-a738a7c139b9.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/packages_copilot-chat_entry_ts-packages_use-debounce_use-debounce_ts-e305e9809f78.js" defer="defer"></script>
<script crossorigin="anonymous" type="application/javascript" src="https://github.githubassets.com/assets/copilot-chat-f386c06bd888.js" defer="defer"></script>
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-react.fc68d0bc2c0aeb3e3bdd.module.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/packages_noop_noop_ts-packages_promise-with-resolvers-polyfill_promise-with-resolvers-polyfil-c444d9.36da8655bba6f5fb004d.module.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/copilot-chat.b9c6ea91ee9df8f32d5e.module.css" />
        <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/copilot-markdown-rendering-ddd978d4a7c0.css" />
        <include-fragment src="/github-copilot/chat?skip_anchor=true" data-nonce="v2:ed13d639-dc6a-0642-6aa0-841fad1c8ed8" data-view-component="true">
  
  <div data-show-on-forbidden-error hidden>
    <div class="Box">
  <div class="blankslate-container">
    <div data-view-component="true" class="blankslate blankslate-spacious color-bg-default rounded-2">
      

      <h3 data-view-component="true" class="blankslate-heading">        Uh oh!
</h3>
      <p data-view-component="true">        <p class="color-fg-muted my-2 mb-2 ws-normal">There was an error while loading. <a class="Link--inTextBlock" data-turbo="false" href="" aria-label="Please reload this page">Please reload this page</a>.</p>
</p>

</div>  </div>
</div>  </div>
</include-fragment>
      </template>
    </react-partial-anchor>
    <div class="position-relative">
      
        <react-partial-anchor>
          <button id="global-copilot-menu-button" data-target="react-partial-anchor.anchor" aria-expanded="false" aria-labelledby="tooltip-21962185-b100-4800-bafc-e05a9639fcde" type="button" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button AppHeader-buttonRight">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down Button-visual">
    <path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path>
</svg>
</button><tool-tip id="tooltip-21962185-b100-4800-bafc-e05a9639fcde" for="global-copilot-menu-button" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Open Copilot…</tool-tip>

          <template data-target="react-partial-anchor.template">
            <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-react.fc68d0bc2c0aeb3e3bdd.module.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/global-copilot-menu.e8b96f8e81aaf397c759.module.css" />

<react-partial
  partial-name="global-copilot-menu"
  data-ssr="false"
  data-attempted-ssr="false"
  data-react-profiling="false"
>
  
  <script type="application/json" data-target="react-partial.embeddedData">{"props":{"repository":{"id":932755268,"name":"BlenderRenderPasses","ownerLogin":"dimitripaiva"}}}</script>
  <div data-target="react-partial.reactRoot"></div>
</react-partial>


          </template>
        </react-partial-anchor>
    </div>
  </div>
</div>


            <div class="AppHeader-actions position-relative">
                 <react-partial-anchor>
      <button id="global-create-menu-anchor" aria-label="Create something new" data-target="react-partial-anchor.anchor" type="button" disabled="disabled" data-view-component="true" class="AppHeader-button AppHeader-button--dropdown global-create-button cursor-wait Button--secondary Button--medium Button width-auto color-fg-muted">  <span class="Button-content">
      <span class="Button-visual Button-leadingVisual">
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-plus">
    <path d="M7.75 2a.75.75 0 0 1 .75.75V7h4.25a.75.75 0 0 1 0 1.5H8.5v4.25a.75.75 0 0 1-1.5 0V8.5H2.75a.75.75 0 0 1 0-1.5H7V2.75A.75.75 0 0 1 7.75 2Z"></path>
</svg>
      </span>
    <span class="Button-label"><svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-triangle-down">
    <path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path>
</svg></span>
  </span>
</button><tool-tip id="tooltip-2d692636-f751-4641-b31e-453d7a28e166" for="global-create-menu-anchor" popover="manual" data-direction="s" data-type="description" data-view-component="true" class="sr-only position-absolute">Create new…</tool-tip>

      <template data-target="react-partial-anchor.template">
        <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-react.fc68d0bc2c0aeb3e3bdd.module.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/global-create-menu.4d24ecb322134c573644.module.css" />

<react-partial
  partial-name="global-create-menu"
  data-ssr="false"
  data-attempted-ssr="false"
  data-react-profiling="false"
>
  
  <script type="application/json" data-target="react-partial.embeddedData">{"props":{"createRepo":true,"importRepo":true,"codespaces":true,"spark":false,"codingAgent":false,"gist":true,"createOrg":true,"createProject":false,"createProjectUrl":"/deodatopr?tab=projects","createLegacyProject":false,"createIssue":true,"org":null,"owner":"dimitripaiva","repo":"BlenderRenderPasses"}}</script>
  <div data-target="react-partial.reactRoot"></div>
</react-partial>


      </template>
    </react-partial-anchor>


                <a href="/issues" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;ISSUES_HEADER&quot;,&quot;label&quot;:null}" id="icon-button-b8fc4e3d-bbbe-4582-819f-8b6ebd22fccf" aria-labelledby="tooltip-01fde070-cb27-4918-84cd-53ee6857a315" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened Button-visual">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
</a><tool-tip id="tooltip-01fde070-cb27-4918-84cd-53ee6857a315" for="icon-button-b8fc4e3d-bbbe-4582-819f-8b6ebd22fccf" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Your issues</tool-tip>

                <a href="/pulls" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;PULL_REQUESTS_HEADER&quot;,&quot;label&quot;:null}" id="icon-button-2e03893d-4ee2-4864-9820-1fa9ad6b2873" aria-labelledby="tooltip-2fa3f5c7-d7bb-4117-b3e9-f14ff16dbcfa" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request Button-visual">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
</a><tool-tip id="tooltip-2fa3f5c7-d7bb-4117-b3e9-f14ff16dbcfa" for="icon-button-2e03893d-4ee2-4864-9820-1fa9ad6b2873" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Your pull requests</tool-tip>

            </div>

              <notification-indicator data-channel="eyJjIjoibm90aWZpY2F0aW9uLWNoYW5nZWQ6MTY5Nzk3NTAiLCJ0IjoxNzYwNDUzMjgxfQ==--bce03480b259beef7cc26a1f5e9197b1fd83376b823da21b9a3742694d195077" data-indicator-mode="none" data-tooltip-global="You have unread notifications" data-tooltip-unavailable="Notifications are unavailable at the moment." data-tooltip-none="You have no unread notifications" data-header-redesign-enabled="true" data-fetch-indicator-src="/notifications/indicator" data-fetch-indicator-enabled="true" data-view-component="true" class="js-socket-channel">
    <a id="AppHeader-notifications-button" href="/notifications" aria-labelledby="notification-indicator-tooltip" data-hotkey="g n" data-target="notification-indicator.link" data-analytics-event="{&quot;category&quot;:&quot;Global navigation&quot;,&quot;action&quot;:&quot;NOTIFICATIONS_HEADER&quot;,&quot;label&quot;:null}" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium AppHeader-button  color-fg-muted">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-inbox Button-visual">
    <path d="M2.8 2.06A1.75 1.75 0 0 1 4.41 1h7.18c.7 0 1.333.417 1.61 1.06l2.74 6.395c.04.093.06.194.06.295v4.5A1.75 1.75 0 0 1 14.25 15H1.75A1.75 1.75 0 0 1 0 13.25v-4.5c0-.101.02-.202.06-.295Zm1.61.44a.25.25 0 0 0-.23.152L1.887 8H4.75a.75.75 0 0 1 .6.3L6.625 10h2.75l1.275-1.7a.75.75 0 0 1 .6-.3h2.863L11.82 2.652a.25.25 0 0 0-.23-.152Zm10.09 7h-2.875l-1.275 1.7a.75.75 0 0 1-.6.3h-3.5a.75.75 0 0 1-.6-.3L4.375 9.5H1.5v3.75c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25Z"></path>
</svg>
</a>

    <tool-tip id="notification-indicator-tooltip" data-target="notification-indicator.tooltip" for="AppHeader-notifications-button" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Notifications</tool-tip>
</notification-indicator>

            <div class="AppHeader-user">
              <deferred-side-panel data-url="/_side-panels/user?repository_id=932755268">
  <include-fragment data-target="deferred-side-panel.fragment" data-nonce="v2:ed13d639-dc6a-0642-6aa0-841fad1c8ed8" data-view-component="true">
  
    <react-partial-anchor
  
>
  <button data-target="react-partial-anchor.anchor" data-login="deodatopr" aria-label="Open user navigation menu" type="button" data-view-component="true" class="cursor-wait Button--invisible Button--medium Button Button--invisible-noVisuals color-bg-transparent p-0">  <span class="Button-content">
    <span class="Button-label"><img src="https://avatars.githubusercontent.com/u/16979750?v=4" alt="" size="32" height="32" width="32" data-view-component="true" class="avatar circle" /></span>
  </span>
</button>
  <template data-target="react-partial-anchor.template">
    <link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/primer-react.fc68d0bc2c0aeb3e3bdd.module.css" />
<link crossorigin="anonymous" media="all" rel="stylesheet" href="https://github.githubassets.com/assets/global-user-nav-drawer.c2bc1ffb732493d0bf54.module.css" />

<react-partial
  partial-name="global-user-nav-drawer"
  data-ssr="false"
  data-attempted-ssr="false"
  data-react-profiling="false"
>
  
  <script type="application/json" data-target="react-partial.embeddedData">{"props":{"owner":{"login":"deodatopr","name":"Deo's Tools","avatarUrl":"https://avatars.githubusercontent.com/u/16979750?v=4"},"drawerId":"global-user-nav-drawer","lazyLoadItemDataFetchUrl":"/_side-panels/user.json","canAddAccount":true,"addAccountPath":"/login?add_account=1\u0026return_to=https%3A%2F%2Fgithub.com%2Fdimitripaiva%2FBlenderRenderPasses%2Fblob%2Fmain%2Frender_layers_setup.py","switchAccountPath":"/switch_account","loginAccountPath":"/login?add_account=1","projectsPath":"/deodatopr?tab=projects","gistsUrl":"https://gist.github.com/mine","docsUrl":"https://docs.github.com","yourEnterpriseUrl":null,"enterpriseSettingsUrl":null,"supportUrl":"https://support.github.com","showAccountSwitcher":true,"showCopilot":true,"showEnterprises":true,"showEnterprise":false,"showGists":true,"showOrganizations":true,"showSponsors":true,"showUpgrade":true,"showFeaturesPreviews":true,"showEnterpriseSettings":false,"createMenuProps":{"createRepo":true,"importRepo":true,"codespaces":true,"spark":false,"codingAgent":false,"gist":true,"createOrg":true,"createProject":false,"createProjectUrl":"/deodatopr?tab=projects","createLegacyProject":false,"createIssue":true,"org":null,"owner":"dimitripaiva","repo":"BlenderRenderPasses"}}}</script>
  <div data-target="react-partial.reactRoot"></div>
</react-partial>


  </template>
</react-partial-anchor>


  <div data-show-on-forbidden-error hidden>
    <div class="Box">
  <div class="blankslate-container">
    <div data-view-component="true" class="blankslate blankslate-spacious color-bg-default rounded-2">
      

      <h3 data-view-component="true" class="blankslate-heading">        Uh oh!
</h3>
      <p data-view-component="true">        <p class="color-fg-muted my-2 mb-2 ws-normal">There was an error while loading. <a class="Link--inTextBlock" data-turbo="false" href="" aria-label="Please reload this page">Please reload this page</a>.</p>
</p>

</div>  </div>
</div>  </div>
</include-fragment></deferred-side-panel>
            </div>

            <div class="position-absolute mt-2">
                
<site-header-logged-in-user-menu>

</site-header-logged-in-user-menu>

            </div>
          </div>
        </div>


        
            <div class="AppHeader-localBar" >
              <nav data-pjax="#js-repo-pjax-container" aria-label="Repository" data-view-component="true" class="js-repo-nav js-sidenav-container-pjax js-responsive-underlinenav overflow-hidden UnderlineNav">

  <ul data-view-component="true" class="UnderlineNav-body list-style-none">
      <li data-view-component="true" class="d-inline-flex">
  <a id="code-tab" href="/dimitripaiva/BlenderRenderPasses" data-tab-item="i0code-tab" data-selected-links="repo_source repo_downloads repo_commits repo_releases repo_tags repo_branches repo_packages repo_deployments repo_attestations /dimitripaiva/BlenderRenderPasses" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g c" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Code&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code UnderlineNav-octicon d-none d-sm-inline">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
        <span data-content="Code">Code</span>
          <span id="code-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="issues-tab" href="/dimitripaiva/BlenderRenderPasses/issues" data-tab-item="i1issues-tab" data-selected-links="repo_issues repo_labels repo_milestones /dimitripaiva/BlenderRenderPasses/issues" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g i" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Issues&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened UnderlineNav-octicon d-none d-sm-inline">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
        <span data-content="Issues">Issues</span>
          <span id="issues-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="0" hidden="hidden" data-view-component="true" class="Counter">0</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="pull-requests-tab" href="/dimitripaiva/BlenderRenderPasses/pulls" data-tab-item="i2pull-requests-tab" data-selected-links="repo_pulls checks /dimitripaiva/BlenderRenderPasses/pulls" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g p" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Pull requests&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request UnderlineNav-octicon d-none d-sm-inline">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
        <span data-content="Pull requests">Pull requests</span>
          <span id="pull-requests-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="0" hidden="hidden" data-view-component="true" class="Counter">0</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="actions-tab" href="/dimitripaiva/BlenderRenderPasses/actions" data-tab-item="i3actions-tab" data-selected-links="repo_actions /dimitripaiva/BlenderRenderPasses/actions" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g a" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Actions&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play UnderlineNav-octicon d-none d-sm-inline">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"></path>
</svg>
        <span data-content="Actions">Actions</span>
          <span id="actions-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="projects-tab" href="/dimitripaiva/BlenderRenderPasses/projects" data-tab-item="i4projects-tab" data-selected-links="repo_projects new_repo_project repo_project /dimitripaiva/BlenderRenderPasses/projects" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g b" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Projects&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-table UnderlineNav-octicon d-none d-sm-inline">
    <path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25ZM6.5 6.5v8h7.75a.25.25 0 0 0 .25-.25V6.5Zm8-1.5V1.75a.25.25 0 0 0-.25-.25H6.5V5Zm-13 1.5v7.75c0 .138.112.25.25.25H5v-8ZM5 5V1.5H1.75a.25.25 0 0 0-.25.25V5Z"></path>
</svg>
        <span data-content="Projects">Projects</span>
          <span id="projects-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="0" hidden="hidden" data-view-component="true" class="Counter">0</span>


    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="security-tab" href="/dimitripaiva/BlenderRenderPasses/security" data-tab-item="i5security-tab" data-selected-links="security overview alerts policy token_scanning code_scanning /dimitripaiva/BlenderRenderPasses/security" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-hotkey="g s" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Security&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield UnderlineNav-octicon d-none d-sm-inline">
    <path d="M7.467.133a1.748 1.748 0 0 1 1.066 0l5.25 1.68A1.75 1.75 0 0 1 15 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.697 1.697 0 0 1-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 0 1 1.217-1.667Zm.61 1.429a.25.25 0 0 0-.153 0l-5.25 1.68a.25.25 0 0 0-.174.238V7c0 1.358.275 2.666 1.057 3.86.784 1.194 2.121 2.34 4.366 3.297a.196.196 0 0 0 .154 0c2.245-.956 3.582-2.104 4.366-3.298C13.225 9.666 13.5 8.36 13.5 7V3.48a.251.251 0 0 0-.174-.237l-5.25-1.68ZM8.75 4.75v3a.75.75 0 0 1-1.5 0v-3a.75.75 0 0 1 1.5 0ZM9 10.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
        <span data-content="Security">Security</span>
          <include-fragment src="/dimitripaiva/BlenderRenderPasses/security/overall-count" accept="text/fragment+html" data-nonce="v2:ed13d639-dc6a-0642-6aa0-841fad1c8ed8" data-view-component="true">
  
  <div data-show-on-forbidden-error hidden>
    <div class="Box">
  <div class="blankslate-container">
    <div data-view-component="true" class="blankslate blankslate-spacious color-bg-default rounded-2">
      

      <h3 data-view-component="true" class="blankslate-heading">        Uh oh!
</h3>
      <p data-view-component="true">        <p class="color-fg-muted my-2 mb-2 ws-normal">There was an error while loading. <a class="Link--inTextBlock" data-turbo="false" href="" aria-label="Please reload this page">Please reload this page</a>.</p>
</p>

</div>  </div>
</div>  </div>
</include-fragment>

    
</a></li>
      <li data-view-component="true" class="d-inline-flex">
  <a id="insights-tab" href="/dimitripaiva/BlenderRenderPasses/pulse" data-tab-item="i6insights-tab" data-selected-links="repo_graphs repo_contributors dependency_graph dependabot_updates pulse people community /dimitripaiva/BlenderRenderPasses/pulse" data-pjax="#repo-content-pjax-container" data-turbo-frame="repo-content-turbo-frame" data-analytics-event="{&quot;category&quot;:&quot;Underline navbar&quot;,&quot;action&quot;:&quot;Click tab&quot;,&quot;label&quot;:&quot;Insights&quot;,&quot;target&quot;:&quot;UNDERLINE_NAV.TAB&quot;}" data-view-component="true" class="UnderlineNav-item no-wrap js-responsive-underlinenav-item js-selected-navigation-item">
    
              <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-graph UnderlineNav-octicon d-none d-sm-inline">
    <path d="M1.5 1.75V13.5h13.75a.75.75 0 0 1 0 1.5H.75a.75.75 0 0 1-.75-.75V1.75a.75.75 0 0 1 1.5 0Zm14.28 2.53-5.25 5.25a.75.75 0 0 1-1.06 0L7 7.06 4.28 9.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.25-3.25a.75.75 0 0 1 1.06 0L10 7.94l4.72-4.72a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
        <span data-content="Insights">Insights</span>
          <span id="insights-repo-tab-count" data-pjax-replace="" data-turbo-replace="" title="Not available" data-view-component="true" class="Counter"></span>


    
</a></li>
</ul>
    <div style="visibility:hidden;" data-view-component="true" class="UnderlineNav-actions js-responsive-underlinenav-overflow position-absolute pr-3 pr-md-4 pr-lg-5 right-0">      <action-menu data-select-variant="none" data-view-component="true">
  <focus-group direction="vertical" mnemonics retain>
    <button id="action-menu-f2eee68f-531f-44da-a0a4-2256cc107f70-button" popovertarget="action-menu-f2eee68f-531f-44da-a0a4-2256cc107f70-overlay" aria-controls="action-menu-f2eee68f-531f-44da-a0a4-2256cc107f70-list" aria-haspopup="true" aria-labelledby="tooltip-81940a98-8b17-49fb-a9a6-31464e343446" type="button" data-view-component="true" class="Button Button--iconOnly Button--secondary Button--medium UnderlineNav-item">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-kebab-horizontal Button-visual">
    <path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path>
</svg>
</button><tool-tip id="tooltip-81940a98-8b17-49fb-a9a6-31464e343446" for="action-menu-f2eee68f-531f-44da-a0a4-2256cc107f70-button" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Additional navigation options</tool-tip>


<anchored-position data-target="action-menu.overlay" id="action-menu-f2eee68f-531f-44da-a0a4-2256cc107f70-overlay" anchor="action-menu-f2eee68f-531f-44da-a0a4-2256cc107f70-button" align="start" side="outside-bottom" anchor-offset="normal" popover="auto" data-view-component="true">
  <div data-view-component="true" class="Overlay Overlay--size-auto">
    
      <div data-view-component="true" class="Overlay-body Overlay-body--paddingNone">          <action-list>
  <div data-view-component="true">
    <ul aria-labelledby="action-menu-f2eee68f-531f-44da-a0a4-2256cc107f70-button" id="action-menu-f2eee68f-531f-44da-a0a4-2256cc107f70-list" role="menu" data-view-component="true" class="ActionListWrap--inset ActionListWrap">
        <li hidden="hidden" data-menu-item="i0code-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-5c1a81a0-727f-4df5-a05a-5e9ea573893b" href="/dimitripaiva/BlenderRenderPasses" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-code">
    <path d="m11.28 3.22 4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L13.94 8l-3.72-3.72a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215Zm-6.56 0a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L2.06 8l3.72 3.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L.47 8.53a.75.75 0 0 1 0-1.06Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Code
</span>      
</a>
  
</li>
        <li hidden="hidden" data-menu-item="i1issues-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-d12aa8af-e85a-4f51-8c69-9627d939ade4" href="/dimitripaiva/BlenderRenderPasses/issues" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-issue-opened">
    <path d="M8 9.5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path><path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Issues
</span>      
</a>
  
</li>
        <li hidden="hidden" data-menu-item="i2pull-requests-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-04d1d626-f9c0-493e-b982-40d09901af93" href="/dimitripaiva/BlenderRenderPasses/pulls" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-git-pull-request">
    <path d="M1.5 3.25a2.25 2.25 0 1 1 3 2.122v5.256a2.251 2.251 0 1 1-1.5 0V5.372A2.25 2.25 0 0 1 1.5 3.25Zm5.677-.177L9.573.677A.25.25 0 0 1 10 .854V2.5h1A2.5 2.5 0 0 1 13.5 5v5.628a2.251 2.251 0 1 1-1.5 0V5a1 1 0 0 0-1-1h-1v1.646a.25.25 0 0 1-.427.177L7.177 3.427a.25.25 0 0 1 0-.354ZM3.75 2.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm0 9.5a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Zm8.25.75a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Pull requests
</span>      
</a>
  
</li>
        <li hidden="hidden" data-menu-item="i3actions-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-a60f81ae-27d4-43f8-b9ea-e6ae8ba34268" href="/dimitripaiva/BlenderRenderPasses/actions" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-play">
    <path d="M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Actions
</span>      
</a>
  
</li>
        <li hidden="hidden" data-menu-item="i4projects-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-9ed306b2-2f4a-4140-8c5d-9b2b29901c35" href="/dimitripaiva/BlenderRenderPasses/projects" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-table">
    <path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25ZM6.5 6.5v8h7.75a.25.25 0 0 0 .25-.25V6.5Zm8-1.5V1.75a.25.25 0 0 0-.25-.25H6.5V5Zm-13 1.5v7.75c0 .138.112.25.25.25H5v-8ZM5 5V1.5H1.75a.25.25 0 0 0-.25.25V5Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Projects
</span>      
</a>
  
</li>
        <li hidden="hidden" data-menu-item="i5security-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-227cead1-e5c1-4f30-ab32-98decdc5ccd1" href="/dimitripaiva/BlenderRenderPasses/security" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-shield">
    <path d="M7.467.133a1.748 1.748 0 0 1 1.066 0l5.25 1.68A1.75 1.75 0 0 1 15 3.48V7c0 1.566-.32 3.182-1.303 4.682-.983 1.498-2.585 2.813-5.032 3.855a1.697 1.697 0 0 1-1.33 0c-2.447-1.042-4.049-2.357-5.032-3.855C1.32 10.182 1 8.566 1 7V3.48a1.75 1.75 0 0 1 1.217-1.667Zm.61 1.429a.25.25 0 0 0-.153 0l-5.25 1.68a.25.25 0 0 0-.174.238V7c0 1.358.275 2.666 1.057 3.86.784 1.194 2.121 2.34 4.366 3.297a.196.196 0 0 0 .154 0c2.245-.956 3.582-2.104 4.366-3.298C13.225 9.666 13.5 8.36 13.5 7V3.48a.251.251 0 0 0-.174-.237l-5.25-1.68ZM8.75 4.75v3a.75.75 0 0 1-1.5 0v-3a.75.75 0 0 1 1.5 0ZM9 10.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Security
</span>      
</a>
  
</li>
        <li hidden="hidden" data-menu-item="i6insights-tab" data-targets="action-list.items" role="none" data-view-component="true" class="ActionListItem">
    
    
    <a tabindex="-1" id="item-c1693ded-3ff1-45b2-bb1a-8c43a09b45bf" href="/dimitripaiva/BlenderRenderPasses/pulse" role="menuitem" data-view-component="true" class="ActionListContent ActionListContent--visual16">
        <span class="ActionListItem-visual ActionListItem-visual--leading">
          <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-graph">
    <path d="M1.5 1.75V13.5h13.75a.75.75 0 0 1 0 1.5H.75a.75.75 0 0 1-.75-.75V1.75a.75.75 0 0 1 1.5 0Zm14.28 2.53-5.25 5.25a.75.75 0 0 1-1.06 0L7 7.06 4.28 9.78a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l3.25-3.25a.75.75 0 0 1 1.06 0L10 7.94l4.72-4.72a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path>
</svg>
        </span>
      
        <span data-view-component="true" class="ActionListItem-label">
          Insights
</span>      
</a>
  
</li>
</ul>    
</div></action-list>


</div>
      
</div></anchored-position>  </focus-group>
</action-menu></div>
</nav>
              
            </div>
    </header>


      <div hidden="hidden" data-view-component="true" class="js-stale-session-flash stale-session-flash flash flash-warn flash-full">
  
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path d="M6.457 1.047c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0 1 14.082 15H1.918a1.75 1.75 0 0 1-1.543-2.575Zm1.763.707a.25.25 0 0 0-.44 0L1.698 13.132a.25.25 0 0 0 .22.368h12.164a.25.25 0 0 0 .22-.368Zm.53 3.996v2.5a.75.75 0 0 1-1.5 0v-2.5a.75.75 0 0 1 1.5 0ZM9 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
        <span class="js-stale-session-flash-signed-in" hidden>You signed in with another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>
        <span class="js-stale-session-flash-signed-out" hidden>You signed out in another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>
        <span class="js-stale-session-flash-switched" hidden>You switched accounts on another tab or window. <a class="Link--inTextBlock" href="">Reload</a> to refresh your session.</span>

    <button id="icon-button-740fdf9e-7ecb-4e72-a7b9-b9a4e842c7be" aria-labelledby="tooltip-4f1467cc-d50b-4b7b-ad59-c776c5a3d8ed" type="button" data-view-component="true" class="Button Button--iconOnly Button--invisible Button--medium flash-close js-flash-close">  <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x Button-visual">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
</button><tool-tip id="tooltip-4f1467cc-d50b-4b7b-ad59-c776c5a3d8ed" for="icon-button-740fdf9e-7ecb-4e72-a7b9-b9a4e842c7be" popover="manual" data-direction="s" data-type="label" data-view-component="true" class="sr-only position-absolute">Dismiss alert</tool-tip>


  
</div>
        
          
    </div>

  <div id="start-of-content" class="show-on-focus"></div>








    <div id="js-flash-container" class="flash-container" data-turbo-replace>




  <template class="js-flash-template">
    
<div class="flash flash-full   {{ className }}">
  <div >
    <button autofocus class="flash-close js-flash-close" type="button" aria-label="Dismiss this message">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
    </button>
    <div aria-atomic="true" role="alert" class="js-flash-alert">
      
      <div>{{ message }}</div>

    </div>
  </div>
</div>
  </template>
</div>


    
  <notification-shelf-watcher data-base-url="https://github.com/notifications/beta/shelf" data-channel="eyJjIjoibm90aWZpY2F0aW9uLWNoYW5nZWQ6MTY5Nzk3NTAiLCJ0IjoxNzYwNDUzMjgxfQ==--bce03480b259beef7cc26a1f5e9197b1fd83376b823da21b9a3742694d195077" data-view-component="true" class="js-socket-channel"></notification-shelf-watcher>
  <div hidden data-initial data-target="notification-shelf-watcher.placeholder"></div>






  <div
    class="application-main "
    data-commit-hovercards-enabled
    data-discussion-hovercards-enabled
    data-issue-and-pr-hovercards-enabled
    data-project-hovercards-enabled
  >
        <div itemscope itemtype="http://schema.org/SoftwareSourceCode" class="">
    <main id="js-repo-pjax-container" >
      
      






    
  <div id="repository-container-header" data-turbo-replace hidden ></div>




<turbo-frame id="repo-content-turbo-frame" target="_top" data-turbo-action="advance" class="">
    <div id="repo-content-pjax-container" class="repository-content " >
      <a href="https://github.dev/" class="d-none js-github-dev-shortcut" data-hotkey=".,Mod+Alt+.">Open in github.dev</a>
  <a href="https://github.dev/" class="d-none js-github-dev-new-tab-shortcut" data-hotkey="Shift+.,Shift+&gt;,&gt;" target="_blank" rel="noopener noreferrer">Open in a new github.dev tab</a>
    <a class="d-none" data-hotkey=",,Mod+Alt+," target="_blank" href="/codespaces/new/dimitripaiva/BlenderRenderPasses/tree/main?resume=1">Open in codespace</a>




    
      
    








<react-app
  app-name="react-code-view"
  initial-path="/dimitripaiva/BlenderRenderPasses/blob/main/render_layers_setup.py"
    style="display: block; min-height: calc(100vh - 64px);"
  data-attempted-ssr="true"
  data-ssr="true"
  data-lazy="false"
  data-alternate="false"
  data-data-router-enabled="false"
  data-react-profiling="false"
>
  
  <script type="application/json" data-target="react-app.embeddedData">{"payload":{"allShortcutsEnabled":true,"fileTree":{"":{"items":[{"name":"PBRLayersSetup.md","path":"PBRLayersSetup.md","contentType":"file"},{"name":"README.md","path":"README.md","contentType":"file"},{"name":"render_layers_setup.py","path":"render_layers_setup.py","contentType":"file"}],"totalCount":3}},"fileTreeProcessingTime":2.855845,"foldersToFetch":[],"incompleteFileTree":false,"repo":{"id":932755268,"defaultBranch":"main","name":"BlenderRenderPasses","ownerLogin":"dimitripaiva","currentUserCanPush":false,"isFork":false,"isEmpty":false,"createdAt":"2025-02-14T07:12:12.000-06:00","ownerAvatar":"https://avatars.githubusercontent.com/u/50772360?v=4","public":true,"private":false,"isOrgOwned":false},"codeLineWrapEnabled":false,"symbolsExpanded":true,"treeExpanded":true,"refInfo":{"name":"main","listCacheKey":"v0:1739539623.0","canEdit":true,"refType":"branch","currentOid":"6d3ddb22ec6e24848b19f4f3ad54a623572e2bf8","canEditOnDefaultBranch":true,"fileExistsOnDefault":true},"path":"render_layers_setup.py","currentUser":{"id":16979750,"login":"deodatopr","userEmail":"deodatopr@gmail.com"},"blob":{"rawLines":["bl_info = {\r","    \"name\": \"PBR Render Layers Setup\",\r","    \"author\": \"Assistant\",\r","    \"version\": (1, 0),\r","    \"blender\": (3, 0, 0),\r","    \"location\": \"Properties \u003e Render \u003e PBR Setup and Node Editor \u003e Add \u003e Group\",\r","    \"description\": \"Creates a PBR render layers setup with all passes\",\r","    \"category\": \"Render\",\r","}\r","\r","import bpy\r","from bpy.types import Operator, Panel\r","from bpy.utils import register_class, unregister_class\r","\r","class SetupPBRCompositor(Operator):\r","    bl_idname = \"render.setup_pbr_compositor\"\r","    bl_label = \"Setup PBR Compositor\"\r","    bl_options = {'REGISTER', 'UNDO'}\r","    \r","    def execute(self, context):\r","        # Enable use_nodes for the scene\r","        context.scene.use_nodes = True\r","        \r","        # Enable all necessary render passes in the View Layer\r","        view_layer = context.view_layer\r","        # Diffuse\r","        view_layer.use_pass_diffuse_direct = True\r","        view_layer.use_pass_diffuse_indirect = True\r","        view_layer.use_pass_diffuse_color = True\r","        # Glossy\r","        view_layer.use_pass_glossy_direct = True\r","        view_layer.use_pass_glossy_indirect = True\r","        view_layer.use_pass_glossy_color = True\r","        # Transmission\r","        view_layer.use_pass_transmission_direct = True\r","        view_layer.use_pass_transmission_indirect = True\r","        view_layer.use_pass_transmission_color = True\r","        # Additional passes\r","        view_layer.use_pass_emit = True\r","        view_layer.use_pass_environment = True\r","        \r","        # Clear existing nodes\r","        context.scene.node_tree.nodes.clear()\r","        \r","        # Create render layer node\r","        rl = context.scene.node_tree.nodes.new('CompositorNodeRLayers')\r","        rl.location = (-600, 0)\r","        \r","        # Create the node group if it doesn't exist\r","        if 'PBR Render Layers Setup' not in bpy.data.node_groups:\r","            bpy.ops.node.create_pbr_setup()\r","        \r","        # Create group node\r","        group = context.scene.node_tree.nodes.new('CompositorNodeGroup')\r","        group.node_tree = bpy.data.node_groups['PBR Render Layers Setup']\r","        group.location = (-300, 0)\r","        \r","        # Create composite output\r","        composite = context.scene.node_tree.nodes.new('CompositorNodeComposite')\r","        composite.location = (0, 0)\r","        \r","        # Debug: Print all available outputs\r","        print(\"Available Render Layer outputs:\", [o.name for o in rl.outputs])\r","        print(\"Available Group inputs:\", [i.name for i in group.inputs])\r","        \r","        # Create links\r","        links = context.scene.node_tree.links\r","        \r","        try:\r","            # Connect all passes with error checking\r","            # Diffuse passes\r","            print(\"Connecting Diffuse passes...\")\r","            links.new(rl.outputs['DiffDir'], group.inputs['Diffuse Direct'])\r","            links.new(rl.outputs['DiffInd'], group.inputs['Diffuse Indirect'])\r","            links.new(rl.outputs['DiffCol'], group.inputs['Diffuse Color'])\r","            \r","            # Glossy passes\r","            print(\"Connecting Glossy passes...\")\r","            links.new(rl.outputs['GlossDir'], group.inputs['Glossy Direct'])\r","            links.new(rl.outputs['GlossInd'], group.inputs['Glossy Indirect'])\r","            links.new(rl.outputs['GlossCol'], group.inputs['Glossy Color'])\r","            \r","            # Transmission passes\r","            print(\"Connecting Transmission passes...\")\r","            links.new(rl.outputs['TransDir'], group.inputs['Transmission Direct'])\r","            links.new(rl.outputs['TransInd'], group.inputs['Transmission Indirect'])\r","            links.new(rl.outputs['TransCol'], group.inputs['Transmission Color'])\r","            \r","            # Additional passes\r","            print(\"Connecting additional passes...\")\r","            links.new(rl.outputs['Emit'], group.inputs['Emission'])\r","            links.new(rl.outputs['Env'], group.inputs['Environment'])\r","            \r","            # Connect output\r","            links.new(group.outputs['Combined'], composite.inputs[0])\r","            \r","        except Exception as e:\r","            print(f\"Error connecting nodes: {str(e)}\")\r","            return {'CANCELLED'}\r","        \r","        return {'FINISHED'}\r","\r","class CreatePBRRenderLayersSetup(Operator):\r","    bl_idname = \"node.create_pbr_setup\"\r","    bl_label = \"PBR Render Layers Setup\"\r","    bl_options = {'REGISTER', 'UNDO'}\r","\r","    def execute(self, context):\r","        # Check if the node group already exists and remove it\r","        if 'PBR Render Layers Setup' in bpy.data.node_groups:\r","            bpy.data.node_groups.remove(bpy.data.node_groups['PBR Render Layers Setup'])\r","        \r","        # Create new node group\r","        node_group = bpy.data.node_groups.new(type=\"CompositorNodeTree\", name=\"PBR Render Layers Setup\")\r","        \r","        # Create group input/output nodes first\r","        group_in = node_group.nodes.new('NodeGroupInput')\r","        group_in.location = (-800, 0)\r","        group_out = node_group.nodes.new('NodeGroupOutput')\r","        group_out.location = (400, 0)\r","        \r","        # Create input sockets\r","        input_names = [\r","            'Diffuse Direct', 'Diffuse Indirect', 'Diffuse Color',\r","            'Glossy Direct', 'Glossy Indirect', 'Glossy Color',\r","            'Transmission Direct', 'Transmission Indirect', 'Transmission Color',\r","            'Emission', 'Environment'\r","        ]\r","        \r","        for name in input_names:\r","            node_group.interface.new_socket(name=name, in_out='INPUT', socket_type='NodeSocketColor')\r","        \r","        # Create output socket\r","        node_group.interface.new_socket(name='Combined', in_out='OUTPUT', socket_type='NodeSocketColor')\r","        \r","        # Create nodes\r","        nodes = node_group.nodes\r","        \r","        # Diffuse nodes\r","        diffuse_add = nodes.new('CompositorNodeMixRGB')\r","        diffuse_add.blend_type = 'ADD'\r","        diffuse_add.location = (-400, 200)\r","        diffuse_add.inputs[0].default_value = 1\r","        \r","        diffuse_mult = nodes.new('CompositorNodeMixRGB')\r","        diffuse_mult.blend_type = 'MULTIPLY'\r","        diffuse_mult.location = (-200, 200)\r","        diffuse_mult.inputs[0].default_value = 1\r","        \r","        # Glossy nodes\r","        glossy_add = nodes.new('CompositorNodeMixRGB')\r","        glossy_add.blend_type = 'ADD'\r","        glossy_add.location = (-400, 0)\r","        glossy_add.inputs[0].default_value = 1\r","        \r","        glossy_mult = nodes.new('CompositorNodeMixRGB')\r","        glossy_mult.blend_type = 'MULTIPLY'\r","        glossy_mult.location = (-200, 0)\r","        glossy_mult.inputs[0].default_value = 1\r","        \r","        # Transmission nodes\r","        trans_add = nodes.new('CompositorNodeMixRGB')\r","        trans_add.blend_type = 'ADD'\r","        trans_add.location = (-400, -200)\r","        trans_add.inputs[0].default_value = 1\r","        \r","        trans_mult = nodes.new('CompositorNodeMixRGB')\r","        trans_mult.blend_type = 'MULTIPLY'\r","        trans_mult.location = (-200, -200)\r","        trans_mult.inputs[0].default_value = 1\r","        \r","        # Final combination nodes\r","        add1 = nodes.new('CompositorNodeMixRGB')\r","        add1.blend_type = 'ADD'\r","        add1.inputs[0].default_value = 1\r","        add1.location = (0, 0)\r","        \r","        add2 = nodes.new('CompositorNodeMixRGB')\r","        add2.blend_type = 'ADD'\r","        add2.inputs[0].default_value = 1\r","        add2.location = (100, 0)\r","        \r","        add3 = nodes.new('CompositorNodeMixRGB')\r","        add3.blend_type = 'ADD'\r","        add3.inputs[0].default_value = 1\r","        add3.location = (200, 0)\r","        \r","        final_add = nodes.new('CompositorNodeMixRGB')\r","        final_add.blend_type = 'ADD'\r","        final_add.inputs[0].default_value = 1\r","        final_add.location = (300, 0)\r","        \r","        # Create all links\r","        links = node_group.links\r","        \r","        # Connect Add nodes\r","        # Diffuse\r","        links.new(group_in.outputs['Diffuse Direct'], diffuse_add.inputs[1])\r","        links.new(group_in.outputs['Diffuse Indirect'], diffuse_add.inputs[2])\r","        \r","        # Glossy\r","        links.new(group_in.outputs['Glossy Direct'], glossy_add.inputs[1])\r","        links.new(group_in.outputs['Glossy Indirect'], glossy_add.inputs[2])\r","        \r","        # Transmission\r","        links.new(group_in.outputs['Transmission Direct'], trans_add.inputs[1])\r","        links.new(group_in.outputs['Transmission Indirect'], trans_add.inputs[2])\r","        \r","        # Connect to Multiply nodes\r","        # Diffuse\r","        links.new(diffuse_add.outputs[0], diffuse_mult.inputs[1])\r","        links.new(group_in.outputs['Diffuse Color'], diffuse_mult.inputs[2])\r","        \r","        # Glossy\r","        links.new(glossy_add.outputs[0], glossy_mult.inputs[1])\r","        links.new(group_in.outputs['Glossy Color'], glossy_mult.inputs[2])\r","        \r","        # Transmission\r","        links.new(trans_add.outputs[0], trans_mult.inputs[1])\r","        links.new(group_in.outputs['Transmission Color'], trans_mult.inputs[2])\r","        \r","        # Combine everything\r","        links.new(diffuse_mult.outputs[0], add1.inputs[1])\r","        links.new(glossy_mult.outputs[0], add1.inputs[2])\r","        \r","        links.new(add1.outputs[0], add2.inputs[1])\r","        links.new(trans_mult.outputs[0], add2.inputs[2])\r","        \r","        links.new(add2.outputs[0], add3.inputs[1])\r","        links.new(group_in.outputs['Emission'], add3.inputs[2])\r","        \r","        links.new(add3.outputs[0], final_add.inputs[1])\r","        links.new(group_in.outputs['Environment'], final_add.inputs[2])\r","        \r","        # Connect to output\r","        links.new(final_add.outputs[0], group_out.inputs[0])\r","        \r","        return {'FINISHED'}\r","\r","class PBR_PT_SetupPanel(Panel):\r","    bl_label = \"PBR Setup\"\r","    bl_idname = \"RENDER_PT_pbr_setup\"\r","    bl_space_type = 'PROPERTIES'\r","    bl_region_type = 'WINDOW'\r","    bl_context = \"render\"\r","    \r","    def draw(self, context):\r","        layout = self.layout\r","        layout.operator(SetupPBRCompositor.bl_idname)\r","\r","def menu_func(self, context):\r","    self.layout.operator(CreatePBRRenderLayersSetup.bl_idname)\r","\r","def register():\r","    register_class(CreatePBRRenderLayersSetup)\r","    register_class(SetupPBRCompositor)\r","    register_class(PBR_PT_SetupPanel)\r","    bpy.types.NODE_MT_add.append(menu_func)\r","\r","def unregister():\r","    unregister_class(PBR_PT_SetupPanel)\r","    unregister_class(SetupPBRCompositor)\r","    unregister_class(CreatePBRRenderLayersSetup)\r","    bpy.types.NODE_MT_add.remove(menu_func)\r","\r","if __name__ == \"__main__\":\r","    register() "],"stylingDirectives":null,"colorizedLines":["\u003cspan class=pl-s1\u003ebl_info\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e {","    \u003cspan class=pl-s\u003e\u0026quot;name\u0026quot;\u003c/span\u003e: \u003cspan class=pl-s\u003e\u0026quot;PBR Render Layers Setup\u0026quot;\u003c/span\u003e,","    \u003cspan class=pl-s\u003e\u0026quot;author\u0026quot;\u003c/span\u003e: \u003cspan class=pl-s\u003e\u0026quot;Assistant\u0026quot;\u003c/span\u003e,","    \u003cspan class=pl-s\u003e\u0026quot;version\u0026quot;\u003c/span\u003e: (\u003cspan class=pl-c1\u003e1\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e),","    \u003cspan class=pl-s\u003e\u0026quot;blender\u0026quot;\u003c/span\u003e: (\u003cspan class=pl-c1\u003e3\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e),","    \u003cspan class=pl-s\u003e\u0026quot;location\u0026quot;\u003c/span\u003e: \u003cspan class=pl-s\u003e\u0026quot;Properties \u0026gt; Render \u0026gt; PBR Setup and Node Editor \u0026gt; Add \u0026gt; Group\u0026quot;\u003c/span\u003e,","    \u003cspan class=pl-s\u003e\u0026quot;description\u0026quot;\u003c/span\u003e: \u003cspan class=pl-s\u003e\u0026quot;Creates a PBR render layers setup with all passes\u0026quot;\u003c/span\u003e,","    \u003cspan class=pl-s\u003e\u0026quot;category\u0026quot;\u003c/span\u003e: \u003cspan class=pl-s\u003e\u0026quot;Render\u0026quot;\u003c/span\u003e,","}","","\u003cspan class=pl-k\u003eimport\u003c/span\u003e \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e","\u003cspan class=pl-k\u003efrom\u003c/span\u003e \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-s1\u003etypes\u003c/span\u003e \u003cspan class=pl-k\u003eimport\u003c/span\u003e \u003cspan class=pl-v\u003eOperator\u003c/span\u003e, \u003cspan class=pl-v\u003ePanel\u003c/span\u003e","\u003cspan class=pl-k\u003efrom\u003c/span\u003e \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-s1\u003eutils\u003c/span\u003e \u003cspan class=pl-k\u003eimport\u003c/span\u003e \u003cspan class=pl-s1\u003eregister_class\u003c/span\u003e, \u003cspan class=pl-s1\u003eunregister_class\u003c/span\u003e","","\u003cspan class=pl-k\u003eclass\u003c/span\u003e \u003cspan class=pl-v\u003eSetupPBRCompositor\u003c/span\u003e(\u003cspan class=pl-v\u003eOperator\u003c/span\u003e):","    \u003cspan class=pl-s1\u003ebl_idname\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026quot;render.setup_pbr_compositor\u0026quot;\u003c/span\u003e","    \u003cspan class=pl-s1\u003ebl_label\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026quot;Setup PBR Compositor\u0026quot;\u003c/span\u003e","    \u003cspan class=pl-s1\u003ebl_options\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e {\u003cspan class=pl-s\u003e\u0026#39;REGISTER\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;UNDO\u0026#39;\u003c/span\u003e}","    ","    \u003cspan class=pl-k\u003edef\u003c/span\u003e \u003cspan class=pl-en\u003eexecute\u003c/span\u003e(\u003cspan class=pl-s1\u003eself\u003c/span\u003e, \u003cspan class=pl-s1\u003econtext\u003c/span\u003e):","        \u003cspan class=pl-c\u003e# Enable use_nodes for the scene\u003c/span\u003e","        \u003cspan class=pl-s1\u003econtext\u003c/span\u003e.\u003cspan class=pl-c1\u003escene\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_nodes\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        ","        \u003cspan class=pl-c\u003e# Enable all necessary render passes in the View Layer\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003econtext\u003c/span\u003e.\u003cspan class=pl-c1\u003eview_layer\u003c/span\u003e","        \u003cspan class=pl-c\u003e# Diffuse\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_diffuse_direct\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_diffuse_indirect\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_diffuse_color\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-c\u003e# Glossy\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_glossy_direct\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_glossy_indirect\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_glossy_color\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-c\u003e# Transmission\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_transmission_direct\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_transmission_indirect\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_transmission_color\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-c\u003e# Additional passes\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_emit\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        \u003cspan class=pl-s1\u003eview_layer\u003c/span\u003e.\u003cspan class=pl-c1\u003euse_pass_environment\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003eTrue\u003c/span\u003e","        ","        \u003cspan class=pl-c\u003e# Clear existing nodes\u003c/span\u003e","        \u003cspan class=pl-s1\u003econtext\u003c/span\u003e.\u003cspan class=pl-c1\u003escene\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_tree\u003c/span\u003e.\u003cspan class=pl-c1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003eclear\u003c/span\u003e()","        ","        \u003cspan class=pl-c\u003e# Create render layer node\u003c/span\u003e","        \u003cspan class=pl-s1\u003erl\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003econtext\u003c/span\u003e.\u003cspan class=pl-c1\u003escene\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_tree\u003c/span\u003e.\u003cspan class=pl-c1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeRLayers\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e600\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        ","        \u003cspan class=pl-c\u003e# Create the node group if it doesn\u0026#39;t exist\u003c/span\u003e","        \u003cspan class=pl-k\u003eif\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;PBR Render Layers Setup\u0026#39;\u003c/span\u003e \u003cspan class=pl-c1\u003e\u003cspan class=pl-c1\u003enot\u003c/span\u003e \u003cspan class=pl-c1\u003ein\u003c/span\u003e\u003c/span\u003e \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003edata\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_groups\u003c/span\u003e:","            \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003eops\u003c/span\u003e.\u003cspan class=pl-c1\u003enode\u003c/span\u003e.\u003cspan class=pl-c1\u003ecreate_pbr_setup\u003c/span\u003e()","        ","        \u003cspan class=pl-c\u003e# Create group node\u003c/span\u003e","        \u003cspan class=pl-s1\u003egroup\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003econtext\u003c/span\u003e.\u003cspan class=pl-c1\u003escene\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_tree\u003c/span\u003e.\u003cspan class=pl-c1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeGroup\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_tree\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003edata\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_groups\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;PBR Render Layers Setup\u0026#39;\u003c/span\u003e]","        \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e300\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        ","        \u003cspan class=pl-c\u003e# Create composite output\u003c/span\u003e","        \u003cspan class=pl-s1\u003ecomposite\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003econtext\u003c/span\u003e.\u003cspan class=pl-c1\u003escene\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_tree\u003c/span\u003e.\u003cspan class=pl-c1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeComposite\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003ecomposite\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e0\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        ","        \u003cspan class=pl-c\u003e# Debug: Print all available outputs\u003c/span\u003e","        \u003cspan class=pl-en\u003eprint\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026quot;Available Render Layer outputs:\u0026quot;\u003c/span\u003e, [\u003cspan class=pl-s1\u003eo\u003c/span\u003e.\u003cspan class=pl-c1\u003ename\u003c/span\u003e \u003cspan class=pl-k\u003efor\u003c/span\u003e \u003cspan class=pl-s1\u003eo\u003c/span\u003e \u003cspan class=pl-c1\u003ein\u003c/span\u003e \u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e])","        \u003cspan class=pl-en\u003eprint\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026quot;Available Group inputs:\u0026quot;\u003c/span\u003e, [\u003cspan class=pl-s1\u003ei\u003c/span\u003e.\u003cspan class=pl-c1\u003ename\u003c/span\u003e \u003cspan class=pl-k\u003efor\u003c/span\u003e \u003cspan class=pl-s1\u003ei\u003c/span\u003e \u003cspan class=pl-c1\u003ein\u003c/span\u003e \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Create links\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003econtext\u003c/span\u003e.\u003cspan class=pl-c1\u003escene\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_tree\u003c/span\u003e.\u003cspan class=pl-c1\u003elinks\u003c/span\u003e","        ","        \u003cspan class=pl-k\u003etry\u003c/span\u003e:","            \u003cspan class=pl-c\u003e# Connect all passes with error checking\u003c/span\u003e","            \u003cspan class=pl-c\u003e# Diffuse passes\u003c/span\u003e","            \u003cspan class=pl-en\u003eprint\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026quot;Connecting Diffuse passes...\u0026quot;\u003c/span\u003e)","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;DiffDir\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Diffuse Direct\u0026#39;\u003c/span\u003e])","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;DiffInd\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Diffuse Indirect\u0026#39;\u003c/span\u003e])","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;DiffCol\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Diffuse Color\u0026#39;\u003c/span\u003e])","            ","            \u003cspan class=pl-c\u003e# Glossy passes\u003c/span\u003e","            \u003cspan class=pl-en\u003eprint\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026quot;Connecting Glossy passes...\u0026quot;\u003c/span\u003e)","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;GlossDir\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Glossy Direct\u0026#39;\u003c/span\u003e])","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;GlossInd\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Glossy Indirect\u0026#39;\u003c/span\u003e])","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;GlossCol\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Glossy Color\u0026#39;\u003c/span\u003e])","            ","            \u003cspan class=pl-c\u003e# Transmission passes\u003c/span\u003e","            \u003cspan class=pl-en\u003eprint\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026quot;Connecting Transmission passes...\u0026quot;\u003c/span\u003e)","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;TransDir\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Transmission Direct\u0026#39;\u003c/span\u003e])","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;TransInd\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Transmission Indirect\u0026#39;\u003c/span\u003e])","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;TransCol\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Transmission Color\u0026#39;\u003c/span\u003e])","            ","            \u003cspan class=pl-c\u003e# Additional passes\u003c/span\u003e","            \u003cspan class=pl-en\u003eprint\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026quot;Connecting additional passes...\u0026quot;\u003c/span\u003e)","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Emit\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Emission\u0026#39;\u003c/span\u003e])","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003erl\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Env\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Environment\u0026#39;\u003c/span\u003e])","            ","            \u003cspan class=pl-c\u003e# Connect output\u003c/span\u003e","            \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Combined\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003ecomposite\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e])","            ","        \u003cspan class=pl-k\u003eexcept\u003c/span\u003e \u003cspan class=pl-v\u003eException\u003c/span\u003e \u003cspan class=pl-k\u003eas\u003c/span\u003e \u003cspan class=pl-s1\u003ee\u003c/span\u003e:","            \u003cspan class=pl-en\u003eprint\u003c/span\u003e(\u003cspan class=pl-s\u003ef\u0026quot;Error connecting nodes: \u003cspan class=pl-s1\u003e\u003cspan class=pl-kos\u003e{\u003c/span\u003e\u003cspan class=pl-en\u003estr\u003c/span\u003e(\u003cspan class=pl-s1\u003ee\u003c/span\u003e)\u003cspan class=pl-kos\u003e}\u003c/span\u003e\u003c/span\u003e\u0026quot;\u003c/span\u003e)","            \u003cspan class=pl-k\u003ereturn\u003c/span\u003e {\u003cspan class=pl-s\u003e\u0026#39;CANCELLED\u0026#39;\u003c/span\u003e}","        ","        \u003cspan class=pl-k\u003ereturn\u003c/span\u003e {\u003cspan class=pl-s\u003e\u0026#39;FINISHED\u0026#39;\u003c/span\u003e}","","\u003cspan class=pl-k\u003eclass\u003c/span\u003e \u003cspan class=pl-v\u003eCreatePBRRenderLayersSetup\u003c/span\u003e(\u003cspan class=pl-v\u003eOperator\u003c/span\u003e):","    \u003cspan class=pl-s1\u003ebl_idname\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026quot;node.create_pbr_setup\u0026quot;\u003c/span\u003e","    \u003cspan class=pl-s1\u003ebl_label\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026quot;PBR Render Layers Setup\u0026quot;\u003c/span\u003e","    \u003cspan class=pl-s1\u003ebl_options\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e {\u003cspan class=pl-s\u003e\u0026#39;REGISTER\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;UNDO\u0026#39;\u003c/span\u003e}","","    \u003cspan class=pl-k\u003edef\u003c/span\u003e \u003cspan class=pl-en\u003eexecute\u003c/span\u003e(\u003cspan class=pl-s1\u003eself\u003c/span\u003e, \u003cspan class=pl-s1\u003econtext\u003c/span\u003e):","        \u003cspan class=pl-c\u003e# Check if the node group already exists and remove it\u003c/span\u003e","        \u003cspan class=pl-k\u003eif\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;PBR Render Layers Setup\u0026#39;\u003c/span\u003e \u003cspan class=pl-c1\u003ein\u003c/span\u003e \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003edata\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_groups\u003c/span\u003e:","            \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003edata\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_groups\u003c/span\u003e.\u003cspan class=pl-c1\u003eremove\u003c/span\u003e(\u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003edata\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_groups\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;PBR Render Layers Setup\u0026#39;\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Create new node group\u003c/span\u003e","        \u003cspan class=pl-s1\u003enode_group\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003edata\u003c/span\u003e.\u003cspan class=pl-c1\u003enode_groups\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003etype\u003c/span\u003e\u003cspan class=pl-c1\u003e=\u003c/span\u003e\u003cspan class=pl-s\u003e\u0026quot;CompositorNodeTree\u0026quot;\u003c/span\u003e, \u003cspan class=pl-s1\u003ename\u003c/span\u003e\u003cspan class=pl-c1\u003e=\u003c/span\u003e\u003cspan class=pl-s\u003e\u0026quot;PBR Render Layers Setup\u0026quot;\u003c/span\u003e)","        ","        \u003cspan class=pl-c\u003e# Create group input/output nodes first\u003c/span\u003e","        \u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enode_group\u003c/span\u003e.\u003cspan class=pl-c1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;NodeGroupInput\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e800\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        \u003cspan class=pl-s1\u003egroup_out\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enode_group\u003c/span\u003e.\u003cspan class=pl-c1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;NodeGroupOutput\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003egroup_out\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e400\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        ","        \u003cspan class=pl-c\u003e# Create input sockets\u003c/span\u003e","        \u003cspan class=pl-s1\u003einput_names\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e [","            \u003cspan class=pl-s\u003e\u0026#39;Diffuse Direct\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;Diffuse Indirect\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;Diffuse Color\u0026#39;\u003c/span\u003e,","            \u003cspan class=pl-s\u003e\u0026#39;Glossy Direct\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;Glossy Indirect\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;Glossy Color\u0026#39;\u003c/span\u003e,","            \u003cspan class=pl-s\u003e\u0026#39;Transmission Direct\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;Transmission Indirect\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;Transmission Color\u0026#39;\u003c/span\u003e,","            \u003cspan class=pl-s\u003e\u0026#39;Emission\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s\u003e\u0026#39;Environment\u0026#39;\u003c/span\u003e","        ]","        ","        \u003cspan class=pl-k\u003efor\u003c/span\u003e \u003cspan class=pl-s1\u003ename\u003c/span\u003e \u003cspan class=pl-c1\u003ein\u003c/span\u003e \u003cspan class=pl-s1\u003einput_names\u003c/span\u003e:","            \u003cspan class=pl-s1\u003enode_group\u003c/span\u003e.\u003cspan class=pl-c1\u003einterface\u003c/span\u003e.\u003cspan class=pl-c1\u003enew_socket\u003c/span\u003e(\u003cspan class=pl-s1\u003ename\u003c/span\u003e\u003cspan class=pl-c1\u003e=\u003c/span\u003e\u003cspan class=pl-s1\u003ename\u003c/span\u003e, \u003cspan class=pl-s1\u003ein_out\u003c/span\u003e\u003cspan class=pl-c1\u003e=\u003c/span\u003e\u003cspan class=pl-s\u003e\u0026#39;INPUT\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s1\u003esocket_type\u003c/span\u003e\u003cspan class=pl-c1\u003e=\u003c/span\u003e\u003cspan class=pl-s\u003e\u0026#39;NodeSocketColor\u0026#39;\u003c/span\u003e)","        ","        \u003cspan class=pl-c\u003e# Create output socket\u003c/span\u003e","        \u003cspan class=pl-s1\u003enode_group\u003c/span\u003e.\u003cspan class=pl-c1\u003einterface\u003c/span\u003e.\u003cspan class=pl-c1\u003enew_socket\u003c/span\u003e(\u003cspan class=pl-s1\u003ename\u003c/span\u003e\u003cspan class=pl-c1\u003e=\u003c/span\u003e\u003cspan class=pl-s\u003e\u0026#39;Combined\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s1\u003ein_out\u003c/span\u003e\u003cspan class=pl-c1\u003e=\u003c/span\u003e\u003cspan class=pl-s\u003e\u0026#39;OUTPUT\u0026#39;\u003c/span\u003e, \u003cspan class=pl-s1\u003esocket_type\u003c/span\u003e\u003cspan class=pl-c1\u003e=\u003c/span\u003e\u003cspan class=pl-s\u003e\u0026#39;NodeSocketColor\u0026#39;\u003c/span\u003e)","        ","        \u003cspan class=pl-c\u003e# Create nodes\u003c/span\u003e","        \u003cspan class=pl-s1\u003enodes\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enode_group\u003c/span\u003e.\u003cspan class=pl-c1\u003enodes\u003c/span\u003e","        ","        \u003cspan class=pl-c\u003e# Diffuse nodes\u003c/span\u003e","        \u003cspan class=pl-s1\u003ediffuse_add\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003ediffuse_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;ADD\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003ediffuse_add\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e400\u003c/span\u003e, \u003cspan class=pl-c1\u003e200\u003c/span\u003e)","        \u003cspan class=pl-s1\u003ediffuse_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        ","        \u003cspan class=pl-s1\u003ediffuse_mult\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003ediffuse_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;MULTIPLY\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003ediffuse_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e200\u003c/span\u003e, \u003cspan class=pl-c1\u003e200\u003c/span\u003e)","        \u003cspan class=pl-s1\u003ediffuse_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        ","        \u003cspan class=pl-c\u003e# Glossy nodes\u003c/span\u003e","        \u003cspan class=pl-s1\u003eglossy_add\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003eglossy_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;ADD\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003eglossy_add\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e400\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        \u003cspan class=pl-s1\u003eglossy_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        ","        \u003cspan class=pl-s1\u003eglossy_mult\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003eglossy_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;MULTIPLY\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003eglossy_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e200\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        \u003cspan class=pl-s1\u003eglossy_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        ","        \u003cspan class=pl-c\u003e# Transmission nodes\u003c/span\u003e","        \u003cspan class=pl-s1\u003etrans_add\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003etrans_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;ADD\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003etrans_add\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e400\u003c/span\u003e, \u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e200\u003c/span\u003e)","        \u003cspan class=pl-s1\u003etrans_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        ","        \u003cspan class=pl-s1\u003etrans_mult\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003etrans_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;MULTIPLY\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003etrans_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e200\u003c/span\u003e, \u003cspan class=pl-c1\u003e-\u003c/span\u003e\u003cspan class=pl-c1\u003e200\u003c/span\u003e)","        \u003cspan class=pl-s1\u003etrans_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        ","        \u003cspan class=pl-c\u003e# Final combination nodes\u003c/span\u003e","        \u003cspan class=pl-s1\u003eadd1\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003eadd1\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;ADD\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003eadd1\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        \u003cspan class=pl-s1\u003eadd1\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e0\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        ","        \u003cspan class=pl-s1\u003eadd2\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003eadd2\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;ADD\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003eadd2\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        \u003cspan class=pl-s1\u003eadd2\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e100\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        ","        \u003cspan class=pl-s1\u003eadd3\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003eadd3\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;ADD\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003eadd3\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        \u003cspan class=pl-s1\u003eadd3\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e200\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        ","        \u003cspan class=pl-s1\u003efinal_add\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enodes\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s\u003e\u0026#39;CompositorNodeMixRGB\u0026#39;\u003c/span\u003e)","        \u003cspan class=pl-s1\u003efinal_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eblend_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;ADD\u0026#39;\u003c/span\u003e","        \u003cspan class=pl-s1\u003efinal_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e].\u003cspan class=pl-c1\u003edefault_value\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-c1\u003e1\u003c/span\u003e","        \u003cspan class=pl-s1\u003efinal_add\u003c/span\u003e.\u003cspan class=pl-c1\u003elocation\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e (\u003cspan class=pl-c1\u003e300\u003c/span\u003e, \u003cspan class=pl-c1\u003e0\u003c/span\u003e)","        ","        \u003cspan class=pl-c\u003e# Create all links\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003enode_group\u003c/span\u003e.\u003cspan class=pl-c1\u003elinks\u003c/span\u003e","        ","        \u003cspan class=pl-c\u003e# Connect Add nodes\u003c/span\u003e","        \u003cspan class=pl-c\u003e# Diffuse\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Diffuse Direct\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003ediffuse_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Diffuse Indirect\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003ediffuse_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Glossy\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Glossy Direct\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003eglossy_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Glossy Indirect\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003eglossy_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Transmission\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Transmission Direct\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003etrans_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Transmission Indirect\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003etrans_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Connect to Multiply nodes\u003c/span\u003e","        \u003cspan class=pl-c\u003e# Diffuse\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003ediffuse_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003ediffuse_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Diffuse Color\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003ediffuse_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Glossy\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003eglossy_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003eglossy_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Glossy Color\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003eglossy_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Transmission\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003etrans_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003etrans_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Transmission Color\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003etrans_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Combine everything\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003ediffuse_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003eadd1\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003eglossy_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003eadd1\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003eadd1\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003eadd2\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003etrans_mult\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003eadd2\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003eadd2\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003eadd3\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Emission\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003eadd3\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003eadd3\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003efinal_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e1\u003c/span\u003e])","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003egroup_in\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-s\u003e\u0026#39;Environment\u0026#39;\u003c/span\u003e], \u003cspan class=pl-s1\u003efinal_add\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e2\u003c/span\u003e])","        ","        \u003cspan class=pl-c\u003e# Connect to output\u003c/span\u003e","        \u003cspan class=pl-s1\u003elinks\u003c/span\u003e.\u003cspan class=pl-c1\u003enew\u003c/span\u003e(\u003cspan class=pl-s1\u003efinal_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eoutputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e], \u003cspan class=pl-s1\u003egroup_out\u003c/span\u003e.\u003cspan class=pl-c1\u003einputs\u003c/span\u003e[\u003cspan class=pl-c1\u003e0\u003c/span\u003e])","        ","        \u003cspan class=pl-k\u003ereturn\u003c/span\u003e {\u003cspan class=pl-s\u003e\u0026#39;FINISHED\u0026#39;\u003c/span\u003e}","","\u003cspan class=pl-k\u003eclass\u003c/span\u003e \u003cspan class=pl-v\u003ePBR_PT_SetupPanel\u003c/span\u003e(\u003cspan class=pl-v\u003ePanel\u003c/span\u003e):","    \u003cspan class=pl-s1\u003ebl_label\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026quot;PBR Setup\u0026quot;\u003c/span\u003e","    \u003cspan class=pl-s1\u003ebl_idname\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026quot;RENDER_PT_pbr_setup\u0026quot;\u003c/span\u003e","    \u003cspan class=pl-s1\u003ebl_space_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;PROPERTIES\u0026#39;\u003c/span\u003e","    \u003cspan class=pl-s1\u003ebl_region_type\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026#39;WINDOW\u0026#39;\u003c/span\u003e","    \u003cspan class=pl-s1\u003ebl_context\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026quot;render\u0026quot;\u003c/span\u003e","    ","    \u003cspan class=pl-k\u003edef\u003c/span\u003e \u003cspan class=pl-en\u003edraw\u003c/span\u003e(\u003cspan class=pl-s1\u003eself\u003c/span\u003e, \u003cspan class=pl-s1\u003econtext\u003c/span\u003e):","        \u003cspan class=pl-s1\u003elayout\u003c/span\u003e \u003cspan class=pl-c1\u003e=\u003c/span\u003e \u003cspan class=pl-s1\u003eself\u003c/span\u003e.\u003cspan class=pl-c1\u003elayout\u003c/span\u003e","        \u003cspan class=pl-s1\u003elayout\u003c/span\u003e.\u003cspan class=pl-c1\u003eoperator\u003c/span\u003e(\u003cspan class=pl-v\u003eSetupPBRCompositor\u003c/span\u003e.\u003cspan class=pl-c1\u003ebl_idname\u003c/span\u003e)","","\u003cspan class=pl-k\u003edef\u003c/span\u003e \u003cspan class=pl-en\u003emenu_func\u003c/span\u003e(\u003cspan class=pl-s1\u003eself\u003c/span\u003e, \u003cspan class=pl-s1\u003econtext\u003c/span\u003e):","    \u003cspan class=pl-s1\u003eself\u003c/span\u003e.\u003cspan class=pl-c1\u003elayout\u003c/span\u003e.\u003cspan class=pl-c1\u003eoperator\u003c/span\u003e(\u003cspan class=pl-v\u003eCreatePBRRenderLayersSetup\u003c/span\u003e.\u003cspan class=pl-c1\u003ebl_idname\u003c/span\u003e)","","\u003cspan class=pl-k\u003edef\u003c/span\u003e \u003cspan class=pl-en\u003eregister\u003c/span\u003e():","    \u003cspan class=pl-en\u003eregister_class\u003c/span\u003e(\u003cspan class=pl-v\u003eCreatePBRRenderLayersSetup\u003c/span\u003e)","    \u003cspan class=pl-en\u003eregister_class\u003c/span\u003e(\u003cspan class=pl-v\u003eSetupPBRCompositor\u003c/span\u003e)","    \u003cspan class=pl-en\u003eregister_class\u003c/span\u003e(\u003cspan class=pl-v\u003ePBR_PT_SetupPanel\u003c/span\u003e)","    \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003etypes\u003c/span\u003e.\u003cspan class=pl-c1\u003eNODE_MT_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eappend\u003c/span\u003e(\u003cspan class=pl-s1\u003emenu_func\u003c/span\u003e)","","\u003cspan class=pl-k\u003edef\u003c/span\u003e \u003cspan class=pl-en\u003eunregister\u003c/span\u003e():","    \u003cspan class=pl-en\u003eunregister_class\u003c/span\u003e(\u003cspan class=pl-v\u003ePBR_PT_SetupPanel\u003c/span\u003e)","    \u003cspan class=pl-en\u003eunregister_class\u003c/span\u003e(\u003cspan class=pl-v\u003eSetupPBRCompositor\u003c/span\u003e)","    \u003cspan class=pl-en\u003eunregister_class\u003c/span\u003e(\u003cspan class=pl-v\u003eCreatePBRRenderLayersSetup\u003c/span\u003e)","    \u003cspan class=pl-s1\u003ebpy\u003c/span\u003e.\u003cspan class=pl-c1\u003etypes\u003c/span\u003e.\u003cspan class=pl-c1\u003eNODE_MT_add\u003c/span\u003e.\u003cspan class=pl-c1\u003eremove\u003c/span\u003e(\u003cspan class=pl-s1\u003emenu_func\u003c/span\u003e)","","\u003cspan class=pl-k\u003eif\u003c/span\u003e \u003cspan class=pl-s1\u003e__name__\u003c/span\u003e \u003cspan class=pl-c1\u003e==\u003c/span\u003e \u003cspan class=pl-s\u003e\u0026quot;__main__\u0026quot;\u003c/span\u003e:","    \u003cspan class=pl-en\u003eregister\u003c/span\u003e() "],"csv":null,"csvError":null,"copilotSWEAgentEnabled":false,"dependabotInfo":{"showConfigurationBanner":false,"configFilePath":null,"networkDependabotPath":"/dimitripaiva/BlenderRenderPasses/network/updates","dismissConfigurationNoticePath":"/settings/dismiss-notice/dependabot_configuration_notice","configurationNoticeDismissed":false},"displayName":"render_layers_setup.py","displayUrl":"https://github.com/dimitripaiva/BlenderRenderPasses/blob/main/render_layers_setup.py?raw=true","headerInfo":{"blobSize":"10.2 KB","deleteTooltip":"Fork this repository and delete the file","editTooltip":"Fork this repository and edit the file","ghDesktopPath":"x-github-client://openRepo/https://github.com/dimitripaiva/BlenderRenderPasses?branch=main\u0026filepath=render_layers_setup.py","isGitLfs":false,"onBranch":true,"shortPath":"b918510","siteNavLoginPath":"/login?return_to=https%3A%2F%2Fgithub.com%2Fdimitripaiva%2FBlenderRenderPasses%2Fblob%2Fmain%2Frender_layers_setup.py","isCSV":false,"isRichtext":false,"toc":null,"lineInfo":{"truncatedLoc":"267","truncatedSloc":"212"},"mode":"file"},"image":false,"isCodeownersFile":null,"isPlain":false,"isValidLegacyIssueTemplate":false,"issueTemplate":null,"discussionTemplate":null,"language":"Python","languageID":303,"large":false,"planSupportInfo":{"repoIsFork":null,"repoOwnedByCurrentUser":null,"requestFullPath":"/dimitripaiva/BlenderRenderPasses/blob/main/render_layers_setup.py","showFreeOrgGatedFeatureMessage":null,"showPlanSupportBanner":null,"upgradeDataAttributes":null,"upgradePath":null},"publishBannersInfo":{"dismissActionNoticePath":"/settings/dismiss-notice/publish_action_from_dockerfile","releasePath":"/dimitripaiva/BlenderRenderPasses/releases/new?marketplace=true","showPublishActionBanner":false},"rawBlobUrl":"https://github.com/dimitripaiva/BlenderRenderPasses/raw/refs/heads/main/render_layers_setup.py","renderImageOrRaw":false,"richText":null,"renderedFileInfo":null,"shortPath":null,"symbolsEnabled":true,"tabSize":4,"topBannersInfo":{"overridingGlobalFundingFile":false,"globalPreferredFundingPath":null,"showInvalidCitationWarning":false,"citationHelpUrl":"https://docs.github.com/github/creating-cloning-and-archiving-repositories/creating-a-repository-on-github/about-citation-files","actionsOnboardingTip":null},"truncated":false,"viewable":true,"workflowRedirectUrl":null,"symbols":{"timed_out":false,"not_analyzed":false,"symbols":[{"name":"bl_info","kind":"constant","ident_start":0,"ident_end":7,"extent_start":0,"extent_end":315,"fully_qualified_name":"bl_info","ident_utf16":{"start":{"line_number":0,"utf16_col":0},"end":{"line_number":0,"utf16_col":7}},"extent_utf16":{"start":{"line_number":0,"utf16_col":0},"end":{"line_number":8,"utf16_col":1}}},{"name":"SetupPBRCompositor","kind":"class","ident_start":434,"ident_end":452,"extent_start":428,"extent_end":4183,"fully_qualified_name":"SetupPBRCompositor","ident_utf16":{"start":{"line_number":14,"utf16_col":6},"end":{"line_number":14,"utf16_col":24}},"extent_utf16":{"start":{"line_number":14,"utf16_col":0},"end":{"line_number":100,"utf16_col":27}}},{"name":"bl_idname","kind":"constant","ident_start":469,"ident_end":478,"extent_start":469,"extent_end":510,"fully_qualified_name":"SetupPBRCompositor.bl_idname","ident_utf16":{"start":{"line_number":15,"utf16_col":4},"end":{"line_number":15,"utf16_col":13}},"extent_utf16":{"start":{"line_number":15,"utf16_col":4},"end":{"line_number":15,"utf16_col":45}}},{"name":"bl_label","kind":"constant","ident_start":516,"ident_end":524,"extent_start":516,"extent_end":549,"fully_qualified_name":"SetupPBRCompositor.bl_label","ident_utf16":{"start":{"line_number":16,"utf16_col":4},"end":{"line_number":16,"utf16_col":12}},"extent_utf16":{"start":{"line_number":16,"utf16_col":4},"end":{"line_number":16,"utf16_col":37}}},{"name":"bl_options","kind":"constant","ident_start":555,"ident_end":565,"extent_start":555,"extent_end":588,"fully_qualified_name":"SetupPBRCompositor.bl_options","ident_utf16":{"start":{"line_number":17,"utf16_col":4},"end":{"line_number":17,"utf16_col":14}},"extent_utf16":{"start":{"line_number":17,"utf16_col":4},"end":{"line_number":17,"utf16_col":37}}},{"name":"execute","kind":"function","ident_start":604,"ident_end":611,"extent_start":600,"extent_end":4183,"fully_qualified_name":"SetupPBRCompositor.execute","ident_utf16":{"start":{"line_number":19,"utf16_col":8},"end":{"line_number":19,"utf16_col":15}},"extent_utf16":{"start":{"line_number":19,"utf16_col":4},"end":{"line_number":100,"utf16_col":27}}},{"name":"CreatePBRRenderLayersSetup","kind":"class","ident_start":4193,"ident_end":4219,"extent_start":4187,"extent_end":9627,"fully_qualified_name":"CreatePBRRenderLayersSetup","ident_utf16":{"start":{"line_number":102,"utf16_col":6},"end":{"line_number":102,"utf16_col":32}},"extent_utf16":{"start":{"line_number":102,"utf16_col":0},"end":{"line_number":237,"utf16_col":27}}},{"name":"bl_idname","kind":"constant","ident_start":4236,"ident_end":4245,"extent_start":4236,"extent_end":4271,"fully_qualified_name":"CreatePBRRenderLayersSetup.bl_idname","ident_utf16":{"start":{"line_number":103,"utf16_col":4},"end":{"line_number":103,"utf16_col":13}},"extent_utf16":{"start":{"line_number":103,"utf16_col":4},"end":{"line_number":103,"utf16_col":39}}},{"name":"bl_label","kind":"constant","ident_start":4277,"ident_end":4285,"extent_start":4277,"extent_end":4313,"fully_qualified_name":"CreatePBRRenderLayersSetup.bl_label","ident_utf16":{"start":{"line_number":104,"utf16_col":4},"end":{"line_number":104,"utf16_col":12}},"extent_utf16":{"start":{"line_number":104,"utf16_col":4},"end":{"line_number":104,"utf16_col":40}}},{"name":"bl_options","kind":"constant","ident_start":4319,"ident_end":4329,"extent_start":4319,"extent_end":4352,"fully_qualified_name":"CreatePBRRenderLayersSetup.bl_options","ident_utf16":{"start":{"line_number":105,"utf16_col":4},"end":{"line_number":105,"utf16_col":14}},"extent_utf16":{"start":{"line_number":105,"utf16_col":4},"end":{"line_number":105,"utf16_col":37}}},{"name":"execute","kind":"function","ident_start":4364,"ident_end":4371,"extent_start":4360,"extent_end":9627,"fully_qualified_name":"CreatePBRRenderLayersSetup.execute","ident_utf16":{"start":{"line_number":107,"utf16_col":8},"end":{"line_number":107,"utf16_col":15}},"extent_utf16":{"start":{"line_number":107,"utf16_col":4},"end":{"line_number":237,"utf16_col":27}}},{"name":"PBR_PT_SetupPanel","kind":"class","ident_start":9637,"ident_end":9654,"extent_start":9631,"extent_end":9942,"fully_qualified_name":"PBR_PT_SetupPanel","ident_utf16":{"start":{"line_number":239,"utf16_col":6},"end":{"line_number":239,"utf16_col":23}},"extent_utf16":{"start":{"line_number":239,"utf16_col":0},"end":{"line_number":248,"utf16_col":53}}},{"name":"bl_label","kind":"constant","ident_start":9668,"ident_end":9676,"extent_start":9668,"extent_end":9690,"fully_qualified_name":"PBR_PT_SetupPanel.bl_label","ident_utf16":{"start":{"line_number":240,"utf16_col":4},"end":{"line_number":240,"utf16_col":12}},"extent_utf16":{"start":{"line_number":240,"utf16_col":4},"end":{"line_number":240,"utf16_col":26}}},{"name":"bl_idname","kind":"constant","ident_start":9696,"ident_end":9705,"extent_start":9696,"extent_end":9729,"fully_qualified_name":"PBR_PT_SetupPanel.bl_idname","ident_utf16":{"start":{"line_number":241,"utf16_col":4},"end":{"line_number":241,"utf16_col":13}},"extent_utf16":{"start":{"line_number":241,"utf16_col":4},"end":{"line_number":241,"utf16_col":37}}},{"name":"bl_space_type","kind":"constant","ident_start":9735,"ident_end":9748,"extent_start":9735,"extent_end":9763,"fully_qualified_name":"PBR_PT_SetupPanel.bl_space_type","ident_utf16":{"start":{"line_number":242,"utf16_col":4},"end":{"line_number":242,"utf16_col":17}},"extent_utf16":{"start":{"line_number":242,"utf16_col":4},"end":{"line_number":242,"utf16_col":32}}},{"name":"bl_region_type","kind":"constant","ident_start":9769,"ident_end":9783,"extent_start":9769,"extent_end":9794,"fully_qualified_name":"PBR_PT_SetupPanel.bl_region_type","ident_utf16":{"start":{"line_number":243,"utf16_col":4},"end":{"line_number":243,"utf16_col":18}},"extent_utf16":{"start":{"line_number":243,"utf16_col":4},"end":{"line_number":243,"utf16_col":29}}},{"name":"bl_context","kind":"constant","ident_start":9800,"ident_end":9810,"extent_start":9800,"extent_end":9821,"fully_qualified_name":"PBR_PT_SetupPanel.bl_context","ident_utf16":{"start":{"line_number":244,"utf16_col":4},"end":{"line_number":244,"utf16_col":14}},"extent_utf16":{"start":{"line_number":244,"utf16_col":4},"end":{"line_number":244,"utf16_col":25}}},{"name":"draw","kind":"function","ident_start":9837,"ident_end":9841,"extent_start":9833,"extent_end":9942,"fully_qualified_name":"PBR_PT_SetupPanel.draw","ident_utf16":{"start":{"line_number":246,"utf16_col":8},"end":{"line_number":246,"utf16_col":12}},"extent_utf16":{"start":{"line_number":246,"utf16_col":4},"end":{"line_number":248,"utf16_col":53}}},{"name":"menu_func","kind":"function","ident_start":9950,"ident_end":9959,"extent_start":9946,"extent_end":10039,"fully_qualified_name":"menu_func","ident_utf16":{"start":{"line_number":250,"utf16_col":4},"end":{"line_number":250,"utf16_col":13}},"extent_utf16":{"start":{"line_number":250,"utf16_col":0},"end":{"line_number":251,"utf16_col":62}}},{"name":"register","kind":"function","ident_start":10047,"ident_end":10055,"extent_start":10043,"extent_end":10230,"fully_qualified_name":"register","ident_utf16":{"start":{"line_number":253,"utf16_col":4},"end":{"line_number":253,"utf16_col":12}},"extent_utf16":{"start":{"line_number":253,"utf16_col":0},"end":{"line_number":257,"utf16_col":43}}},{"name":"unregister","kind":"function","ident_start":10238,"ident_end":10248,"extent_start":10234,"extent_end":10429,"fully_qualified_name":"unregister","ident_utf16":{"start":{"line_number":259,"utf16_col":4},"end":{"line_number":259,"utf16_col":14}},"extent_utf16":{"start":{"line_number":259,"utf16_col":0},"end":{"line_number":263,"utf16_col":43}}}]}},"copilotInfo":null,"copilotAccessAllowed":true,"modelsAccessAllowed":false,"modelsRepoIntegrationEnabled":false,"isMarketplaceEnabled":true,"csrf_tokens":{"/dimitripaiva/BlenderRenderPasses/branches":{"post":"W0oTfdRCyENOqL00eEeQTquhHEqJf8wTisGJbljL-JIX-1SYKqr2JhzYz9Fj3zHKFmFODNmvO5A-73aMTrKeqA"},"/repos/preferences":{"post":"5Nb4xBItvkTdZcyGyx-jqMwkS_5VNzXwhJJwpTZPJkepJdEbOsUhYYSzrn6FBADcCnViUl0zKJTugVi5o1AdRA"}}},"title":"BlenderRenderPasses/render_layers_setup.py at main · dimitripaiva/BlenderRenderPasses","appPayload":{"helpUrl":"https://docs.github.com","findFileWorkerPath":"/assets-cdn/worker/find-file-worker-9bd411a8e273.js","findInFileWorkerPath":"/assets-cdn/worker/find-in-file-worker-4747241b1152.js","githubDevUrl":"https://github.dev/","enabled_features":{"code_nav_ui_events":false,"react_blob_overlay":true,"accessible_code_button":true}}}</script>
  <div data-target="react-app.reactRoot"><style data-styled="true" data-styled-version="5.3.11">.dprDCc[data-size="medium"][data-no-visuals]{border-top-left-radius:0;border-bottom-left-radius:0;}/*!sc*/
.ivCQLZ[data-size="medium"][data-no-visuals]{display:none;}/*!sc*/
.fTvnfu{-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;}/*!sc*/
.MOaSq[data-size="small"][data-no-visuals]{border-top-left-radius:0;border-bottom-left-radius:0;}/*!sc*/
.iOGEtD[data-size="small"][data-no-visuals]:hover:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.iOGEtD[data-size="small"][data-no-visuals]:focus:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.iOGEtD[data-size="small"][data-no-visuals]:active:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.ezdBfS[data-size="medium"][data-no-visuals]{-webkit-order:3;-ms-flex-order:3;order:3;color:var(--fgColor-default,var(--color-fg-default,#e6edf3));margin-right:-8px;}/*!sc*/
data-styled.g1[id="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0"]{content:"dprDCc,ivCQLZ,fTvnfu,MOaSq,iOGEtD,ezdBfS,"}/*!sc*/
.gISSDQ{width:100%;}/*!sc*/
@media screen and (min-width:544px){.gISSDQ{width:100%;}}/*!sc*/
@media screen and (min-width:768px){.gISSDQ{width:auto;}}/*!sc*/
.birIjn{max-height:100%;height:100%;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;}/*!sc*/
@media screen and (max-width:768px){.birIjn{display:none;}}/*!sc*/
@media screen and (min-width:768px){.birIjn{max-height:100vh;height:100vh;}}/*!sc*/
.jfIeyl{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;margin-bottom:16px;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}/*!sc*/
@media screen and (max-width:768px){.jLLPHh{display:none;}}/*!sc*/
.fFMzrG{position:absolute;inset:0 -2px;cursor:col-resize;background-color:transparent;-webkit-transition-delay:0.1s;transition-delay:0.1s;}/*!sc*/
.fFMzrG:hover{background-color:var(--bgColor-neutral-muted,var(--color-neutral-muted,rgba(110,118,129,0.4)));}/*!sc*/
.leYMvG{margin-left:auto;margin-right:auto;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;padding-bottom:40px;max-width:100%;margin-top:0;}/*!sc*/
.KMPzq{display:inherit;}/*!sc*/
.cEytCf{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;font-size:16px;min-width:0;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;max-width:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}/*!sc*/
.fzFXnm{max-width:100%;}/*!sc*/
.iMnkmv{max-width:100%;list-style:none;display:inline-block;}/*!sc*/
.ghzDag{display:inline-block;max-width:100%;}/*!sc*/
.dJxjrT{margin-left:16px;margin-right:16px;}/*!sc*/
.ldRxiI{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;}/*!sc*/
.efRoCL{width:100%;height:-webkit-fit-content;height:-moz-fit-content;height:fit-content;min-width:0;margin-right:16px;}/*!sc*/
.gNAmSV{height:40px;padding-left:4px;padding-bottom:16px;}/*!sc*/
.jdLMhu{top:0px;z-index:4;background:var(--bgColor-default,var(--color-canvas-default));position:-webkit-sticky;position:sticky;}/*!sc*/
.hqwSEx{display:none;min-width:0;padding-top:8px;padding-bottom:8px;}/*!sc*/
.fHind{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;font-size:14px;min-width:0;-webkit-flex-shrink:1;-ms-flex-negative:1;flex-shrink:1;-webkit-flex-wrap:wrap;-ms-flex-wrap:wrap;flex-wrap:wrap;max-width:100%;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;}/*!sc*/
.gFKFyc{border-radius:6px 6px 0px 0px;}/*!sc*/
.hycJXc{border:1px solid;border-top:none;border-color:var(--borderColor-default,var(--color-border-default,#30363d));border-radius:0px 0px 6px 6px;min-width:273px;}/*!sc*/
.dceWRL{background-color:var(--bgColor-default,var(--color-canvas-default));border:0px;border-width:0;border-radius:0px 0px 6px 6px;padding:0;min-width:0;margin-top:46px;}/*!sc*/
.dGXHv{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex:1;-ms-flex:1;flex:1;padding-top:8px;padding-bottom:8px;-webkit-flex-direction:column;-ms-flex-direction:column;flex-direction:column;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;min-width:0;position:relative;}/*!sc*/
.bpDFns{position:relative;}/*!sc*/
.iJOeCH{-webkit-flex:1;-ms-flex:1;flex:1;position:relative;min-width:0;}/*!sc*/
.glDApP{tab-size:4;isolation:isolate;position:relative;overflow:auto;max-width:unset;}/*!sc*/
.cJGaMs{margin:1px 8px;position:absolute;z-index:1;}/*!sc*/
.iGLarr{position:absolute;}/*!sc*/
.mgQhK{padding-bottom:33px;}/*!sc*/
.cxUsTr{padding-top:8px;padding-bottom:8px;padding-left:16px;padding-right:16px;}/*!sc*/
.jXkPPw{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;}/*!sc*/
.hECgeo{font-size:14px;-webkit-order:1;-ms-flex-order:1;order:1;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;-webkit-box-pack:center;-webkit-justify-content:center;-ms-flex-pack:center;justify-content:center;-webkit-align-items:center;-webkit-box-align:center;-ms-flex-align:center;align-items:center;font-weight:600;}/*!sc*/
.hoyhab{font-size:12px;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));padding-top:8px;}/*!sc*/
.cNGRpP{margin-top:8px;border-radius:6px;}/*!sc*/
.gqhZpQ{margin-right:6px;}/*!sc*/
.ccgkJf{margin-left:-16px;margin-bottom:-8px;}/*!sc*/
.kACRto{margin-bottom:-8px;overflow-y:auto;max-height:calc(100vh - 237px);padding-left:16px;padding-bottom:8px;padding-top:4px;}/*!sc*/
.cSURfY{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;}/*!sc*/
.bTXewe{display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-flex-direction:row;-ms-flex-direction:row;flex-direction:row;position:relative;margin-right:8px;}/*!sc*/
.dotKsF{background-color:var(--color-prettylights-syntax-variable,#ffa657);opacity:0.1;position:absolute;border-radius:5px;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;height:100%;}/*!sc*/
.iGIwaf{color:var(--color-prettylights-syntax-variable,#ffa657);border-radius:5px;font-weight:600;font-size:smaller;padding-left:4px;padding-right:4px;padding-top:1px;padding-bottom:1px;}/*!sc*/
.jDUiPd{background-color:var(--color-prettylights-syntax-constant,#79c0ff);opacity:0.1;position:absolute;border-radius:5px;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;height:100%;}/*!sc*/
.fPctCv{color:var(--color-prettylights-syntax-constant,#79c0ff);border-radius:5px;font-weight:600;font-size:smaller;padding-left:4px;padding-right:4px;padding-top:1px;padding-bottom:1px;}/*!sc*/
.gxAxAi{background-color:var(--color-prettylights-syntax-entity,#d2a8ff);opacity:0.1;position:absolute;border-radius:5px;-webkit-align-items:stretch;-webkit-box-align:stretch;-ms-flex-align:stretch;align-items:stretch;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;width:100%;height:100%;}/*!sc*/
.gWkFIQ{color:var(--color-prettylights-syntax-entity,#d2a8ff);border-radius:5px;font-weight:600;font-size:smaller;padding-left:4px;padding-right:4px;padding-top:1px;padding-bottom:1px;}/*!sc*/
.cCoXib{position:fixed;top:0;right:0;height:100%;width:15px;-webkit-transition:-webkit-transform 0.3s;-webkit-transition:transform 0.3s;transition:transform 0.3s;z-index:1;}/*!sc*/
.cCoXib:hover{-webkit-transform:scaleX(1.5);-ms-transform:scaleX(1.5);transform:scaleX(1.5);}/*!sc*/
data-styled.g3[id="Box-sc-g0xbh4-0"]{content:"gISSDQ,birIjn,jfIeyl,jLLPHh,fFMzrG,leYMvG,KMPzq,cEytCf,fzFXnm,iMnkmv,ghzDag,dJxjrT,ldRxiI,efRoCL,gNAmSV,jdLMhu,hqwSEx,fHind,gFKFyc,hycJXc,dceWRL,dGXHv,bpDFns,iJOeCH,glDApP,cJGaMs,iGLarr,mgQhK,cxUsTr,jXkPPw,hECgeo,hoyhab,cNGRpP,gqhZpQ,ccgkJf,kACRto,cSURfY,bTXewe,dotKsF,iGIwaf,jDUiPd,fPctCv,gxAxAi,gWkFIQ,cCoXib,"}/*!sc*/
.iqSttj{position:relative;display:inline-block;}/*!sc*/
.iqSttj::after{position:absolute;z-index:1000000;display:none;padding:0.5em 0.75em;font:normal normal 11px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans",Helvetica,Arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji";-webkit-font-smoothing:subpixel-antialiased;color:var(--tooltip-fgColor,var(--fgColor-onEmphasis,var(--color-fg-on-emphasis,#ffffff)));text-align:center;-webkit-text-decoration:none;text-decoration:none;text-shadow:none;text-transform:none;-webkit-letter-spacing:normal;-moz-letter-spacing:normal;-ms-letter-spacing:normal;letter-spacing:normal;word-wrap:break-word;white-space:pre;pointer-events:none;content:attr(aria-label);background:var(--tooltip-bgColor,var(--bgColor-emphasis,var(--color-neutral-emphasis-plus,#6e7681)));border-radius:6px;opacity:0;}/*!sc*/
@-webkit-keyframes tooltip-appear{from{opacity:0;}to{opacity:1;}}/*!sc*/
@keyframes tooltip-appear{from{opacity:0;}to{opacity:1;}}/*!sc*/
.iqSttj:hover::after,.iqSttj:active::after,.iqSttj:focus::after,.iqSttj:focus-within::after{display:inline-block;-webkit-text-decoration:none;text-decoration:none;-webkit-animation-name:tooltip-appear;animation-name:tooltip-appear;-webkit-animation-duration:0.1s;animation-duration:0.1s;-webkit-animation-fill-mode:forwards;animation-fill-mode:forwards;-webkit-animation-timing-function:ease-in;animation-timing-function:ease-in;-webkit-animation-delay:0s;animation-delay:0s;}/*!sc*/
.iqSttj.tooltipped-no-delay:hover::after,.iqSttj.tooltipped-no-delay:active::after,.iqSttj.tooltipped-no-delay:focus::after,.iqSttj.tooltipped-no-delay:focus-within::after{-webkit-animation-delay:0s;animation-delay:0s;}/*!sc*/
.iqSttj.tooltipped-multiline:hover::after,.iqSttj.tooltipped-multiline:active::after,.iqSttj.tooltipped-multiline:focus::after,.iqSttj.tooltipped-multiline:focus-within::after{display:table-cell;}/*!sc*/
.iqSttj.tooltipped-s::after,.iqSttj.tooltipped-se::after,.iqSttj.tooltipped-sw::after{top:100%;right:50%;margin-top:6px;}/*!sc*/
.iqSttj.tooltipped-se::after{right:auto;left:50%;margin-left:-16px;}/*!sc*/
.iqSttj.tooltipped-sw::after{margin-right:-16px;}/*!sc*/
.iqSttj.tooltipped-n::after,.iqSttj.tooltipped-ne::after,.iqSttj.tooltipped-nw::after{right:50%;bottom:100%;margin-bottom:6px;}/*!sc*/
.iqSttj.tooltipped-ne::after{right:auto;left:50%;margin-left:-16px;}/*!sc*/
.iqSttj.tooltipped-nw::after{margin-right:-16px;}/*!sc*/
.iqSttj.tooltipped-s::after,.iqSttj.tooltipped-n::after{-webkit-transform:translateX(50%);-ms-transform:translateX(50%);transform:translateX(50%);}/*!sc*/
.iqSttj.tooltipped-w::after{right:100%;bottom:50%;margin-right:6px;-webkit-transform:translateY(50%);-ms-transform:translateY(50%);transform:translateY(50%);}/*!sc*/
.iqSttj.tooltipped-e::after{bottom:50%;left:100%;margin-left:6px;-webkit-transform:translateY(50%);-ms-transform:translateY(50%);transform:translateY(50%);}/*!sc*/
.iqSttj.tooltipped-multiline::after{width:-webkit-max-content;width:-moz-max-content;width:max-content;max-width:250px;word-wrap:break-word;white-space:pre-line;border-collapse:separate;}/*!sc*/
.iqSttj.tooltipped-multiline.tooltipped-s::after,.iqSttj.tooltipped-multiline.tooltipped-n::after{right:auto;left:50%;-webkit-transform:translateX(-50%);-ms-transform:translateX(-50%);transform:translateX(-50%);}/*!sc*/
.iqSttj.tooltipped-multiline.tooltipped-w::after,.iqSttj.tooltipped-multiline.tooltipped-e::after{right:100%;}/*!sc*/
.iqSttj.tooltipped-align-right-2::after{right:0;margin-right:0;}/*!sc*/
.iqSttj.tooltipped-align-left-2::after{left:0;margin-left:0;}/*!sc*/
data-styled.g5[id="Tooltip__TooltipBase-sc-17tf59c-0"]{content:"iqSttj,"}/*!sc*/
.dWfbpP{font-size:16px;margin-left:8px;}/*!sc*/
.hJQQvf{font-weight:600;display:inline-block;max-width:100%;font-size:16px;}/*!sc*/
.cGzJbh{font-weight:600;display:inline-block;max-width:100%;font-size:14px;}/*!sc*/
data-styled.g17[id="Heading-sc-1vc165i-0"]{content:"dWfbpP,hJQQvf,cGzJbh,"}/*!sc*/
.htWjsS{font-weight:600;}/*!sc*/
data-styled.g19[id="Link__StyledLink-sc-1syctfj-0"]{content:"htWjsS,"}/*!sc*/
.iwmTUC linkButtonSx:hover:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.iwmTUC linkButtonSx:focus:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
.iwmTUC linkButtonSx:active:not([disabled]){-webkit-text-decoration:none;text-decoration:none;}/*!sc*/
data-styled.g20[id="LinkButton-sc-1v6zkmg-0"]{content:"iwmTUC,"}/*!sc*/
.xsVwu{padding-left:4px;padding-right:4px;font-weight:400;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));font-size:16px;}/*!sc*/
.iHrMHQ{padding-left:4px;padding-right:4px;font-weight:400;color:var(--fgColor-muted,var(--color-fg-muted,#848d97));font-size:14px;}/*!sc*/
data-styled.g23[id="Text__StyledText-sc-1klmep6-0"]{content:"xsVwu,iHrMHQ,"}/*!sc*/
.bkmqFA{max-width:180px;display:block;}/*!sc*/
data-styled.g25[id="Truncate-sc-x3i4it-0"]{content:"bkmqFA,"}/*!sc*/
</style><meta data-hydrostats="publish"/> <!-- --> <!-- --> <button hidden="" data-testid="header-permalink-button" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><div><div style="--spacing:var(--spacing-none)" class="prc-PageLayout-PageLayoutRoot-1zlEO"><div class="prc-PageLayout-PageLayoutWrapper-s2ao4" data-width="full"><div class="prc-PageLayout-PageLayoutContent-jzDMn"><div tabindex="0" class="Box-sc-g0xbh4-0 gISSDQ"><div class="prc-PageLayout-PaneWrapper-nGO0U ReposFileTreePane-module__Pane--D26Sw ReposFileTreePane-module__HidePaneWithTreeOverlay--CJn2n" style="--offset-header:0px;--spacing-row:var(--spacing-none);--spacing-column:var(--spacing-none)" data-is-hidden="false" data-position="start" data-sticky="true"><div class="prc-PageLayout-HorizontalDivider-CYLp5 prc-PageLayout-PaneHorizontalDivider-4exOb" data-variant="none" data-position="start" style="--spacing-divider:var(--spacing-none);--spacing:var(--spacing-none)"></div><div class="prc-PageLayout-Pane-Vl5LI" data-resizable="true" style="--spacing:var(--spacing-none);--pane-min-width:256px;--pane-max-width:calc(100vw - var(--pane-max-width-diff));--pane-width-size:var(--pane-width-large);--pane-width:320px"><div class="react-tree-pane-contents-3-panel"><div id="repos-file-tree" class="Box-sc-g0xbh4-0 birIjn"><div class="ReposFileTreePane-module__Box_1--ZT_4S"><div class="Box-sc-g0xbh4-0 jfIeyl"><h2 class="use-tree-pane-module__Heading--iI_ad prc-Heading-Heading-6CmGO"><button type="button" aria-label="Expand file tree" data-testid="expand-file-tree-button-mobile" class="prc-Button-ButtonBase-c50BI ExpandFileTreeButton-module__Button_1--g8F6Q" data-loading="false" data-size="medium" data-variant="invisible" aria-describedby=":Rl6mplab:-loading-announcement"><span data-component="buttonContent" data-align="center" class="prc-Button-ButtonContent-HKbr-"><span data-component="leadingVisual" class="prc-Button-Visual-2epfX prc-Button-VisualWrap-Db-eB"><svg aria-hidden="true" focusable="false" class="octicon octicon-arrow-left" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M7.78 12.53a.75.75 0 0 1-1.06 0L2.47 8.28a.75.75 0 0 1 0-1.06l4.25-4.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L4.81 7h7.44a.75.75 0 0 1 0 1.5H4.81l2.97 2.97a.75.75 0 0 1 0 1.06Z"></path></svg></span><span data-component="text" class="prc-Button-Label-pTQ3x">Files</span></span></button><button data-component="IconButton" type="button" data-testid="collapse-file-tree-button" aria-expanded="true" aria-controls="repos-file-tree" class="prc-Button-ButtonBase-c50BI position-relative ExpandFileTreeButton-module__expandButton--oKI1R ExpandFileTreeButton-module__filesButtonBreakpoint--03FKA fgColor-muted prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="medium" data-variant="invisible" aria-describedby=":R756mplab:-loading-announcement" aria-labelledby=":R156mplab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-sidebar-expand" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="m4.177 7.823 2.396-2.396A.25.25 0 0 1 7 5.604v4.792a.25.25 0 0 1-.427.177L4.177 8.177a.25.25 0 0 1 0-.354Z"></path><path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25H9.5v-13Zm12.5 13a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25H11v13Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="se" aria-hidden="true" id=":R156mplab:">Collapse file tree</span><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button></h2><h2 class="Heading-sc-1vc165i-0 dWfbpP">Files</h2></div><div class="ReposFileTreePane-module__Box_2--RgzGf"><div class="ReposFileTreePane-module__Box_3--XDLn8"><button style="min-width:0" type="button" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-label="main branch" data-testid="anchor-button" class="prc-Button-ButtonBase-c50BI react-repos-tree-pane-ref-selector width-full ref-selector-class RefSelectorAnchoredOverlay-module__RefSelectorOverlayBtn--D34zl" data-loading="false" data-size="medium" data-variant="default" aria-describedby="ref-picker-repos-header-ref-selector-loading-announcement" id="ref-picker-repos-header-ref-selector"><span data-component="buttonContent" data-align="center" class="prc-Button-ButtonContent-HKbr-"><span data-component="text" class="prc-Button-Label-pTQ3x"><div class="RefSelectorAnchoredOverlay-module__RefSelectorOverlayContainer--mCbv8"><div class="RefSelectorAnchoredOverlay-module__RefSelectorOverlayHeader--D4cnZ"><svg aria-hidden="true" focusable="false" class="octicon octicon-git-branch" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M9.5 3.25a2.25 2.25 0 1 1 3 2.122V6A2.5 2.5 0 0 1 10 8.5H6a1 1 0 0 0-1 1v1.128a2.251 2.251 0 1 1-1.5 0V5.372a2.25 2.25 0 1 1 1.5 0v1.836A2.493 2.493 0 0 1 6 7h4a1 1 0 0 0 1-1v-.628A2.25 2.25 0 0 1 9.5 3.25Zm-6 0a.75.75 0 1 0 1.5 0 .75.75 0 0 0-1.5 0Zm8.25-.75a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5ZM4.25 12a.75.75 0 1 0 0 1.5.75.75 0 0 0 0-1.5Z"></path></svg></div><div class="ref-selector-button-text-container RefSelectorAnchoredOverlay-module__RefSelectorBtnTextContainer--yO402"><span class="RefSelectorAnchoredOverlay-module__RefSelectorText--bxVhQ"> <!-- -->main</span></div></div></span><span data-component="trailingVisual" class="prc-Button-Visual-2epfX prc-Button-VisualWrap-Db-eB"><svg aria-hidden="true" focusable="false" class="octicon octicon-triangle-down" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path></svg></span></span></button><button hidden="" data-testid="ref-selector-hotkey-button" data-hotkey-scope="read-only-cursor-text-area"></button></div><div class="ReposFileTreePane-module__Box_4--TLAAU"><a data-component="IconButton" type="button" class="prc-Button-ButtonBase-c50BI ReposFileTreePane-module__IconButton--fpuBk prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="medium" data-variant="default" aria-describedby=":R6q6mplab:-loading-announcement" aria-labelledby=":Rq6mplab:" href="/dimitripaiva/BlenderRenderPasses/new/main" data-discover="true"><svg aria-hidden="true" focusable="false" class="octicon octicon-plus" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M7.75 2a.75.75 0 0 1 .75.75V7h4.25a.75.75 0 0 1 0 1.5H8.5v4.25a.75.75 0 0 1-1.5 0V8.5H2.75a.75.75 0 0 1 0-1.5H7V2.75A.75.75 0 0 1 7.75 2Z"></path></svg></a><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="n" aria-hidden="true" id=":Rq6mplab:">Add file</span><button data-component="IconButton" type="button" class="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0 dprDCc prc-Button-ButtonBase-c50BI SearchButton-module__IconButton--kxA3Q prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="medium" data-variant="default" aria-describedby=":Rra6mplab:-loading-announcement" aria-labelledby=":R3a6mplab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-search" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="nw" aria-hidden="true" id=":R3a6mplab:">Search this repository</span><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button></div></div></div><div class="Box-sc-g0xbh4-0 jLLPHh ReposFileTreePane-module__FileResultsList--YEf_n"><span class="d-flex FileResultsList-module__FilesSearchBox--fSAh3 TextInput-wrapper prc-components-TextInputWrapper-i1ofR prc-components-TextInputBaseWrapper-ueK9q" data-leading-visual="true" data-trailing-visual="true" aria-busy="false"><span class="TextInput-icon" id=":R5amplab:" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="octicon octicon-search" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M10.68 11.74a6 6 0 0 1-7.922-8.982 6 6 0 0 1 8.982 7.922l3.04 3.04a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215ZM11.5 7a4.499 4.499 0 1 0-8.997 0A4.499 4.499 0 0 0 11.5 7Z"></path></svg></span><input type="text" aria-label="Go to file" role="combobox" aria-controls="file-results-list" aria-expanded="false" aria-haspopup="dialog" autoCorrect="off" spellcheck="false" placeholder="Go to file" aria-describedby=":R5amplab: :R5amplabH1:" data-component="input" class="prc-components-Input-Ic-y8" value=""/><span class="TextInput-icon" id=":R5amplabH1:" aria-hidden="true"><kbd>t</kbd></span></span></div><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><div class="Box-sc-g0xbh4-0 jLLPHh ReposFileTreePane-module__Box_5--cckih"><div class="react-tree-show-tree-items"><div class="ReposFileTreeView-module__Box--bDodO" data-testid="repos-file-tree-container"><nav aria-label="File Tree Navigation"><span class="prc-src-InternalVisuallyHidden-nlR9R" role="status" aria-live="polite" aria-atomic="true"></span><ul role="tree" aria-label="Files" data-truncate-text="true" class="prc-TreeView-TreeViewRootUlStyles-eZtxW"><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="PBRLayersSetup.md-item" role="treeitem" aria-labelledby=":R3pimplab:" aria-describedby=":R3pimplabH1:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1;content-visibility:auto;contain-intrinsic-size:auto 2rem"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R3pimplab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><div class="PRIVATE_VisuallyHidden prc-TreeView-TreeViewVisuallyHidden-4-mPv" aria-hidden="true" id=":R3pimplabH1:"></div><div class="PRIVATE_TreeView-item-visual prc-TreeView-TreeViewItemVisual-dRlGq" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="octicon octicon-file" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0 1 13.25 16h-9.5A1.75 1.75 0 0 1 2 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 9 4.25V1.5Zm6.75.062V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"></path></svg></div><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><span>PBRLayersSetup.md</span></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="README.md-item" role="treeitem" aria-labelledby=":R5pimplab:" aria-describedby=":R5pimplabH1:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1;content-visibility:auto;contain-intrinsic-size:auto 2rem"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R5pimplab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><div class="PRIVATE_VisuallyHidden prc-TreeView-TreeViewVisuallyHidden-4-mPv" aria-hidden="true" id=":R5pimplabH1:"></div><div class="PRIVATE_TreeView-item-visual prc-TreeView-TreeViewItemVisual-dRlGq" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="octicon octicon-file" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0 1 13.25 16h-9.5A1.75 1.75 0 0 1 2 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 9 4.25V1.5Zm6.75.062V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"></path></svg></div><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><span>README.md</span></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="render_layers_setup.py-item" role="treeitem" aria-labelledby=":R7pimplab:" aria-describedby=":R7pimplabH1:" aria-level="1" aria-current="true" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R7pimplab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><div class="PRIVATE_VisuallyHidden prc-TreeView-TreeViewVisuallyHidden-4-mPv" aria-hidden="true" id=":R7pimplabH1:"></div><div class="PRIVATE_TreeView-item-visual prc-TreeView-TreeViewItemVisual-dRlGq" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="octicon octicon-file" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M2 1.75C2 .784 2.784 0 3.75 0h6.586c.464 0 .909.184 1.237.513l2.914 2.914c.329.328.513.773.513 1.237v9.586A1.75 1.75 0 0 1 13.25 16h-9.5A1.75 1.75 0 0 1 2 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h9.5a.25.25 0 0 0 .25-.25V6h-2.75A1.75 1.75 0 0 1 9 4.25V1.5Zm6.75.062V4.25c0 .138.112.25.25.25h2.688l-.011-.013-2.914-2.914-.013-.011Z"></path></svg></div><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><span>render_layers_setup.py</span></span></div></div></li></ul></nav></div></div></div></div></div></div><div class="prc-PageLayout-VerticalDivider-4A4Qm prc-PageLayout-PaneVerticalDivider-1c9vy" data-variant="none" data-position="start" style="--spacing:var(--spacing-none)"><div role="slider" aria-label="Draggable pane splitter" aria-valuemin="0" aria-valuemax="0" aria-valuenow="0" aria-valuetext="Pane width 0 pixels" tabindex="0" class="Box-sc-g0xbh4-0 fFMzrG"></div></div></div></div><div class="prc-PageLayout-ContentWrapper-b-QRo CodeView-module__SplitPageLayout_Content--qxR1C" data-is-hidden="false"><div class="prc-PageLayout-Content--F7-I" data-width="full" style="--spacing:var(--spacing-none)"><div data-selector="repos-split-pane-content" tabindex="0" class="Box-sc-g0xbh4-0 leYMvG"><div class="Box-sc-g0xbh4-0 KMPzq"><div class="container CodeViewHeader-module__Box--PofRM"><div class="px-3 pt-3 pb-0" id="StickyHeader"><div class="CodeViewHeader-module__Box_1--KpLzV"><div class="CodeViewHeader-module__Box_2--xzDOt"><div class="CodeViewHeader-module__Box_6--iStzT"><div class="Box-sc-g0xbh4-0 cEytCf"><nav data-testid="breadcrumbs" aria-labelledby="repos-header-breadcrumb--wide-heading" id="repos-header-breadcrumb--wide" class="Box-sc-g0xbh4-0 fzFXnm"><h2 class="sr-only ScreenReaderHeading-module__userSelectNone--vlUbc prc-Heading-Heading-6CmGO" data-testid="screen-reader-heading" id="repos-header-breadcrumb--wide-heading">Breadcrumbs</h2><ol class="Box-sc-g0xbh4-0 iMnkmv"><li class="Box-sc-g0xbh4-0 ghzDag"><a class="Link__StyledLink-sc-1syctfj-0 htWjsS prc-Link-Link-85e08" data-testid="breadcrumbs-repo-link" href="/dimitripaiva/BlenderRenderPasses/tree/main" data-discover="true">BlenderRenderPasses</a></li></ol></nav><div data-testid="breadcrumbs-filename" class="Box-sc-g0xbh4-0 ghzDag"><span class="Text__StyledText-sc-1klmep6-0 xsVwu prc-Text-Text-0ima0" aria-hidden="true">/</span><h1 tabindex="-1" id="file-name-id-wide" class="Heading-sc-1vc165i-0 hJQQvf">render_layers_setup.py</h1></div><button data-component="IconButton" type="button" class="prc-Button-ButtonBase-c50BI ml-2 prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="small" data-variant="invisible" aria-describedby=":Rvb9lab:-loading-announcement" aria-labelledby=":R3b9lab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-copy" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path></svg></button><span class="Box-sc-g0xbh4-0 CopyToClipboardButton-module__tooltip--HDUYz prc-TooltipV2-Tooltip-cYMVY" data-direction="nw" aria-label="Copy path" aria-hidden="true" id=":R3b9lab:">Copy path</span></div></div><div class="react-code-view-header-element--wide"><div class="CodeViewHeader-module__Box_7--FZfkg"><div class="d-flex gap-2"> <button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><button type="button" class="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0 ivCQLZ prc-Button-ButtonBase-c50BI NavigationMenu-module__Button--SJihq" data-loading="false" data-no-visuals="true" data-size="medium" data-variant="default" aria-describedby=":R1ahj9lab:-loading-announcement"><span data-component="buttonContent" class="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0 fTvnfu prc-Button-ButtonContent-HKbr-"><span data-component="text" class="prc-Button-Label-pTQ3x">Blame</span></span></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button data-component="IconButton" type="button" data-testid="more-file-actions-button-nav-menu-wide" aria-haspopup="true" aria-expanded="false" tabindex="0" class="prc-Button-ButtonBase-c50BI js-blob-dropdown-click NavigationMenu-module__IconButton--NqJ_L prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="medium" data-variant="default" aria-describedby=":Rihj9lab:-loading-announcement" aria-labelledby=":Rfihj9lab:" id=":Rihj9lab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-kebab-horizontal" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="nw" aria-hidden="true" id=":Rfihj9lab:">More file actions</span> </div></div></div><div class="react-code-view-header-element--narrow"><div class="CodeViewHeader-module__Box_7--FZfkg"><div class="d-flex gap-2"> <button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><button type="button" class="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0 ivCQLZ prc-Button-ButtonBase-c50BI NavigationMenu-module__Button--SJihq" data-loading="false" data-no-visuals="true" data-size="medium" data-variant="default" aria-describedby=":R1ahr9lab:-loading-announcement"><span data-component="buttonContent" class="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0 fTvnfu prc-Button-ButtonContent-HKbr-"><span data-component="text" class="prc-Button-Label-pTQ3x">Blame</span></span></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button data-component="IconButton" type="button" data-testid="more-file-actions-button-nav-menu-narrow" aria-haspopup="true" aria-expanded="false" tabindex="0" class="prc-Button-ButtonBase-c50BI js-blob-dropdown-click NavigationMenu-module__IconButton--NqJ_L prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="medium" data-variant="default" aria-describedby=":Rihr9lab:-loading-announcement" aria-labelledby=":Rfihr9lab:" id=":Rihr9lab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-kebab-horizontal" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="nw" aria-hidden="true" id=":Rfihr9lab:">More file actions</span> </div></div></div></div></div></div></div></div><div class="Box-sc-g0xbh4-0 dJxjrT react-code-view-bottom-padding"> <div class="BlobTopBanners-module__Box--g_bGk"></div> <!-- --> <!-- --> </div><div class="Box-sc-g0xbh4-0 dJxjrT"> <!-- --> <!-- --> <button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button><div class="d-flex flex-column border rounded-2 mb-3 pl-1"><div class="LatestCommit-module__Box--Fimpo"><h2 class="sr-only ScreenReaderHeading-module__userSelectNone--vlUbc prc-Heading-Heading-6CmGO" data-testid="screen-reader-heading">Latest commit</h2><div style="width:120px" class="Skeleton Skeleton--text" data-testid="loading"> </div><div class="d-flex flex-shrink-0 gap-2"><div data-testid="latest-commit-details" class="d-none d-sm-flex flex-items-center"></div><div class="d-flex gap-2"><h2 class="sr-only ScreenReaderHeading-module__userSelectNone--vlUbc prc-Heading-Heading-6CmGO" data-testid="screen-reader-heading">History</h2><a href="/dimitripaiva/BlenderRenderPasses/commits/main/render_layers_setup.py" class="prc-Button-ButtonBase-c50BI d-none d-lg-flex LinkButton-module__code-view-link-button--thtqc flex-items-center fgColor-default" data-loading="false" data-size="small" data-variant="invisible" aria-describedby=":R1bdal9lab:-loading-announcement"><span data-component="buttonContent" data-align="center" class="prc-Button-ButtonContent-HKbr-"><span data-component="leadingVisual" class="prc-Button-Visual-2epfX prc-Button-VisualWrap-Db-eB"><svg aria-hidden="true" focusable="false" class="octicon octicon-history" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="m.427 1.927 1.215 1.215a8.002 8.002 0 1 1-1.6 5.685.75.75 0 1 1 1.493-.154 6.5 6.5 0 1 0 1.18-4.458l1.358 1.358A.25.25 0 0 1 3.896 6H.25A.25.25 0 0 1 0 5.75V2.104a.25.25 0 0 1 .427-.177ZM7.75 4a.75.75 0 0 1 .75.75v2.992l2.028.812a.75.75 0 0 1-.557 1.392l-2.5-1A.751.751 0 0 1 7 8.25v-3.5A.75.75 0 0 1 7.75 4Z"></path></svg></span><span data-component="text" class="prc-Button-Label-pTQ3x"><span class="fgColor-default">History</span></span></span></a><div class="d-sm-none"></div><div class="d-flex d-lg-none"><span role="tooltip" aria-label="History" id="history-icon-button-tooltip" class="Tooltip__TooltipBase-sc-17tf59c-0 iqSttj tooltipped-n"><a aria-label="View commit history for this file." href="/dimitripaiva/BlenderRenderPasses/commits/main/render_layers_setup.py" class="prc-Button-ButtonBase-c50BI LinkButton-module__code-view-link-button--thtqc flex-items-center fgColor-default" data-loading="false" data-size="small" data-variant="invisible" aria-describedby=":R6bdal9lab:-loading-announcement history-icon-button-tooltip"><span data-component="buttonContent" data-align="center" class="prc-Button-ButtonContent-HKbr-"><span data-component="leadingVisual" class="prc-Button-Visual-2epfX prc-Button-VisualWrap-Db-eB"><svg aria-hidden="true" focusable="false" class="octicon octicon-history" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="m.427 1.927 1.215 1.215a8.002 8.002 0 1 1-1.6 5.685.75.75 0 1 1 1.493-.154 6.5 6.5 0 1 0 1.18-4.458l1.358 1.358A.25.25 0 0 1 3.896 6H.25A.25.25 0 0 1 0 5.75V2.104a.25.25 0 0 1 .427-.177ZM7.75 4a.75.75 0 0 1 .75.75v2.992l2.028.812a.75.75 0 0 1-.557 1.392l-2.5-1A.751.751 0 0 1 7 8.25v-3.5A.75.75 0 0 1 7.75 4Z"></path></svg></span></span></a></span></div></div></div></div></div><div class="Box-sc-g0xbh4-0 ldRxiI"><div class="Box-sc-g0xbh4-0 efRoCL container"><div class="Box-sc-g0xbh4-0 gNAmSV react-code-size-details-banner"><div class="react-code-size-details-banner CodeSizeDetails-module__Box--QdxnQ"><div class="text-mono CodeSizeDetails-module__Box_1--_uFDs"><div data-testid="blob-size" class="CodeSizeDetails-module__Truncate_1--er0Uk prc-Truncate-Truncate-A9Wn6" data-inline="true" title="10.2 KB" style="--truncate-max-width:100%"><span>267 lines (212 loc) · 10.2 KB</span></div></div></div></div><div class="Box-sc-g0xbh4-0 jdLMhu react-blob-view-header-sticky" id="repos-sticky-header"><div class="BlobViewHeader-module__Box--pvsIA"><div class="react-blob-sticky-header"><div class="Box-sc-g0xbh4-0 hqwSEx"><div class="FileNameStickyHeader-module__Box_5--xBJ2J"><div class="Box-sc-g0xbh4-0 fHind"><nav data-testid="breadcrumbs" aria-labelledby="sticky-breadcrumb-heading" id="sticky-breadcrumb" class="Box-sc-g0xbh4-0 fzFXnm"><h2 class="sr-only ScreenReaderHeading-module__userSelectNone--vlUbc prc-Heading-Heading-6CmGO" data-testid="screen-reader-heading" id="sticky-breadcrumb-heading">Breadcrumbs</h2><ol class="Box-sc-g0xbh4-0 iMnkmv"><li class="Box-sc-g0xbh4-0 ghzDag"><a class="Link__StyledLink-sc-1syctfj-0 htWjsS prc-Link-Link-85e08" data-testid="breadcrumbs-repo-link" href="/dimitripaiva/BlenderRenderPasses/tree/main" data-discover="true">BlenderRenderPasses</a></li></ol></nav><div data-testid="breadcrumbs-filename" class="Box-sc-g0xbh4-0 ghzDag"><span class="Text__StyledText-sc-1klmep6-0 iHrMHQ prc-Text-Text-0ima0" aria-hidden="true">/</span><h1 tabindex="-1" id="sticky-file-name-id" class="Heading-sc-1vc165i-0 cGzJbh">render_layers_setup.py</h1></div></div><button type="button" class="prc-Button-ButtonBase-c50BI FileNameStickyHeader-module__Button--SaiiH FileNameStickyHeader-module__GoToTopButton--9lB4x" data-loading="false" data-size="small" data-variant="invisible" aria-describedby=":R4mfal9lab:-loading-announcement"><span data-component="buttonContent" data-align="center" class="prc-Button-ButtonContent-HKbr-"><span data-component="leadingVisual" class="prc-Button-Visual-2epfX prc-Button-VisualWrap-Db-eB"><svg aria-hidden="true" focusable="false" class="octicon octicon-arrow-up" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M3.47 7.78a.75.75 0 0 1 0-1.06l4.25-4.25a.75.75 0 0 1 1.06 0l4.25 4.25a.751.751 0 0 1-.018 1.042.751.751 0 0 1-1.042.018L9 4.81v7.44a.75.75 0 0 1-1.5 0V4.81L4.53 7.78a.75.75 0 0 1-1.06 0Z"></path></svg></span><span data-component="text" class="prc-Button-Label-pTQ3x">Top</span></span></button></div></div></div><div class="Box-sc-g0xbh4-0 gFKFyc BlobViewHeader-module__Box_1--PPihg"><h2 class="sr-only ScreenReaderHeading-module__userSelectNone--vlUbc prc-Heading-Heading-6CmGO" data-testid="screen-reader-heading">File metadata and controls</h2><div class="BlobViewHeader-module__Box_2--G_jCG"><ul aria-label="File view" class="prc-SegmentedControl-SegmentedControl-e7570 BlobTabButtons-module__SegmentedControl--JMGov" data-size="small"><li class="prc-SegmentedControl-Item-7Aq6h" data-selected=""><button aria-current="true" class="prc-SegmentedControl-Button-ojWXD" type="button" style="--separator-color:transparent"><span class="prc-SegmentedControl-Content-gnQ4n segmentedControl-content"><div class="prc-SegmentedControl-Text-c5gSh segmentedControl-text" data-text="Code">Code</div></span></button></li><li class="prc-SegmentedControl-Item-7Aq6h"><button aria-current="false" class="prc-SegmentedControl-Button-ojWXD" type="button" style="--separator-color:var(--borderColor-default, var(--color-border-default, #30363d))"><span class="prc-SegmentedControl-Content-gnQ4n segmentedControl-content"><div class="prc-SegmentedControl-Text-c5gSh segmentedControl-text" data-text="Blame">Blame</div></span></button></li></ul><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><div class="react-code-size-details-in-header CodeSizeDetails-module__Box--QdxnQ"><div class="text-mono CodeSizeDetails-module__Box_1--_uFDs"><div data-testid="blob-size" class="CodeSizeDetails-module__Truncate_1--er0Uk prc-Truncate-Truncate-A9Wn6" data-inline="true" title="10.2 KB" style="--truncate-max-width:100%"><span>267 lines (212 loc) · 10.2 KB</span></div></div></div></div><div class="BlobViewHeader-module__Box_3--Kvpex"><button data-component="IconButton" type="button" data-testid="copilot-ask-menu" class="prc-Button-ButtonBase-c50BI prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="small" data-variant="default" aria-describedby="blob-view-header-copilot-icon-loading-announcement" aria-labelledby=":Rv6fal9lab:" id="blob-view-header-copilot-icon"><svg aria-hidden="true" focusable="false" class="octicon octicon-copilot" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M7.998 15.035c-4.562 0-7.873-2.914-7.998-3.749V9.338c.085-.628.677-1.686 1.588-2.065.013-.07.024-.143.036-.218.029-.183.06-.384.126-.612-.201-.508-.254-1.084-.254-1.656 0-.87.128-1.769.693-2.484.579-.733 1.494-1.124 2.724-1.261 1.206-.134 2.262.034 2.944.765.05.053.096.108.139.165.044-.057.094-.112.143-.165.682-.731 1.738-.899 2.944-.765 1.23.137 2.145.528 2.724 1.261.566.715.693 1.614.693 2.484 0 .572-.053 1.148-.254 1.656.066.228.098.429.126.612.012.076.024.148.037.218.924.385 1.522 1.471 1.591 2.095v1.872c0 .766-3.351 3.795-8.002 3.795Zm0-1.485c2.28 0 4.584-1.11 5.002-1.433V7.862l-.023-.116c-.49.21-1.075.291-1.727.291-1.146 0-2.059-.327-2.71-.991A3.222 3.222 0 0 1 8 6.303a3.24 3.24 0 0 1-.544.743c-.65.664-1.563.991-2.71.991-.652 0-1.236-.081-1.727-.291l-.023.116v4.255c.419.323 2.722 1.433 5.002 1.433ZM6.762 2.83c-.193-.206-.637-.413-1.682-.297-1.019.113-1.479.404-1.713.7-.247.312-.369.789-.369 1.554 0 .793.129 1.171.308 1.371.162.181.519.379 1.442.379.853 0 1.339-.235 1.638-.54.315-.322.527-.827.617-1.553.117-.935-.037-1.395-.241-1.614Zm4.155-.297c-1.044-.116-1.488.091-1.681.297-.204.219-.359.679-.242 1.614.091.726.303 1.231.618 1.553.299.305.784.54 1.638.54.922 0 1.28-.198 1.442-.379.179-.2.308-.578.308-1.371 0-.765-.123-1.242-.37-1.554-.233-.296-.693-.587-1.713-.7Z"></path><path d="M6.25 9.037a.75.75 0 0 1 .75.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 .75-.75Zm4.25.75v1.501a.75.75 0 0 1-1.5 0V9.787a.75.75 0 0 1 1.5 0Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="n" aria-hidden="true" id=":Rv6fal9lab:">Ask Copilot about this file</span><div class="react-blob-header-edit-and-raw-actions BlobViewHeader-module__Box_4--vFP89"><div class="prc-ButtonGroup-ButtonGroup-vcMeG"><div><a href="https://github.com/dimitripaiva/BlenderRenderPasses/raw/refs/heads/main/render_layers_setup.py" data-testid="raw-button" class="prc-Button-ButtonBase-c50BI LinkButton-sc-1v6zkmg-0 iwmTUC BlobViewHeader-module__LinkButton--DMph4" data-loading="false" data-no-visuals="true" data-size="small" data-variant="default" aria-describedby=":R2lf6fal9lab:-loading-announcement"><span data-component="buttonContent" data-align="center" class="prc-Button-ButtonContent-HKbr-"><span data-component="text" class="prc-Button-Label-pTQ3x">Raw</span></span></a></div><div><button data-component="IconButton" type="button" data-testid="copy-raw-button" class="prc-Button-ButtonBase-c50BI prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="small" data-variant="default" aria-describedby=":R3clf6fal9lab:-loading-announcement" aria-labelledby=":Rclf6fal9lab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-copy" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="n" aria-hidden="true" id=":Rclf6fal9lab:">Copy raw file</span></div><div><button data-component="IconButton" type="button" data-testid="download-raw-button" class="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0 MOaSq prc-Button-ButtonBase-c50BI prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="small" data-variant="default" aria-describedby=":Rulf6fal9lab:-loading-announcement" aria-labelledby=":R6lf6fal9lab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-download" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M2.75 14A1.75 1.75 0 0 1 1 12.25v-2.5a.75.75 0 0 1 1.5 0v2.5c0 .138.112.25.25.25h10.5a.25.25 0 0 0 .25-.25v-2.5a.75.75 0 0 1 1.5 0v2.5A1.75 1.75 0 0 1 13.25 14Z"></path><path d="M7.25 7.689V2a.75.75 0 0 1 1.5 0v5.689l1.97-1.969a.749.749 0 1 1 1.06 1.06l-3.25 3.25a.749.749 0 0 1-1.06 0L4.22 6.78a.749.749 0 1 1 1.06-1.06l1.97 1.969Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="n" aria-hidden="true" id=":R6lf6fal9lab:">Download raw file</span></div></div><button hidden="" data-testid="raw-button-shortcut" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden="" data-testid="copy-raw-button-shortcut" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden="" data-testid="download-raw-button-shortcut" data-hotkey-scope="read-only-cursor-text-area"></button><a class="js-github-dev-shortcut d-none prc-Link-Link-85e08" href="https://github.dev/"></a><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><a class="js-github-dev-new-tab-shortcut d-none prc-Link-Link-85e08" href="https://github.dev/" target="_blank"></a><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><div class="prc-ButtonGroup-ButtonGroup-vcMeG"><div><a sx="[object Object]" data-component="IconButton" type="button" data-testid="edit-button" class="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0 iOGEtD prc-Button-ButtonBase-c50BI BlobViewHeader-module__IconButton_1--MzNlL prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="small" data-variant="default" aria-describedby=":Rr9f6fal9lab:-loading-announcement" aria-labelledby=":R39f6fal9lab:" href="/dimitripaiva/BlenderRenderPasses/edit/main/render_layers_setup.py" data-discover="true"><svg aria-hidden="true" focusable="false" class="octicon octicon-pencil" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M11.013 1.427a1.75 1.75 0 0 1 2.474 0l1.086 1.086a1.75 1.75 0 0 1 0 2.474l-8.61 8.61c-.21.21-.47.364-.756.445l-3.251.93a.75.75 0 0 1-.927-.928l.929-3.25c.081-.286.235-.547.445-.758l8.61-8.61Zm.176 4.823L9.75 4.81l-6.286 6.287a.253.253 0 0 0-.064.108l-.558 1.953 1.953-.558a.253.253 0 0 0 .108-.064Zm1.238-3.763a.25.25 0 0 0-.354 0L10.811 3.75l1.439 1.44 1.263-1.263a.25.25 0 0 0 0-.354Z"></path></svg></a><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="nw" aria-hidden="true" id=":R39f6fal9lab:">Fork this repository and edit the file</span></div><div><button data-component="IconButton" type="button" data-testid="more-edit-button" aria-haspopup="true" aria-expanded="false" tabindex="0" class="prc-Button-ButtonBase-c50BI prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="small" data-variant="default" aria-describedby=":R59f6fal9lab:-loading-announcement" aria-labelledby=":R3t9f6fal9lab:" id=":R59f6fal9lab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-triangle-down" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="m4.427 7.427 3.396 3.396a.25.25 0 0 0 .354 0l3.396-3.396A.25.25 0 0 0 11.396 7H4.604a.25.25 0 0 0-.177.427Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="nw" aria-hidden="true" id=":R3t9f6fal9lab:">More edit options</span></div></div><button hidden="" data-testid="" data-hotkey="e,Shift+E" data-hotkey-scope="read-only-cursor-text-area"></button></div><button data-component="IconButton" type="button" aria-pressed="true" aria-expanded="true" aria-controls="symbols-pane" data-testid="symbols-button" class="prc-Button-ButtonBase-c50BI BlobViewHeader-module__IconButton_2--KDy6i prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="small" data-variant="invisible" aria-describedby="symbols-button-loading-announcement" aria-labelledby=":R1n6fal9lab:" id="symbols-button"><svg aria-hidden="true" focusable="false" class="octicon octicon-code-square" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M0 1.75C0 .784.784 0 1.75 0h12.5C15.216 0 16 .784 16 1.75v12.5A1.75 1.75 0 0 1 14.25 16H1.75A1.75 1.75 0 0 1 0 14.25Zm1.75-.25a.25.25 0 0 0-.25.25v12.5c0 .138.112.25.25.25h12.5a.25.25 0 0 0 .25-.25V1.75a.25.25 0 0 0-.25-.25Zm7.47 3.97a.75.75 0 0 1 1.06 0l2 2a.75.75 0 0 1 0 1.06l-2 2a.749.749 0 0 1-1.275-.326.749.749 0 0 1 .215-.734L10.69 8 9.22 6.53a.75.75 0 0 1 0-1.06ZM6.78 6.53 5.31 8l1.47 1.47a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215l-2-2a.75.75 0 0 1 0-1.06l2-2a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="nw" aria-hidden="true" id=":R1n6fal9lab:">Close symbols panel</span><div class="react-blob-header-edit-and-raw-actions-combined"><button data-component="IconButton" type="button" title="More file actions" data-testid="more-file-actions-button" aria-haspopup="true" aria-expanded="false" tabindex="0" class="prc-Button-ButtonBase-c50BI js-blob-dropdown-click BlobViewHeader-module__IconButton--uO1fA prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="small" data-variant="invisible" aria-describedby=":Ra76fal9lab:-loading-announcement" aria-labelledby=":R7q76fal9lab:" id=":Ra76fal9lab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-kebab-horizontal" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M8 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3ZM1.5 9a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Zm13 0a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="nw" aria-hidden="true" id=":R7q76fal9lab:">Edit and raw actions</span></div></div></div></div><div></div></div><div class="Box-sc-g0xbh4-0 hycJXc"><section aria-labelledby="file-name-id-wide file-name-id-mobile" class="Box-sc-g0xbh4-0 dceWRL"><div class="Box-sc-g0xbh4-0 dGXHv"><div id="highlighted-line-menu-positioner" class="position-relative"><div id="copilot-button-positioner" class="Box-sc-g0xbh4-0 bpDFns"><div class="Box-sc-g0xbh4-0 iJOeCH"><div class="Box-sc-g0xbh4-0 glDApP react-code-file-contents" role="presentation" aria-hidden="true" data-tab-size="4" data-paste-markdown-skip="true" data-hpc="true"><div class="react-line-numbers-no-virtualization" style="pointer-events:auto;position:relative;z-index:2"><div class="react-no-virtualization-wrapper-lines-ssr"><div data-line-number="1" class="react-line-number react-code-text" style="padding-right:16px">1<span class="Box-sc-g0xbh4-0 cJGaMs"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 iGLarr"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="2" class="child-of-line-0  react-line-number react-code-text" style="padding-right:16px">2</div><div data-line-number="3" class="child-of-line-0  react-line-number react-code-text" style="padding-right:16px">3</div><div data-line-number="4" class="child-of-line-0  react-line-number react-code-text" style="padding-right:16px">4</div><div data-line-number="5" class="child-of-line-0  react-line-number react-code-text" style="padding-right:16px">5</div><div data-line-number="6" class="child-of-line-0  react-line-number react-code-text" style="padding-right:16px">6</div><div data-line-number="7" class="child-of-line-0  react-line-number react-code-text" style="padding-right:16px">7</div><div data-line-number="8" class="child-of-line-0  react-line-number react-code-text" style="padding-right:16px">8</div><div data-line-number="9" class="react-line-number react-code-text" style="padding-right:16px">9</div><div data-line-number="10" class="react-line-number react-code-text" style="padding-right:16px">10</div><div data-line-number="11" class="react-line-number react-code-text" style="padding-right:16px">11</div><div data-line-number="12" class="react-line-number react-code-text" style="padding-right:16px">12</div><div data-line-number="13" class="react-line-number react-code-text" style="padding-right:16px">13</div><div data-line-number="14" class="react-line-number react-code-text" style="padding-right:16px">14</div><div data-line-number="15" class="react-line-number react-code-text" style="padding-right:16px">15<span class="Box-sc-g0xbh4-0 cJGaMs"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 iGLarr"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="16" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">16</div><div data-line-number="17" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">17</div><div data-line-number="18" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">18</div><div data-line-number="19" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">19</div><div data-line-number="20" class="child-of-line-14  react-line-number react-code-text" style="padding-right:16px">20<span class="Box-sc-g0xbh4-0 cJGaMs"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 iGLarr"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="21" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">21</div><div data-line-number="22" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">22</div><div data-line-number="23" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">23</div><div data-line-number="24" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">24</div><div data-line-number="25" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">25</div><div data-line-number="26" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">26</div><div data-line-number="27" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">27</div><div data-line-number="28" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">28</div><div data-line-number="29" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">29</div><div data-line-number="30" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">30</div><div data-line-number="31" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">31</div><div data-line-number="32" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">32</div><div data-line-number="33" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">33</div><div data-line-number="34" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">34</div><div data-line-number="35" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">35</div><div data-line-number="36" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">36</div><div data-line-number="37" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">37</div><div data-line-number="38" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">38</div><div data-line-number="39" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">39</div><div data-line-number="40" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">40</div><div data-line-number="41" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">41</div><div data-line-number="42" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">42</div><div data-line-number="43" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">43</div><div data-line-number="44" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">44</div><div data-line-number="45" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">45</div><div data-line-number="46" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">46</div><div data-line-number="47" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">47</div><div data-line-number="48" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">48</div><div data-line-number="49" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">49</div><div data-line-number="50" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">50</div><div data-line-number="51" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">51</div><div data-line-number="52" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">52</div><div data-line-number="53" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">53</div><div data-line-number="54" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">54</div><div data-line-number="55" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">55</div><div data-line-number="56" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">56</div><div data-line-number="57" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">57</div><div data-line-number="58" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">58</div><div data-line-number="59" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">59</div><div data-line-number="60" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">60</div></div><div class="react-no-virtualization-wrapper-lines-ssr"><div data-line-number="61" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">61</div><div data-line-number="62" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">62</div><div data-line-number="63" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">63</div><div data-line-number="64" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">64</div><div data-line-number="65" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">65</div><div data-line-number="66" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">66</div><div data-line-number="67" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">67</div><div data-line-number="68" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">68</div><div data-line-number="69" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">69</div><div data-line-number="70" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">70</div><div data-line-number="71" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">71</div><div data-line-number="72" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">72</div><div data-line-number="73" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">73</div><div data-line-number="74" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">74</div><div data-line-number="75" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">75</div><div data-line-number="76" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">76</div><div data-line-number="77" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">77</div><div data-line-number="78" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">78</div><div data-line-number="79" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">79</div><div data-line-number="80" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">80</div><div data-line-number="81" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">81</div><div data-line-number="82" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">82</div><div data-line-number="83" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">83</div><div data-line-number="84" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">84</div><div data-line-number="85" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">85</div><div data-line-number="86" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">86</div><div data-line-number="87" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">87</div><div data-line-number="88" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">88</div><div data-line-number="89" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">89</div><div data-line-number="90" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">90</div><div data-line-number="91" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">91</div><div data-line-number="92" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">92</div><div data-line-number="93" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">93</div><div data-line-number="94" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">94</div><div data-line-number="95" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">95</div><div data-line-number="96" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">96</div><div data-line-number="97" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">97</div><div data-line-number="98" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">98</div><div data-line-number="99" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">99</div><div data-line-number="100" class="child-of-line-14 child-of-line-19  react-line-number react-code-text" style="padding-right:16px">100</div><div data-line-number="101" class="react-line-number react-code-text" style="padding-right:16px">101</div><div data-line-number="102" class="react-line-number react-code-text" style="padding-right:16px">102</div><div data-line-number="103" class="react-line-number react-code-text" style="padding-right:16px">103<span class="Box-sc-g0xbh4-0 cJGaMs"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 iGLarr"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="104" class="child-of-line-102  react-line-number react-code-text" style="padding-right:16px">104</div><div data-line-number="105" class="child-of-line-102  react-line-number react-code-text" style="padding-right:16px">105</div><div data-line-number="106" class="child-of-line-102  react-line-number react-code-text" style="padding-right:16px">106</div><div data-line-number="107" class="child-of-line-102  react-line-number react-code-text" style="padding-right:16px">107</div><div data-line-number="108" class="child-of-line-102  react-line-number react-code-text" style="padding-right:16px">108<span class="Box-sc-g0xbh4-0 cJGaMs"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 iGLarr"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="109" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">109</div><div data-line-number="110" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">110</div><div data-line-number="111" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">111</div><div data-line-number="112" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">112</div><div data-line-number="113" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">113</div><div data-line-number="114" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">114</div><div data-line-number="115" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">115</div><div data-line-number="116" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">116</div><div data-line-number="117" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">117</div><div data-line-number="118" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">118</div><div data-line-number="119" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">119</div><div data-line-number="120" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">120</div></div><div class="react-no-virtualization-wrapper-lines-ssr"><div data-line-number="121" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">121</div><div data-line-number="122" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">122</div><div data-line-number="123" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">123</div><div data-line-number="124" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">124</div><div data-line-number="125" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">125</div><div data-line-number="126" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">126</div><div data-line-number="127" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">127</div><div data-line-number="128" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">128</div><div data-line-number="129" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">129</div><div data-line-number="130" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">130</div><div data-line-number="131" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">131</div><div data-line-number="132" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">132</div><div data-line-number="133" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">133</div><div data-line-number="134" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">134</div><div data-line-number="135" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">135</div><div data-line-number="136" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">136</div><div data-line-number="137" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">137</div><div data-line-number="138" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">138</div><div data-line-number="139" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">139</div><div data-line-number="140" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">140</div><div data-line-number="141" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">141</div><div data-line-number="142" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">142</div><div data-line-number="143" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">143</div><div data-line-number="144" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">144</div><div data-line-number="145" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">145</div><div data-line-number="146" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">146</div><div data-line-number="147" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">147</div><div data-line-number="148" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">148</div><div data-line-number="149" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">149</div><div data-line-number="150" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">150</div><div data-line-number="151" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">151</div><div data-line-number="152" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">152</div><div data-line-number="153" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">153</div><div data-line-number="154" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">154</div><div data-line-number="155" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">155</div><div data-line-number="156" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">156</div><div data-line-number="157" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">157</div><div data-line-number="158" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">158</div><div data-line-number="159" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">159</div><div data-line-number="160" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">160</div><div data-line-number="161" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">161</div><div data-line-number="162" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">162</div><div data-line-number="163" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">163</div><div data-line-number="164" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">164</div><div data-line-number="165" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">165</div><div data-line-number="166" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">166</div><div data-line-number="167" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">167</div><div data-line-number="168" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">168</div><div data-line-number="169" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">169</div><div data-line-number="170" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">170</div><div data-line-number="171" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">171</div><div data-line-number="172" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">172</div><div data-line-number="173" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">173</div><div data-line-number="174" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">174</div><div data-line-number="175" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">175</div><div data-line-number="176" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">176</div><div data-line-number="177" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">177</div><div data-line-number="178" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">178</div><div data-line-number="179" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">179</div><div data-line-number="180" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">180</div></div><div class="react-no-virtualization-wrapper-lines-ssr"><div data-line-number="181" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">181</div><div data-line-number="182" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">182</div><div data-line-number="183" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">183</div><div data-line-number="184" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">184</div><div data-line-number="185" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">185</div><div data-line-number="186" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">186</div><div data-line-number="187" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">187</div><div data-line-number="188" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">188</div><div data-line-number="189" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">189</div><div data-line-number="190" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">190</div><div data-line-number="191" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">191</div><div data-line-number="192" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">192</div><div data-line-number="193" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">193</div><div data-line-number="194" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">194</div><div data-line-number="195" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">195</div><div data-line-number="196" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">196</div><div data-line-number="197" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">197</div><div data-line-number="198" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">198</div><div data-line-number="199" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">199</div><div data-line-number="200" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">200</div><div data-line-number="201" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">201</div><div data-line-number="202" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">202</div><div data-line-number="203" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">203</div><div data-line-number="204" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">204</div><div data-line-number="205" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">205</div><div data-line-number="206" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">206</div><div data-line-number="207" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">207</div><div data-line-number="208" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">208</div><div data-line-number="209" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">209</div><div data-line-number="210" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">210</div><div data-line-number="211" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">211</div><div data-line-number="212" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">212</div><div data-line-number="213" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">213</div><div data-line-number="214" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">214</div><div data-line-number="215" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">215</div><div data-line-number="216" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">216</div><div data-line-number="217" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">217</div><div data-line-number="218" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">218</div><div data-line-number="219" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">219</div><div data-line-number="220" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">220</div><div data-line-number="221" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">221</div><div data-line-number="222" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">222</div><div data-line-number="223" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">223</div><div data-line-number="224" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">224</div><div data-line-number="225" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">225</div><div data-line-number="226" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">226</div><div data-line-number="227" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">227</div><div data-line-number="228" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">228</div><div data-line-number="229" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">229</div><div data-line-number="230" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">230</div><div data-line-number="231" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">231</div><div data-line-number="232" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">232</div><div data-line-number="233" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">233</div><div data-line-number="234" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">234</div><div data-line-number="235" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">235</div><div data-line-number="236" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">236</div><div data-line-number="237" class="child-of-line-102 child-of-line-107  react-line-number react-code-text" style="padding-right:16px">237</div><div data-line-number="238" class="react-line-number react-code-text" style="padding-right:16px">238</div><div data-line-number="239" class="react-line-number react-code-text" style="padding-right:16px">239</div><div data-line-number="240" class="react-line-number react-code-text" style="padding-right:16px">240<span class="Box-sc-g0xbh4-0 cJGaMs"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 iGLarr"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div></div><div class="react-no-virtualization-wrapper-lines-ssr"><div data-line-number="241" class="child-of-line-239  react-line-number react-code-text" style="padding-right:16px">241</div><div data-line-number="242" class="child-of-line-239  react-line-number react-code-text" style="padding-right:16px">242</div><div data-line-number="243" class="child-of-line-239  react-line-number react-code-text" style="padding-right:16px">243</div><div data-line-number="244" class="child-of-line-239  react-line-number react-code-text" style="padding-right:16px">244</div><div data-line-number="245" class="child-of-line-239  react-line-number react-code-text" style="padding-right:16px">245</div><div data-line-number="246" class="child-of-line-239  react-line-number react-code-text" style="padding-right:16px">246</div><div data-line-number="247" class="child-of-line-239  react-line-number react-code-text" style="padding-right:16px">247</div><div data-line-number="248" class="child-of-line-239  react-line-number react-code-text" style="padding-right:16px">248</div><div data-line-number="249" class="react-line-number react-code-text" style="padding-right:16px">249</div><div data-line-number="250" class="react-line-number react-code-text" style="padding-right:16px">250</div><div data-line-number="251" class="react-line-number react-code-text" style="padding-right:16px">251</div><div data-line-number="252" class="react-line-number react-code-text" style="padding-right:16px">252</div><div data-line-number="253" class="react-line-number react-code-text" style="padding-right:16px">253</div><div data-line-number="254" class="react-line-number react-code-text" style="padding-right:16px">254<span class="Box-sc-g0xbh4-0 cJGaMs"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 iGLarr"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="255" class="child-of-line-253  react-line-number react-code-text" style="padding-right:16px">255</div><div data-line-number="256" class="child-of-line-253  react-line-number react-code-text" style="padding-right:16px">256</div><div data-line-number="257" class="child-of-line-253  react-line-number react-code-text" style="padding-right:16px">257</div><div data-line-number="258" class="react-line-number react-code-text" style="padding-right:16px">258</div><div data-line-number="259" class="react-line-number react-code-text" style="padding-right:16px">259</div><div data-line-number="260" class="react-line-number react-code-text" style="padding-right:16px">260<span class="Box-sc-g0xbh4-0 cJGaMs"><div aria-label="Collapse code section" role="button" class="Box-sc-g0xbh4-0 iGLarr"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M12.78 5.22a.749.749 0 0 1 0 1.06l-4.25 4.25a.749.749 0 0 1-1.06 0L3.22 6.28a.749.749 0 1 1 1.06-1.06L8 8.939l3.72-3.719a.749.749 0 0 1 1.06 0Z"></path></svg></div></span></div><div data-line-number="261" class="child-of-line-259  react-line-number react-code-text" style="padding-right:16px">261</div><div data-line-number="262" class="child-of-line-259  react-line-number react-code-text" style="padding-right:16px">262</div><div data-line-number="263" class="child-of-line-259  react-line-number react-code-text" style="padding-right:16px">263</div><div data-line-number="264" class="react-line-number react-code-text" style="padding-right:16px">264</div><div data-line-number="265" class="react-line-number react-code-text" style="padding-right:16px">265</div><div data-line-number="266" class="react-line-number react-code-text" style="padding-right:16px">266</div><div data-line-number="267" class="react-line-number react-code-text" style="padding-right:16px">267</div></div></div><div class="react-code-lines"><div><div id="LC1" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-s1>bl_info</span> <span class=pl-c1>=</span> {</div>
<div id="LC2" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-0 ">    <span class=pl-s>&quot;name&quot;</span>: <span class=pl-s>&quot;PBR Render Layers Setup&quot;</span>,</div>
<div id="LC3" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-0 ">    <span class=pl-s>&quot;author&quot;</span>: <span class=pl-s>&quot;Assistant&quot;</span>,</div>
<div id="LC4" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-0 ">    <span class=pl-s>&quot;version&quot;</span>: (<span class=pl-c1>1</span>, <span class=pl-c1>0</span>),</div>
<div id="LC5" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-0 ">    <span class=pl-s>&quot;blender&quot;</span>: (<span class=pl-c1>3</span>, <span class=pl-c1>0</span>, <span class=pl-c1>0</span>),</div>
<div id="LC6" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-0 ">    <span class=pl-s>&quot;location&quot;</span>: <span class=pl-s>&quot;Properties &gt; Render &gt; PBR Setup and Node Editor &gt; Add &gt; Group&quot;</span>,</div>
<div id="LC7" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-0 ">    <span class=pl-s>&quot;description&quot;</span>: <span class=pl-s>&quot;Creates a PBR render layers setup with all passes&quot;</span>,</div>
<div id="LC8" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-0 ">    <span class=pl-s>&quot;category&quot;</span>: <span class=pl-s>&quot;Render&quot;</span>,</div>
<div id="LC9" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">}</div>
<div id="LC10" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC11" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>import</span> <span class=pl-s1>bpy</span></div>
<div id="LC12" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>from</span> <span class=pl-s1>bpy</span>.<span class=pl-s1>types</span> <span class=pl-k>import</span> <span class=pl-v>Operator</span>, <span class=pl-v>Panel</span></div>
<div id="LC13" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>from</span> <span class=pl-s1>bpy</span>.<span class=pl-s1>utils</span> <span class=pl-k>import</span> <span class=pl-s1>register_class</span>, <span class=pl-s1>unregister_class</span></div>
<div id="LC14" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC15" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>class</span> <span class=pl-v>SetupPBRCompositor</span>(<span class=pl-v>Operator</span>):</div>
<div id="LC16" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    <span class=pl-s1>bl_idname</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;render.setup_pbr_compositor&quot;</span></div>
<div id="LC17" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    <span class=pl-s1>bl_label</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;Setup PBR Compositor&quot;</span></div>
<div id="LC18" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    <span class=pl-s1>bl_options</span> <span class=pl-c1>=</span> {<span class=pl-s>&#39;REGISTER&#39;</span>, <span class=pl-s>&#39;UNDO&#39;</span>}</div>
<div id="LC19" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    </div>
<div id="LC20" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 ">    <span class=pl-k>def</span> <span class=pl-en>execute</span>(<span class=pl-s1>self</span>, <span class=pl-s1>context</span>):</div>
<div id="LC21" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Enable use_nodes for the scene</span></div>
<div id="LC22" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>context</span>.<span class=pl-c1>scene</span>.<span class=pl-c1>use_nodes</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC23" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC24" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Enable all necessary render passes in the View Layer</span></div>
<div id="LC25" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span> <span class=pl-c1>=</span> <span class=pl-s1>context</span>.<span class=pl-c1>view_layer</span></div>
<div id="LC26" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Diffuse</span></div>
<div id="LC27" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_diffuse_direct</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC28" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_diffuse_indirect</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC29" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_diffuse_color</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC30" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Glossy</span></div>
<div id="LC31" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_glossy_direct</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC32" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_glossy_indirect</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC33" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_glossy_color</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC34" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Transmission</span></div>
<div id="LC35" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_transmission_direct</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC36" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_transmission_indirect</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC37" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_transmission_color</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC38" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Additional passes</span></div>
<div id="LC39" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_emit</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC40" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>view_layer</span>.<span class=pl-c1>use_pass_environment</span> <span class=pl-c1>=</span> <span class=pl-c1>True</span></div>
<div id="LC41" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC42" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Clear existing nodes</span></div>
<div id="LC43" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>context</span>.<span class=pl-c1>scene</span>.<span class=pl-c1>node_tree</span>.<span class=pl-c1>nodes</span>.<span class=pl-c1>clear</span>()</div>
<div id="LC44" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC45" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Create render layer node</span></div>
<div id="LC46" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>rl</span> <span class=pl-c1>=</span> <span class=pl-s1>context</span>.<span class=pl-c1>scene</span>.<span class=pl-c1>node_tree</span>.<span class=pl-c1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeRLayers&#39;</span>)</div>
<div id="LC47" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>rl</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>600</span>, <span class=pl-c1>0</span>)</div>
<div id="LC48" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC49" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Create the node group if it doesn&#39;t exist</span></div>
<div id="LC50" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-k>if</span> <span class=pl-s>&#39;PBR Render Layers Setup&#39;</span> <span class=pl-c1><span class=pl-c1>not</span> <span class=pl-c1>in</span></span> <span class=pl-s1>bpy</span>.<span class=pl-c1>data</span>.<span class=pl-c1>node_groups</span>:</div>
<div id="LC51" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>bpy</span>.<span class=pl-c1>ops</span>.<span class=pl-c1>node</span>.<span class=pl-c1>create_pbr_setup</span>()</div>
<div id="LC52" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC53" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Create group node</span></div>
<div id="LC54" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>group</span> <span class=pl-c1>=</span> <span class=pl-s1>context</span>.<span class=pl-c1>scene</span>.<span class=pl-c1>node_tree</span>.<span class=pl-c1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeGroup&#39;</span>)</div>
<div id="LC55" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>group</span>.<span class=pl-c1>node_tree</span> <span class=pl-c1>=</span> <span class=pl-s1>bpy</span>.<span class=pl-c1>data</span>.<span class=pl-c1>node_groups</span>[<span class=pl-s>&#39;PBR Render Layers Setup&#39;</span>]</div>
<div id="LC56" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>group</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>300</span>, <span class=pl-c1>0</span>)</div>
<div id="LC57" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC58" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Create composite output</span></div>
<div id="LC59" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>composite</span> <span class=pl-c1>=</span> <span class=pl-s1>context</span>.<span class=pl-c1>scene</span>.<span class=pl-c1>node_tree</span>.<span class=pl-c1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeComposite&#39;</span>)</div>
<div id="LC60" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>composite</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>0</span>, <span class=pl-c1>0</span>)</div>
<div id="LC61" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC62" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Debug: Print all available outputs</span></div>
<div id="LC63" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-en>print</span>(<span class=pl-s>&quot;Available Render Layer outputs:&quot;</span>, [<span class=pl-s1>o</span>.<span class=pl-c1>name</span> <span class=pl-k>for</span> <span class=pl-s1>o</span> <span class=pl-c1>in</span> <span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>])</div>
<div id="LC64" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-en>print</span>(<span class=pl-s>&quot;Available Group inputs:&quot;</span>, [<span class=pl-s1>i</span>.<span class=pl-c1>name</span> <span class=pl-k>for</span> <span class=pl-s1>i</span> <span class=pl-c1>in</span> <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>])</div>
<div id="LC65" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC66" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-c># Create links</span></div>
<div id="LC67" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-s1>links</span> <span class=pl-c1>=</span> <span class=pl-s1>context</span>.<span class=pl-c1>scene</span>.<span class=pl-c1>node_tree</span>.<span class=pl-c1>links</span></div>
<div id="LC68" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC69" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-k>try</span>:</div>
<div id="LC70" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-c># Connect all passes with error checking</span></div>
<div id="LC71" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-c># Diffuse passes</span></div>
<div id="LC72" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-en>print</span>(<span class=pl-s>&quot;Connecting Diffuse passes...&quot;</span>)</div>
<div id="LC73" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;DiffDir&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Diffuse Direct&#39;</span>])</div>
<div id="LC74" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;DiffInd&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Diffuse Indirect&#39;</span>])</div>
<div id="LC75" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;DiffCol&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Diffuse Color&#39;</span>])</div>
<div id="LC76" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            </div>
<div id="LC77" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-c># Glossy passes</span></div>
<div id="LC78" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-en>print</span>(<span class=pl-s>&quot;Connecting Glossy passes...&quot;</span>)</div>
<div id="LC79" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;GlossDir&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Glossy Direct&#39;</span>])</div>
<div id="LC80" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;GlossInd&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Glossy Indirect&#39;</span>])</div>
<div id="LC81" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;GlossCol&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Glossy Color&#39;</span>])</div>
<div id="LC82" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            </div>
<div id="LC83" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-c># Transmission passes</span></div>
<div id="LC84" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-en>print</span>(<span class=pl-s>&quot;Connecting Transmission passes...&quot;</span>)</div>
<div id="LC85" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;TransDir&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Transmission Direct&#39;</span>])</div>
<div id="LC86" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;TransInd&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Transmission Indirect&#39;</span>])</div>
<div id="LC87" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;TransCol&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Transmission Color&#39;</span>])</div>
<div id="LC88" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            </div>
<div id="LC89" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-c># Additional passes</span></div>
<div id="LC90" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-en>print</span>(<span class=pl-s>&quot;Connecting additional passes...&quot;</span>)</div>
<div id="LC91" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Emit&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Emission&#39;</span>])</div>
<div id="LC92" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>rl</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Env&#39;</span>], <span class=pl-s1>group</span>.<span class=pl-c1>inputs</span>[<span class=pl-s>&#39;Environment&#39;</span>])</div>
<div id="LC93" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            </div>
<div id="LC94" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-c># Connect output</span></div>
<div id="LC95" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Combined&#39;</span>], <span class=pl-s1>composite</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>])</div>
<div id="LC96" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            </div>
<div id="LC97" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        <span class=pl-k>except</span> <span class=pl-v>Exception</span> <span class=pl-k>as</span> <span class=pl-s1>e</span>:</div>
<div id="LC98" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-en>print</span>(<span class=pl-s>f&quot;Error connecting nodes: <span class=pl-s1><span class=pl-kos>{</span><span class=pl-en>str</span>(<span class=pl-s1>e</span>)<span class=pl-kos>}</span></span>&quot;</span>)</div>
<div id="LC99" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">            <span class=pl-k>return</span> {<span class=pl-s>&#39;CANCELLED&#39;</span>}</div>
<div id="LC100" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-14 child-of-line-19 ">        </div>
<div id="LC101" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">        <span class=pl-k>return</span> {<span class=pl-s>&#39;FINISHED&#39;</span>}</div>
<div id="LC102" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC103" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>class</span> <span class=pl-v>CreatePBRRenderLayersSetup</span>(<span class=pl-v>Operator</span>):</div>
<div id="LC104" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 ">    <span class=pl-s1>bl_idname</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;node.create_pbr_setup&quot;</span></div>
<div id="LC105" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 ">    <span class=pl-s1>bl_label</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;PBR Render Layers Setup&quot;</span></div>
<div id="LC106" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 ">    <span class=pl-s1>bl_options</span> <span class=pl-c1>=</span> {<span class=pl-s>&#39;REGISTER&#39;</span>, <span class=pl-s>&#39;UNDO&#39;</span>}</div>
<div id="LC107" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 ">
</div>
<div id="LC108" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 ">    <span class=pl-k>def</span> <span class=pl-en>execute</span>(<span class=pl-s1>self</span>, <span class=pl-s1>context</span>):</div>
<div id="LC109" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Check if the node group already exists and remove it</span></div>
<div id="LC110" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-k>if</span> <span class=pl-s>&#39;PBR Render Layers Setup&#39;</span> <span class=pl-c1>in</span> <span class=pl-s1>bpy</span>.<span class=pl-c1>data</span>.<span class=pl-c1>node_groups</span>:</div>
<div id="LC111" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">            <span class=pl-s1>bpy</span>.<span class=pl-c1>data</span>.<span class=pl-c1>node_groups</span>.<span class=pl-c1>remove</span>(<span class=pl-s1>bpy</span>.<span class=pl-c1>data</span>.<span class=pl-c1>node_groups</span>[<span class=pl-s>&#39;PBR Render Layers Setup&#39;</span>])</div>
<div id="LC112" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC113" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Create new node group</span></div>
<div id="LC114" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>node_group</span> <span class=pl-c1>=</span> <span class=pl-s1>bpy</span>.<span class=pl-c1>data</span>.<span class=pl-c1>node_groups</span>.<span class=pl-c1>new</span>(<span class=pl-s1>type</span><span class=pl-c1>=</span><span class=pl-s>&quot;CompositorNodeTree&quot;</span>, <span class=pl-s1>name</span><span class=pl-c1>=</span><span class=pl-s>&quot;PBR Render Layers Setup&quot;</span>)</div>
<div id="LC115" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC116" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Create group input/output nodes first</span></div>
<div id="LC117" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>group_in</span> <span class=pl-c1>=</span> <span class=pl-s1>node_group</span>.<span class=pl-c1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;NodeGroupInput&#39;</span>)</div>
<div id="LC118" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>group_in</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>800</span>, <span class=pl-c1>0</span>)</div>
<div id="LC119" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>group_out</span> <span class=pl-c1>=</span> <span class=pl-s1>node_group</span>.<span class=pl-c1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;NodeGroupOutput&#39;</span>)</div>
<div id="LC120" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>group_out</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>400</span>, <span class=pl-c1>0</span>)</div>
<div id="LC121" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC122" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Create input sockets</span></div>
<div id="LC123" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>input_names</span> <span class=pl-c1>=</span> [</div>
<div id="LC124" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">            <span class=pl-s>&#39;Diffuse Direct&#39;</span>, <span class=pl-s>&#39;Diffuse Indirect&#39;</span>, <span class=pl-s>&#39;Diffuse Color&#39;</span>,</div>
<div id="LC125" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">            <span class=pl-s>&#39;Glossy Direct&#39;</span>, <span class=pl-s>&#39;Glossy Indirect&#39;</span>, <span class=pl-s>&#39;Glossy Color&#39;</span>,</div>
<div id="LC126" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">            <span class=pl-s>&#39;Transmission Direct&#39;</span>, <span class=pl-s>&#39;Transmission Indirect&#39;</span>, <span class=pl-s>&#39;Transmission Color&#39;</span>,</div>
<div id="LC127" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">            <span class=pl-s>&#39;Emission&#39;</span>, <span class=pl-s>&#39;Environment&#39;</span></div>
<div id="LC128" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        ]</div>
<div id="LC129" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC130" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-k>for</span> <span class=pl-s1>name</span> <span class=pl-c1>in</span> <span class=pl-s1>input_names</span>:</div>
<div id="LC131" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">            <span class=pl-s1>node_group</span>.<span class=pl-c1>interface</span>.<span class=pl-c1>new_socket</span>(<span class=pl-s1>name</span><span class=pl-c1>=</span><span class=pl-s1>name</span>, <span class=pl-s1>in_out</span><span class=pl-c1>=</span><span class=pl-s>&#39;INPUT&#39;</span>, <span class=pl-s1>socket_type</span><span class=pl-c1>=</span><span class=pl-s>&#39;NodeSocketColor&#39;</span>)</div>
<div id="LC132" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC133" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Create output socket</span></div>
<div id="LC134" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>node_group</span>.<span class=pl-c1>interface</span>.<span class=pl-c1>new_socket</span>(<span class=pl-s1>name</span><span class=pl-c1>=</span><span class=pl-s>&#39;Combined&#39;</span>, <span class=pl-s1>in_out</span><span class=pl-c1>=</span><span class=pl-s>&#39;OUTPUT&#39;</span>, <span class=pl-s1>socket_type</span><span class=pl-c1>=</span><span class=pl-s>&#39;NodeSocketColor&#39;</span>)</div>
<div id="LC135" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC136" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Create nodes</span></div>
<div id="LC137" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>nodes</span> <span class=pl-c1>=</span> <span class=pl-s1>node_group</span>.<span class=pl-c1>nodes</span></div>
<div id="LC138" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC139" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Diffuse nodes</span></div>
<div id="LC140" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>diffuse_add</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC141" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>diffuse_add</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;ADD&#39;</span></div>
<div id="LC142" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>diffuse_add</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>400</span>, <span class=pl-c1>200</span>)</div>
<div id="LC143" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>diffuse_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC144" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC145" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>diffuse_mult</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC146" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>diffuse_mult</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;MULTIPLY&#39;</span></div>
<div id="LC147" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>diffuse_mult</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>200</span>, <span class=pl-c1>200</span>)</div>
<div id="LC148" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>diffuse_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC149" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC150" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Glossy nodes</span></div>
<div id="LC151" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>glossy_add</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC152" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>glossy_add</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;ADD&#39;</span></div>
<div id="LC153" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>glossy_add</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>400</span>, <span class=pl-c1>0</span>)</div>
<div id="LC154" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>glossy_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC155" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC156" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>glossy_mult</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC157" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>glossy_mult</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;MULTIPLY&#39;</span></div>
<div id="LC158" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>glossy_mult</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>200</span>, <span class=pl-c1>0</span>)</div>
<div id="LC159" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>glossy_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC160" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC161" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Transmission nodes</span></div>
<div id="LC162" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>trans_add</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC163" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>trans_add</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;ADD&#39;</span></div>
<div id="LC164" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>trans_add</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>400</span>, <span class=pl-c1>-</span><span class=pl-c1>200</span>)</div>
<div id="LC165" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>trans_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC166" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC167" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>trans_mult</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC168" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>trans_mult</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;MULTIPLY&#39;</span></div>
<div id="LC169" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>trans_mult</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>-</span><span class=pl-c1>200</span>, <span class=pl-c1>-</span><span class=pl-c1>200</span>)</div>
<div id="LC170" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>trans_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC171" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC172" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Final combination nodes</span></div>
<div id="LC173" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add1</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC174" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add1</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;ADD&#39;</span></div>
<div id="LC175" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add1</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC176" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add1</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>0</span>, <span class=pl-c1>0</span>)</div>
<div id="LC177" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC178" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add2</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC179" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add2</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;ADD&#39;</span></div>
<div id="LC180" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add2</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC181" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add2</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>100</span>, <span class=pl-c1>0</span>)</div>
<div id="LC182" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC183" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add3</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC184" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add3</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;ADD&#39;</span></div>
<div id="LC185" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add3</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC186" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>add3</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>200</span>, <span class=pl-c1>0</span>)</div>
<div id="LC187" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC188" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>final_add</span> <span class=pl-c1>=</span> <span class=pl-s1>nodes</span>.<span class=pl-c1>new</span>(<span class=pl-s>&#39;CompositorNodeMixRGB&#39;</span>)</div>
<div id="LC189" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>final_add</span>.<span class=pl-c1>blend_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;ADD&#39;</span></div>
<div id="LC190" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>final_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>].<span class=pl-c1>default_value</span> <span class=pl-c1>=</span> <span class=pl-c1>1</span></div>
<div id="LC191" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>final_add</span>.<span class=pl-c1>location</span> <span class=pl-c1>=</span> (<span class=pl-c1>300</span>, <span class=pl-c1>0</span>)</div>
<div id="LC192" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC193" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Create all links</span></div>
<div id="LC194" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span> <span class=pl-c1>=</span> <span class=pl-s1>node_group</span>.<span class=pl-c1>links</span></div>
<div id="LC195" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC196" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Connect Add nodes</span></div>
<div id="LC197" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Diffuse</span></div>
<div id="LC198" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Diffuse Direct&#39;</span>], <span class=pl-s1>diffuse_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC199" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Diffuse Indirect&#39;</span>], <span class=pl-s1>diffuse_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC200" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC201" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Glossy</span></div>
<div id="LC202" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Glossy Direct&#39;</span>], <span class=pl-s1>glossy_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC203" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Glossy Indirect&#39;</span>], <span class=pl-s1>glossy_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC204" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC205" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Transmission</span></div>
<div id="LC206" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Transmission Direct&#39;</span>], <span class=pl-s1>trans_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC207" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Transmission Indirect&#39;</span>], <span class=pl-s1>trans_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC208" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC209" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Connect to Multiply nodes</span></div>
<div id="LC210" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Diffuse</span></div>
<div id="LC211" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>diffuse_add</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>diffuse_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC212" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Diffuse Color&#39;</span>], <span class=pl-s1>diffuse_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC213" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC214" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Glossy</span></div>
<div id="LC215" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>glossy_add</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>glossy_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC216" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Glossy Color&#39;</span>], <span class=pl-s1>glossy_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC217" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC218" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Transmission</span></div>
<div id="LC219" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>trans_add</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>trans_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC220" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Transmission Color&#39;</span>], <span class=pl-s1>trans_mult</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC221" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC222" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Combine everything</span></div>
<div id="LC223" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>diffuse_mult</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>add1</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC224" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>glossy_mult</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>add1</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC225" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC226" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>add1</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>add2</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC227" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>trans_mult</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>add2</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC228" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC229" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>add2</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>add3</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC230" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Emission&#39;</span>], <span class=pl-s1>add3</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC231" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC232" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>add3</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>final_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>1</span>])</div>
<div id="LC233" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>group_in</span>.<span class=pl-c1>outputs</span>[<span class=pl-s>&#39;Environment&#39;</span>], <span class=pl-s1>final_add</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>2</span>])</div>
<div id="LC234" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC235" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-c># Connect to output</span></div>
<div id="LC236" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        <span class=pl-s1>links</span>.<span class=pl-c1>new</span>(<span class=pl-s1>final_add</span>.<span class=pl-c1>outputs</span>[<span class=pl-c1>0</span>], <span class=pl-s1>group_out</span>.<span class=pl-c1>inputs</span>[<span class=pl-c1>0</span>])</div>
<div id="LC237" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-102 child-of-line-107 ">        </div>
<div id="LC238" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">        <span class=pl-k>return</span> {<span class=pl-s>&#39;FINISHED&#39;</span>}</div>
<div id="LC239" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC240" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>class</span> <span class=pl-v>PBR_PT_SetupPanel</span>(<span class=pl-v>Panel</span>):</div>
<div id="LC241" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-239 ">    <span class=pl-s1>bl_label</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;PBR Setup&quot;</span></div>
<div id="LC242" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-239 ">    <span class=pl-s1>bl_idname</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;RENDER_PT_pbr_setup&quot;</span></div>
<div id="LC243" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-239 ">    <span class=pl-s1>bl_space_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;PROPERTIES&#39;</span></div>
<div id="LC244" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-239 ">    <span class=pl-s1>bl_region_type</span> <span class=pl-c1>=</span> <span class=pl-s>&#39;WINDOW&#39;</span></div>
<div id="LC245" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-239 ">    <span class=pl-s1>bl_context</span> <span class=pl-c1>=</span> <span class=pl-s>&quot;render&quot;</span></div>
<div id="LC246" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-239 ">    </div>
<div id="LC247" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-239 ">    <span class=pl-k>def</span> <span class=pl-en>draw</span>(<span class=pl-s1>self</span>, <span class=pl-s1>context</span>):</div>
<div id="LC248" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-239 ">        <span class=pl-s1>layout</span> <span class=pl-c1>=</span> <span class=pl-s1>self</span>.<span class=pl-c1>layout</span></div>
<div id="LC249" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">        <span class=pl-s1>layout</span>.<span class=pl-c1>operator</span>(<span class=pl-v>SetupPBRCompositor</span>.<span class=pl-c1>bl_idname</span>)</div>
<div id="LC250" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC251" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>def</span> <span class=pl-en>menu_func</span>(<span class=pl-s1>self</span>, <span class=pl-s1>context</span>):</div>
<div id="LC252" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">    <span class=pl-s1>self</span>.<span class=pl-c1>layout</span>.<span class=pl-c1>operator</span>(<span class=pl-v>CreatePBRRenderLayersSetup</span>.<span class=pl-c1>bl_idname</span>)</div>
<div id="LC253" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC254" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>def</span> <span class=pl-en>register</span>():</div>
<div id="LC255" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-253 ">    <span class=pl-en>register_class</span>(<span class=pl-v>CreatePBRRenderLayersSetup</span>)</div>
<div id="LC256" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-253 ">    <span class=pl-en>register_class</span>(<span class=pl-v>SetupPBRCompositor</span>)</div>
<div id="LC257" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-253 ">    <span class=pl-en>register_class</span>(<span class=pl-v>PBR_PT_SetupPanel</span>)</div>
<div id="LC258" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">    <span class=pl-s1>bpy</span>.<span class=pl-c1>types</span>.<span class=pl-c1>NODE_MT_add</span>.<span class=pl-c1>append</span>(<span class=pl-s1>menu_func</span>)</div>
<div id="LC259" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC260" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>def</span> <span class=pl-en>unregister</span>():</div>
<div id="LC261" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-259 ">    <span class=pl-en>unregister_class</span>(<span class=pl-v>PBR_PT_SetupPanel</span>)</div>
<div id="LC262" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-259 ">    <span class=pl-en>unregister_class</span>(<span class=pl-v>SetupPBRCompositor</span>)</div>
<div id="LC263" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div child-of-line-259 ">    <span class=pl-en>unregister_class</span>(<span class=pl-v>CreatePBRRenderLayersSetup</span>)</div>
<div id="LC264" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">    <span class=pl-s1>bpy</span>.<span class=pl-c1>types</span>.<span class=pl-c1>NODE_MT_add</span>.<span class=pl-c1>remove</span>(<span class=pl-s1>menu_func</span>)</div>
<div id="LC265" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">
</div>
<div id="LC266" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div "><span class=pl-k>if</span> <span class=pl-s1>__name__</span> <span class=pl-c1>==</span> <span class=pl-s>&quot;__main__&quot;</span>:</div>
<div id="LC267" class="react-code-text react-code-line-contents-no-virtualization react-file-line html-div ">    <span class=pl-en>register</span>() </div></div></div></div></div><div id="copilot-button-container"></div></div><div id="highlighted-line-menu-container"></div></div></div><button hidden="" data-testid="hotkey-button" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button></section></div></div><div class="Box-sc-g0xbh4-0 mgQhK"></div><div class="Box-sc-g0xbh4-0 jdLMhu Panel-module__Box--lC3LD panel-content-narrow-styles inner-panel-content-not-narrow"><div id="symbols-pane"><div aria-labelledby="symbols-pane-header" class="Box-sc-g0xbh4-0 cxUsTr"><div class="Box-sc-g0xbh4-0 jXkPPw"><h2 id="symbols-pane-header" tabindex="-1" class="Box-sc-g0xbh4-0 hECgeo">Symbols</h2><button data-component="IconButton" type="button" data-hotkey="Escape" class="ButtonBase__BoxTemporaryWorkaround-sc-107cqdy-0 ezdBfS prc-Button-ButtonBase-c50BI prc-Button-IconButton-szpyj" data-loading="false" data-no-visuals="true" data-size="medium" data-variant="invisible" aria-describedby=":R1omnal9lab:-loading-announcement" aria-labelledby=":R8mnal9lab:"><svg aria-hidden="true" focusable="false" class="octicon octicon-x" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path></svg></button><span class="prc-TooltipV2-Tooltip-cYMVY" data-direction="w" aria-hidden="true" id=":R8mnal9lab:">Close symbols</span></div><div class="Box-sc-g0xbh4-0 hoyhab">Find definitions and references for functions and other symbols in this file by clicking a symbol below or in the code.</div><span class="Box-sc-g0xbh4-0 cNGRpP TextInput-wrapper prc-components-TextInputWrapper-i1ofR prc-components-TextInputBaseWrapper-ueK9q" data-block="true" data-trailing-action="true" data-leading-visual="true" data-trailing-visual="true" aria-busy="false"><span class="TextInput-icon" id=":R1mnal9lab:" aria-hidden="true"><svg aria-hidden="true" focusable="false" class="octicon octicon-filter Octicon-sc-9kayk9-0" viewBox="0 0 16 16" width="16" height="16" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M.75 3h14.5a.75.75 0 0 1 0 1.5H.75a.75.75 0 0 1 0-1.5ZM3 7.75A.75.75 0 0 1 3.75 7h8.5a.75.75 0 0 1 0 1.5h-8.5A.75.75 0 0 1 3 7.75Zm3 4a.75.75 0 0 1 .75-.75h2.5a.75.75 0 0 1 0 1.5h-2.5a.75.75 0 0 1-.75-.75Z"></path></svg></span><input type="text" placeholder="Filter symbols" name="Filter symbols" aria-label="Filter symbols" aria-controls="filter-results" aria-expanded="true" aria-autocomplete="list" role="combobox" aria-describedby=":R1mnal9lab: :R1mnal9labH1:" data-component="input" class="prc-components-Input-Ic-y8" value=""/><span class="TextInput-icon" id=":R1mnal9labH1:" aria-hidden="true"><div class="Box-sc-g0xbh4-0 gqhZpQ"><kbd>r</kbd></div></span></span><div class="Box-sc-g0xbh4-0 ccgkJf"><div id="filter-results" class="Box-sc-g0xbh4-0 kACRto"><span class="prc-src-InternalVisuallyHidden-nlR9R" role="status" aria-live="polite" aria-atomic="true"></span><ul role="tree" aria-label="Code Navigation" data-omit-spacer="false" data-truncate-text="true" class="prc-TreeView-TreeViewRootUlStyles-eZtxW"><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="0bl_info" role="treeitem" aria-labelledby=":Rq6nal9lab:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":Rq6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_info" style="--truncate-max-width:125px"><span>bl_info</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="1SetupPBRCompositor" role="treeitem" aria-labelledby=":R1a6nal9lab:" aria-level="1" aria-expanded="true" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div class="PRIVATE_TreeView-item-toggle PRIVATE_TreeView-item-toggle--hover PRIVATE_TreeView-item-toggle--end prc-TreeView-TreeViewItemToggle-gWUdE prc-TreeView-TreeViewItemToggleHover-nEgP- prc-TreeView-TreeViewItemToggleEnd-t-AEB"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down" viewBox="0 0 12 12" width="12" height="12" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M6 8.825c-.2 0-.4-.1-.5-.2l-3.3-3.3c-.3-.3-.3-.8 0-1.1.3-.3.8-.3 1.1 0l2.7 2.7 2.7-2.7c.3-.3.8-.3 1.1 0 .3.3.3.8 0 1.1l-3.2 3.2c-.2.2-.4.3-.6.3Z"></path></svg></div><div id=":R1a6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 jDUiPd"></div><div class="Box-sc-g0xbh4-0 fPctCv">class</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="SetupPBRCompositor" style="--truncate-max-width:125px"><span>SetupPBRCompositor</span></div></div></span></div></div><ul role="group" style="list-style:none;padding:0;margin:0" aria-label=""><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="0bl_idname" role="treeitem" aria-labelledby=":R5la6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":R5la6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_idname" style="--truncate-max-width:125px"><span>bl_idname</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="1bl_label" role="treeitem" aria-labelledby=":R9la6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":R9la6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_label" style="--truncate-max-width:125px"><span>bl_label</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="2bl_options" role="treeitem" aria-labelledby=":Rdla6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":Rdla6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_options" style="--truncate-max-width:125px"><span>bl_options</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="3execute" role="treeitem" aria-labelledby=":Rhla6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":Rhla6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 gxAxAi"></div><div class="Box-sc-g0xbh4-0 gWkFIQ">func</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="execute" style="--truncate-max-width:125px"><span>execute</span></div></div></span></div></div></li></ul></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="2CreatePBRRenderLayersSetup" role="treeitem" aria-labelledby=":R1q6nal9lab:" aria-level="1" aria-expanded="true" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div class="PRIVATE_TreeView-item-toggle PRIVATE_TreeView-item-toggle--hover PRIVATE_TreeView-item-toggle--end prc-TreeView-TreeViewItemToggle-gWUdE prc-TreeView-TreeViewItemToggleHover-nEgP- prc-TreeView-TreeViewItemToggleEnd-t-AEB"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down" viewBox="0 0 12 12" width="12" height="12" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M6 8.825c-.2 0-.4-.1-.5-.2l-3.3-3.3c-.3-.3-.3-.8 0-1.1.3-.3.8-.3 1.1 0l2.7 2.7 2.7-2.7c.3-.3.8-.3 1.1 0 .3.3.3.8 0 1.1l-3.2 3.2c-.2.2-.4.3-.6.3Z"></path></svg></div><div id=":R1q6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 jDUiPd"></div><div class="Box-sc-g0xbh4-0 fPctCv">class</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="CreatePBRRenderLayersSetup" style="--truncate-max-width:125px"><span>CreatePBRRenderLayersSetup</span></div></div></span></div></div><ul role="group" style="list-style:none;padding:0;margin:0" aria-label=""><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="0bl_idname" role="treeitem" aria-labelledby=":R5lq6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":R5lq6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_idname" style="--truncate-max-width:125px"><span>bl_idname</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="1bl_label" role="treeitem" aria-labelledby=":R9lq6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":R9lq6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_label" style="--truncate-max-width:125px"><span>bl_label</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="2bl_options" role="treeitem" aria-labelledby=":Rdlq6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":Rdlq6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_options" style="--truncate-max-width:125px"><span>bl_options</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="3execute" role="treeitem" aria-labelledby=":Rhlq6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":Rhlq6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 gxAxAi"></div><div class="Box-sc-g0xbh4-0 gWkFIQ">func</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="execute" style="--truncate-max-width:125px"><span>execute</span></div></div></span></div></div></li></ul></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="3PBR_PT_SetupPanel" role="treeitem" aria-labelledby=":R2a6nal9lab:" aria-level="1" aria-expanded="true" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div class="PRIVATE_TreeView-item-toggle PRIVATE_TreeView-item-toggle--hover PRIVATE_TreeView-item-toggle--end prc-TreeView-TreeViewItemToggle-gWUdE prc-TreeView-TreeViewItemToggleHover-nEgP- prc-TreeView-TreeViewItemToggleEnd-t-AEB"><svg aria-hidden="true" focusable="false" class="octicon octicon-chevron-down" viewBox="0 0 12 12" width="12" height="12" fill="currentColor" display="inline-block" overflow="visible" style="vertical-align:text-bottom"><path d="M6 8.825c-.2 0-.4-.1-.5-.2l-3.3-3.3c-.3-.3-.3-.8 0-1.1.3-.3.8-.3 1.1 0l2.7 2.7 2.7-2.7c.3-.3.8-.3 1.1 0 .3.3.3.8 0 1.1l-3.2 3.2c-.2.2-.4.3-.6.3Z"></path></svg></div><div id=":R2a6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 jDUiPd"></div><div class="Box-sc-g0xbh4-0 fPctCv">class</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="PBR_PT_SetupPanel" style="--truncate-max-width:125px"><span>PBR_PT_SetupPanel</span></div></div></span></div></div><ul role="group" style="list-style:none;padding:0;margin:0" aria-label=""><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="0bl_label" role="treeitem" aria-labelledby=":R5ma6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":R5ma6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_label" style="--truncate-max-width:125px"><span>bl_label</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="1bl_idname" role="treeitem" aria-labelledby=":R9ma6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":R9ma6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_idname" style="--truncate-max-width:125px"><span>bl_idname</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="2bl_space_type" role="treeitem" aria-labelledby=":Rdma6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":Rdma6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_space_type" style="--truncate-max-width:125px"><span>bl_space_type</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="3bl_region_type" role="treeitem" aria-labelledby=":Rhma6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":Rhma6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_region_type" style="--truncate-max-width:125px"><span>bl_region_type</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="4bl_context" role="treeitem" aria-labelledby=":Rlma6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":Rlma6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 dotKsF"></div><div class="Box-sc-g0xbh4-0 iGIwaf">const</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="bl_context" style="--truncate-max-width:125px"><span>bl_context</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="5draw" role="treeitem" aria-labelledby=":Rpma6nal9lab:" aria-level="2" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:2"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"><div class="PRIVATE_TreeView-item-level-line prc-TreeView-TreeViewItemLevelLine-KPSSL"></div></div></div><div id=":Rpma6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 gxAxAi"></div><div class="Box-sc-g0xbh4-0 gWkFIQ">func</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="draw" style="--truncate-max-width:125px"><span>draw</span></div></div></span></div></div></li></ul></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="4menu_func" role="treeitem" aria-labelledby=":R2q6nal9lab:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R2q6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 gxAxAi"></div><div class="Box-sc-g0xbh4-0 gWkFIQ">func</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="menu_func" style="--truncate-max-width:125px"><span>menu_func</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="5register" role="treeitem" aria-labelledby=":R3a6nal9lab:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R3a6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 gxAxAi"></div><div class="Box-sc-g0xbh4-0 gWkFIQ">func</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="register" style="--truncate-max-width:125px"><span>register</span></div></div></span></div></div></li><li class="PRIVATE_TreeView-item prc-TreeView-TreeViewItem-ShJr0" tabindex="0" id="6unregister" role="treeitem" aria-labelledby=":R3q6nal9lab:" aria-level="1" aria-selected="false"><div class="PRIVATE_TreeView-item-container prc-TreeView-TreeViewItemContainer--2Rkn" style="--level:1"><div style="grid-area:spacer;display:flex"><div style="width:100%;display:flex"></div></div><div id=":R3q6nal9lab:" class="PRIVATE_TreeView-item-content prc-TreeView-TreeViewItemContent-f0r0b"><span class="PRIVATE_TreeView-item-content-text prc-TreeView-TreeViewItemContentText-smZM-"><div class="Box-sc-g0xbh4-0 cSURfY"><div class="Box-sc-g0xbh4-0 bTXewe"><div class="Box-sc-g0xbh4-0 gxAxAi"></div><div class="Box-sc-g0xbh4-0 gWkFIQ">func</div></div>  <div class="Truncate-sc-x3i4it-0 bkmqFA prc-Truncate-Truncate-A9Wn6" title="unregister" style="--truncate-max-width:125px"><span>unregister</span></div></div></span></div></div></li></ul></div></div></div></div></div></div> <!-- --> <!-- --> </div></div></div></div></div></div></div><div id="find-result-marks-container" class="Box-sc-g0xbh4-0 cCoXib"></div><button hidden="" data-testid="" data-hotkey-scope="read-only-cursor-text-area"></button><button hidden=""></button></div> <!-- --> <!-- --> <script type="application/json" id="__PRIMER_DATA_:R0:__">{"resolvedServerColorMode":"night"}</script></div>
</react-app>
</turbo-frame>



  </div>

</turbo-frame>

    </main>
  </div>

  </div>

          <footer class="footer pt-8 pb-6 f6 color-fg-muted p-responsive" role="contentinfo" >
  <h2 class='sr-only'>Footer</h2>

  


  <div class="d-flex flex-justify-center flex-items-center flex-column-reverse flex-lg-row flex-wrap flex-lg-nowrap">
    <div class="d-flex flex-items-center flex-shrink-0 mx-2">
      <a aria-label="GitHub Homepage" class="footer-octicon mr-2" href="https://github.com">
        <svg aria-hidden="true" height="24" viewBox="0 0 24 24" version="1.1" width="24" data-view-component="true" class="octicon octicon-mark-github">
    <path d="M12 1C5.923 1 1 5.923 1 12c0 4.867 3.149 8.979 7.521 10.436.55.096.756-.233.756-.522 0-.262-.013-1.128-.013-2.049-2.764.509-3.479-.674-3.699-1.292-.124-.317-.66-1.293-1.127-1.554-.385-.207-.936-.715-.014-.729.866-.014 1.485.797 1.691 1.128.99 1.663 2.571 1.196 3.204.907.096-.715.385-1.196.701-1.471-2.448-.275-5.005-1.224-5.005-5.432 0-1.196.426-2.186 1.128-2.956-.111-.275-.496-1.402.11-2.915 0 0 .921-.288 3.024 1.128a10.193 10.193 0 0 1 2.75-.371c.936 0 1.871.123 2.75.371 2.104-1.43 3.025-1.128 3.025-1.128.605 1.513.221 2.64.111 2.915.701.77 1.127 1.747 1.127 2.956 0 4.222-2.571 5.157-5.019 5.432.399.344.743 1.004.743 2.035 0 1.471-.014 2.654-.014 3.025 0 .289.206.632.756.522C19.851 20.979 23 16.854 23 12c0-6.077-4.922-11-11-11Z"></path>
</svg>
</a>
      <span>
        &copy; 2025 GitHub,&nbsp;Inc.
      </span>
    </div>

    <nav aria-label="Footer">
      <h3 class="sr-only" id="sr-footer-heading">Footer navigation</h3>

      <ul class="list-style-none d-flex flex-justify-center flex-wrap mb-2 mb-lg-0" aria-labelledby="sr-footer-heading">

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to Terms&quot;,&quot;label&quot;:&quot;text:terms&quot;}" href="https://docs.github.com/site-policy/github-terms/github-terms-of-service" data-view-component="true" class="Link--secondary Link">Terms</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to privacy&quot;,&quot;label&quot;:&quot;text:privacy&quot;}" href="https://docs.github.com/site-policy/privacy-policies/github-privacy-statement" data-view-component="true" class="Link--secondary Link">Privacy</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to security&quot;,&quot;label&quot;:&quot;text:security&quot;}" href="https://github.com/security" data-view-component="true" class="Link--secondary Link">Security</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to status&quot;,&quot;label&quot;:&quot;text:status&quot;}" href="https://www.githubstatus.com/" data-view-component="true" class="Link--secondary Link">Status</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to community&quot;,&quot;label&quot;:&quot;text:community&quot;}" href="https://github.community/" data-view-component="true" class="Link--secondary Link">Community</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to docs&quot;,&quot;label&quot;:&quot;text:docs&quot;}" href="https://docs.github.com/" data-view-component="true" class="Link--secondary Link">Docs</a>
          </li>

          <li class="mx-2">
            <a data-analytics-event="{&quot;category&quot;:&quot;Footer&quot;,&quot;action&quot;:&quot;go to contact&quot;,&quot;label&quot;:&quot;text:contact&quot;}" href="https://support.github.com?tags=dotcom-footer" data-view-component="true" class="Link--secondary Link">Contact</a>
          </li>

          <li class="mx-2" >
  <cookie-consent-link>
    <button
      type="button"
      class="Link--secondary underline-on-hover border-0 p-0 color-bg-transparent"
      data-action="click:cookie-consent-link#showConsentManagement"
      data-analytics-event="{&quot;location&quot;:&quot;footer&quot;,&quot;action&quot;:&quot;cookies&quot;,&quot;context&quot;:&quot;subfooter&quot;,&quot;tag&quot;:&quot;link&quot;,&quot;label&quot;:&quot;cookies_link_subfooter_footer&quot;}"
    >
       Manage cookies
    </button>
  </cookie-consent-link>
</li>

<li class="mx-2">
  <cookie-consent-link>
    <button
      type="button"
      class="Link--secondary underline-on-hover border-0 p-0 color-bg-transparent text-left"
      data-action="click:cookie-consent-link#showConsentManagement"
      data-analytics-event="{&quot;location&quot;:&quot;footer&quot;,&quot;action&quot;:&quot;dont_share_info&quot;,&quot;context&quot;:&quot;subfooter&quot;,&quot;tag&quot;:&quot;link&quot;,&quot;label&quot;:&quot;dont_share_info_link_subfooter_footer&quot;}"
    >
      Do not share my personal information
    </button>
  </cookie-consent-link>
</li>

      </ul>
    </nav>
  </div>
</footer>



    <ghcc-consent id="ghcc" class="position-fixed bottom-0 left-0" style="z-index: 999999"
      data-locale="en"
      data-initial-cookie-consent-allowed=""
      data-cookie-consent-required="false"
    ></ghcc-consent>




  <div id="ajax-error-message" class="ajax-error-message flash flash-error" hidden>
    <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-alert">
    <path d="M6.457 1.047c.659-1.234 2.427-1.234 3.086 0l6.082 11.378A1.75 1.75 0 0 1 14.082 15H1.918a1.75 1.75 0 0 1-1.543-2.575Zm1.763.707a.25.25 0 0 0-.44 0L1.698 13.132a.25.25 0 0 0 .22.368h12.164a.25.25 0 0 0 .22-.368Zm.53 3.996v2.5a.75.75 0 0 1-1.5 0v-2.5a.75.75 0 0 1 1.5 0ZM9 11a1 1 0 1 1-2 0 1 1 0 0 1 2 0Z"></path>
</svg>
    <button type="button" class="flash-close js-ajax-error-dismiss" aria-label="Dismiss error">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
    </button>
    You can’t perform that action at this time.
  </div>

    <template id="site-details-dialog">
  <details class="details-reset details-overlay details-overlay-dark lh-default color-fg-default hx_rsm" open>
    <summary role="button" aria-label="Close dialog"></summary>
    <details-dialog class="Box Box--overlay d-flex flex-column anim-fade-in fast hx_rsm-dialog hx_rsm-modal">
      <button class="Box-btn-octicon m-0 btn-octicon position-absolute right-0 top-0" type="button" aria-label="Close dialog" data-close-dialog>
        <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-x">
    <path d="M3.72 3.72a.75.75 0 0 1 1.06 0L8 6.94l3.22-3.22a.749.749 0 0 1 1.275.326.749.749 0 0 1-.215.734L9.06 8l3.22 3.22a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215L8 9.06l-3.22 3.22a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L6.94 8 3.72 4.78a.75.75 0 0 1 0-1.06Z"></path>
</svg>
      </button>
      <div class="octocat-spinner my-6 js-details-dialog-spinner"></div>
    </details-dialog>
  </details>
</template>

    <div class="Popover js-hovercard-content position-absolute" style="display: none; outline: none;">
  <div class="Popover-message Popover-message--bottom-left Popover-message--large Box color-shadow-large" style="width:360px;">
  </div>
</div>

    <template id="snippet-clipboard-copy-button">
  <div class="zeroclipboard-container position-absolute right-0 top-0">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn js-clipboard-copy m-2 p-0" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon m-2">
    <path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none m-2">
    <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>
<template id="snippet-clipboard-copy-button-unpositioned">
  <div class="zeroclipboard-container">
    <clipboard-copy aria-label="Copy" class="ClipboardButton btn btn-invisible js-clipboard-copy m-2 p-0 d-flex flex-justify-center flex-items-center" data-copy-feedback="Copied!" data-tooltip-direction="w">
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-copy js-clipboard-copy-icon">
    <path d="M0 6.75C0 5.784.784 5 1.75 5h1.5a.75.75 0 0 1 0 1.5h-1.5a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-1.5a.75.75 0 0 1 1.5 0v1.5A1.75 1.75 0 0 1 9.25 16h-7.5A1.75 1.75 0 0 1 0 14.25Z"></path><path d="M5 1.75C5 .784 5.784 0 6.75 0h7.5C15.216 0 16 .784 16 1.75v7.5A1.75 1.75 0 0 1 14.25 11h-7.5A1.75 1.75 0 0 1 5 9.25Zm1.75-.25a.25.25 0 0 0-.25.25v7.5c0 .138.112.25.25.25h7.5a.25.25 0 0 0 .25-.25v-7.5a.25.25 0 0 0-.25-.25Z"></path>
</svg>
      <svg aria-hidden="true" height="16" viewBox="0 0 16 16" version="1.1" width="16" data-view-component="true" class="octicon octicon-check js-clipboard-check-icon color-fg-success d-none">
    <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0Z"></path>
</svg>
    </clipboard-copy>
  </div>
</template>


    <style>
      .user-mention[href$="/deodatopr"] {
        color: var(--color-user-mention-fg);
        background-color: var(--bgColor-attention-muted, var(--color-attention-subtle));
        border-radius: 2px;
        margin-left: -2px;
        margin-right: -2px;
      }
      .user-mention[href$="/deodatopr"]:before,
      .user-mention[href$="/deodatopr"]:after {
        content: '';
        display: inline-block;
        width: 2px;
      }
    </style>


    </div>
    <div id="js-global-screen-reader-notice" class="sr-only mt-n1" aria-live="polite" aria-atomic="true" ></div>
    <div id="js-global-screen-reader-notice-assertive" class="sr-only mt-n1" aria-live="assertive" aria-atomic="true"></div>
  </body>
</html>

