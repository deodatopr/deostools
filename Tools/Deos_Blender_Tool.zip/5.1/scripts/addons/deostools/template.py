import bpy, os

os.system("cls")           # Clear console system
# bpy.ops.script.reload()     # Reload system Scripts

#Read all actions
#bpy.app.debug_wm = True 
#bpy.app.debug_wm = False

# OPERATOR EMPTY
# class DeoOperatorEmpty (Operator):
# bl_idname = "deo.operator_empty"
# bl_label = ""
# bl_description = "Empty Operator for testing purposes"
# bl_options = {'REGISTER', 'UNDO'}

# def execute(self, context) :
# self.report({'INFO'}, "Deo's Tools - Empty Operator")
# return {'FINISHED'}

#Execute by Time
#bpy.app.timers.register(NameDefinition, first_interval = 2.0)