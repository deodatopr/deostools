#------------------------------------------------
# TOOL EXPORTER MAPS
#------------------------------------------------

import bpy											# Python
import os												# Os
import time											# Time - time.sleep(2)
import functools 								# FuncionsToWait
from bpy.types import Operator	# Operators


class DeosOperExporterMapBatch (Operator):
	
	bl_idname = "deo.exportermap_batch"
	bl_label = ""
	bl_description = "Export Maps [ Batch the Map(s) selected ]"
	bl_options = {'REGISTER', 'UNDO'}
	
	def execute(self, context) :
		
		# Mesh Loaded
		v_ObjPickerHighSel = bpy.context.scene.deoPropertyGrp.picker_ExporterMap_High  		# _init_

		if v_ObjPickerHighSel == None :
			self.report({'WARNING'}, "[There is No 'Mesh' Loaded]")
			
		else :
			# Mesh Loaded, mats?
			v_SelectedHighMesh = bpy.data.objects[bpy.context.scene.deoPropertyGrp.picker_ExporterMap_High.name]
			bpy.context.view_layer.objects.active = v_SelectedHighMesh
		
			if len(bpy.context.active_object.data.materials) == 0:
				self.report({'WARNING'}, "[The loaded mesh has No 'Material']")
				
			else :
				# -------------------------------
				#region [EXPORTAR NODOS A MAPAS]

				# OBJETOS VALORES DE PASES SELECCIONADOS CON SUS NOMBRES
				BoolPassBaseColor = bpy.context.scene.deoPropertyGrp.bool_ExporterMap_Color  		# _init_
				BoolPassMetallic = bpy.context.scene.deoPropertyGrp.bool_ExporterMap_Metallic  	# _init_
				BoolPassRoughness = bpy.context.scene.deoPropertyGrp.bool_ExporterMap_Roughness  # _init_
				BoolPassNormal = bpy.context.scene.deoPropertyGrp.bool_ExporterMap_Normal  			# _init_
				BoolPassEmission = bpy.context.scene.deoPropertyGrp.bool_ExporterMap_Emission  	# _init_

				# LIMPIAR SELECCIONES
				bpy.ops.object.select_all(action='DESELECT')

				# ACTIVAR OBJETO Y MATERIAL
				ObjExpMaps = bpy.context.scene.deoPropertyGrp.picker_ExporterMap_High						# _init_
				bpy.data.objects[ObjExpMaps.name].select_set(True)
				MatObjExpMaps = ObjExpMaps.data.materials[0]

				# TAMAÑO DE TEXTURA
				if bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgSize == "Op1" :
					v_TextureSize = 256
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgSize == "Op2" :
					v_TextureSize = 512
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgSize == "Op3" :
					v_TextureSize = 1024
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgSize == "Op4" :
					v_TextureSize = 2048
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgSize == "Op5" :
					v_TextureSize = 4096
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgSize == "Op6" :
					v_TextureSize = 8192

				# FORMATO DE IMAGEN
				if bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgFormat == "Op1" :
					v_TextureFormatImg = 'JPEG'
					v_TxtExtension = ".jpg"
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgFormat == "Op2" :
					v_TextureFormatImg = 'PNG'
					v_TxtExtension = ".png"
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_ImgFormat == "Op3" :
					v_TextureFormatImg = 'TARGA'
					v_TxtExtension = ".tga"

				# UV EDGE
				if bpy.context.scene.deoPropertyGrp.enum_ExporterMap_edgePadding == "Op1" :
					v_EdgeMargin = 8192
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_edgePadding == "Op2" :
					v_EdgeMargin = 128
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_edgePadding == "Op3" :
					v_EdgeMargin = 64
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_edgePadding == "Op4" :
					v_EdgeMargin = 32
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_edgePadding == "Op5" :
					v_EdgeMargin = 16
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_edgePadding == "Op6" :
					v_EdgeMargin = 8
				elif bpy.context.scene.deoPropertyGrp.enum_ExporterMap_edgePadding == "Op7" :
					v_EdgeMargin = 4
				#endregion
				# -------------------------------

				# BASE COLOR ------------------
				if BoolPassBaseColor :
					print ("Baking Base Color")

					v_TxtPassName = '_Color'		# Nombre del pase a exportar
					v_BakeType = 'DIFFUSE'			# Nombre del Bake a procesar
					
					# Crear Image Texture
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=True )
					# bpy.context.scene.render.image_settings.compression = 75
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.generated_color = [0,0,0,1]
					TxtImageNode.colorspace_settings.name = 'sRGB'

					# Crear Image Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Mesh y Textturas Activas (Seleccionadas)
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode

					# [ BAKE ]

					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType
					bpy.context.scene.render.bake.use_pass_direct = False
					bpy.context.scene.render.bake.use_pass_indirect = False
					bpy.context.scene.render.bake.use_pass_color = True
					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True
					
					# *****************

					# Metallic: Si existe el Base color sale negro, por lo cual se debe de quitar para calcular el BC.
					# Obtener Material y Nodos especificos
					v_ActiveMaterial = bpy.context.active_object.active_material  							# Obtener Material Mesh
					v_GetMatBSD = v_ActiveMaterial.node_tree.nodes.get("Principled BSDF")				# Obtener Mat BSDF
					v_MetalRestoreConnection = ''
					v_MetalWire = False																					

					# Validar si hay conexiones en Metallic 
					if v_GetMatBSD.inputs["Metallic"].links :																		# SI TIENE CONEXION.
						
						if v_GetMatBSD.inputs["Metallic"].links[0].is_muted :											# En Mute
							v_GetMatBSD.inputs["Metallic"].default_value = 0												# Eliminar Metal
						
						else : 																																		# Sin Mute!
							v_MetalWire = v_GetMatBSD.inputs["Metallic"].links[0]									 	# Guardar la conexion
							v_MetalWire.is_muted = True																							# Ponerlo en Mute
							v_GetMatBSD.inputs["Metallic"].default_value = 0												# Eliminar Metal
							
							v_MetalRestoreConnection = 'MetalSiConectado'														# Clean (Posterior)

					else : 																																			# NO TIENE CONEXION.
							v_get_MetallicVal = v_GetMatBSD.inputs["Metallic"].default_value				# Guardar valor del Metal
							v_GetMatBSD.inputs["Metallic"].default_value = 0												# Eliminar Metal

							v_MetalRestoreConnection = 'MetalNoConectado'														# Clean (Posterior)
							
					# *****************

					# Action
					bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)

					# Esperar hasta que termine el bake en la textura
					while TxtImageNode.is_dirty :
						break
					

					# [ SAVE ]

					# FileName
					if bpy.context.scene.deoPropertyGrp.bool_ExporterMap_MeshName :
						v_TxtFileName = ObjExpMaps.name
					else :
						v_TxtFileName = bpy.context.scene.deoPropertyGrp.str_ExporterMap_FileNameCustom

					# PathLocation
					if bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir == 'My File Location' :
						v_PathDir = ''
					else : 
						v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir)
						v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'
					
					# Save 
					TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
					

					# [ CLEAN ]
					bpy.data.images.remove(TxtImgShaNode.image)
					MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
					
					# Resturar metal
					if v_MetalRestoreConnection == 'MetalSiConectado': 
						v_MetalWire.is_muted = False																							# Eliminar el Mute asignado.
					
					elif v_MetalRestoreConnection == 'MetalNoConectado': 
						v_GetMatBSD.inputs["Metallic"].default_value = v_get_MetallicVal					# Regresar el valor anterior.

					bpy.ops.wm.redraw_timer()    #Mostrar tiempo de ejecucion

				# METALLIC ------------------
				if BoolPassMetallic :
					print ("Baking Metallic")
					
					v_TxtPassName = '_Metallic'		# Nombre del pase a exportar
					v_BakeType = 'EMIT'						# Nombre del Bake a procesar

					# Crear Image Texture Node
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
					# bpy.context.scene.render.image_settings.compression = 75
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.generated_color = [0,0,0,1]
					TxtImageNode.colorspace_settings.name = 'Non-Color'
					TxtImageNode.colorspace_settings.is_data = True
					
					# Crear Image Shader Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Mesh y Textturas Activas (Seleccionadas)
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode


					# [ BAKE ]
					
					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType
					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True

					# -----
					
					# Metallic (No hay manera en Blender que te opcion de calcular Metallic, asi que sera directo al shader).
					v_ActiveMaterial = bpy.context.active_object.active_material
					v_MatBSD = v_ActiveMaterial.node_tree.nodes["Principled BSDF"]
					v_BSDFInpMetal = v_MatBSD.inputs['Metallic']

					v_MatOut = v_ActiveMaterial.node_tree.nodes.get("Material Output")
					v_MatOutInpSurface = v_MatOut.inputs['Surface']
					v_MatMixMetalInBSDF = ''
					v_wasMetalInBSDF = False

					
					if v_BSDFInpMetal.links : 	# SI HAY CONEXION AL BSDF METALLIC
						# Almacenar quien esta Conectado en BSDF>Metallic
						v_MatMixMetalInBSDF = v_BSDFInpMetal.links[0].from_node			

						# Conectar del BSDF > Metallic al MatOutput>Surface
						v_ActiveMaterial.node_tree.links.remove(v_BSDFInpMetal.links[0])                                            # Eliminar conexion
						v_ActiveMaterial.node_tree.links.new(v_MatMixMetalInBSDF.outputs["Metallic"], v_MatOut.inputs['Surface'])   # Conectar Node a Surface
						v_wasMetalInBSDF = True

						# -----

						# Action
						bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
						# Esperar hasta que termine el bake en la textura
						while TxtImageNode.is_dirty :
							break


						# [ SAVE ]

						# FileName
						if bpy.context.scene.deoPropertyGrp.bool_ExporterMap_MeshName :
							v_TxtFileName = ObjExpMaps.name
						else :
							v_TxtFileName = bpy.context.scene.deoPropertyGrp.str_ExporterMap_FileNameCustom

						# PathLocation
						if bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir == 'My File Location' :
							v_PathDir = ''
						else : 
							v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir)
							v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

						# SaveImg
						TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
					

						# [ CLEAN ]
						
						# General
						bpy.data.images.remove(TxtImgShaNode.image)
						MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
			
						# Metal: Reconectar BSDF > MatOut | Metallic > BSDF (Si lo habia)
						if v_wasMetalInBSDF :
								v_ActiveMaterial.node_tree.links.new(v_MatBSD.outputs["BSDF"], v_MatOut.inputs['Surface'])
								v_ActiveMaterial.node_tree.links.new(v_MatMixMetalInBSDF.outputs["Metallic"], v_MatBSD.inputs["Metallic"])
						

					else : 											# NO HAY CONEXION AL BSDF METALLIC SOLO SLIDER-VALOR.
						
						# Crear  textura con Salider-Valor del Metallic > Bake > Save

						# El valor del Metallic (Slider)
						v_rgb = v_GetMatBSD.inputs["Metallic"].default_value

						# Crear Image Texture Node
						TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
						TxtImageNode.file_format = v_TextureFormatImg
						TxtImageNode.colorspace_settings.name = 'Non-Color'
						TxtImageNode.generated_color = [v_rgb,v_rgb,v_rgb,1]
						
						# Crear Image Shader Node
						TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
						TxtImgShaNode.name = 'Deos_ExporterMap_Node'
						TxtImgShaNode.image = TxtImageNode

						# Objeto y Texttura Activos
						bpy.context.view_layer.objects.active = ObjExpMaps
						MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode
					
						# [ SAVE ]

						# FileName
						if bpy.context.scene.deoPropertyGrp.bool_ExporterMap_MeshName :
							v_TxtFileName = ObjExpMaps.name
						else :
							v_TxtFileName = bpy.context.scene.deoPropertyGrp.str_ExporterMap_FileNameCustom

						# PathLocation
						if bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir == 'My File Location' :
							v_PathDir = ''
						else : 
							v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir)
							v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

						# SaveImg
						TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)

						# [ CLEAN ]
						bpy.data.images.remove(TxtImgShaNode.image)
						MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
					
					bpy.ops.wm.redraw_timer()    #Mostrar tiempo de ejecucion


				# ROUGHNESS ------------------
				if BoolPassRoughness :
					print ("Baking Roughness")

					
					v_TxtPassName = '_Roughness'	# Nombre del pase a exportar
					v_BakeType = 'ROUGHNESS'		# Nombre del Bake a procesar

					# Crear Image Texture
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.generated_color = [0,0,0,1]
					TxtImageNode.colorspace_settings.name = 'Non-Color'
					TxtImageNode.colorspace_settings.is_data = True
					

					# Crear Image Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Objeto y Texttura Activos
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode


					# [ BAKE ]

					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType
					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True

					# Action
					bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
					# Esperar hasta que termine el bake en la textura
					while TxtImageNode.is_dirty :
						break

					
					# [ SAVE ]

					# FileName
					if bpy.context.scene.deoPropertyGrp.bool_ExporterMap_MeshName :
						v_TxtFileName = ObjExpMaps.name
					else :
						v_TxtFileName = bpy.context.scene.deoPropertyGrp.str_ExporterMap_FileNameCustom

					# PathLocation
					if bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir == 'My File Location' :
						v_PathDir = ''
					else : 
						v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir)
						v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

					# Action
					TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)


					# [ CLEAN ]
					bpy.data.images.remove(TxtImgShaNode.image)
					MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)

					bpy.ops.wm.redraw_timer()    #Mostrar tiempo de ejecucion


				# NORMAL ------------------
				if BoolPassNormal :
					print ("Baking Normal")
					
					v_TxtPassName = '_Normal'	# Nombre del pase a exportar
					v_BakeType = 'NORMAL'		# Nombre del Bake a procesar

					# Crear Image Texture
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.generated_color = [0.5,0.5,1,1]
					TxtImageNode.colorspace_settings.name = 'Non-Color'
					TxtImageNode.colorspace_settings.is_data = True


					# Crear Image Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Activar: Objeto y Textura
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode

					# -----

					# [ BAKE ]
					
					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType

					bpy.context.scene.render.bake.normal_space = 'TANGENT'
					bpy.context.scene.render.bake.normal_r = 'POS_X'
					bpy.context.scene.render.bake.normal_g = 'POS_Y'
					bpy.context.scene.render.bake.normal_b = 'POS_Z'

					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True
					
					# Action
					bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
					# Esperar hasta que termine el bake en la textura
					while TxtImageNode.is_dirty :
						break


					# [ SAVE ]

					# FileName
					if bpy.context.scene.deoPropertyGrp.bool_ExporterMap_MeshName :
						v_TxtFileName = ObjExpMaps.name
					else :
						v_TxtFileName = bpy.context.scene.deoPropertyGrp.str_ExporterMap_FileNameCustom

					# PathLocation
					if bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir == 'My File Location' :
						v_PathDir = v_TxtFileName + v_TxtPassName + v_TxtExtension
					else : 
						v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir)
						v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

					# Action
					TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
					TxtImageNode.colorspace_settings
					
					# -----
					
					# [ CLEAN ]
					bpy.data.images.remove(TxtImgShaNode.image)
					MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
					
					bpy.ops.wm.redraw_timer()    #Mostrar tiempo de ejecucion

				
				# EMISSION ------------------
				if BoolPassEmission :
					print ("Baking Emission")
					
					v_TxtPassName = '_Emission'	# Nombre del pase a exportar
					v_BakeType = 'EMIT'			# Nombre del Bake a procesar

					# Crear Image Texture
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.colorspace_settings.name = 'sRGB'
					TxtImageNode.generated_color = [0,0,0,1]
					
					# Crear Image Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Objeto y Texttura Activos
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode
					
					# [ BAKE ]
					
					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType
					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True
					
					# Action
					bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
					
					# Esperar hasta que termine el bake en la textura
					while TxtImageNode.is_dirty :
						break
					
					
					# [ SAVE ]

					# FileName
					if bpy.context.scene.deoPropertyGrp.bool_ExporterMap_MeshName :
						v_TxtFileName = ObjExpMaps.name
					else :
						v_TxtFileName = bpy.context.scene.deoPropertyGrp.str_ExporterMap_FileNameCustom

					# PathLocation
					if bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir == 'My File Location' :
						v_PathDir = v_TxtFileName + v_TxtPassName + v_TxtExtension
					else : 
						v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.deoPropertyGrp.str_ExporterMap_PathDir)
						v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

					# Action
					TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
					

					# [ CLEAN ]
					bpy.data.images.remove(TxtImgShaNode.image)
					MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
					
					bpy.ops.wm.redraw_timer()    #Mostrar tiempo de ejecucion

			# ------------------------------------------------------------

				# No Selection mesh
				bpy.ops.object.select_all(action='DESELECT')
				
				# Info
				self.report({'INFO'}, "BAKING PROCESS IS DONE!")

		return {'FINISHED'}