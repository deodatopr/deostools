#------------------------------------------------
# TOOL OPTIMIZER SCENE
#------------------------------------------------

# Python
import bpy, time, math

# Operadores
from bpy.types import Operator

#-----------------------------#
#	  	 GLOBAL VARIABLES	  #
#-----------------------------#

# Visual Colors
vc_matsLibraryCreated = False
vc_colorSlots = 6
vc_meshesProcessed = []

# Poly Count
pc_objs_found = 0

#-----------------------------#
#	  	 SCENE HANDLER		  #
#-----------------------------#

def Opt_Clear_OnLoadBlendFile():
	global vc_meshesProcessed
	global pc_objs_found

	vc_meshesProcessed.clear()

	bpy.context.scene.coll_PolyCount_ListInstances.clear()
	bpy.context.scene.optimizePropertyGrp.str_OptPlyCnt_ObjSel = "0"
	pc_objs_found = 0

	bpy.context.scene.coll_MshInstances_ListInstances.clear()
	bpy.context.scene.optimizePropertyGrp.str_OptInstance_TotalInst = "0"


#-----------------------------#
#	  	 VISUAL COLORS		  #
#-----------------------------#

# region VISUAL COLORS
rangeColorsTris = [
	(0.4, 0.7, 1.0, 1.0),		# Min Color
	(0.0, 0.8, 0.8, 1.0),
	(0.0, 1.0, 0.0, 1.0),
	(1.0, 1.0, 0.0, 1.0),
	(1.0, 0.2, 0.0, 1.0),
	(1.0, 0.0, 0.0, 1.0)		# Max Color
]

def Opt_VC_MatLibrary_Create(_self):
	matDebugLvl1 = bpy.data.materials.new("Deo's_Colorize_ByTris_1")
	matDebugLvl1.diffuse_color = rangeColorsTris[0]
	matDebugLvl1.use_nodes = True

	matDebugLvl2 = bpy.data.materials.new("Deo's_Colorize_ByTris_2")
	matDebugLvl2.diffuse_color = rangeColorsTris[1]
	matDebugLvl2.use_nodes = True

	matDebugLvl3 = bpy.data.materials.new("Deo's_Colorize_ByTris_3")
	matDebugLvl3.diffuse_color = rangeColorsTris[2]
	matDebugLvl3.use_nodes = True

	matDebugLvl4 = bpy.data.materials.new("Deo's_Colorize_ByTris_4")
	matDebugLvl4.diffuse_color = rangeColorsTris[3]
	matDebugLvl4.use_nodes = True

	matDebugLvl5 = bpy.data.materials.new("Deo's_Colorize_ByTris_5")
	matDebugLvl5.diffuse_color = rangeColorsTris[4]
	matDebugLvl5.use_nodes = True

	matDebugLvl6 = bpy.data.materials.new("Deo's_Colorize_ByTris_6")
	matDebugLvl6.diffuse_color = rangeColorsTris[5]
	matDebugLvl6.use_nodes = True

def Opt_VC_MatLibrary_Get(_indice):
	# Get material by index
	if _indice == 0:
		return bpy.data.materials.get("Deo's_Colorize_ByTris_1")
	elif _indice == 1:
		return bpy.data.materials.get("Deo's_Colorize_ByTris_2")
	elif _indice == 2:
		return bpy.data.materials.get("Deo's_Colorize_ByTris_3")
	elif _indice == 3:
		return bpy.data.materials.get("Deo's_Colorize_ByTris_4")
	elif _indice == 4:
		return bpy.data.materials.get("Deo's_Colorize_ByTris_5")
	elif _indice == 5:
		return bpy.data.materials.get("Deo's_Colorize_ByTris_6")
	else:
		return None
	
def Opt_VC_MatLibrary_Remove():
	for mat in bpy.data.materials:
		if mat.name.startswith("Deo's_Colorize_"):
			bpy.data.materials.remove(mat)

def Opt_VC_Clean_Remove_EmptySlots(_mesh):
	valid_materials = [slot.material for slot in _mesh.material_slots if slot.material is not None]

	_mesh.data.materials.clear()

	for mat in valid_materials:
		_mesh.data.materials.append(mat)

def Opt_VC_Clean():
	global vc_meshesProcessed
	
	for mesh in vc_meshesProcessed:
		for i in reversed(range(len(mesh.material_slots))):

			slot = mesh.material_slots[i]
			# Remove materials VC if exist
			if slot.material != None:
				if slot.material and slot.material.name.startswith("Deo's_Colorize_"):
					mesh.active_material_index = i
					bpy.context.view_layer.objects.active = mesh
					mesh.select_set(True)
					bpy.ops.object.material_slot_remove()
				else:
					# Reset colors
					slot.material.diffuse_color = (1.0,1.0,1.0,1.0)

		Opt_VC_Clean_Remove_EmptySlots(mesh)

def Opt_VC_ColorsInMats_FromTris(_self, _meshes):
	global vc_meshesProcessed

	# CLEAN
	if len(vc_meshesProcessed) == 0:
		vc_meshesProcessed = [obj for obj in bpy.data.objects if obj.type == 'MESH']

	Opt_VC_Clean()


	# SHADING MODE
	bpy.context.space_data.shading.type = 'SOLID'
	bpy.context.space_data.shading.light = 'STUDIO'
	bpy.context.space_data.shading.color_type = 'MATERIAL'
	
	# VALIDATE MESH 
	_meshes = [obj for obj in _meshes if obj.type == 'MESH']
	
	#SAVE MESHES
	vc_meshesProcessed = _meshes.copy()

	# GET MIN TRIS PER MESH
	array_tris = [len(obj.data.loop_triangles) for obj in _meshes]
	min_tris = min(array_tris)
	
	# GET MAX TRIS PER MESH
	uiCustomTrisBool = bpy.context.scene.optimizePropertyGrp.bool_OptVisCol_UseMaxTris
	uiCustomTrisVal = bpy.context.scene.optimizePropertyGrp.int_OptVisCol_UseMaxTris
	max_tris = uiCustomTrisVal if uiCustomTrisBool else max(array_tris)

	trisBySection = math.ceil((max_tris - min_tris + 1) / vc_colorSlots)

	# CREATE LIST WITH TRIS RANGES
	list_maxTris_by_colorLevel = [min_tris + trisBySection * (i + 1) - 1 for i in range(vc_colorSlots)]

	# Info
	infoMshAnalized = 0

	# APPLY COLORS INTO MATS
	for mesh in _meshes:
		tris_count = len(mesh.data.loop_triangles)

		# GET COLOR INDEX
		color_index = 0
		for i, max_val in enumerate(list_maxTris_by_colorLevel):
			if tris_count <= max_val:
				color_index = i
				break
		else:
			color_index = vc_colorSlots - 1  # Si supera todos los rangos, usar el último color
		
		r,g,b,a = rangeColorsTris[color_index]

		# Clean slots materials
		Opt_VC_Clean_Remove_EmptySlots(mesh)

		# Config material default
		mat = Opt_VC_MatLibrary_Get(color_index)

		# If is empty, add a material
		if len(mesh.data.materials) == 0:
			mesh.data.materials.append(mat)

		for mat in mesh.data.materials:
			if mat:
				mat.diffuse_color = (r,g,b, a)

		# Info: obj analized
		infoMshAnalized += 1

	# Save results
	bpy.context.scene.optimizePropertyGrp.str_OptVisCol_MinTris = str(min_tris)
	bpy.context.scene.optimizePropertyGrp.str_OptVisCol_MaxTris = str(max_tris)
	bpy.context.scene.optimizePropertyGrp.str_OptVisCol_ObjAnalized = str(infoMshAnalized)

	#Enable btn UI cleaner
	bpy.context.scene.optimizePropertyGrp.bool_OptVisCol_IsCleanerActive = True

	_self.report({'INFO'}, f"[ {infoMshAnalized} Meshes were analized ]")

def Opt_VC_Clear_UI():
	bpy.context.scene.optimizePropertyGrp.str_OptVisCol_MinTris = "0"
	bpy.context.scene.optimizePropertyGrp.str_OptVisCol_MaxTris = "0"
	bpy.context.scene.optimizePropertyGrp.str_OptVisCol_ObjAnalized = "0"


class Deo_Opt_OperMesh_VC_Colorize (Operator):
	bl_idname = "deo.opt_mesh_vc_colorize"
	bl_label = ""
	bl_description = "Visualize the mesh(es) by tris count"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, context):
		# Create Library (Only once)
		global vc_matsLibraryCreated
		if not vc_matsLibraryCreated:
			Opt_VC_MatLibrary_Remove()
			Opt_VC_MatLibrary_Create(_self)
			vc_matsLibraryCreated = True

		# All scene
		if bpy.context.scene.optimizePropertyGrp.enum_OptVisCol_SelectMode == "Op1":
			meshes_in_scene = [obj for obj in bpy.data.objects if obj.type == 'MESH']

			if len(meshes_in_scene) > 0:
				Opt_VC_ColorsInMats_FromTris(_self, meshes_in_scene)
			else:
				_self.report({'WARNING'}, "[ No Mesh(es) in scene ]")
		# Selected
		elif bpy.context.scene.optimizePropertyGrp.enum_OptVisCol_SelectMode == "Op2":
			selected_meshes = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']

			if len(selected_meshes) > 0:
				Opt_VC_ColorsInMats_FromTris(_self, selected_meshes)
			else:
				_self.report({'WARNING'}, "[ No Mesh(es) Selected ]")
		# Collection
		elif bpy.context.scene.optimizePropertyGrp.enum_OptVisCol_SelectMode == "Op3":
			if bpy.context.scene.optimizePropertyGrp.pntr_OptVisCol_Collect != None:
				meshesInColl = GetAllMeshesFromColl(bpy.context.scene.optimizePropertyGrp.pntr_OptVisCol_Collect)
				Opt_VC_ColorsInMats_FromTris(_self, meshesInColl)
			else:
				_self.report({'WARNING'}, "[ Need to Load a Collection ]")


		return {'FINISHED'}


class Deo_Opt_OperMesh_VC_Clean (Operator):
	bl_idname = "deo.opt_mesh_vc_clean"
	bl_label = ""
	bl_description = "Clean visual colors materials"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		global vc_meshesProcessed
		if not vc_meshesProcessed:
			vc_meshesProcessed = [obj for obj in bpy.data.objects if obj.type == 'MESH']

		Opt_VC_Clean()

		bpy.app.timers.register(Opt_VC_Clear_UI, first_interval = 0.0)

		# Disable btn UI cleaner
		bpy.context.scene.optimizePropertyGrp.bool_OptVisCol_IsCleanerActive = False

		return {'FINISHED'}

#-----------------------------#
#	  	 POLYCOUNT			  #
#-----------------------------#
# region POLYCOUNT
def Deo_Opt_PolyCount_OnUpdateIndexList(self, context):
	if len(bpy.context.scene.coll_PolyCount_ListInstances) == 0:
		return

	scene = context.scene

	index = scene.int_PolyCount_ListActiveIndex
	obj_name = scene.coll_PolyCount_ListInstances[index].itemList_Name
	obj = bpy.data.objects.get(obj_name)

	if not obj:
		self.report({'WARNING'}, f"Objeto '{obj_name}' no encontrado")
		return {'CANCELLED'}

	bpy.ops.object.select_all(action='DESELECT')
	bpy.context.view_layer.objects.active = obj
	obj.select_set(True)

def Opt_PolyCount_AddItemsToList(_obj,_condition, _trisAmount):
	global pc_objs_found

	if _condition:
		pc_objs_found += 1
		_obj.select_set(True)

		item = bpy.context.scene.coll_PolyCount_ListInstances.add()
		item.itemList_Name = _obj.name

def Opt_PolyCount_Tris(_self, _meshes):
	global pc_objs_found

	bpy.context.scene.coll_PolyCount_ListInstances.clear()
	pc_objs_found = 0

	tris_amount = bpy.context.scene.optimizePropertyGrp.int_OptPlyCnt_Amount
	compare_action = bpy.context.scene.optimizePropertyGrp.enum_OptPlyCnt_Action

	for obj in _meshes:
		if obj.type != 'MESH':
			continue

		objTris = len(obj.data.loop_triangles)	# Tris Count
		# <
		if compare_action == "Op1":
			Opt_PolyCount_AddItemsToList(obj,objTris < tris_amount,tris_amount)
		# >
		elif compare_action == "Op2":
			Opt_PolyCount_AddItemsToList(obj,objTris > tris_amount,tris_amount)
		# =
		elif compare_action == "Op3":
			Opt_PolyCount_AddItemsToList(obj,objTris == tris_amount,tris_amount)


	bpy.context.scene.optimizePropertyGrp.str_OptPlyCnt_ObjSel = str(pc_objs_found)
	_self.report({'INFO'}, "[ Mesh(es) that match with the rule were selected ]")


class Deo_Opt_OperMesh_PolyCount_Get (Operator):
	bl_idname = "deo.opt_mesh_polycount_get"
	bl_label = ""
	bl_description = "Get the mesh(es) with the polycount assigned"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		#All scene
		if bpy.context.scene.optimizePropertyGrp.enum_OptPlyCnt_SelectMode == "Op1":
			if len([obj for obj in bpy.context.scene.objects if obj.type == 'MESH']) > 0:
				Opt_PolyCount_Tris(self, bpy.context.scene.objects)
			else:
				self.report({'WARNING'}, "[ No Mesh(es) in scene ]")
		#Selected
		elif bpy.context.scene.optimizePropertyGrp.enum_OptPlyCnt_SelectMode == "Op2":
			if len(bpy.context.selected_objects) > 0:
				Opt_PolyCount_Tris(self, bpy.context.selected_objects)
			else:
				self.report({'WARNING'}, "[ No Mesh(es) Selected ]")
		#Collection
		elif bpy.context.scene.optimizePropertyGrp.enum_OptPlyCnt_SelectMode == "Op3":
			if bpy.context.scene.optimizePropertyGrp.pntr_OptPlyCnt_Collect != None:
				meshesInScene = GetAllMeshesFromColl(bpy.context.scene.optimizePropertyGrp.pntr_OptPlyCnt_Collect)
				Opt_PolyCount_Tris(self, meshesInScene)
			else:
				self.report({'WARNING'}, "[ Need to Load a Collection ]")

		return {'FINISHED'}
	
class Deo_Opt_OperMesh_PolyCount_Clean(Operator):
	bl_idname = "deo.opt_mesh_polycount_clean"
	bl_label = ""
	bl_description = "Clean instances list"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		global pc_objs_found

		bpy.context.scene.coll_PolyCount_ListInstances.clear()
		bpy.context.scene.optimizePropertyGrp.str_OptPlyCnt_ObjSel = "0"

		pc_objs_found = 0

		return {'FINISHED'}

# endregion

#-----------------------------#
#	  	 INSTANCES  		  #
#-----------------------------#
# region INSTANCES

def Deo_Opt_Msh_Inst_OnUpdateIndexList(self, context):
	if len(bpy.context.scene.coll_MshInstances_ListInstances) == 0:
		return

	scene = context.scene

	index = scene.int_MshInstances_ListActiveIndex
	obj_name = scene.coll_MshInstances_ListInstances[index].itemList_Name
	obj = bpy.data.objects.get(obj_name)

	if not obj:
		self.report({'WARNING'}, f"Objeto '{obj_name}' no encontrado")
		return {'CANCELLED'}

	bpy.ops.object.select_all(action='DESELECT')
	bpy.context.view_layer.objects.active = obj
	obj.select_set(True)

def Opt_Inst_Get(self, _objToAnalize):
	if _objToAnalize:
		bpy.context.scene.coll_MshInstances_ListInstances.clear()

		instancias = [obj for obj in bpy.context.scene.objects if obj.data == _objToAnalize.data]		# Find
		bpy.context.scene.optimizePropertyGrp.str_OptInstance_TotalInst = str(len(instancias)-1)		# Count

		for inst in instancias:
			item = bpy.context.scene.coll_MshInstances_ListInstances.add()
			item.itemList_Name = inst.name

		self.report({'INFO'}, f"[ {_objToAnalize.name} instances were analized ]")
	else:
		self.report({'WARNING'}, "[ Need to 'Load/Select' a Mesh ]")

def Opt_Inst_Reset():
	bpy.context.scene.optimizePropertyGrp.str_OptInstance_TotalInst = "0"

class Deo_Opt_OperMesh_Inst_Pntr (Operator):
	bl_idname = "deo.opt_mesh_inst_pntr"
	bl_label = ""
	bl_description = "Get instances from the mesh loaded"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		analized_Mesh_Inst = bpy.context.scene.optimizePropertyGrp.pntr_OptInstance_Picker
		Opt_Inst_Get(self, analized_Mesh_Inst)

		return {'FINISHED'}

class Deo_Opt_OperMesh_Inst_Selctd (Operator):
	bl_idname = "deo.opt_mesh_inst_sel"
	bl_label = ""
	bl_description = "Get instances from selected mesh"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		Opt_Inst_Get(self, bpy.context.active_object)

		return {'FINISHED'}
	
class Deo_Opt_OperMesh_Inst_Clean(Operator):
	bl_idname = "deo.opt_mesh_inst_clean"
	bl_label = ""
	bl_description = "Clean instances list"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		bpy.context.scene.coll_MshInstances_ListInstances.clear()
		bpy.context.scene.optimizePropertyGrp.str_OptInstance_TotalInst = "0"
		return {'FINISHED'}
# endregion

#-----------------------------#
# ****** UTILITIES ******
#-----------------------------#

def GetAllMeshesFromColl(collection):
	#Search recursively all meshes from collection (include sub collections)
	
	meshes = []

	meshes.extend([obj for obj in collection.objects if obj.type == 'MESH'])

	# Check subcollections 
	for subcol in collection.children:
		meshes.extend(GetAllMeshesFromColl(subcol))
	
	return meshes