#------------------------------------------------
# TOOL OPTIMIZER SCENE
#------------------------------------------------

# Python
import bpy, os

# Operadores
from bpy.types import Operator

#-----------------------------#
#	  	 GLOBAL VARIABLES	  #
#-----------------------------#
imgCopyResized = None
areFiltersActive = False
suspendUpdate_TexModify = False

#-----------------------------#
#	  	 SCENE HANDLER		  #
#-----------------------------#

def Opt_Clear_OnLoadBlendFile():
	global imgCopyResized
	global areFiltersActive

	bpy.context.scene.optimizePropertyGrp.bool_OptTex_Selection = False
	bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalTextures = "0"
	bpy.context.scene.optimizePropertyGrp.enum_OptTex_Filter_Format = "Op1"
	bpy.context.scene.optimizePropertyGrp.enum_OptTex_Filter_Pixels = "Op1"
	bpy.context.scene.coll_Tex_ListTex.clear()
	bpy.context.scene.coll_Tex_ListTex_Filtered.clear()

	imgCopyResized = None
	areFiltersActive = False
	
#region [ PANEL ]
def Deo_Opt_Tex_GetIfTexIsSingleImg(_imgSource):
	source_types = {
		'FILE': True,
		'GENERATED': False,
		'SEQUENCE': False,
		'MOVIE': False,
		'VIEWER': False
	}
	
	return source_types[_imgSource]

def Deo_Opt_Tex_GetFormat(_enumFormat):	
	format_map = {
		'PNG': 'PNG',
		'JPEG': 'JPG',
		'TARGA': 'TGA',
		'OPEN_EXR': 'EXR',
		'OPEN_EXR_MULTILAYER': 'EXR',
		'HDR': 'HDR',
		'TIFF': 'TIFF',
		'WEBP': 'WEBP',
		'BMP': 'BMP',
		'CINEON': 'CIN',
		'DPX': 'DPX'
	}
	
	return format_map.get(_enumFormat.file_format, _enumFormat.file_format)


def Deo_Opt_Tex_GetDataMaterialsUsingTex(_texName):
	materials = []
	
	# Find in all materials
	for mat in bpy.data.materials:
		if not mat.node_tree:
			continue
			
		# Find in nodes
		for node in mat.node_tree.nodes:
			if node.type == 'TEX_IMAGE' and node.image and node.image.name == _texName:
				materials.append(mat)
				break  # Break if find any match
	
	return materials

def Deo_Opt_Tex_GetNameMaterialsUsingTex(_matsData, _texName):
	materials = []
	
	# Find in all materials
	for mat in _matsData:
			
		# Find in nodes
		for node in mat.node_tree.nodes:
			if node.type == 'TEX_IMAGE' and node.image and node.image.name == _texName:
				materials.append(mat.name)
				break  # Break if find any match
	
	return ", ".join(materials)

def Deo_Opt_Tex_GetTexSizeVRam(_img):	
	width = _img.size[0]
	height = _img.size[1]
	channels = _img.channels
	depth = 8

	vram_bytes = width * height * channels * depth // 8
	vram_megabytes = vram_bytes / (1024 * 1024)

	return round(vram_megabytes, 2) # Return in MB

def Deo_Opt_Tex_GetTexturesFromMesh(_mesh):
	textures_info = []

	for mat_slot in _mesh.material_slots:
		# Filter only materials with textures
		mat = mat_slot.material
		if not mat or not mat.use_nodes:
			continue

		# Get textures from nodes
		for node in mat.node_tree.nodes:
			if node.type == 'TEX_IMAGE' and node.image:
				img = node.image
				img_path = bpy.path.abspath(img.filepath)

				# Check if image is being used
				linked = "Unlinked"
				for output in node.outputs:
					if output.is_linked:
						linked = "Linked"

				name = img.name
				file_size = 0

				if os.path.exists(img_path):
					file_size = os.path.getsize(img_path) / (1024 * 1024)  # en MB

				# Set data into dictionary
				matsData = Deo_Opt_Tex_GetDataMaterialsUsingTex(img.name)
				nameMats = Deo_Opt_Tex_GetNameMaterialsUsingTex(matsData, img.name)
				isSingleImg =  Deo_Opt_Tex_GetIfTexIsSingleImg(img.source)
				format =  Deo_Opt_Tex_GetFormat(img)
				size = str(img.size[0]) + "x" + str(img.size[1])
				vRam = Deo_Opt_Tex_GetTexSizeVRam(img)

				textures_info.append({
					"image_data" : img,
					"materials_data": matsData,
					"materials_name": nameMats,
					"is_image_from_disk" :isSingleImg,
					"image_name": name,
					"linked": linked,
					"format": format,
					"size_px" : size,
					"size_width" : img.size[0],
					"size_height": img.size[1],
					"size_disk": round(file_size, 2),
					"vRam": vRam
				})

	return textures_info

def Deo_Opt_Tex_OnUpdateFilters(_self,_context):
	global areFiltersActive
	global suspendUpdate_TexModify

	OptzmGrp = _context.scene.optimizePropertyGrp

	isFltrFormatActive = False
	isFltrPixelsActive = False

	# Check active filters
	if OptzmGrp.enum_OptTex_Filter_Format != "Op1":
		OptzmGrp.bool_OptTex_Attbt_Format = True
		isFltrFormatActive = True

	if OptzmGrp.enum_OptTex_Filter_Pixels != "Op1":
		OptzmGrp.bool_OptTex_Attbt_SizePx = True
		isFltrPixelsActive = True

	areFiltersActive = isFltrFormatActive or isFltrPixelsActive

	totalTexturesFound = 0
	totalDiskSize = 0.0
	totalVRamSize = 0.0

	# Exit if there aren´t active filters
	if not areFiltersActive:
		totalTexSelected = 0

		for item in bpy.context.scene.coll_Tex_ListTex:
			# Update totals
			if item.itemList_TexModify:
				totalTexSelected += 1

			totalTexturesFound += 1
			totalDiskSize += item.itemList_TexSizeDisk_Val
			totalVRamSize += item.itemList_TexVRam_Val

		# UI totals
		bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalTextures = str(totalTexturesFound)
		bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalDiskSize = f"{round(totalDiskSize,2)} MB"
		bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalVRamSize = f"{round(totalVRamSize,2)} MB"
			
		# Set UI number
		OptzmGrp.str_OptTex_TexSlctdFromList = str(totalTexSelected)

		return
	
	#APPLY FILTERS
	
	# Clear filtered list
	bpy.context.scene.coll_Tex_ListTex_Filtered.clear()

	fltrFormat = ""
	fltrPixels = 0


	# Save filters values
	if isFltrFormatActive:
		if OptzmGrp.enum_OptTex_Filter_Format == "Op2":fltrFormat = "PNG"
		elif OptzmGrp.enum_OptTex_Filter_Format == "Op3":fltrFormat = "JPG"
		elif OptzmGrp.enum_OptTex_Filter_Format == "Op4":fltrFormat = "TGA"
		elif OptzmGrp.enum_OptTex_Filter_Format == "Op5":fltrFormat = "EXR"
		elif OptzmGrp.enum_OptTex_Filter_Format == "Op6":fltrFormat = "HDR"
		elif OptzmGrp.enum_OptTex_Filter_Format == "Op7":fltrFormat = "WEBP"
	
	if isFltrPixelsActive:
		if OptzmGrp.enum_OptTex_Filter_Pixels == "Op2":fltrPixels = 256
		elif OptzmGrp.enum_OptTex_Filter_Pixels == "Op3":fltrPixels = 512
		elif OptzmGrp.enum_OptTex_Filter_Pixels == "Op4":fltrPixels = 1024
		elif OptzmGrp.enum_OptTex_Filter_Pixels == "Op5":fltrPixels = 2048
		elif OptzmGrp.enum_OptTex_Filter_Pixels == "Op6":fltrPixels = 4096

	# Check items to match with filters
	suspendUpdate_TexModify = True
	textures_slctToModify = 0

	for item in _context.scene.coll_Tex_ListTex:
		matchFltrFormat = True
		matchFltrPixels = True

		if isFltrFormatActive:
			if item.itemList_TexFormat != fltrFormat:
				matchFltrFormat = False

		if isFltrPixelsActive:
			widthMatch = False
			heightMatch = False

			# =
			if OptzmGrp.enum_OptTex_Filter_PxCondition == "Op1":
				widthMatch = item.itemList_TexSizeWidth_Val == fltrPixels
				heightMatch = item.itemList_TexSizeHeight_Val == fltrPixels
			# >=
			if OptzmGrp.enum_OptTex_Filter_PxCondition == "Op2":
				widthMatch = item.itemList_TexSizeWidth_Val >= fltrPixels
				heightMatch = item.itemList_TexSizeHeight_Val >= fltrPixels
			# <=
			if OptzmGrp.enum_OptTex_Filter_PxCondition == "Op3":
				widthMatch = item.itemList_TexSizeWidth_Val <= fltrPixels
				heightMatch = item.itemList_TexSizeHeight_Val <= fltrPixels
			# >
			if OptzmGrp.enum_OptTex_Filter_PxCondition == "Op4":
				widthMatch = item.itemList_TexSizeWidth_Val > fltrPixels
				heightMatch = item.itemList_TexSizeHeight_Val > fltrPixels
			# <
			if OptzmGrp.enum_OptTex_Filter_PxCondition == "Op5":
				widthMatch = item.itemList_TexSizeWidth_Val < fltrPixels
				heightMatch = item.itemList_TexSizeHeight_Val < fltrPixels

			if not widthMatch and not heightMatch:
				matchFltrPixels = False

		if matchFltrFormat and matchFltrPixels:
			# Add item with data to Filtered list
			item_Filtered = bpy.context.scene.coll_Tex_ListTex_Filtered.add()
			item_Filtered.item_List_Idx = item.item_List_Idx
			item_Filtered.itemList_TexModify = item.itemList_TexModify
			item_Filtered.itemList_TexImgData = item.itemList_TexImgData
			item_Filtered.itemList_TexIsSingleImg = item.itemList_TexIsSingleImg
			item_Filtered.itemList_MatName = item.itemList_MatName
			item_Filtered.itemList_TexName = item.itemList_TexName
			item_Filtered.itemList_TexSizePx = item.itemList_TexSizePx
			item_Filtered.itemList_TexSizeWidth_Val = item.itemList_TexSizeWidth_Val
			item_Filtered.itemList_TexSizeHeight_Val = item.itemList_TexSizeHeight_Val
			item_Filtered.itemList_TexSizeDisk = item.itemList_TexSizeDisk
			item_Filtered.itemList_TexSizeDisk_Val = item.itemList_TexSizeDisk_Val
			item_Filtered.itemList_TexFormat = item.itemList_TexFormat
			item_Filtered.itemList_TexLinked = item.itemList_TexLinked
			item_Filtered.itemList_TexVRam = item.itemList_TexVRam
			item_Filtered.itemList_TexVRam_Val = item.itemList_TexVRam_Val

			# Save materials data
			for item in item.itemList_CollMatsData:
				itemMat = item_Filtered.itemList_CollMatsData.add()
				itemMat.itemList_MatData = item.itemList_MatData

			# Update totals
			totalTexturesFound += 1

			# Update textures to modify
			if item_Filtered.itemList_TexModify:
				textures_slctToModify += 1

			totalDiskSize += item_Filtered.itemList_TexSizeDisk_Val
			totalVRamSize += item_Filtered.itemList_TexVRam_Val
		
	suspendUpdate_TexModify = False

	# UI totals
	bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalTextures = str(totalTexturesFound)
	bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalDiskSize = f"{round(totalDiskSize,2)} MB"
	bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalVRamSize = f"{round(totalVRamSize,2)} MB"

	bpy.context.scene.optimizePropertyGrp.str_OptTex_TexSlctdFromList = str(textures_slctToModify)

def Deo_Opt_Tex_UpdateTexturesList(_self):
	bpy.context.scene.coll_Tex_ListTex.clear()

	meshesToAnalyze = []

	#All scene
	if bpy.context.scene.optimizePropertyGrp.enum_OptTex_SelectMode == "Op1":
		if len([obj for obj in bpy.context.scene.objects if obj.type == 'MESH']) > 0:
			meshesToAnalyze = [obj for obj in bpy.data.objects if obj.type == 'MESH']
		else:
			#Clean variables
			bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalTextures = "0"
			bpy.context.scene.coll_Tex_ListTex.clear()
			
			_self.report({'WARNING'}, "[ No Textures in scene ]")
	#Selected
	elif bpy.context.scene.optimizePropertyGrp.enum_OptTex_SelectMode == "Op2":
		if len(bpy.context.selected_objects) > 0:
			meshesToAnalyze = bpy.context.selected_objects
		else:
			#Clean variables
			bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalTextures = "0"
			bpy.context.scene.coll_Tex_ListTex.clear()

			_self.report({'WARNING'}, "[ No Meshes Selected ]")
			return {'FINISHED'}				

	#Collection
	elif bpy.context.scene.optimizePropertyGrp.enum_OptTex_SelectMode == "Op3":
		if bpy.context.scene.optimizePropertyGrp.pntr_OptTex_Collect != None:
			meshesToAnalyze = GetAllMeshesFromColl(bpy.context.scene.optimizePropertyGrp.pntr_OptTex_Collect)
		else:
			#Clean variables
			bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalTextures = "0"
			bpy.context.scene.coll_Tex_ListTex.clear()

			_self.report({'WARNING'}, "[ Need to Load a Collection ]")
			return {'FINISHED'}

	#Get textures list
	if len(meshesToAnalyze) > 0:
		totalTexturesFound = 0
		totalDiskSize = 0
		totalVRamSize = 0

		idxTex = 0

		# Analize each mesh
		for mesh in meshesToAnalyze:

			# Get textures from mesh´s materials
			texturesData = Deo_Opt_Tex_GetTexturesFromMesh(mesh)

			if len(texturesData) > 0:
				existing_items = {item.itemList_TexName: item for item in bpy.context.scene.coll_Tex_ListTex}

				# Analize each texture
				for texture in texturesData:

					#Check if texture is not already in list to add
					tex_name = texture["image_name"]
					if tex_name not in existing_items:
						
						# Add item with data to list
						item = bpy.context.scene.coll_Tex_ListTex.add()
						item.item_List_Idx = idxTex
						item.itemList_TexImgData = texture["image_data"]
						item.itemList_TexIsSingleImg = texture["is_image_from_disk"]
						item.itemList_MatName = texture["materials_name"]
						item.itemList_TexName = texture["image_name"]
						item.itemList_TexSizePx = texture["size_px"] if texture["size_width"] > 0 and texture["size_height"] > 0 else "--"
						item.itemList_TexSizeWidth_Val = texture["size_width"]
						item.itemList_TexSizeHeight_Val = texture["size_height"]
						item.itemList_TexSizeDisk = str(texture["size_disk"] if texture["size_disk"] > 0 else "--") + " MB"
						item.itemList_TexSizeDisk_Val = texture["size_disk"]
						item.itemList_TexFormat = texture["format"]
						item.itemList_TexLinked = texture["linked"]
						item.itemList_TexVRam = str(texture["vRam"] if texture["vRam"] > 0 else "--") + " MB"
						item.itemList_TexVRam_Val = texture["vRam"]

						# Save materials data
						for mat in texture["materials_data"]:
							itemMat = item.itemList_CollMatsData.add()
							itemMat.itemList_MatData = mat
						#Update totals
						totalTexturesFound += 1
						idxTex += 1
						totalDiskSize += item.itemList_TexSizeDisk_Val
						totalVRamSize += float(texture["vRam"])

		# UI totals
		bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalTextures = str(totalTexturesFound)
		bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalDiskSize = f"{round(totalDiskSize,2)} MB"
		bpy.context.scene.optimizePropertyGrp.str_OptTex_TotalVRamSize = f"{round(totalVRamSize,2)} MB"

		# Clean UI Resizer
		bpy.context.scene.optimizePropertyGrp.str_OptTex_TexSlctdFromList = "0"

		_self.report({'INFO'}, f"[ {len(bpy.context.scene.coll_Tex_ListTex)} Textures found ]")

class Deo_Opt_OperTex_SelectUnselect(Operator):
	bl_idname = "deo.opt_tex_select_unselect"
	bl_label = ""
	bl_description = "Select/Unselect all textures"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		global suspendUpdate_TexModify

		scene = _context.scene
		OptzmGrp = _context.scene.optimizePropertyGrp

		# Avoid recursion
		suspendUpdate_TexModify = True

		# Select / Unselect
		OptzmGrp.bool_OptTex_Selection = not OptzmGrp.bool_OptTex_Selection

		# Select collection: All / Filtered
		collTextures = scene.coll_Tex_ListTex_Filtered if areFiltersActive else scene.coll_Tex_ListTex

		# Apply select / Unselect all
		totalTexSelected = 0
		for item in collTextures:
			# Avoid selected textures generated in blender
			if not item.itemList_TexIsSingleImg:
				continue

			item.itemList_TexModify = OptzmGrp.bool_OptTex_Selection
			
			if item.itemList_TexModify:
				totalTexSelected += 1

		# Set UI number
		OptzmGrp.str_OptTex_TexSlctdFromList = str(totalTexSelected)

		suspendUpdate_TexModify = False

		return {'FINISHED'}
	

class Deo_Opt_OperTex_FillList(Operator):
	bl_idname = "deo.opt_tex_fill_list"
	bl_label = ""
	bl_description = "Get All Textures (Single Image) from Materials"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		Deo_Opt_Tex_UpdateTexturesList(_self)

		return {'FINISHED'}
#endregion
	
#region [ BTN CLEAN LIST ]
class Deo_Opt_OperTex_CleanList(Operator):
	bl_idname = "deo.opt_tex_cleanlist"
	bl_label = ""
	bl_description = "Clean items from list"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		bpy.context.scene.coll_Tex_ListTex.clear()
		bpy.context.scene.coll_Tex_ListTex_Filtered.clear()

		bpy.context.scene.optimizePropertyGrp.enum_OptTex_Filter_Format = "Op1"
		bpy.context.scene.optimizePropertyGrp.enum_OptTex_Filter_Pixels = "Op1"

		return {'FINISHED'}
#endregion
	
#region [ MENU RESIZER ]
class Deo_Opt_OperTex_ShowHideMenuResizer(Operator):
	bl_idname = "deo.opt_tex_showhidemenuresizer"
	bl_label = ""
	bl_description = "Show/Hide Menu Resizer"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		bpy.context.scene.optimizePropertyGrp.bool_OptTex_MenuResizerIsActive = not bpy.context.scene.optimizePropertyGrp.bool_OptTex_MenuResizerIsActive
		return {'FINISHED'}

def Deo_Opt_Tex_OnSlctTexToModify(self, context):
	global areFiltersActive
	global suspendUpdate_TexModify

	# Avoid recursion
	if suspendUpdate_TexModify:
		return

	scene = context.scene
	OptimizeGrp = scene.optimizePropertyGrp

	# Get number of textures to modified
	totalTexSelected = 0

	# Select collection: All / Filtered
	collTextures = scene.coll_Tex_ListTex_Filtered if areFiltersActive else scene.coll_Tex_ListTex

	for item in collTextures:
		if item.itemList_TexModify:
			totalTexSelected += 1

		# Sync same textures selected in both list (All / Filtered)
		if areFiltersActive:
			suspendUpdate_TexModify = True
			idItem = item.item_List_Idx

			for item_listComplete in scene.coll_Tex_ListTex:
				if item_listComplete.item_List_Idx == idItem:
					item_listComplete.itemList_TexModify = item.itemList_TexModify

			
	# Set UI number
	OptimizeGrp.str_OptTex_TexSlctdFromList = str(totalTexSelected)
	suspendUpdate_TexModify = False

def Deo_Opt_Tex_GetSizePixelsByEnum(_option)-> int:
	if _option == 'Op1':
		return 256
	elif _option == 'Op2':
		return 512
	elif _option == 'Op3':
		return 1024
	elif _option == 'Op4':
		return 2048
	elif _option == 'Op5':
		return 4096
	
def Deo_Opt_Tex_IsImageExists(image: bpy.types.Image) -> bool:
	# Path is valid
	if not image.filepath_raw:
		return False

	# Relative to absolute
	abs_path = bpy.path.abspath(image.filepath_raw)

	return os.path.exists(abs_path)

def Deo_Opt_Tex_GetExtensionFromImage(_enumFormat):
	format_map = {
		'PNG': '.png',
		'JPEG': '.jpg',
		'TARGA': '.tga',
		'OPEN_EXR': '.exr',
		'OPEN_EXR_MULTILAYER': '.exr',
		'HDR': '.hdr',
		'TIFF': '.tiff',
		'WEBP': '.webp',
		'BMP': '.bmp',
		'CINEON': '.cin',
		'DPX': '.dpx'
	}
	
	return format_map[_enumFormat]

def Deo_Opt_Tex_Resize(_img, _width: int, _height: int, _overwrite: bool):
	if _overwrite:
		# Unpack
		if _img.packed_file:
			_img.unpack(method = 'USE_LOCAL')

		# Resize
		_img.scale(_width, _height)

		# Save
		_img.save()
	else:
		global imgCopyResized

		# Scale a copy of the original
		copyImg = _img.copy()

		# Get path
		directory = os.path.dirname(copyImg.filepath_raw)

		# Get name & extension
		orig_name, extension = os.path.splitext(os.path.basename(copyImg.filepath))

		# Rename
		new_name = f"{orig_name}_Resized__{_width}x{_height}{extension}"
		copyImg.name = new_name

		# Final path
		path_toSave = os.path.join(directory, new_name)

		# Resize
		copyImg.scale(_width, _height)

		# Save
		copyImg.save(filepath = path_toSave)

		# Global Variable
		imgCopyResized = copyImg

def Deo_Opt_Tex_ReplaceNodeTexture(_newImage, _mat, _currentNameTex):
	tex_node = None

	# Find tex node
	for node in _mat.node_tree.nodes:
		if node.type == 'TEX_IMAGE' and node.image and node.image.name == _currentNameTex:
			tex_node = node
	
	# Replace texture with resized texture
	tex_node.name = _newImage.name
	tex_node.label = _newImage.name
	tex_node.image = _newImage

class Deo_Opt_OperTex_ResizeImage(Operator):
	bl_idname = "deo.opt_tex_resizeimage"
	bl_label = ""
	bl_description = "Change Size Pixels from selected textures"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		scene = _context.scene
		OptimizeGrp = scene.optimizePropertyGrp

		# Get size from dropdowns
		width = 0
		height = 0

		if OptimizeGrp.bool_OptTex_Square:
			width = Deo_Opt_Tex_GetSizePixelsByEnum(OptimizeGrp.enum_OptTex_SelectSize_Square)
			height = Deo_Opt_Tex_GetSizePixelsByEnum(OptimizeGrp.enum_OptTex_SelectSize_Square)
		else:
			width = Deo_Opt_Tex_GetSizePixelsByEnum(OptimizeGrp.enum_OptTex_SelectSize_Width)
			height = Deo_Opt_Tex_GetSizePixelsByEnum(OptimizeGrp.enum_OptTex_SelectSize_Height)

		# Resize		
		numImgModified = 0

		# Select collection: All / Filtered
		collTextures = scene.coll_Tex_ListTex_Filtered if areFiltersActive else scene.coll_Tex_ListTex

		for item in collTextures:
			if item.itemList_TexModify: # Check if item is selected in list
				image = item.itemList_TexImgData # Get image

				# Resize
				Deo_Opt_Tex_Resize(image, width, height, OptimizeGrp.bool_OptTex_Overwrite)

				if not OptimizeGrp.bool_OptTex_Overwrite:
					global imgCopyResized

					# Replace texture to mats nodes
					for itemMat in item.itemList_CollMatsData: # Get materials
						Deo_Opt_Tex_ReplaceNodeTexture(imgCopyResized, itemMat.itemList_MatData, image.name)

				numImgModified += 1

		# Update list
		Deo_Opt_Tex_UpdateTexturesList(_self)

		# Filters
		Deo_Opt_Tex_OnUpdateFilters(_self, _context)

		_self.report({'INFO'}, f"[ {numImgModified} Textures resized ]")

		return {'FINISHED'}
	

def Deo_Opt_Tex_ChangeFormat(_img, _new_ext: str, _overwrite: bool):
	
	valid_formats = {
		"png": "PNG",
		"jpg": "JPEG",
		"tga": "TARGA",
		"exr": "OPEN_EXR"
	}

	new_ext = _new_ext.lower()

	# Get directory
	directory = os.path.dirname(bpy.path.abspath(_img.filepath_raw))

	# Get original name
	orig_name, _ = os.path.splitext(os.path.basename(_img.filepath_raw))

	if _overwrite:
		# Overwrite original file
		new_name = f"{orig_name}.{new_ext}"
		
		# Avoid duplicates
		if new_name in bpy.data.images:				
			old_img = bpy.data.images[new_name]
			bpy.data.images.remove(old_img)

		new_path = os.path.join(directory, orig_name + "." + new_ext)

		# Unpack
		if _img.packed_file:
			_img.unpack(method = 'USE_LOCAL')

		_img.name = new_name
		_img.file_format = valid_formats[new_ext]
		_img.filepath_raw = new_path

		# Save
		_img.save()

		return _img
	else:
		# Create a new file: Copy Image

		new_name = f"{orig_name}.{new_ext}" if "_Converted" in orig_name else f"{orig_name}_Converted.{new_ext}"
		
		new_img = bpy.data.images.new(name = new_name, width=_img.size[0], height=_img.size[1], alpha=True)
		new_img.pixels = _img.pixels[:] # Pixels

		
		new_path = os.path.join(directory, new_name)

		new_img.name = new_name
		new_img.filepath_raw = new_path
		new_img.file_format = valid_formats[new_ext]

		# Save
		new_img.save()

		return new_img

def Deo_Opt_Tex_ProcessTexturesToReFormat(_self,_context, _extension: str):
	global areFiltersActive

	scene = _context.scene
	OptimizeGrp = scene.optimizePropertyGrp

	numImgModified = 0

	# Select collection: All / Filtered
	collTextures = scene.coll_Tex_ListTex_Filtered if areFiltersActive else scene.coll_Tex_ListTex

	for item in collTextures:
		if item.itemList_TexModify: # Check if item is selected in list
			image = item.itemList_TexImgData # Get image

			# Change format
			newImg = Deo_Opt_Tex_ChangeFormat(image, _extension, OptimizeGrp.bool_OptTex_Overwrite)

			# Replace texture to mats nodes
			for itemMat in item.itemList_CollMatsData: # Get materials
				Deo_Opt_Tex_ReplaceNodeTexture(newImg, itemMat.itemList_MatData, image.name)

			numImgModified += 1

	# Update list
	Deo_Opt_Tex_UpdateTexturesList(_self)

	# Filters
	Deo_Opt_Tex_OnUpdateFilters(_self, _context)

	_self.report({'INFO'}, f"[ {numImgModified} Textures were modified ]")

	return {'FINISHED'}

class Deo_Opt_OperTex_Changeformat(Operator):
	bl_idname = "deo.opt_tex_changeformat"
	bl_label = ""
	bl_description = "Change format of selected textures"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		scene = _context.scene
		OptimizeGrp = scene.optimizePropertyGrp

		if OptimizeGrp.enum_OptTex_TexFormat == "Op1":
			Deo_Opt_Tex_ProcessTexturesToReFormat(_self,_context,"png")
		elif OptimizeGrp.enum_OptTex_TexFormat == "Op2":
			Deo_Opt_Tex_ProcessTexturesToReFormat(_self,_context, "jpg")
		elif OptimizeGrp.enum_OptTex_TexFormat == "Op3":
			Deo_Opt_Tex_ProcessTexturesToReFormat(_self,_context, "tga")
		elif OptimizeGrp.enum_OptTex_TexFormat == "Op4":
			Deo_Opt_Tex_ProcessTexturesToReFormat(_self,_context, "exr")

		return {'FINISHED'}
	
#endregion

#-----------------------------#
# ****** UTILITIES ******
#-----------------------------#

def GetAllMeshesFromColl(collection):
	#Search recursively all meshes from collection (include sub collections)
	
	meshes = []

	meshes.extend([obj for obj in collection.objects if obj.type == 'MESH'])

	# Check subcollections 
	for subcol in collection.children:
		meshes.extend(GetAllMeshesFromColl(subcol))
	
	return meshes