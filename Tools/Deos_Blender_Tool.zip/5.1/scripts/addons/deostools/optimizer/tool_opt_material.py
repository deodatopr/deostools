#------------------------------------------------
# TOOL OPTIMIZER SCENE
#------------------------------------------------

# Python
import bpy

# Operadores
from bpy.types import Operator

#-----------------------------#
#	  	 SCENE HANDLER		  #
#-----------------------------#

def Opt_Clear_OnLoadBlendFile():
	bpy.context.scene.optimizePropertyGrp.str_MatToMsh_TotalMshsByMat = str(0)
	bpy.context.scene.coll_MatToMsh_ListMesh.clear()
	bpy.context.scene.int_MatToMsh_ListActiveIndex = 0

	bpy.context.scene.coll_MshMatInfo_ListMats.clear()
	bpy.context.scene.int_MshMatInfo_ListActiveIndex = 0

	bpy.context.scene.coll_MshMatCleaner_ListMshes.clear()
	bpy.context.scene.int_MshMatCleaner_ListActiveIndex = 0

	bpy.context.scene.coll_MshMatsEmissive_ListMshes.clear()
	bpy.context.scene.int_MshMatsEmissive_ListActiveIndex = 0


#-------------------------------------#
#	  	SELECT MESH(ES) BY MATERIAL	  #
#-------------------------------------#

def Deo_Opt_Mats_MshFromMat_OnUpdateIndexList(self, context):
	if len(bpy.context.scene.coll_MatToMsh_ListMesh) == 0:
		return

	scene = context.scene

	# Get selected mesh
	index = scene.int_MatToMsh_ListActiveIndex
	obj_name = scene.coll_MatToMsh_ListMesh[index].itemList_Name
	obj = bpy.data.objects.get(obj_name)

	if not obj:
		self.report({'WARNING'}, f"Objeto '{obj_name}' no encontrado")
		return {'CANCELLED'}

	# Select mesh from list
	bpy.ops.object.select_all(action='DESELECT')
	obj.select_set(True)
	bpy.context.view_layer.objects.active = obj

def Opt_Mats_MshFromMat_FindMeshes():
	# Get the selected material
	mat = bpy.context.scene.optimizePropertyGrp.pntr_MatToMsh_Picker

	bpy.ops.object.select_all(action='DESELECT') 

	meshes_found = 0
	for msh in bpy.data.objects:
		if msh.type == 'MESH':
			if mat.name in [mat.name for mat in msh.data.materials if mat is not None]:
				msh.select_set(True)
				meshes_found += 1


	# Fill Scroll Panel
	objects_list = []
	for obj in bpy.context.scene.objects:
		if obj.type == 'MESH' and obj.data.materials:
			if any(m == mat for m in obj.data.materials):
				objects_list.append(obj.name)
	
	bpy.context.scene.coll_MatToMsh_ListMesh.clear()
	
	# Add items to list
	for name in objects_list:
		item = bpy.context.scene.coll_MatToMsh_ListMesh.add()
		item.itemList_Name = name

	bpy.context.scene.optimizePropertyGrp.str_MatToMsh_TotalMshsByMat = str(meshes_found)

class Deo_Opt_OperMats_MshFromMat_FindMeshes (Operator):
	bl_idname = "deo.opt_mshfrommat_findmeshes"
	bl_label = ""
	bl_description = "Find and select all meshes using the selected material"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		if bpy.context.scene.optimizePropertyGrp.pntr_MatToMsh_Picker != None:
			Opt_Mats_MshFromMat_FindMeshes()
		else:
			#Clean variables
			bpy.context.scene.int_MatToMsh_ListActiveIndex = 0
			bpy.context.scene.coll_MatToMsh_ListMesh.clear()
			bpy.context.scene.optimizePropertyGrp.str_MatToMsh_TotalMshsByMat = str(0)
			
			_self.report({'WARNING'}, "[ Need to Load a Material ]")

		return {'FINISHED'}
	
class Deo_Opt_OperMats_MshFromMat_Clean(Operator):
	bl_idname = "deo.opt_mat_mshfrommat_clean"
	bl_label = ""
	bl_description = "Clean instances list"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		bpy.context.scene.coll_MatToMsh_ListMesh.clear()
		bpy.context.scene.optimizePropertyGrp.str_MatToMsh_TotalMshsByMat = "0"

		return {'FINISHED'}

#-------------------------------------#
#	  	MATERIALS BY MESH			  #
#-------------------------------------#

def Opt_Mats_MshMatsInfo_GetMats(_mesh):
	bpy.context.scene.coll_MshMatInfo_ListMats.clear()
	materials_found = 0

	mats = [mat for mat in _mesh.data.materials if mat is not None]
	for mat in mats:

		numMapsUsed = 0
		numMapsUnused = 0

		# Check if nodes textures are being used
		for node in mat.node_tree.nodes:
			if isinstance(node, bpy.types.ShaderNodeTexImage): # Check if its a texture node
				for output in node.outputs:
					if node.image and output.is_linked: #Check if an image is loaded and linked
						numMapsUsed += 1
					elif node.image and not output.is_linked:
						numMapsUnused += 1
						break
		
		# Add item to list with its data
		item = bpy.context.scene.coll_MshMatInfo_ListMats.add()
		item.itemList_Name = mat.name
		item.itemList_MapsInUse = str(numMapsUsed)
		item.itemList_MapsUnused = str(numMapsUnused)

		materials_found += 1

	bpy.context.scene.optimizePropertyGrp.str_MshMatsInfo_TotalMats = str(materials_found)

class Deo_Opt_OperMats_MshMatsInfo_Pntr (Operator):
	bl_idname = "deo.opt_mshmatsinfo_analize_pntr"
	bl_label = ""
	bl_description = "Analize materials from Mesh"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		if bpy.context.scene.optimizePropertyGrp.pntr_MshMatsInfo_Picker != None:
			Opt_Mats_MshMatsInfo_GetMats(bpy.context.scene.optimizePropertyGrp.pntr_MshMatsInfo_Picker)
		else:
			#Clean variables
			bpy.context.scene.int_MshMatInfo_ListActiveIndex = 0
			bpy.context.scene.coll_MshMatInfo_ListMats.clear()
			bpy.context.scene.optimizePropertyGrp.str_MshMatsInfo_TotalMats = "0"
			
			_self.report({'WARNING'}, "[ Need to Load a Mesh ]")

		return {'FINISHED'}
	
class Deo_Opt_OperMats_MshMatsInfo_Selctd (Operator):
	bl_idname = "deo.opt_mshmatsinfo_analize_selctd"
	bl_label = ""
	bl_description = "Analize materials from Mesh"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		if bpy.context.active_object != None:
			Opt_Mats_MshMatsInfo_GetMats(bpy.context.active_object)
		else:
			bpy.context.scene.optimizePropertyGrp.str_MshMatsInfo_TotalMats = "0"
			_self.report({'WARNING'}, "[ Need to Select a Mesh ]")

		return {'FINISHED'}
	
class Deo_Opt_OperMats_MshMatsInfo_Clean(Operator):
	bl_idname = "deo.opt_mat_mshmatinfo_clean"
	bl_label = ""
	bl_description = "Clean instances list"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(self, context):
		bpy.context.scene.coll_MshMatInfo_ListMats.clear()
		bpy.context.scene.optimizePropertyGrp.str_MshMatsInfo_TotalMats = "0"

		return {'FINISHED'}
	
#-------------------------------------#
#	  	MATERIALS CLEANER			  #
#-------------------------------------#
def Deo_Opt_Mats_Clean_OnUpdateIndexList(self, context):

	scene = context.scene

	# Exit if list is empty
	if len(bpy.context.scene.coll_MshMatCleaner_ListMshes) == 0:
		return
	
	# Get selected mesh
	index = scene.int_MshMatCleaner_ListActiveIndex
	obj_name = scene.coll_MshMatCleaner_ListMshes[index].itemList_Name
	obj = bpy.data.objects.get(obj_name)

	if not obj:
		self.report({'WARNING'}, f"Objeto '{obj_name}' no encontrado")
		return {'CANCELLED'}

	# Select mesh from list
	bpy.ops.object.select_all(action='DESELECT')
	obj.select_set(True)
	bpy.context.view_layer.objects.active = obj

def Deo_Opt_Mats_Clean_GetMeshes(_meshes):
	bpy.context.scene.coll_MshMatCleaner_ListMshes.clear()

	thereAreEmptySlots = False

	for mesh in _meshes:
		matsInMsh = mesh.material_slots
		meshHasEmptySlots = False
		empty_slots = []
		numEmptySlots = 0

		# Check if mesh has empty slots
		for i, slot in enumerate(matsInMsh):	# Enumerator (index, obj)
			if slot.material == None:
				empty_slots.append(i)	# Save Index from empty slot
				meshHasEmptySlots = True  
				numEmptySlots += 1 

		# Add item to list and its data
		if meshHasEmptySlots:
			item = bpy.context.scene.coll_MshMatCleaner_ListMshes.add()
			item.itemList_Name = mesh.name
			item.itemList_EmptySlots = str(numEmptySlots)
			thereAreEmptySlots = True

	return thereAreEmptySlots

def Deo_Opt_Mats_Clean_CleanMeshSlots(_mesh):
	matsInMsh = _mesh.material_slots
	empty_slots = []

	# Select mesh
	bpy.ops.object.select_all(action='DESELECT')
	_mesh.select_set(True)
	bpy.context.view_layer.objects.active = _mesh

	# Check and save index of empty slots
	for i, slot in enumerate(matsInMsh):
		if slot.material == None:
			empty_slots.append(i)

	slotsToRemove = len(empty_slots)

	# Remove empty slots
	if empty_slots:
		for ids in reversed(empty_slots):		   
			_mesh.active_material_index = ids
			bpy.ops.object.material_slot_remove()

	return slotsToRemove

def Deo_Opt_Mats_Clean_FindIdxMshInColl(_mesh):
	# Get index of mesh in collection list to remove
	for i, msh in enumerate(bpy.context.scene.coll_MshMatCleaner_ListMshes):
		if msh.itemList_Name == _mesh.name:
			return i

class Deo_Opt_OperMats_Clean_GetMeshes (Operator):
	bl_idname = "deo.opt_mshmatcleaner_getmeshes"
	bl_label = ""
	bl_description = "Analize meshes"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		meshes_in_scene = [obj for obj in bpy.data.objects if obj.type == 'MESH']

		if len(meshes_in_scene) > 0:
			#Find all meshes with empty materials
			thereAreEmptySlots = Deo_Opt_Mats_Clean_GetMeshes(meshes_in_scene)

			if not thereAreEmptySlots:
				_self.report({'INFO'}, "[ NO EMPTY SLOTS IN SCENE ]")
		else:
			_self.report({'WARNING'}, "[ No MESHES FOUND IN SCENE ]")

		return {'FINISHED'}
	

class Deo_Opt_OperMats_Clean_Selected (Operator):
	bl_idname = "deo.clean_selected"
	bl_label = ""
	bl_description = "Clean the selected item from the list"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		scene = _context.scene
		if scene.int_MshMatCleaner_ListActiveIndex < 0:
			_self.report({'WARNING'}, "[ Need to select an item from the list ]")
			return {'CANCELLED'}

		# Get selected mesh
		index = scene.int_MshMatCleaner_ListActiveIndex
		msh_name = scene.coll_MshMatCleaner_ListMshes[index].itemList_Name
		msh = bpy.data.objects.get(msh_name)

		# Remove empty materials		
		slotsCleaned = Deo_Opt_Mats_Clean_CleanMeshSlots(msh)

		# Remove item from list
		idxMeshInColl = Deo_Opt_Mats_Clean_FindIdxMshInColl(msh)
		scene.coll_MshMatCleaner_ListMshes.remove(idxMeshInColl)

		# Update list
		meshes_in_scene = [obj for obj in bpy.data.objects if obj.type == 'MESH']
		Deo_Opt_Mats_Clean_GetMeshes(meshes_in_scene)

		# Update index list
		if scene.coll_MshMatCleaner_ListMshes:
			scene.int_MshMatCleaner_ListActiveIndex = max(0,min(len(scene.coll_MshMatCleaner_ListMshes)-1,idxMeshInColl - 1))
			Deo_Opt_Mats_Clean_OnUpdateIndexList(_self,_context)

		_self.report({'INFO'}, f"[ {slotsCleaned} SLOTS WERE CLEANED ]")

		return {'FINISHED'}
	

class Deo_Opt_OperMats_Clean_Scene(Operator):
	bl_idname = "deo.clean_scene"
	bl_label = ""
	bl_description = "Clean the complete scene"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		meshes_in_scene = [obj for obj in bpy.data.objects if obj.type == 'MESH']

		if len(meshes_in_scene) > 0:
			for msh in meshes_in_scene:
				Deo_Opt_Mats_Clean_CleanMeshSlots(msh)

			bpy.context.scene.coll_MshMatCleaner_ListMshes.clear()

			_self.report({'INFO'}, "[ ALL EMPTY MATERIAL WERE CLEANED ]")
		else:
			_self.report({'WARNING'}, "[ NO MESHES IN SCENE ]")

		return {'FINISHED'}
	
#-------------------------------------#
#	  	EMISSIVE MATERIALS			  #
#-------------------------------------#
def Deo_Opt_Mats_Emissive_OnUpdateIndexList(self, context):

	scene = context.scene

	# Exit if list is empty
	if len(bpy.context.scene.coll_MshMatsEmissive_ListMshes) == 0:
		return
	
	# Get selected mesh
	index = scene.int_MshMatsEmissive_ListActiveIndex
	obj_name = scene.coll_MshMatsEmissive_ListMshes[index].itemList_Name
	obj = bpy.data.objects.get(obj_name)

	if not obj:
		self.report({'WARNING'}, f"Objeto '{obj_name}' no encontrado")
		return {'CANCELLED'}

	# Select mesh from list
	bpy.ops.object.select_all(action='DESELECT')
	obj.select_set(True)
	bpy.context.view_layer.objects.active = obj

	# Asegura que el modo de objeto esté en 'OBJECT' (necesario para que las propiedades se actualicen bien)
	if bpy.ops.object.mode_set.poll():
		bpy.ops.object.mode_set(mode='OBJECT')

class Deo_Opt_OperMats_GetEmissiveMats_Clean(Operator):
	bl_idname = "deo.opt_mat_emission_mshs_clean"
	bl_label = ""
	bl_description = "Clean list"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		# Clear list
		bpy.context.scene.coll_MshMatsEmissive_ListMshes.clear()
		return {'FINISHED'}


class Deo_Opt_OperMats_GetEmissiveMats(Operator):
	bl_idname = "deo.opt_mat_emission_mshs"
	bl_label = ""
	bl_description = "Clean the complete scene"
	bl_options = {'REGISTER', 'UNDO'}

	def execute(_self, _context):
		OptmzPropertyGrp = _context.scene.optimizePropertyGrp

		# Clear list
		bpy.context.scene.coll_MshMatsEmissive_ListMshes.clear()

		# All scene
		if OptmzPropertyGrp.enum_EmissiveMshs_SelectMode == "Op1":
			mshInScene = [obj for obj in bpy.data.objects if obj.type == 'MESH']

			if len(mshInScene) > 0:

				for msh in mshInScene:
					FindEmissveMatsFromMesh(msh)

				_self.report({'INFO'}, f"[ {len(bpy.context.scene.coll_MshMatsEmissive_ListMshes)} MESHES WITH EMISSIVE MATERIAL WERE FOUND ]")
			else:
				_self.report({'WARNING'}, "[ NO MESHES IN SCENE ]")
		# Collection
		else:
			if bpy.context.scene.optimizePropertyGrp.pntr_EmissiveMshs_Collect != None:

				collection = OptmzPropertyGrp.pntr_EmissiveMshs_Collect
				mshInCollection = GetAllMeshesFromColl(collection)

				for msh in mshInCollection:
					FindEmissveMatsFromMesh(msh)

				_self.report({'INFO'}, f"[ {len(bpy.context.scene.coll_MshMatsEmissive_ListMshes)} MESHES WITH EMISSIVE MATERIAL WERE FOUND ]")
			
			else:
				_self.report({'WARNING'}, "[ Need to Load a Collection ]")


		return {'FINISHED'}
	
def FindEmissveMatsFromMesh(_msh):
	emissive_materials = []
	
	for slot in _msh.material_slots:
		mat = slot.material
		if not mat or not mat.use_nodes:
			continue
		
		for node in mat.node_tree.nodes:
			# Check emission node
			if node.type == 'EMISSION':
				emissive_materials.append(mat)
				break

			# Check BSDF node
			elif node.type == 'BSDF_PRINCIPLED':
				emission_strength_input = node.inputs.get('Emission Strength')
				if emission_strength_input and emission_strength_input.default_value > 0.0:
					emissive_materials.append(mat)
					break


	if emissive_materials:
		# Add item to list and its data
		item = bpy.context.scene.coll_MshMatsEmissive_ListMshes.add()
		item.itemList_Name = _msh.name

		material_names_str = ", ".join([mat.name for mat in emissive_materials])
		item.itemList_MatName = material_names_str


#-----------------------------#
# ****** UTILITIES ******
#-----------------------------#

def GetAllMeshesFromColl(collection):
	#Search recursively all meshes from collection (include sub collections)
	
	meshes = []

	meshes.extend([obj for obj in collection.objects if obj.type == 'MESH'])

	# Check subcollections 
	for subcol in collection.children:
		meshes.extend(GetAllMeshesFromColl(subcol))
	
	return meshes