#-----------------------------------------------------------------------------------------------
#  TOOL OPTIMIZER SCENE
#-----------------------------------------------------------------------------------------------

# region IMPORTS

# [Blender]
import bpy, os

# [Types]
from bpy.types import (Panel, Operator, PropertyGroup, UIList)

# [Props (UI)]
from bpy.props import (BoolProperty, IntProperty, FloatProperty, StringProperty, EnumProperty, CollectionProperty, PointerProperty)

# [Utilities (Icons)]
from bpy.utils import previews

# [ Handlers ]
from bpy.app.handlers import persistent

# [ OPERATORS ]
from .tool_opt_mesh import *
from .tool_opt_material import *
from .tool_opt_texture import *

#endregion

#-----------------------------------------------------------------------------------------------
# VARIABLES >> GLOBALS
#-----------------------------------------------------------------------------------------------

# region Paths
# pathAsset = bpy.utils.resource_path('USER') + "\\scripts\\addons\\deos_Optimize\\Name.ext"	# Blender Root
# pathAsset = os.path.dirname (__file__) + "Name.ext"																				 # Addon Root
# endregion

# region IconLibrary

iconInst = previews.new()
iconsPath = os.path.dirname(__file__) + "\\UI\\"
iconInst.load("MyIconTris_1", os.path.join(iconsPath, "Ico_tris_1.png"), 'IMAGE')
iconInst.load("MyIconTris_2", os.path.join(iconsPath, "Ico_tris_2.png"), 'IMAGE')
iconInst.load("MyIconTris_3", os.path.join(iconsPath, "Ico_tris_3.png"), 'IMAGE')
iconInst.load("MyIconTris_4", os.path.join(iconsPath, "Ico_tris_4.png"), 'IMAGE')
iconInst.load("MyIconTris_5", os.path.join(iconsPath, "Ico_tris_5.png"), 'IMAGE')
iconInst.load("MyIconTris_6", os.path.join(iconsPath, "Ico_tris_6.png"), 'IMAGE')

# endregion

#-----------------------------------------------------------------------------------------------
# PROPERTIES
#-----------------------------------------------------------------------------------------------

# region PROP LIST
class DEO_UL_Opt_CustomList_Mesh(UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			layout.label(text=item.itemList_Name, icon='OUTLINER_OB_MESH')

class DEO_UL_Opt_CustomList_TexturesNodes(UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			split = layout.split(factor=0.55, align=True)
			split.label(text=item.itemList_Name, icon='MATERIAL')

			split2 = split.split(factor=0.5, align=True)
			split2.label(text=item.itemList_MapsInUse, icon = 'LINKED')
			split2.label(text=item.itemList_MapsUnused, icon = 'UNLINKED')

class DEO_UL_Opt_CustomList_MshMats(UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			split = layout.split(factor=0.45, align=True)
			split.label(text=item.itemList_Name, icon='OUTLINER_OB_MESH')
			split.label(text=item.itemList_MatName, icon = 'MATERIAL')

class DEO_UL_Opt_CustomList_MshEmptyMats(UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			split = layout.split(factor=0.75, align=True)
			split.label(text=item.itemList_Name, icon='OUTLINER_OB_MESH')
			split.label(text=item.itemList_EmptySlots, icon = 'MATERIAL')

class DEO_UL_Opt_CustomList_Textures(UIList):
	def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
		if self.layout_type in {'DEFAULT', 'COMPACT'}:
			OptimizePropGrps = context.scene.optimizePropertyGrp

			split = layout.split(factor=0.1, align=True)

			# Check if texture is a single image (Not generated, sequence, etc.)
			if item.itemList_TexIsSingleImg:
				# Allow modify it
				split.prop(item,"itemList_TexModify")
			else:
				# Avoid modify it
				split.label(text="", icon='FILE_BLEND')

			# Check if there are filters active
			thereAreFilters = any([OptimizePropGrps.bool_OptTex_Attbt_Material,
									OptimizePropGrps.bool_OptTex_Attbt_SizePx,
									OptimizePropGrps.bool_OptTex_Attbt_Format,
									OptimizePropGrps.bool_OptTex_Attbt_Linked,
									OptimizePropGrps.bool_OptTex_Attbt_SizeDisk,
									OptimizePropGrps.bool_OptTex_Attbt_VRam])
			

			if thereAreFilters:
				# Create another split for the values

				split2 = split.split(factor=0.4, align=True)
				split2.label(text=item.itemList_TexName)

				# Attributes to show
				if OptimizePropGrps.bool_OptTex_Attbt_Material:
					split2.label(text=item.itemList_MatName)

				if OptimizePropGrps.bool_OptTex_Attbt_SizePx:
					split2.label(text=item.itemList_TexSizePx)

				if OptimizePropGrps.bool_OptTex_Attbt_Format:
					split2.label(text=item.itemList_TexFormat)

				if OptimizePropGrps.bool_OptTex_Attbt_Linked:
					if item.itemList_TexLinked == "Linked":
						split2.label(icon = 'LINKED')
					else:
						split2.label(icon = 'UNLINKED')

				if OptimizePropGrps.bool_OptTex_Attbt_SizeDisk:
					split2.label(text=item.itemList_TexSizeDisk)

				if OptimizePropGrps.bool_OptTex_Attbt_VRam:
					split2.label(text=item.itemList_TexVRam)
			else:
				# No filters active
				split.label(text=item.itemList_TexName)
# endregion

class Deo_PropertyGroup_Optimize_Tex_Mats (PropertyGroup):
	itemList_MatData : PointerProperty(
		type=bpy.types.Material,
		name="",
		description=""
	) # type: ignore

class Deo_PropertyGroup_Optimize (PropertyGroup):
#region [ LIST ]
	item_List_Idx : IntProperty (
		name="",
		description = "Element index",
		default=0,
	) # type: ignore

	itemList_Name: StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore

	itemList_MapsInUse: StringProperty (
		name="",
		description="Textures in use",
		default="0",
		maxlen=1024
	) # type: ignore

	itemList_MapsUnused: StringProperty (
		name="",
		description="Textures unplugged",
		default="0",
		maxlen=1024
	) # type: ignore

	itemList_EmptySlots: StringProperty (
		name="",
		description="Slots empty",
		default="0",
		maxlen=1024
	) # type: ignore

	itemList_TexImgData : PointerProperty(
		name = "",
		description = "Save image data",
		type = bpy.types.Image,
	) # type: ignore

	itemList_TexIsSingleImg : BoolProperty(
		name="",
		description="It is an image and it was loaded from disk",
		default=False,
	) # type: ignore

	itemList_TexModify : BoolProperty(
		name="",
		description="Can be modified",
		default=False,
		update = Deo_Opt_Tex_OnSlctTexToModify
	) # type: ignore

	itemList_MatName: StringProperty (
		name="",
		description="",
		default="Mat_Name",
		maxlen=1024
	) # type: ignore

	itemList_CollMatsData : CollectionProperty(
		type=Deo_PropertyGroup_Optimize_Tex_Mats,
		name="",
		description=""
	) # type: ignore

	itemList_TexName: StringProperty (
		name="",
		description="",
		default="Tex_Name",
		maxlen=1024
	) # type: ignore

	itemList_TexSizePx: StringProperty (
		name="",
		description="",
		default="XXX x XXX",
		maxlen=1024
	) # type: ignore

	itemList_TexSizeWidth_Val : IntProperty (
		name="",
		description = "Size width Px",
		default=0,
	) # type: ignore

	itemList_TexSizeHeight_Val : IntProperty (
		name="",
		description = "Size width Px",
		default=0,
	) # type: ignore

	itemList_TexSizeDisk: StringProperty (
		name="",
		description="",
		default="XXX",
		maxlen=1024
	) # type: ignore

	itemList_TexSizeDisk_Val: FloatProperty (
		name="",
		description="",
		default=0.0,
	) # type: ignore

	itemList_TexFormat: StringProperty (
		name="",
		description="",
		default="XXX",
		maxlen=1024
	) # type: ignore

	itemList_TexVRam: StringProperty (
		name="",
		description="",
		default="XXX",
		maxlen=1024
	) # type: ignore

	itemList_TexVRam_Val: FloatProperty (
		name="",
		description="",
		default=0.0,
	) # type: ignore

	itemList_TexLinked: StringProperty (
		name="",
		description="",
		default="XXX",
		maxlen=1024
	)# type: ignore
#endregion

#region [ MESHES ]

#region Visualize

	enum_OptVisCol_SelectMode : EnumProperty (
		name = "",
		description = "",
		items = 
			[ 
				('Op1', "Complete", "All meshes in the scene"), 
				('Op2', "Selected", "From the selected meshes"), 
				('Op3', "Collection", "From the loaded collection"), 
			],
		default = 'Op1',
	) # type: ignore

	pntr_OptVisCol_Collect : PointerProperty (
		name = "",
		description = "Load the Collection to analize",
		type = bpy.types.Collection,
	) # type: ignore
	
	str_OptVisCol_ObjAnalized : StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore

	str_OptVisCol_MinTris : StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore

	str_OptVisCol_MaxTris : StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore

	enum_OptVisCol_Colors : EnumProperty (
		name = "",
		description = "",
		items = 
			[ 
				# Val, Name, Desc, Icon, Index
				('Op1', "1", "", iconInst["MyIconTris_1"].icon_id, 1),
				('Op2', "2", "", iconInst["MyIconTris_2"].icon_id, 2),
				('Op3', "3", "", iconInst["MyIconTris_3"].icon_id, 3),
				('Op4', "4", "", iconInst["MyIconTris_4"].icon_id, 4),
				('Op5', "5", "", iconInst["MyIconTris_5"].icon_id, 5),
				('Op6', "6", "", iconInst["MyIconTris_6"].icon_id, 6),
			],
		default = 'Op1',
	) # type: ignore

	bool_OptVisCol_UseMaxTris : BoolProperty(
		name = "",
		description = "Use Custom Max Tris amount",
		default = False
	) # type: ignore

	int_OptVisCol_UseMaxTris : IntProperty (
		name="",
		description = "Use Custom Max Tris amount",
		default=0,
	) # type: ignore

	bool_OptVisCol_IsCleanerActive : BoolProperty(
		name = "",
		description = "Use Custom Max Tris amount",
		default = False 
	) # type: ignore

#endregion

# region PolyCount

	enum_OptPlyCnt_SelectMode : EnumProperty (
		name = "",
		description = "",
		items = 
			[ 
				('Op1', "Complete", "All meshes in the scene"), 
				('Op2', "Selected", "From the selected meshes"), 
				('Op3', "Collection", "From the loaded collection"), 
			],
		default = 'Op1',
	) # type: ignore
	
	pntr_OptPlyCnt_Collect : PointerProperty (
		name = "",
		description = "Load the Collection to analize",
		type = bpy.types.Collection,
	) # type: ignore
	
	enum_OptPlyCnt_Action : EnumProperty (
		name = "",
		description = "",
		items = 
			[ 
				('Op1', "<", "Tris amount Less than..."),
				('Op2', ">", "Tris amount Grather than..."), 
				('Op3', "=", "Tris amount Equal to.."), 
			],
		default = 'Op1',
	) # type: ignore
	
	int_OptPlyCnt_Amount : IntProperty (
		name="",
		description="",
		default=0,
	) # type: ignore

	str_OptPlyCnt_ObjSel : StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore


# endregion

# region Instances

	pntr_OptInstance_Picker : PointerProperty (
		name = "",
		description = "Load the Mesh to analize",
		type = bpy.types.Object,
	) # type: ignore
	
	str_OptInstance_TotalInst : StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024
	) # type: ignore

# endregion

#endregion

#region [ MATERIALS ]

#region MatToMesh
	pntr_MatToMsh_Picker : PointerProperty (
		name = "",
		description = "Load the material to analize",
		type = bpy.types.Material,
	) # type: ignore
	
	str_MatToMsh_TotalMshsByMat : StringProperty (
	name="",
	description="",
	default="0",
	maxlen=1024
	) # type: ignore
#endregion

#region MshMatsInfo
	pntr_MshMatsInfo_Picker : PointerProperty (
		name = "",
		description = "Load Mesh to analize",
		type = bpy.types.Object,
	) # type: ignore
	
	str_MshMatsInfo_TotalMats : StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024	
	) # type: ignore
#endregion

#region EmissiveMeshes
	enum_EmissiveMshs_SelectMode : EnumProperty (
		name = "",
		description = "",
		items = 
			[ 
				('Op1', "Complete", "All meshes in the scene"), 
				('Op2', "Collection", "From the loaded collection"), 
			],
		default = 'Op1',
	) # type: ignore

	pntr_EmissiveMshs_Collect : PointerProperty (
		name = "",
		description = "Load the Collection to analize",
		type = bpy.types.Collection,
	) # type: ignore
#endregion

#endregion

#region [ TEXTURES ]
	enum_OptTex_SelectMode : EnumProperty (
		name = "",
		description = "",
		items = 
			[ 
				('Op1', "Complete", "All meshes in the scene"), 
				('Op2', "Selected", "From the selected meshes"), 
				('Op3', "Collection", "From the loaded collection"), 
			],
		default = 'Op1',
	) # type: ignore

	pntr_OptTex_Collect : PointerProperty (
		name = "",
		description = "Load the Collection to analize",
		type = bpy.types.Collection,
	) # type: ignore

	bool_OptTex_MenuResizerIsActive: BoolProperty (
	name = "",
	description = "Menu resizer is being showed",
	default = False
  ) # type: ignore

	str_OptTex_TotalTextures: StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024	
	) # type: ignore

	str_OptTex_TotalDiskSize: StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024	
	) # type: ignore

	str_OptTex_TotalVRamSize: StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024	
	) # type: ignore

	str_OptTex_TexSlctdFromList: StringProperty (
		name="",
		description="",
		default="0",
		maxlen=1024	
	) # type: ignore

	bool_OptTex_Square: BoolProperty (
		name = "",
		description = "Size (px) of the texture",
		default = True
  	) # type: ignore
	
	bool_OptTex_Overwrite: BoolProperty (
		name = "",
		description = "[ (On) Overwrite texture |(Off) Create a new one, Ex. Texture_Resized.* ]",
		default = True
  	) # type: ignore
	
	bool_OptTex_Selection: BoolProperty (
		name = "",
		description = "[ Select / Unselect Textures from the list ]",
		default = False
 	 ) # type: ignore

	
	enum_OptTex_SelectSize_Square : EnumProperty (
		name = "",
		description = "Texture Width and Height (px)",
		items = 
			[ 
				('Op1', "256", ""), 
				('Op2', "512", ""), 
				('Op3', "1024", ""),
				('Op4', "2048", ""),
				('Op5', "4096", "")
			],
		default = 'Op1',
	) # type: ignore
	
	enum_OptTex_SelectSize_Width : EnumProperty (
		name = "",
		description = "Texture Width (px)",
		items = 
			[ 
				('Op1', "256", ""), 
				('Op2', "512", ""), 
				('Op3', "1024", ""),
				('Op4', "2048", ""),
				('Op5', "4096", "")
			],
		default = 'Op1',
	) # type: ignore

	enum_OptTex_SelectSize_Height : EnumProperty (
		name = "",
		description = "Texture Height (px)",
		items = 
			[ 
				('Op1', "256", ""), 
				('Op2', "512", ""), 
				('Op3', "1024", ""),
				('Op4', "2048", ""),
				('Op5', "4096", "")
			],
		default = 'Op1',
	) # type: ignore

	enum_OptTex_TexFormat : EnumProperty (
		name = "",
		description = "Texture Format",
		items = 
			[ 
				('Op1', "PNG", ""), 
				('Op2', "JPG", ""), 
				('Op3', "TGA", ""), 
				('Op4', "EXR", "")
			],
		default = 'Op1',
	) # type: ignore

	enum_OptTex_Filter_Format : EnumProperty (
		name = "",
		description = "Filter: Texture Format",
		items = 
			[ 
				('Op1', "All", ""), 
				('Op2', "PNG", ""), 
				('Op3', "JPG", ""), 
				('Op4', "TGA", ""), 
				('Op5', "EXR", ""),
				('Op6', "HDR", ""),
				('Op7', "WEBP", ""),
			],
		default = 'Op1',
		update=Deo_Opt_Tex_OnUpdateFilters
	) # type: ignore

	enum_OptTex_Filter_Pixels : EnumProperty (
		name = "",
		description = "Filter: Texture Size",
		items = 
			[ 
				('Op1', "All", ""), 
				('Op2', "256", ""), 
				('Op3', "512", ""), 
				('Op4', "1024", ""), 
				('Op5', "2048", ""),
				('Op6', "4096", "")
			],
		default = 'Op1',
		update=Deo_Opt_Tex_OnUpdateFilters
	) # type: ignore

	enum_OptTex_Filter_PxCondition : EnumProperty (
		name = "",
		description = "Filter: Texture Size Condition",
		items = 
			[ 
				('Op1', "=", ""),
				('Op2', ">=", ""),
				('Op3', "<=", ""), 
				('Op4', ">", ""),
				('Op5', "<", "")
			],
		default = 'Op1',
		update=Deo_Opt_Tex_OnUpdateFilters
	) # type: ignore


	bool_OptTex_Attbt_SizePx : BoolProperty (
		name = "",
		description = "Pixel size",
		default = True
	)# type: ignore

	bool_OptTex_Attbt_Material : BoolProperty (
		name = "",
		description = "Used in material",
		default = False
	)# type: ignore

	bool_OptTex_Attbt_Format : BoolProperty (
		name = "",
		description = "Format",
		default = False
	)# type: ignore

	bool_OptTex_Attbt_Linked : BoolProperty (
		name = "",
		description = "Linked/Unlinked in mat",
		default = False
	)# type: ignore

	bool_OptTex_Attbt_SizeDisk : BoolProperty (
		name = "",
		description = "Disk Size (MB)",
		default = True
	)# type: ignore

	bool_OptTex_Attbt_VRam : BoolProperty (
		name = "",
		description = "VRam Size (MB)",
		default = False
	)# type: ignore

#endregion


#-----------------------------------------------------------------------------------------------
# INTERFACE
#-----------------------------------------------------------------------------------------------

# UI PANELS 

# Header
class Deo_Optimizer_Panel (Panel):
	bl_idname = "DEOS_PT_Optimizer_Header"
	bl_label = "DEO's OPTIMIZER SCENE"
	bl_category = "Deo's Tools"
	bl_context = ".objectmode"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"

	def draw(self, context) :
		pass


#region [ MESHES ]

# Menu Meshes
class Deo_Opt_MenuMesh (Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Header"

	bl_idname = "DEOS_PT_Optimizer_Meshes"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "[	M E S H E S	]"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"


	def draw(self, context) :
		pass

# SubMeshes - Visual Colors
class Deo_Opt_SubMenuMesh_VisualColors (Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Meshes"

	bl_idname = "DEOS_PT_Opt_Mesh_VisualColors"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "	 Visual Colors"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	
	def draw(self, context) :
		OptimizePropGrps = context.scene.optimizePropertyGrp
		layout = self.layout
		box = layout.box()
		numOfRowize = 0.5

	#region Calculate 

		# Selection Mode
		row = box.row()
		row.scale_y = 1.2
		row.prop(OptimizePropGrps, "enum_OptVisCol_SelectMode", text=" ", expand=True)						 # Buttons
		# row.prop(OptimizePropGrps, "enum_OptVisCol_SelectMode", text="Mode", icon="OBJECT_DATA") # Dropdown
		
		# Collection Visible
		if OptimizePropGrps.enum_OptVisCol_SelectMode == 'Op3' :
			box.prop(OptimizePropGrps, "pntr_OptVisCol_Collect", text="", icon="OUTLINER_COLLECTION")

		# Custom Max Tris 
		row = box.column().split(factor = 0.5)
		row.prop (OptimizePropGrps, "bool_OptVisCol_UseMaxTris", text="Max Tris:")
		row.prop (OptimizePropGrps, "int_OptVisCol_UseMaxTris", text="", emboss=bpy.context.scene.optimizePropertyGrp.bool_OptVisCol_UseMaxTris)

		# Buttons
		split = box.column().split()
		split.operator ("deo.opt_mesh_vc_colorize", text="C O L O R", icon="COLORSET_02_VEC")
		split.operator ("deo.opt_mesh_vc_clean", text="C L E A N", icon="COLORSET_13_VEC", emboss=bpy.context.scene.optimizePropertyGrp.bool_OptVisCol_IsCleanerActive)
	
	# endregion

	#region Info 
		box = layout.box()

		row = box.row()
		row.alignment = 'CENTER'
		row.label(text="Info from Mesh(es):")

		# Obj Analized
		row = box.row().split(factor = numOfRowize)
		row.label(text="Mesh(es) Analized:")
		row.prop (OptimizePropGrps, "str_OptVisCol_ObjAnalized", text="", emboss=False)


		# Tris
		row = box.row().split(factor = numOfRowize)
		row.label(text="Min Mesh Tris:")
		row.prop (OptimizePropGrps, "str_OptVisCol_MinTris", text="", emboss=False)
		
		row = box.column().split(factor = numOfRowize)
		row.label(text="Max Mesh Tris:")
		row.prop (OptimizePropGrps, "str_OptVisCol_MaxTris", text="", emboss=False)
		

		# Colors
		row = box.row()
		row.alignment = 'CENTER'
		row.scale_x = 0.95

		row.label(text="Min")
		row.prop (OptimizePropGrps, "enum_OptVisCol_Colors", text="", expand=True, emboss=False)
		row.label(text="Max")
		
	# endregion

# SubMeshes - PolyCount
class Deo_Opt_SubMenuMesh_PolyCount (Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Meshes"

	bl_idname = "DEOS_PT_Opt_Mesh_PolyCount"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "	 By Polycount"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"

	def draw(self, context) :
		OptimizePropGrps = context.scene.optimizePropertyGrp
		
		scene = context.scene
		layout = self.layout
		box = layout.box()

		# Selection mode
		row = box.row()
		row.scale_y = 1.2
		row.prop(OptimizePropGrps, "enum_OptPlyCnt_SelectMode", text=" ", expand=True)						 # Buttons
		# row.prop(OptimizePropGrps, "enum_OptPlyCnt_SelectMode", text="Mode", icon="OBJECT_DATA") # Dropdown
		
		# UI Collection Visible
		if OptimizePropGrps.enum_OptPlyCnt_SelectMode == 'Op3' :
			box.prop(OptimizePropGrps, "pntr_OptPlyCnt_Collect", text="", icon="OUTLINER_COLLECTION")
		
		# Info: Tittle
		row = box.row()
		row = box.row()
		row.alignment = 'CENTER'
		row.label(text="[ Amount of Tris to find per Mesh ]")
		
		split1 = box.row().split(factor = 0.2)
		split1.prop (OptimizePropGrps, "enum_OptPlyCnt_Action", text="")

		split2 = split1.split(factor = 0.8)
		split2.prop (OptimizePropGrps, "int_OptPlyCnt_Amount", text="")
		split2.operator ("deo.opt_mesh_polycount_get", text="", icon="VIEW_ZOOM")


		# Scroll List
		if scene.coll_PolyCount_ListInstances:
			# Info: Obj Tris Count action
			box = layout.box()
			row = box.row().split(factor = 0.5)
			row.label(text="Mshes Found:")
			row.prop (OptimizePropGrps, "str_OptPlyCnt_ObjSel", text="", emboss=False)
			
			row = box.row()
			
			numOfRow = 4
			if len(scene.coll_PolyCount_ListInstances) < numOfRow:
				numOfRow = len(scene.coll_PolyCount_ListInstances)
			
			# Draw list
			row.template_list(
				listtype_name = "DEO_UL_Opt_CustomList_Mesh",
				list_id = "",
				dataptr = scene,
				propname = "coll_PolyCount_ListInstances",
				active_dataptr =scene,
				active_propname = "int_PolyCount_ListActiveIndex",
				rows=numOfRow
			)

			row = box.row()
			row.operator("deo.opt_mesh_polycount_clean", text="Remove List")

# SubMeshes - Instances
class Deo_Opt_SubMenuMesh_Instances (Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Meshes"

	bl_idname = "DEOS_PT_Opt_Mesh_Instances"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "	 By Instances"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"

	def draw(self, context) :
		OptimizePropGrps = context.scene.optimizePropertyGrp
		scene = context.scene
		layout = self.layout

		box = layout.box()

		row = box.row() 
		row = box.row().split(factor = 0.85)
		row.prop (OptimizePropGrps, "pntr_OptInstance_Picker", text="")
		row.operator ("deo.opt_mesh_inst_pntr", text="", icon="VIEW_ZOOM")

		row = box.row()
		row = box.row().split(factor = 0.85)
		row.label(text="[	From a Selected Mesh	]")
		row.operator ("deo.opt_mesh_inst_sel", text="", icon="VIEW_ZOOM")
		

		# Scroll List
		if scene.coll_MshInstances_ListInstances:
			box = layout.box()
			row = box.row().split(factor = 0.5)
			row.label(text="Instances found:")
			row.prop (OptimizePropGrps, "str_OptInstance_TotalInst", text="", emboss=False)

			row = box.row()
			
			numOfRow = 4
			if len(scene.coll_MshInstances_ListInstances) < numOfRow:
				numOfRow = len(scene.coll_MshInstances_ListInstances)
			
			# Draw list
			row.template_list(
				listtype_name = "DEO_UL_Opt_CustomList_Mesh",
				list_id = "",
				dataptr = scene,
				propname = "coll_MshInstances_ListInstances",
				active_dataptr =scene,
				active_propname = "int_MshInstances_ListActiveIndex",
				rows=numOfRow
			)

			row = box.row()
			row.operator ("deo.opt_mesh_inst_clean", text="Clean")


#endregion

#region [ MATERIALS ]

class Deo_Opt_MenuMaterials (Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Header"

	bl_options = {'DEFAULT_CLOSED'}
	bl_idname = "DEOS_PT_Optimizer_Materials"
	bl_label = "[	M A T E R I A L S	]"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	
	def draw(self, context):
		pass

class Deo_Opt_SubMenuMat_MshFromMat (Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Materials"

	bl_idname = "DEOS_PT_Opt_Mat_MshFromMat"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "	 Get Msh from Mat"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"

	def draw(self, context) :
		scene = context.scene
		OptimizePropGrps = scene.optimizePropertyGrp

		layout = self.layout
		box = layout.box()

		row = box.row().split(factor = 0.85)
		row.prop (OptimizePropGrps, "pntr_MatToMsh_Picker", text="")
		row.operator ("deo.opt_mshfrommat_findmeshes", text="", icon="VIEW_ZOOM")

		# Scroll List
		if scene.coll_MatToMsh_ListMesh:
			box = layout.box()
			row = box.row().split(factor = 0.5)
			row.label(text="Mesh(es) found:")
			row.prop (OptimizePropGrps, "str_MatToMsh_TotalMshsByMat", text="", emboss=False)

			row = box.row()
			
			numOfRow = 4
			if len(scene.coll_MatToMsh_ListMesh) < numOfRow:
				numOfRow = len(scene.coll_MatToMsh_ListMesh)
			
			# Draw list
			row.template_list(
				listtype_name = "DEO_UL_Opt_CustomList_Mesh",
				list_id = "",
				dataptr = scene,
				propname = "coll_MatToMsh_ListMesh",
				active_dataptr =scene,
				active_propname = "int_MatToMsh_ListActiveIndex",
				rows=numOfRow
			)

			row = box.row()
			row.operator ("deo.opt_mat_mshfrommat_clean", text="Clean")

class Deo_Opt_SubMenuMat_MshMatsInfo (Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Materials"

	bl_idname = "DEOS_PT_Opt_Mat_MshMatsInfo"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "	 Get Mat/Map from Msh"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"

	def draw(self, context) :
		OptimizePropGrps = context.scene.optimizePropertyGrp
		scene = context.scene
		layout = self.layout
		box = layout.box()

		row = box.row().split(factor = 0.85)
		row.prop (OptimizePropGrps, "pntr_MshMatsInfo_Picker", text="")
		row.operator ("deo.opt_mshmatsinfo_analize_pntr", text="", icon="VIEW_ZOOM")

		row = box.row()
		row = box.row().split(factor = 0.85)
		row.label(text="[	From a Selected Mesh	]")
		row.operator ("deo.opt_mshmatsinfo_analize_selctd", text="", icon="VIEW_ZOOM")
		
		
		# Scroll List
		if scene.coll_MshMatInfo_ListMats:
			box = layout.box()
			row = box.row().split(factor = 0.7)
			row.label(text="# Total Materials:")
			row.prop (OptimizePropGrps, "str_MshMatsInfo_TotalMats", text="", emboss=False)		

			row = box.row().split(factor = 0.55)
			row.label(text="Material Name")
			row.label(text="# Maps Using")

			row = box.row()
			
			numOfRow = 4
			if len(scene.coll_MshMatInfo_ListMats) < numOfRow:
				numOfRow = len(scene.coll_MshMatInfo_ListMats)
			
			# Draw list
			row.template_list(
				listtype_name = "DEO_UL_Opt_CustomList_TexturesNodes",
				list_id = "",
				dataptr = scene,
				propname = "coll_MshMatInfo_ListMats",
				active_dataptr =scene,
				active_propname = "int_MshMatInfo_ListActiveIndex",
				rows=numOfRow
			)

			row = box.row()
			row.operator ("deo.opt_mat_mshmatinfo_clean", text="Clean")

class Deo_Opt_SubMenuMat_MshMatsCleaner(Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Materials"

	bl_idname = "DEOS_PT_Opt_Mat_MshMatsCleaner"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "	 Get Empty Materials"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"

	def draw(self, context) :
		scene = context.scene
		layout = self.layout
		box = layout.box()

		row = box.row().split(factor = 0.85)
		row.label(text="[	Get Scene Empty Materials	]")
		row.operator ("deo.opt_mshmatcleaner_getmeshes", text="", icon="VIEW_ZOOM")
		
		# Scroll List
		if scene.coll_MshMatCleaner_ListMshes:
			box = layout.box()

			
			numOfRow = 4
			if len(scene.coll_MshMatCleaner_ListMshes) < numOfRow:
				numOfRow = len(scene.coll_MshMatCleaner_ListMshes)
			
			# Draw list
			row = box.row()
			row = box.row().split(factor = 0.55)
			row.label(text="  Mesh")
			row.label(text="# Empty Slots")

			row = box.row()
			row.template_list(
				listtype_name = "DEO_UL_Opt_CustomList_MshEmptyMats",
				list_id = "",
				dataptr = scene,
				propname = "coll_MshMatCleaner_ListMshes",
				active_dataptr =scene,
				active_propname = "int_MshMatCleaner_ListActiveIndex",
				rows=numOfRow
			)

			row = box.row()
			row.alignment = 'CENTER'
			row.label(text="Clean slots:")
			row = box.row().split(factor = 0.5)
			row.operator ("deo.clean_selected", text="Selected")
			row.operator ("deo.clean_scene", text="Scene")

class Deo_Opt_SubMenuMat_EmissiveMeshes(Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Materials"

	bl_idname = "DEOS_PT_Opt_Mat_EmisionMeshes"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "	 Get Emissive Meshes"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"

	def draw(self, context) :
		scene = context.scene
		layout = self.layout
		OptimizePropGrps = scene.optimizePropertyGrp

		box = layout.box()
		row = box.row()
		row.prop(OptimizePropGrps, "enum_EmissiveMshs_SelectMode", text=" ", expand=True) # Buttons
		
		# Collection Visible
		if OptimizePropGrps.enum_EmissiveMshs_SelectMode == 'Op2' :
			row = box.row()
			row.prop(OptimizePropGrps, "pntr_EmissiveMshs_Collect", text="", icon="OUTLINER_COLLECTION")

		row = box.row().split(factor = 0.85)
		row.label(text="[	Get Meshes	]")		
		row.operator ("deo.opt_mat_emission_mshs", text="", icon="VIEW_ZOOM")
		
		# Scroll List
		if scene.coll_MshMatsEmissive_ListMshes:
			box = layout.box()

			numOfRow = 4
			if len(scene.coll_MshMatsEmissive_ListMshes) < numOfRow:
				numOfRow = len(scene.coll_MshMatsEmissive_ListMshes)
			
			# Draw list
			row = box.row()
			row = box.row().split(factor = 0.75)
			row.label(text="  Mesh")
			row.label(text="Mat")

			row = box.row()
			row.template_list(
				listtype_name = "DEO_UL_Opt_CustomList_MshMats",
				list_id = "",
				dataptr = scene,
				propname = "coll_MshMatsEmissive_ListMshes",
				active_dataptr =scene,
				active_propname = "int_MshMatsEmissive_ListActiveIndex",
				rows=numOfRow
			)

			row = box.row()
			# row.alignment = 'CENTER'
			row.operator ("deo.opt_mat_emission_mshs_clean", text="Remove List")


# endregion

#region [ TEXTURES ]

class Deo_Opt_MenuTextures (Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Header"

	bl_options = {'DEFAULT_CLOSED'}
	bl_idname = "DEOS_PT_Optimizer_Textures"
	bl_label = "[	T E X T U R E S	]"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"
	
	def draw(self, context):
		pass
	
class Deo_Opt_SubMenuTex_TexFromMsh(Panel):
	bl_parent_id = "DEOS_PT_Optimizer_Textures"

	bl_idname = "DEOS_PT_Optimizer_TexturesFromMeshes"
	bl_options = {'DEFAULT_CLOSED'}
	bl_label = "	 Get Textures from Mesh(es)"
	bl_space_type = "VIEW_3D"
	bl_region_type = "UI"

	def draw(self, context):
			OptimizePropGrps = context.scene.optimizePropertyGrp
			scene = context.scene
			layout = self.layout

			box = layout.box()

		#region Calculate 

			# Selection Mode
			row = box.row()
			row.prop(OptimizePropGrps, "enum_OptTex_SelectMode", text=" ", expand=True)	# Buttons
			
			# UI Collection Visible
			if OptimizePropGrps.enum_OptTex_SelectMode == 'Op3' :
				box.prop(OptimizePropGrps, "pntr_OptTex_Collect", text="", icon="OUTLINER_COLLECTION")
			
			row = box.row(align=True)
			row.scale_x = 10.0
			row.operator ("deo.opt_tex_fill_list", text="", icon="VIEW_ZOOM")


			if scene.coll_Tex_ListTex:
			# Box List textures
				box = layout.box()
				row = box.row()
				row.alignment = 'CENTER'
				row.label(text=f"# Textures: {OptimizePropGrps.str_OptTex_TotalTextures}")

			# Filters
				row = box.row(align=True)
				split = row.split(factor=0.3)
				row.label(text="Attributes ->")
				row.prop(OptimizePropGrps, "bool_OptTex_Attbt_Material", icon="MATERIAL")
				row.prop(OptimizePropGrps, "bool_OptTex_Attbt_SizePx", icon="TEXTURE")
				row.prop(OptimizePropGrps, "bool_OptTex_Attbt_Format", icon="OUTLINER_OB_IMAGE")
				row.prop(OptimizePropGrps, "bool_OptTex_Attbt_Linked", icon="LINK_BLEND")
				row.prop(OptimizePropGrps, "bool_OptTex_Attbt_SizeDisk", icon="DISK_DRIVE")
				row.prop(OptimizePropGrps, "bool_OptTex_Attbt_VRam", icon="MEMORY")
				
				# Btn Select/Unselect
				row = box.row()
				row.operator ("deo.opt_tex_select_unselect", text="Select / Unselect all")

			# SCROLL LIST			
				numOfRow = 4
				if len(scene.coll_Tex_ListTex) < numOfRow:
					numOfRow = len(scene.coll_Tex_ListTex)
				
				# Draw list
				row = box.row()

				if tool_opt_texture.areFiltersActive:
					# List filtered
					row.template_list(
						listtype_name = "DEO_UL_Opt_CustomList_Textures",
						list_id = "",
						dataptr = scene,
						propname = "coll_Tex_ListTex_Filtered",
						active_dataptr =scene,
						active_propname = "int_Tex_ListActiveIdx_Filtered",
						rows=numOfRow
					)
				else:
					# List all
					row.template_list(
						listtype_name = "DEO_UL_Opt_CustomList_Textures",
						list_id = "",
						dataptr = scene,
						propname = "coll_Tex_ListTex",
						active_dataptr =scene,
						active_propname = "int_Tex_ListActiveIdx",
						rows=numOfRow
					)


				# Filters
				row = box.row()
				row.label(text="", icon="FILTER")
				row.prop(OptimizePropGrps, "enum_OptTex_Filter_Format", text="")
				row.prop(OptimizePropGrps, "enum_OptTex_Filter_Pixels", text="")
				
				if OptimizePropGrps.enum_OptTex_Filter_Pixels != 'Op1':
					row.prop(OptimizePropGrps, "enum_OptTex_Filter_PxCondition", text="")

				# Info Disk & Ram Size
				row = box.row()
				row.alignment = 'CENTER'
				row.split(factor = 0.5)
				row.label(text=f"Disk: {OptimizePropGrps.str_OptTex_TotalDiskSize}")
				row.label(text=f"VRam: {OptimizePropGrps.str_OptTex_TotalVRamSize}")

				# Btn clean list
				row = box.row()
				row.operator ("deo.opt_tex_cleanlist", text="Remove List")
				
			# Show/Hide Menu Resizer
				box = layout.box()
				row = box.row()
				if OptimizePropGrps.bool_OptTex_MenuResizerIsActive:
					row.operator ("deo.opt_tex_showhidemenuresizer", text="Texture Resizer",icon="TRIA_UP",depress=True)
				else:
					row.operator ("deo.opt_tex_showhidemenuresizer", text="Texture Resizer",icon="TRIA_DOWN",depress=OptimizePropGrps.bool_OptTex_MenuResizerIsActive)
			
			# MENU RESIZER
				if OptimizePropGrps.bool_OptTex_MenuResizerIsActive:
					row = box.row()
					row.alignment = 'CENTER'
					row.label(text=f"# Textures selected: {OptimizePropGrps.str_OptTex_TexSlctdFromList}")

					# Only show options when a texture(s) is selected
					if OptimizePropGrps.str_OptTex_TexSlctdFromList != '0':
						row = box.row()
						row.alignment = 'CENTER'
						row.label(text="(Textures will be overwritten)")
						
						row = box.row()
						row.prop (OptimizePropGrps, "bool_OptTex_Square", text="Square")

						#NOTE: Disable overwrite due to an error in some PC´s about permissions
						# row.prop (OptimizePropGrps, "bool_OptTex_Overwrite", text="Overwrite")

						# Texture size
						row = box.row()

						if OptimizePropGrps.bool_OptTex_Square:
							split = row.split(factor = 0.3)
							split.label(text="Size:")
							split2 = split.split(factor = 0.7)
							split2.prop(OptimizePropGrps, "enum_OptTex_SelectSize_Square", text="")
							split2.operator ("deo.opt_tex_resizeimage", text="",icon="EXPORT")
						else:
							split = row.split(factor = 0.3)
							split.label(text="Size:")
							split2 = split.split(factor = 0.35)
							split2.prop(OptimizePropGrps, "enum_OptTex_SelectSize_Width", text="")
							split2.prop(OptimizePropGrps, "enum_OptTex_SelectSize_Height", text="")
							split3 = split2.split(factor = 1)
							split3.operator ("deo.opt_tex_resizeimage", text="",icon="EXPORT")

						# Texture format
						split = box.row().split(factor = 0.3)
						split.label(text="Format:")
						split2 = split.split(factor = 0.7)
						split2.prop(OptimizePropGrps, "enum_OptTex_TexFormat", text="")
						split2.operator ("deo.opt_tex_changeformat", text="",icon="EXPORT")

# endregion

#endregion

#-----------------------------------------------------------------------------------------------
# REGISTRATIONS
#-----------------------------------------------------------------------------------------------

# region REGISTRATION 

DeosRegisterClasses = (

	# LIST (1st to execute)
	DEO_UL_Opt_CustomList_Mesh,
	DEO_UL_Opt_CustomList_TexturesNodes,
	DEO_UL_Opt_CustomList_MshMats,
	DEO_UL_Opt_CustomList_MshEmptyMats,
	DEO_UL_Opt_CustomList_Textures,

	# PROPERTIES (INIT)	
	Deo_PropertyGroup_Optimize_Tex_Mats,
	Deo_PropertyGroup_Optimize, 

	# PANELS (INIT)
	Deo_Optimizer_Panel,
	
	Deo_Opt_MenuMesh,
	Deo_Opt_SubMenuMesh_VisualColors,
	Deo_Opt_SubMenuMesh_PolyCount,
	Deo_Opt_SubMenuMesh_Instances,
	
	Deo_Opt_MenuMaterials,
	Deo_Opt_SubMenuMat_MshFromMat,
	Deo_Opt_SubMenuMat_MshMatsInfo,
	Deo_Opt_SubMenuMat_MshMatsCleaner,
	Deo_Opt_SubMenuMat_EmissiveMeshes,

	Deo_Opt_MenuTextures,
	Deo_Opt_SubMenuTex_TexFromMsh,

	# OPERATORS (TOOLS)
	Deo_Opt_OperMesh_VC_Colorize,
	Deo_Opt_OperMesh_VC_Clean,
	Deo_Opt_OperMesh_PolyCount_Get,
	Deo_Opt_OperMesh_PolyCount_Clean,
	Deo_Opt_OperMesh_Inst_Pntr,
	Deo_Opt_OperMesh_Inst_Selctd,
	Deo_Opt_OperMesh_Inst_Clean,
	
	Deo_Opt_OperMats_MshFromMat_FindMeshes,
	Deo_Opt_OperMats_MshFromMat_Clean,

	Deo_Opt_OperMats_MshMatsInfo_Pntr,
	Deo_Opt_OperMats_MshMatsInfo_Selctd,
	Deo_Opt_OperMats_MshMatsInfo_Clean,

	Deo_Opt_OperMats_Clean_GetMeshes,
	Deo_Opt_OperMats_Clean_Selected,
	Deo_Opt_OperMats_Clean_Scene,

	Deo_Opt_OperMats_GetEmissiveMats,
	Deo_Opt_OperMats_GetEmissiveMats_Clean,

	Deo_Opt_OperTex_SelectUnselect,
	Deo_Opt_OperTex_FillList,
	Deo_Opt_OperTex_CleanList,
	Deo_Opt_OperTex_ShowHideMenuResizer,
	Deo_Opt_OperTex_ResizeImage,
	Deo_Opt_OperTex_Changeformat
)


@persistent
def on_LoadBlendFile(_arg):
	tool_opt_mesh.Opt_Clear_OnLoadBlendFile()
	tool_opt_material.Opt_Clear_OnLoadBlendFile()
	tool_opt_texture.Opt_Clear_OnLoadBlendFile()

# Suscription to signal executed when a blend file is loaded
bpy.app.handlers.load_post.append(on_LoadBlendFile)

def register_optimizer():
	from bpy.utils import register_class

	# Classes
	for myClasses in DeosRegisterClasses:
			register_class(myClasses)


	# region [ LIST PROPERTIES ]
	
	#region [ MESHES ]

		# Poly Count
	bpy.types.Scene.coll_PolyCount_ListInstances = bpy.props.CollectionProperty(type=Deo_PropertyGroup_Optimize)
	bpy.types.Scene.int_PolyCount_ListActiveIndex = bpy.props.IntProperty(
		name="",
		description="",
		default=0,
		update=Deo_Opt_PolyCount_OnUpdateIndexList,
	)

		# Instances)
	bpy.types.Scene.coll_MshInstances_ListInstances = bpy.props.CollectionProperty(type=Deo_PropertyGroup_Optimize)
	bpy.types.Scene.int_MshInstances_ListActiveIndex = bpy.props.IntProperty(
		name="",
		description="",
		default=0,
	update=Deo_Opt_Msh_Inst_OnUpdateIndexList
	)
	#endregion

	#region [ MATERIALS ]

		# Material to Mesh(es)
	bpy.types.Scene.coll_MatToMsh_ListMesh = bpy.props.CollectionProperty(type=Deo_PropertyGroup_Optimize)
	bpy.types.Scene.int_MatToMsh_ListActiveIndex = bpy.props.IntProperty(
		name="",
		description="",
		default=0,
		update=Deo_Opt_Mats_MshFromMat_OnUpdateIndexList,
	)
	
		# Mesh to Material(s)
	bpy.types.Scene.coll_MshMatInfo_ListMats = bpy.props.CollectionProperty(type=Deo_PropertyGroup_Optimize)
	bpy.types.Scene.int_MshMatInfo_ListActiveIndex =  bpy.props.IntProperty(
		name="",
		description="",
		default=0,
	)

		# Materials Cleaner
	bpy.types.Scene.coll_MshMatCleaner_ListMshes = bpy.props.CollectionProperty(type=Deo_PropertyGroup_Optimize)
	bpy.types.Scene.int_MshMatCleaner_ListActiveIndex =  bpy.props.IntProperty(
		name="",
		description="",
		default=-1,
		update=Deo_Opt_Mats_Clean_OnUpdateIndexList,
	)

		# Emissive Materials
	bpy.types.Scene.coll_MshMatsEmissive_ListMshes = bpy.props.CollectionProperty(type=Deo_PropertyGroup_Optimize)
	bpy.types.Scene.int_MshMatsEmissive_ListActiveIndex =  bpy.props.IntProperty(
		name="",
		description="",
		default=0,
		update=Deo_Opt_Mats_Emissive_OnUpdateIndexList,
	)

	#endregion
	
	#region [ TEXTURES ]
	bpy.types.Scene.coll_Tex_ListTex = bpy.props.CollectionProperty(type=Deo_PropertyGroup_Optimize)
	bpy.types.Scene.int_Tex_ListActiveIdx = bpy.props.IntProperty(
		name="",
		description="",
		default=0
	)

	bpy.types.Scene.coll_Tex_ListTex_Filtered = bpy.props.CollectionProperty(type=Deo_PropertyGroup_Optimize)
	bpy.types.Scene.int_Tex_ListActiveIdx_Filtered  = bpy.props.IntProperty(
		name="",
		description="",
		default=0
	)
	#endregion

	#endregion

	# PropertyGroups
	bpy.types.Scene.optimizePropertyGrp = PointerProperty(type=Deo_PropertyGroup_Optimize)

def unregister_optimizer():
	from bpy.utils import unregister_class

	for myClasses in reversed(DeosRegisterClasses):
			unregister_class(myClasses)

	# region ListProperties
	del bpy.types.Scene.coll_PolyCount_ListInstances
	del bpy.types.Scene.int_PolyCount_ListActiveIndex

	del bpy.types.Scene.coll_MshInstances_ListInstances
	del bpy.types.Scene.int_MshInstances_ListActiveIndex

	del bpy.types.Scene.coll_MatToMsh_ListMesh
	del bpy.types.Scene.int_MatToMsh_ListActiveIndex

	del bpy.types.Scene.coll_MshMatInfo_ListMats
	del bpy.types.Scene.int_MshMatInfo_ListActiveIndex

	del bpy.types.Scene.coll_MshMatCleaner_ListMshes
	del bpy.types.Scene.int_MshMatCleaner_ListActiveIndex

	del bpy.types.Scene.coll_MshMatsEmissive_ListMshes
	del bpy.types.Scene.int_MshMatsEmissive_ListActiveIndex

	del bpy.types.Scene.coll_Tex_ListTex
	del bpy.types.Scene.int_Tex_ListActiveIdx

	del bpy.types.Scene.coll_Tex_ListTex_Filtered
	del bpy.types.Scene.int_Tex_ListActiveIdx_Filtered
	
	#endregion

	# PropertyGroups
	del bpy.types.Scene.optimizePropertyGrp

	# Unsuscribe signal when a blend file is loaded
	if on_LoadBlendFile in bpy.app.handlers.load_post:
			bpy.app.handlers.load_post.remove(on_LoadBlendFile)


# if __name__ == "__main__": register_optimizer()

# endregion