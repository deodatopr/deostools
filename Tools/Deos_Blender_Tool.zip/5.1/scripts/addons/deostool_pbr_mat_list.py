# TOOL --------------------------------

bl_info = { 
	"name": "Deo's PBR MatList",
	"version": (1, 0),
	"blender": (4, 5, 0),
	"location": "Properties > Material",
	"description": "PBR Web Table values (Color, Metalness, Roughness, IOR)",
	"category": "Material",
}

import bpy 					# type: ignore
import requests

from bpy.types import (Operator, PropertyGroup, Panel, Scene)																# type: ignore
from bpy.props import EnumProperty, FloatProperty, FloatVectorProperty, PointerProperty			# type: ignore

# --

# ===================================================================
# DEFINITIONS
# ===================================================================

# Global Vars
URL_JSON = "https://raw.githubusercontent.com/AntonPalmqvist/physically-based-api/main/deploy/materials.json"
mat_list_data = []  # List

def matList_fill_items(self, context):
	# No data downloaded
	if not mat_list_data:
		return [("NONE", "No Data", "No materials loaded")]
	
	# Fill Dynamicly items in List [Item >> (identifier, Name, Description) >> All Strings]
	return [ 
			(JsonItemData.get("name"), JsonItemData.get("name"), JsonItemData.get("category")[0])
			for JsonItemData in mat_list_data
		   ]

def on_matList_change(self, context):
	mat_name = self.matList_enum
	mat_data = next((m for m in mat_list_data if m.get("name") == mat_name), None)
	if mat_data:
		#.get (Exist>JSonData, None=ManualValue)
		self.matC_vector = mat_data.get	("color", 			[1.0, 1.0, 1.0, 1.0])
		self.matM_float = mat_data.get	("metalness", 	0.0)
		self.matR_float = mat_data.get	("roughness", 	0.5)
		self.matI_float = mat_data.get	("ior", 				1.5)
		self.matT_float = mat_data.get	("transmission", 0.0)
	
def mat_Alpha_Reset(context):
	mat = context.object.active_material
	if mat:
		if mat.node_tree:
			for node in mat.node_tree.nodes:
				if node.type == 'BSDF_PRINCIPLED':
					node.inputs["Alpha"].default_value = 1.0


# ===================================================================
# OPERATORS
# ===================================================================
class DEO_OT_Json_GetData(Operator):
	bl_idname = "pbr.load_json"
	bl_label = ""
	bl_description = "Load the PBR Mat list from web"

	def execute(self, context):
		global mat_list_data
	
		try:
			response = requests.get(URL_JSON, timeout=5)
			response.raise_for_status()
			raw_data = response.json()
			if isinstance(raw_data, list):
				mat_list_data = raw_data
			else:
				print("Unexpected JSON File format")
			
			print(f"{len(mat_list_data)} Materials Loaded")

		except Exception as e:
			print("Error to download the Web data:", e)
			
		self.report({'INFO'}, f"{len(mat_list_data)} materials loaded!")
		return {'FINISHED'}

class DEO_OT_Mat_Apply(Operator):
	bl_idname = "pbr.apply_to_active"
	bl_label = ""
	bl_description = "Apply Mat selected from the list to the active mat."

	def execute(self, context):
		myPropGrps = context.scene.pbr_props
		mat = context.object.active_material
		if mat:
			mat.diffuse_color = (*myPropGrps.matC_vector, 1.0)
			if mat.node_tree:
				for node in mat.node_tree.nodes:
					if node.type == 'BSDF_PRINCIPLED':
						node.inputs["Base Color"].default_value = (*myPropGrps.matC_vector, 1.0)
						node.inputs["Metallic"].default_value = myPropGrps.matM_float
						node.inputs["Roughness"].default_value = myPropGrps.matR_float
						node.inputs["IOR"].default_value = myPropGrps.matI_float
						node.inputs["Transmission Weight"].default_value = myPropGrps.matT_float
		
		mat_Alpha_Reset(context)

		return {'FINISHED'}

class DEO_OT_Mat_Reset(Operator):
	bl_idname = "pbr.reset_mat"
	bl_label = ""
	bl_description = "Reset Active Material to Default Values"

	def execute(self, context):
		myPropGrps = context.scene.pbr_props
		mat = context.object.active_material
		if mat:
			mat.diffuse_color = (*myPropGrps.matC_vector, 1.0)
			if mat.node_tree:
				for node in mat.node_tree.nodes:
					if node.type == 'BSDF_PRINCIPLED':
						node.inputs["Base Color"].default_value = (1.0,1.0,1.0, 1.0)
						node.inputs["Metallic"].default_value = 0.0
						node.inputs["Roughness"].default_value = 0.5
						node.inputs["IOR"].default_value = 1.5
						node.inputs["Alpha"].default_value = 1.0
						node.inputs["Transmission Weight"].default_value = 0.0
		return {'FINISHED'}

# --


# ===================================================================
# UI - PROPERTIES 
# ===================================================================
class DEO_PGT_uiElements(PropertyGroup):

	matList_enum: EnumProperty(
		name="Material List",
		items=matList_fill_items,
		update=on_matList_change,
	) # type: ignore

	matC_vector: FloatVectorProperty(name="Color", subtype='COLOR', size=3, default=(1.0, 1.0, 1.0)) 			# type: ignore
	matM_float:  FloatProperty(name="Metallic", 		default=0.0, min=0.0, max=1.0, description='Metallic')			# type: ignore
	matR_float:  FloatProperty(name="Roughness",		default=0.5, min=0.0, max=1.0, description='Roughness')			# type: ignore
	matI_float:  FloatProperty(name="IOR", 					default=1.5, min=1.0, max=3.0, description='IOR')						# type: ignore
	matT_float:  FloatProperty(name="Transmission", default=0.0, min=0.0, max=1.0, description='Transmission')	# type: ignore

# ===================================================================
# UI- PANEL
# ===================================================================
class DEO_PT_Tool(Panel):
	bl_idname = "DEOS_PT_pbr_mat_list"
	bl_space_type = 'PROPERTIES'
	bl_context = "material"
	bl_region_type = 'WINDOW'
	bl_label = "Deo's PBR Mat List"
	bl_options = {'DEFAULT_CLOSED'}

	def draw(self, context):
		myPropGrps = context.scene.pbr_props

		box = self.layout.box()

		split = box.column().split(factor = 0.15)
		split.operator("wm.url_open", icon="WORLD_DATA").url = "https://physicallybased.info/"
		
		split = split.split(factor = 0.35)
		split.operator("pbr.load_json", text="LOAD", icon="FILE_REFRESH")
		split.prop(myPropGrps, "matList_enum", text = "")

		split = box.column().split(factor = 0.07, align=True)
		split.prop(myPropGrps, "matC_vector", text='')

		split.prop(myPropGrps, "matM_float", text='M')
		split.prop(myPropGrps, "matR_float", text='R')
		split.prop(myPropGrps, "matI_float", text='I')
		split.prop(myPropGrps, "matT_float", text='T')

		split = box.column().split(factor = 0.8)
		split.operator("pbr.apply_to_active", text="APPLY MAT", icon="MATERIAL")
		split.operator("pbr.reset_mat", text="", icon="NODE_MATERIAL")

# --


# ===================================================================
# REGISTER
# ===================================================================
classes = [
	DEO_PGT_uiElements,
	DEO_PT_Tool,
	DEO_OT_Json_GetData,
	DEO_OT_Mat_Apply,
	DEO_OT_Mat_Reset
]

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	Scene.pbr_props = PointerProperty(type=DEO_PGT_uiElements)

def unregister():
	for cls in reversed(classes):
		bpy.utils.unregister_class(cls)
	del Scene.pbr_props

if __name__ == "__main__":
	register()
