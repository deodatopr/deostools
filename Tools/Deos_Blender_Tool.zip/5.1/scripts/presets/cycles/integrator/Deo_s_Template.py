import bpy
cycles = bpy.context.scene.cycles

cycles.max_bounces = 8
cycles.diffuse_bounces = 4
cycles.glossy_bounces = 2
cycles.transmission_bounces = 2
cycles.volume_bounces = 1
cycles.transparent_max_bounces = 2
cycles.caustics_reflective = False
cycles.caustics_refractive = False
cycles.blur_glossy = 1.0
cycles.use_fast_gi = False
cycles.ao_bounces = 1
cycles.ao_bounces_render = 1
