import bpy
cycles = bpy.context.scene.cycles

cycles.max_bounces = 0
cycles.diffuse_bounces = 0
cycles.glossy_bounces = 0
cycles.transmission_bounces = 0
cycles.volume_bounces = 0
cycles.transparent_max_bounces = 0
cycles.caustics_reflective = False
cycles.caustics_refractive = False
cycles.blur_glossy = 1.0
cycles.use_fast_gi = False
cycles.ao_bounces = 1
cycles.ao_bounces_render = 1
