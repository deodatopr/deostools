import bpy
import blf
import time

# Store the current drawing data
draw_data = {
    "text": "",
    "start_time": 0,
    "duration": 2.0,  # Display duration in seconds
    "fade_duration": 0.5,  # Fade out duration in seconds
    "color": [1.0, 1.0, 1.0, 1.0],  # RGBA
    "size": 20,
    "position": (100, 100),  # Default position
    "vertical_position": 85.0,  # Default vertical position (percentage from bottom)
    "horizontal_position": 50.0,  # Default horizontal position (percentage from left)
    "handler": None,
    "is_enabled": False,
    "timer": None,  # Timer for continuous redraws
    "mode": None,  # Current focal length mode
    "value": None,  # Current focal length value
}

def draw_callback_px():
    """Draw the text in the viewport"""
    try:
        # Check if viewport overlay is enabled in preferences
        try:
            addon_prefs = bpy.context.preferences.addons[__package__].preferences
            if not addon_prefs.display_focal_length_overlay:
                # Focal length overlay is disabled, don't draw
                return
        except (AttributeError, KeyError):
            # If we can't access preferences, default to enabled
            pass
        
        # If we have a value to display or we're in the fade-out period
        if draw_data["value"] is not None or time.time() < draw_data["start_time"] + draw_data["duration"] + draw_data["fade_duration"]:
            # Calculate time elapsed since start
            elapsed = time.time() - draw_data["start_time"]
            
            # Calculate alpha based on fade timing
            if elapsed > draw_data["duration"]:
                # Fade out phase
                fade_progress = (elapsed - draw_data["duration"]) / draw_data["fade_duration"]
                alpha = max(0.0, 1.0 - fade_progress)  # Ensure alpha doesn't go negative
            else:
                alpha = 1.0
            
            # Only draw if alpha is meaningful
            if alpha > 0.01:
                # Set text properties
                font_id = 0  # Default font
                blf.position(font_id, draw_data["position"][0], draw_data["position"][1], 0)
                blf.size(font_id, draw_data["size"])
                
                # Set color with current alpha
                color = draw_data["color"].copy()
                color[3] = alpha * color[3]
                blf.color(font_id, *color)
                
                # Draw the text
                blf.draw(font_id, draw_data["text"])
        else:
            # If there's no value to display and we're outside the fade duration, remove handler
            _remove_handler()
    except Exception as e:
        # If drawing fails, remove the handler to prevent continuous errors
        print(f"Focal Length Tweaker: Error in draw callback: {e}")
        _remove_handler()

def timer_update():
    """Timer callback to force redraw during fading"""
    try:
        # Only redraw if we're in the active workspace and there's a 3D view
        context = bpy.context
        if context.workspace and context.screen:
            # Force a redraw of 3D VIEW regions more efficiently
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
                    break  # Only redraw the first 3D view found
        
        # Calculate time elapsed
        elapsed = time.time() - draw_data["start_time"]
        
        # Stop the timer if we're done fading and not showing continuously
        if elapsed > draw_data["duration"] + draw_data["fade_duration"] and draw_data["value"] is None:
            _remove_timer()
            return None
        
        return 0.033  # ~30 fps refresh rate instead of 100 fps
    except Exception as e:
        # If timer fails, remove it to prevent continuous errors
        print(f"Focal Length Tweaker: Error in timer update: {e}")
        _remove_timer()
        return None

def _remove_handler():
    """Internal function to remove the draw handler if it exists"""
    if draw_data["handler"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(draw_data["handler"], 'WINDOW')
        draw_data["handler"] = None
        draw_data["is_enabled"] = False
    
    # Also remove the timer
    _remove_timer()
    
    # Reset the value
    draw_data["value"] = None

def _remove_timer():
    """Internal function to remove the timer if it exists"""
    if draw_data["timer"] is not None:
        try:
            bpy.app.timers.remove(draw_data["timer"])
        except Exception as e:
            # Timer might already be removed or invalid
            print(f"Focal Length Tweaker: Warning - Could not remove timer: {e}")
        finally:
            draw_data["timer"] = None

def remove_handler():
    """Public function to remove the draw handler, for use by other modules"""
    _remove_handler()

def format_focal_length_value(mode, value):
    """Format the focal length value based on the mode"""
    if mode == 'CAMERA_FOCAL_LENGTH':
        # For camera focal length
        return f"Camera Focal Length: {value:.1f}mm"
    
    elif mode == 'VIEWPORT_FOCAL_LENGTH':
        # For viewport focal length
        return f"Viewport Focal Length: {value:.1f}mm"
    
    else:
        # Default fallback
        return f"Focal Length: {value:.1f}mm"

def update_focal_length_value(mode, value):
    """Update the focal length value to be displayed in the viewport"""
    # Format the text based on the mode and value
    formatted_text = format_focal_length_value(mode, value)
    if not formatted_text:
        return
    
    # Update the focal length value and mode
    draw_data["mode"] = mode
    draw_data["value"] = value
    draw_data["text"] = formatted_text
    
    # Update the start time for fading
    draw_data["start_time"] = time.time()
    
    # Get the region dimensions
    region = bpy.context.region
    if region:
        # Calculate vertical position based on preference (percentage from bottom)
        vertical_pos = int(region.height * (draw_data["vertical_position"] / 100.0))
        
        # Calculate horizontal position based on preference (percentage from left)
        text_width = int(len(draw_data["text"]) * draw_data["size"] * 0.50)  # Approximate text width
        horizontal_pos = int(region.width * (draw_data["horizontal_position"] / 100.0)) - (text_width // 2)
        
        draw_data["position"] = (horizontal_pos, vertical_pos)
    
    # Add the draw handler if not already enabled
    if not draw_data["is_enabled"]:
        draw_data["handler"] = bpy.types.SpaceView3D.draw_handler_add(
            draw_callback_px, (), 'WINDOW', 'POST_PIXEL')
        draw_data["is_enabled"] = True
    
    # Start the timer for continuous redraws if not already running
    if draw_data["timer"] is None:
        draw_data["timer"] = bpy.app.timers.register(timer_update)
    
    # Force initial redraw of all 3D VIEW regions
    context = bpy.context
    if context.screen:
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
                break  # Only redraw the first 3D view found

def register():
    pass

def unregister():
    # Make sure to remove any active handlers on addon unregister
    _remove_handler() 