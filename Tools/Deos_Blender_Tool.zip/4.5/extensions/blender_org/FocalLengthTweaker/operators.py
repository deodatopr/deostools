import bpy
from . import draw_handler

def get_addon_prefs():
    addon_name = __package__
    prefs = None
    try:
        prefs = bpy.context.preferences.addons[addon_name].preferences
    except KeyError:
        prefs = None
    return prefs

class FocalLengthTweaker(bpy.types.Operator):
    """Control viewport and camera focal length with your mouse"""
    bl_idname = "view3d.focal_length_tweaker"
    bl_label = "Focal Length Tweaker"
    bl_description = "Control viewport and camera focal length with your mouse. Hold {SHIFT} for precision."
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    def normalize_focal_change(self, delta, addon_prefs):
        """
        Normalize focal length change based on mouse movement
        """
        # Add safety checks
        if delta == 0:
            return 0.0
            
        # Base constants for normalization
        MOUSE_PIXELS_FOR_FULL_RANGE = 1000.0  # Pixels needed for full focal range
        BASE_FOCAL_CHANGE = 50.0  # Base focal length change in mm
        
        # Get user sensitivity preference (0.1 to 2.0 range)
        user_sensitivity = addon_prefs.sensitivity if addon_prefs else 0.8
        precision_enabled = addon_prefs.enable_precision if addon_prefs else True
        
        # Clamp sensitivity to valid range
        user_sensitivity = max(0.1, min(2.0, user_sensitivity))
        
        # Apply precision mode if shift is held and precision mode is enabled
        precision_multiplier = 0.1 if (self.shift_held and precision_enabled) else 1.0
        
        # Calculate base focal change
        base_change = (delta / MOUSE_PIXELS_FOR_FULL_RANGE) * BASE_FOCAL_CHANGE
        
        # Calculate final focal change with all factors
        final_change = base_change * user_sensitivity * precision_multiplier
        
        return final_change

    def modal(self, context, event):
        try:
            if event.type == 'MOUSEMOVE':
                # Get addon preferences once and cache them
                addon_prefs = get_addon_prefs()
                precision_enabled = addon_prefs.enable_precision if addon_prefs else True
                drag_direction = addon_prefs.mouse_drag_direction if addon_prefs else 'HORIZONTAL'

                # Update shift state only if precision mode is enabled
                if event.shift != self.shift_held and precision_enabled:
                    self.shift_held = event.shift
                    self.start_x = event.mouse_x
                    self.start_y = event.mouse_y
                    self.start_focal_length = self.get_current_focal_length()
                elif not precision_enabled:
                    self.shift_held = False

                # Calculate mouse movement based on drag direction preference
                if drag_direction == 'VERTICAL':
                    # Vertical movement: up increases focal length, down decreases
                    delta = self.start_y - event.mouse_y  # Inverted so up is positive
                else:
                    # Horizontal movement: right increases focal length, left decreases
                    delta = event.mouse_x - self.start_x

                # Get normalized focal change (pass cached preferences)
                focal_change = self.normalize_focal_change(delta, addon_prefs)

                # Calculate new focal length
                new_focal_length = self.start_focal_length + focal_change
                
                # Clamp focal length to reasonable range (8mm to 2000mm)
                new_focal_length = max(8.0, min(2000.0, new_focal_length))
                
                # Apply the new focal length
                self.set_focal_length(new_focal_length)
                
                # Update the focal length value overlay
                draw_handler.update_focal_length_value(self.mode, new_focal_length)
                
                self.safe_redraw()
                return {'RUNNING_MODAL'}

            elif event.type == self.trigger_type and event.value == 'RELEASE':
                self.cleanup()
                return {'FINISHED'}
            elif event.type in {'ESC'}:
                # Restore original focal length
                self.set_focal_length(self.start_focal_length)
                self.cleanup()
                return {'CANCELLED'}
            return {'RUNNING_MODAL'}

        except Exception as e:
            self.report({'ERROR'}, f"An error occurred: {e}")
            self.cleanup()
            return {'CANCELLED'}

    def set_cursor_for_drag_direction(self):
        """Set cursor based on drag direction preference"""
        addon_prefs = get_addon_prefs()
        drag_direction = addon_prefs.mouse_drag_direction if addon_prefs else 'HORIZONTAL'
        cursor_type = 'SCROLL_Y' if drag_direction == 'VERTICAL' else 'SCROLL_X'
        self.window.cursor_modal_set(cursor_type)

    def invoke(self, context, event):
        try:
            # Store initial mouse position
            self.start_x = event.mouse_x
            self.start_y = event.mouse_y
            self.shift_held = event.shift

            # Store the triggering input for release detection
            self.trigger_type = event.type
            self.trigger_value = event.value

            # Store references to frequently accessed data
            self.window = context.window
            self.space = context.space_data
            self.scene = context.scene

            # Get a safe reference to the area
            self.area = self.get_area_safe()
            if not self.area:
                self.report({'WARNING'}, "Operator must be run in a 3D Viewport")
                return {'CANCELLED'}

            # Determine the mode based on current view
            if context.space_data.region_3d.view_perspective == 'CAMERA':
                # Camera view - control selected camera's focal length
                self.mode = 'CAMERA_FOCAL_LENGTH'
                self.camera_object = context.scene.camera
                if not self.camera_object or self.camera_object.type != 'CAMERA':
                    self.report({'WARNING'}, "No camera selected or active camera is not a camera object")
                    return {'CANCELLED'}
                self.camera_data = self.camera_object.data
                self.start_focal_length = self.camera_data.lens
            else:
                # Viewport view - control viewport focal length
                self.mode = 'VIEWPORT_FOCAL_LENGTH'
                self.start_focal_length = self.space.lens

            # Set cursor based on drag direction preference (unified)
            self.set_cursor_for_drag_direction()
            
            # Display initial focal length value
            draw_handler.update_focal_length_value(self.mode, self.start_focal_length)

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        except Exception as e:
            self.report({'ERROR'}, f"Initialization failed: {str(e)}")
            self.cleanup()
            return {'CANCELLED'}

    def cleanup(self):
        # Reset cursor
        if hasattr(self, 'window') and self.window:
            self.window.cursor_modal_restore()
        
        # Clear all stored states
        for attr in ['shift_held', 'start_focal_length', 'mode', 'start_x', 'start_y', 
                    'camera_object', 'camera_data', 'trigger_type', 'trigger_value']:
            if hasattr(self, attr):
                delattr(self, attr)
        
        # Allow the overlay to fade out naturally according to preferences
        # (The draw handler will handle the fade-out timing)

    def safe_redraw(self):
        area = self.get_area_safe()
        if area:
            area.tag_redraw()

    def get_area_safe(self):
        # Safely get area reference
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                return area
        return None

    def get_current_focal_length(self):
        """Get current focal length based on mode"""
        try:
            if self.mode == 'CAMERA_FOCAL_LENGTH':
                return self.camera_data.lens
            elif self.mode == 'VIEWPORT_FOCAL_LENGTH':
                return self.space.lens
            return None
        except Exception as e:
            self.report({'WARNING'}, f"Error getting focal length: {str(e)}")
            return None

    def set_focal_length(self, focal_length):
        """Set focal length based on mode"""
        try:
            if self.mode == 'CAMERA_FOCAL_LENGTH':
                self.camera_data.lens = focal_length
            elif self.mode == 'VIEWPORT_FOCAL_LENGTH':
                self.space.lens = focal_length
            
            # Force update
            bpy.context.view_layer.update()
            self.safe_redraw()
        except Exception as e:
            self.report({'ERROR'}, f"Error setting focal length: {str(e)}")

    def execute(self, context):
        self.cleanup()
        return {'FINISHED'}

    def cancel(self, context):
        # Restore original focal length
        if hasattr(self, 'start_focal_length'):
            self.set_focal_length(self.start_focal_length)
        self.cleanup()
        return {'CANCELLED'}

def register():
    bpy.utils.register_class(FocalLengthTweaker)

def unregister():
    bpy.utils.unregister_class(FocalLengthTweaker)

