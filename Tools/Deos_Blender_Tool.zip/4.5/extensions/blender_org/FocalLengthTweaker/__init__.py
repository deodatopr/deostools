bl_info = {
    "name": "Focal Length Tweaker",
    "description": "Control viewport and camera focal length with your mouse.",
    "author": "1P2D <me@1p2d.com>",
    "version": (1, 0, 1),
    "blender": (4, 2, 0),
    "category": "User Interface",
    "location": "3D View",
}

import bpy
from . import operators, preferences, draw_handler

def register():
    operators.register()
    preferences.register()
    draw_handler.register()

def unregister():
    draw_handler.unregister()
    operators.unregister()
    preferences.unregister()

if __name__ == "__main__":
    register()
