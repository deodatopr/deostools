import bpy
import gpu
import blf
from gpu_extras.batch import batch_for_shader
import time
import math

# Store the current drawing data
draw_data = {
    "text": "",
    "start_time": 0,
    "duration": 2.0,  # Display duration in seconds
    "fade_duration": 0.5,  # Fade out duration in seconds
    "color": [1.0, 1.0, 1.0, 1.0],  # RGBA
    "size": 20,
    "position": (100, 100),  # Default position
    "vertical_position": 85.0,  # Default vertical position (percentage from bottom)
    "horizontal_position": 50.0,  # Default horizontal position (percentage from left)
    "handler": None,
    "is_enabled": False,
    "timer": None,  # Timer for continuous redraws
    "mode": None,  # Current rotation mode
    "value": None,  # Current rotation value
}

def draw_callback_px():
    """Draw the text in the viewport"""
    # If we have a value to display or we're in the fade-out period
    if draw_data["value"] is not None or time.time() < draw_data["start_time"] + draw_data["duration"] + draw_data["fade_duration"]:
        # Calculate time elapsed since start
        elapsed = time.time() - draw_data["start_time"]
        
        # Calculate alpha based on fade timing
        if elapsed > draw_data["duration"]:
            # Fade out phase
            fade_progress = (elapsed - draw_data["duration"]) / draw_data["fade_duration"]
            alpha = 1.0 - fade_progress
        else:
            alpha = 1.0
        
        # Set text properties
        font_id = 0  # Default font
        blf.position(font_id, draw_data["position"][0], draw_data["position"][1], 0)
        blf.size(font_id, draw_data["size"])
        
        # Set color with current alpha
        color = draw_data["color"].copy()
        color[3] = alpha * color[3]
        blf.color(font_id, *color)
        
        # Draw the text
        blf.draw(font_id, draw_data["text"])
    else:
        # If there's no value to display and we're outside the fade duration, remove handler
        _remove_handler()

def timer_update():
    """Timer callback to force redraw during fading"""
    # Force a redraw of all 3D VIEW regions
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        region.tag_redraw()
    
    # Calculate time elapsed
    elapsed = time.time() - draw_data["start_time"]
    
    # Stop the timer if we're done fading and not showing continuously
    if elapsed > draw_data["duration"] + draw_data["fade_duration"] and draw_data["value"] is None:
        _remove_timer()
        return None
    
    return 0.01  # 100 fps refresh rate

def _remove_handler():
    """Internal function to remove the draw handler if it exists"""
    if draw_data["handler"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(draw_data["handler"], 'WINDOW')
        draw_data["handler"] = None
        draw_data["is_enabled"] = False
    
    # Also remove the timer
    _remove_timer()
    
    # Reset the value
    draw_data["value"] = None

def _remove_timer():
    """Internal function to remove the timer if it exists"""
    if draw_data["timer"] is not None:
        bpy.app.timers.remove(draw_data["timer"])
        draw_data["timer"] = None

def remove_handler():
    """Public function to remove the draw handler, for use by other modules"""
    _remove_handler()

def format_rotation_value(mode, value):
    """Format the rotation value based on the mode"""
    if mode == 'SHADOW_ROTATION':
        # Don't show overlay for Shadow rotation as requested
        return None
    
    elif mode == 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION':
        # For studio lighting
        degrees = value
        return f"Studiolight World Space Rotation: {degrees:.2f}°"
    
    elif mode == 'HDRI_ROTATION':
        # For built-in HDRI
        degrees = value
        return f"Built-in HDRI Rotation: {degrees:.2f}°"
    
    elif mode == 'CUSTOM_HDRI_ROTATION':
        # For custom HDRI, handle different value types
        if hasattr(value, 'z'):  # Vector or Euler
            degrees = math.degrees(value.z)
            return f"Custom HDRI Rotation: {degrees:.2f}°"
        else:  # float
            degrees = value
            return f"Custom HDRI Rotation: {degrees:.2f}°"
    
    elif mode == 'MAPPING_NODE_ROTATION':
        # For mapping node, handle different value types
        if hasattr(value, 'z'):  # Vector or Euler
            degrees = math.degrees(value.z)
            return f"HDRI Mapping Rotation: {degrees:.2f}°"
        else:
            degrees = value
            return f"HDRI Mapping Rotation: {degrees:.2f}°"
    
    elif mode == 'SKY_TEXTURE_ROTATION':
        # For sky texture, format as degrees
        degrees = math.degrees(value)
        return f"Sky Texture Rotation: {degrees:.2f}°"
    
    else:
        # Default fallback
        return f"Rotation: {value:.2f}°"

def update_rotation_value(mode, value):
    """Update the rotation value to be displayed in the viewport"""
    # Don't show anything for shadow rotation
    if mode == 'SHADOW_ROTATION':
        return
    
    # Check if viewport overlay is enabled in preferences
    try:
        addon_prefs = bpy.context.preferences.addons[__package__].preferences
        if not addon_prefs.display_rotation_overlay:
            # Rotation overlay is disabled, don't show
            return
    except (AttributeError, KeyError):
        # If we can't access preferences, default to enabled
        pass
    
    # Format the text based on the mode and value
    formatted_text = format_rotation_value(mode, value)
    if not formatted_text:
        return
    
    # Update the rotation value and mode
    draw_data["mode"] = mode
    draw_data["value"] = value
    draw_data["text"] = formatted_text
    
    # Update the start time for fading
    draw_data["start_time"] = time.time()
    
    # Get the region dimensions
    region = bpy.context.region
    if region:
        # Calculate vertical position based on preference (percentage from bottom)
        vertical_pos = int(region.height * (draw_data["vertical_position"] / 100.0))
        
        # Calculate horizontal position based on preference (percentage from left)
        text_width = int(len(draw_data["text"]) * draw_data["size"] * 0.50)  # Approximate text width
        horizontal_pos = int(region.width * (draw_data["horizontal_position"] / 100.0)) - (text_width // 2)
        
        draw_data["position"] = (horizontal_pos, vertical_pos)
    
    # Add the draw handler if not already enabled
    if not draw_data["is_enabled"]:
        draw_data["handler"] = bpy.types.SpaceView3D.draw_handler_add(
            draw_callback_px, (), 'WINDOW', 'POST_PIXEL')
        draw_data["is_enabled"] = True
    
    # Start the timer for continuous redraws if not already running
    if draw_data["timer"] is None:
        draw_data["timer"] = bpy.app.timers.register(timer_update)
    
    # Force initial redraw of all 3D VIEW regions
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        region.tag_redraw()

def register():
    pass

def unregister():
    # Make sure to remove any active handlers on addon unregister
    _remove_handler() 