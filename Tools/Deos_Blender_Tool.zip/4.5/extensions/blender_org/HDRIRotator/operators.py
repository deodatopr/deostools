import bpy
import math
import mathutils
import os
from . import draw_handler

def get_addon_prefs():
    addon_name = __package__
    prefs = None
    try:
        prefs = bpy.context.preferences.addons[addon_name].preferences
    except KeyError:
        prefs = None
    return prefs

class HDRI_Rotator(bpy.types.Operator):
    """Rotate HDRI or Light Direction with your mouse"""
    bl_idname = "view3d.hdri_rotator"
    bl_label = "HDRI Rotator"
    bl_description = "Rotate HDRI or Light Direction with your mouse. Hold {SHIFT} for precision."
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    
    def normalize_rotation_rate(self, delta_x, mode):
        """
        Normalize rotation rate across different HDRI control methods
        """
        # Add safety checks
        if delta_x == 0:
            return 0.0
            
        # Base constants for normalization
        BASE_RANGE = 360.0  # Full rotation range in degrees
        MOUSE_PIXELS_FOR_FULL_ROTATION = 1000.0  # Pixels needed for full rotation
        
        # Get user sensitivity preference (0.1 to 2.0 range)
        addon_prefs = get_addon_prefs()
        user_sensitivity = addon_prefs.sensitivity if addon_prefs else 0.8
        precision_enabled = addon_prefs.enable_precision if addon_prefs else True
        
        # Clamp sensitivity to valid range
        user_sensitivity = max(0.1, min(2.0, user_sensitivity))
        
        # Apply precision mode if shift is held and precision mode is enabled
        precision_multiplier = 0.1 if (self.shift_held and precision_enabled) else 1.0
        
        # Calculate base rotation rate
        base_rotation = (delta_x / MOUSE_PIXELS_FOR_FULL_ROTATION) * BASE_RANGE
        
        # Apply mode-specific scaling
        if mode == 'SHADOW_ROTATION':
            scale_factor = 0.5
        elif mode == 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION':
            scale_factor = 1.0
        elif mode == 'HDRI_ROTATION':
            scale_factor = 1.0
        elif mode == 'CUSTOM_HDRI_ROTATION':
            scale_factor = 1.0
        elif mode == 'SKY_TEXTURE_ROTATION':
            scale_factor = 1.0
        else:
            scale_factor = 1.0
        
        # Calculate final rotation with all factors
        final_rotation = (
            base_rotation * 
            scale_factor * 
            user_sensitivity * 
            precision_multiplier
        )
        
        return final_rotation

    def modal(self, context, event):
        try:
            if event.type == 'MOUSEMOVE':
                # Get addon preferences
                addon_prefs = get_addon_prefs()
                precision_enabled = addon_prefs.enable_precision if addon_prefs else True

                # Update shift state only if precision mode is enabled
                if event.shift != self.shift_held and precision_enabled:
                    self.shift_held = event.shift
                    self.start_x = event.mouse_x
                    self.start_y = event.mouse_y
                    if self.mode == 'SHADOW_ROTATION':  # Renamed from LIGHT_DIRECTION
                        self.start_light_direction = self.scene.display.light_direction.copy()
                    else:
                        self.start_rotation = self.get_current_rotation()
                elif not precision_enabled:
                    self.shift_held = False

                # Calculate mouse movement
                delta_x = event.mouse_x - self.start_x
                delta_y = event.mouse_y - self.start_y

                # Get normalized rotation based on mode
                rotation_change = self.normalize_rotation_rate(delta_x, self.mode)

                if self.mode == 'SHADOW_ROTATION':  # Renamed from LIGHT_DIRECTION
                    # Convert rotation change to radians for vector rotation
                    # Invert delta_y for more intuitive up/down control
                    rot_x = (-delta_y / delta_x) * rotation_change * math.pi / 180.0 if delta_x != 0 else 0
                    rot_z = -rotation_change * math.pi / 180.0
                    
                    new_light_direction = self.calculate_new_direction(
                        self.start_light_direction,
                        rot_x,
                        rot_z
                    )
                    self.scene.display.light_direction = new_light_direction
                    
                    # Update the rotation value overlay
                    draw_handler.update_rotation_value(self.mode, new_light_direction)
                
                elif self.mode == 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION':
                    # For world space lighting with studio shaders, similar to built-in HDRI
                    new_rotation = self.start_rotation + rotation_change
                    # Wrap rotation to -180 to 180 degrees
                    new_rotation = ((new_rotation + 180) % 360) - 180
                    self.set_studio_world_space_rotation(new_rotation)
                    
                    # Update the rotation value overlay
                    draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == 'CUSTOM_HDRI_ROTATION':
                    if isinstance(self.start_rotation, (mathutils.Euler, mathutils.Vector)):
                        new_rotation = self.start_rotation.copy()
                        new_rotation.z = self.start_rotation.z + math.radians(rotation_change)
                    elif isinstance(self.start_rotation, (float, int)):
                        new_rotation = self.start_rotation + rotation_change
                    self.set_custom_hdri_rotation(new_rotation)
                    
                    # Update the rotation value overlay
                    draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == 'MAPPING_NODE_ROTATION':
                    if isinstance(self.start_rotation, (mathutils.Euler, mathutils.Vector)):
                        new_rotation = self.start_rotation.copy()
                        new_rotation.z = self.start_rotation.z + math.radians(rotation_change)
                    self.set_mapping_node_rotation(new_rotation)
                    
                    # Update the rotation value overlay
                    draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == 'SKY_TEXTURE_ROTATION':
                    # For Sky Texture, we're rotating the sun position
                    if isinstance(self.start_rotation, (float, int)):
                        # Sun rotation is in radians while rotation_change is in degrees
                        # Convert rotation_change to radians before adding
                        new_rotation = self.start_rotation + math.radians(rotation_change)
                        self.set_sky_texture_rotation(new_rotation)
                        
                        # Update the rotation value overlay
                        draw_handler.update_rotation_value(self.mode, new_rotation)
                
                elif self.mode == 'HDRI_ROTATION':
                    new_rotation = self.start_rotation + rotation_change
                    # Wrap rotation to -180 to 180 degrees
                    new_rotation = ((new_rotation + 180) % 360) - 180
                    self.set_builtin_hdr_rotation(new_rotation)
                    
                    # Update the rotation value overlay
                    draw_handler.update_rotation_value(self.mode, new_rotation)
                
                self.safe_redraw()
                return {'RUNNING_MODAL'}

            # Rest of the modal method remains unchanged
            elif event.type == 'RIGHTMOUSE' and event.value == 'RELEASE':
                self.cleanup()
                return {'FINISHED'}
            elif event.type in {'ESC'}:
                if self.mode == 'SHADOW_ROTATION':  # Renamed from LIGHT_DIRECTION
                    self.scene.display.light_direction = self.start_light_direction
                elif self.mode == 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION':
                    self.set_studio_world_space_rotation(self.start_rotation)
                elif self.mode == 'CUSTOM_HDRI_ROTATION':
                    self.set_custom_hdri_rotation(self.start_rotation)
                elif self.mode == 'MAPPING_NODE_ROTATION':
                    self.set_mapping_node_rotation(self.start_rotation)
                elif self.mode == 'SKY_TEXTURE_ROTATION':
                    self.set_sky_texture_rotation(self.start_rotation)
                elif self.mode == 'HDRI_ROTATION':
                    self.set_builtin_hdr_rotation(self.start_rotation)
                self.cleanup()
                return {'CANCELLED'}
            return {'RUNNING_MODAL'}

        except Exception as e:
            self.report({'ERROR'}, f"An error occurred: {e}")
            self.cleanup()
            return {'CANCELLED'}


    def invoke(self, context, event):
        try:
            # Store initial mouse position
            self.start_x = event.mouse_x
            self.start_y = event.mouse_y
            self.shift_held = event.shift

            # Store references to frequently accessed data
            self.window = context.window
            self.space = context.space_data
            self.scene = context.scene

            # Get a safe reference to the area
            self.area = self.get_area_safe()
            if not self.area:
                self.report({'WARNING'}, "Operator must be run in a 3D Viewport")
                return {'CANCELLED'}

            # Get shading information
            self.shading = self.space.shading
            self.shading_type = self.shading.type

            # Check specific conditions based on shading type
            if self.shading_type == 'SOLID':
                # In Solid mode, check for shadows and world space lighting
                shadows_enabled = self.shading.show_shadows
                world_space_lighting_enabled = self.shading.use_world_space_lighting
                
                # Implement priority rules for Solid mode
                if shadows_enabled and world_space_lighting_enabled:
                    # Both enabled - prioritize world space lighting with a warning
                    self.mode = 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION'
                    self.start_rotation = math.degrees(self.shading.studiolight_rotate_z)
                    self.window.cursor_modal_set('SCROLL_X')
                    self.report({'INFO'}, "Shadows and World Space Lighting detected - World Space Lighting has been prioritized to prevent conflict")
                    
                    # Display initial rotation value
                    draw_handler.update_rotation_value(self.mode, self.start_rotation)
                elif shadows_enabled:
                    # Only shadows enabled
                    self.mode = 'SHADOW_ROTATION'  # Renamed from LIGHT_DIRECTION
                    self.start_light_direction = self.scene.display.light_direction.copy()
                    self.window.cursor_modal_set('SCROLL_XY')
                    
                    # Display initial rotation value
                    draw_handler.update_rotation_value(self.mode, self.start_light_direction)
                elif world_space_lighting_enabled:
                    # Only world space lighting enabled
                    self.mode = 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION'
                    self.start_rotation = math.degrees(self.shading.studiolight_rotate_z)
                    self.window.cursor_modal_set('SCROLL_X')
                    
                    # Display initial rotation value
                    draw_handler.update_rotation_value(self.mode, self.start_rotation)
                else:
                    # Neither enabled
                    self.report({'WARNING'}, "Shadows and/or World Space Lighting (Studio Lighting only) not detected")
                    return {'CANCELLED'}
            
            # Check if we're in Workbench with shadows (for Rendered mode with Workbench engine)
            elif self.shading_type == 'RENDERED' and context.scene.render.engine == 'BLENDER_WORKBENCH' and self.shading.show_shadows:
                # Workbench Rendered with shadows enabled
                self.mode = 'SHADOW_ROTATION'  # Renamed from LIGHT_DIRECTION
                self.start_light_direction = self.scene.display.light_direction.copy()
                self.window.cursor_modal_set('SCROLL_XY')
                
                # Display initial rotation value
                draw_handler.update_rotation_value(self.mode, self.start_light_direction)
            
            elif self.shading_type in {'MATERIAL', 'RENDERED'}:
                # Material Preview or Rendered modes (non-Workbench)
                if self.shading_type == 'MATERIAL':
                    self.use_scene_world = self.shading.use_scene_world
                    
                else:  # RENDERED
                    self.use_scene_world = self.shading.use_scene_world_render


                if self.use_scene_world:
                    # First, check if there's a Sky Texture node to control
                    self.sky_texture_node = self.find_sky_texture_node()
                    if self.sky_texture_node:
                        # Found a Sky Texture node with a Sun Rotation input
                        self.start_rotation = self.sky_texture_node.sun_rotation
                        self.mode = 'SKY_TEXTURE_ROTATION'
                        
                        # Display initial rotation value
                        draw_handler.update_rotation_value(self.mode, self.start_rotation)
                    else:
                        # Check for custom HDRI setup
                        self.rotation_input = self.find_rotation_input()
                        if self.rotation_input is not None:
                            # Custom HDRI with rotation input
                            default_value = self.rotation_input.default_value
                            if isinstance(default_value, (mathutils.Euler, mathutils.Vector)):
                                self.start_rotation = default_value.copy()
                            elif isinstance(default_value, (float, int)):
                                self.start_rotation = default_value
                            else:
                                self.report({'ERROR'}, "Unsupported rotation input type.")
                                return {'CANCELLED'}
                            self.mode = 'CUSTOM_HDRI_ROTATION'
                            
                            # Sync from built-in HDRI if enabled and same texture detected
                            if self.should_sync_hdri_rotation():
                                self.sync_builtin_rotation_to_world()
                            
                            # Display initial rotation value
                            draw_handler.update_rotation_value(self.mode, self.start_rotation)
                        else:
                            # Check for mapping node
                            self.mapping_node = self.find_mapping_node()
                            if self.mapping_node:
                                default_value = self.mapping_node.inputs['Rotation'].default_value
                                if isinstance(default_value, (mathutils.Vector, mathutils.Euler)):
                                    self.start_rotation = default_value.copy()
                                else:
                                    self.report({'ERROR'}, "Unsupported rotation input type in mapping node.")
                                    return {'CANCELLED'}
                                self.mode = 'MAPPING_NODE_ROTATION'
                                
                                # Sync from built-in HDRI if enabled and same texture detected
                                if self.should_sync_hdri_rotation():
                                    self.sync_builtin_rotation_to_world()
                                
                                # Display initial rotation value
                                draw_handler.update_rotation_value(self.mode, self.start_rotation)
                            else:
                                self.report({'WARNING'}, "No 'Rotation' input, Sky Texture node, or Mapping node found in World nodes")
                                return {'CANCELLED'}
                else:
                    # Built-in HDRI
                    self.start_rotation = self.get_builtin_hdr_rotation()
                    self.mode = 'HDRI_ROTATION'
                    
                    # Sync from World HDRI if enabled and same texture detected
                    if self.should_sync_hdri_rotation():
                        self.sync_world_rotation_to_builtin()
                    
                    # Display initial rotation value
                    draw_handler.update_rotation_value(self.mode, self.start_rotation)

                # Set appropriate cursor for HDRI rotation
                self.window.cursor_modal_set('SCROLL_X')
                
                # Handle mode switch sync for Material/Rendered modes
                if self.shading_type in {'MATERIAL', 'RENDERED'}:
                    self.handle_mode_switch_sync()
            else:
                # Unsupported shading mode
                self.report({'WARNING'}, "Shading type not supported")
                return {'CANCELLED'}

            context.window_manager.modal_handler_add(self)
            

            
            return {'RUNNING_MODAL'}

        except Exception as e:
            self.report({'ERROR'}, f"Initialization failed: {str(e)}")
            self.cleanup()
            return {'CANCELLED'}


        
    def cleanup(self):
        # Reset cursor
        if hasattr(self, 'window') and self.window:
            self.window.cursor_modal_restore()
        
        # Clear all stored states
        for attr in ['shift_held', 'start_rotation', 'start_light_direction', 
                    'rotation_input', 'mapping_node', 'sky_texture_node', 'mode', 'start_x', 'start_y']:
            if hasattr(self, attr):
                delattr(self, attr)
        
        # Keep the overlay visible for a moment but mark as not rotating anymore
        # This allows the overlay to fade out according to preferences
        draw_handler.draw_data["value"] = draw_handler.draw_data["value"]

    def safe_redraw(self):
        area = self.get_area_safe()
        if area:
            area.tag_redraw()

    def get_area_safe(self):
        # Safely get area reference
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                return area
        return None

    def find_sky_texture_node(self):
        """Find a Sky Texture node in the World node tree"""
        world = self.scene.world
        if world is None or not world.use_nodes:
            return None
        node_tree = world.node_tree

        visited_groups = set()
        nodes_to_check = list(node_tree.nodes)

        while nodes_to_check:
            node = nodes_to_check.pop()
            if node.type == 'GROUP':
                if node.node_tree and node.node_tree not in visited_groups:
                    visited_groups.add(node.node_tree)
                    nodes_to_check.extend(node.node_tree.nodes)
            elif node.type == 'TEX_SKY':
                return node
        return None

    def set_sky_texture_rotation(self, rotation_value):
        """Set the Sun Rotation value for a Sky Texture node"""
        if not self.sky_texture_node:
            return
        
        # Sky Texture sun_rotation is in radians
        if isinstance(rotation_value, (float, int)):
            # Convert to radians if the value is in degrees
            if rotation_value > math.pi * 2:  # If value is likely in degrees
                rotation_rad = math.radians(rotation_value)
            else:
                rotation_rad = rotation_value
            
            # Don't force wrapping to make behavior consistent with custom HDRI
            self.sky_texture_node.sun_rotation = rotation_rad
        else:
            # If it's already in radians
            rotation_rad = rotation_value
            self.sky_texture_node.sun_rotation = rotation_rad
        
        # Sync to built-in HDRI if enabled and same texture detected
        if self.should_sync_hdri_rotation():
            self.sync_world_to_builtin_rotation(rotation_rad)
        
        # Force update
        bpy.context.view_layer.update()
        self.safe_redraw()

    def get_current_rotation(self):
        """Get current rotation value based on mode"""
        try:
            if self.mode == 'SHADOW_ROTATION':  # Renamed from LIGHT_DIRECTION
                return self.scene.display.light_direction.copy()
            elif self.mode == 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION':
                return math.degrees(self.shading.studiolight_rotate_z)
            elif self.mode == 'CUSTOM_HDRI_ROTATION':
                if isinstance(self.start_rotation, (mathutils.Euler, mathutils.Vector)):
                    return self.rotation_input.default_value.copy()
                elif isinstance(self.start_rotation, (float, int)):
                    return self.rotation_input.default_value
                return None  # Handle unexpected types
            elif self.mode == 'MAPPING_NODE_ROTATION':
                return self.mapping_node.inputs['Rotation'].default_value.copy()
            elif self.mode == 'SKY_TEXTURE_ROTATION':
                return self.sky_texture_node.sun_rotation
            elif self.mode == 'HDRI_ROTATION':
                return self.get_builtin_hdr_rotation()
            return None  # Handle unexpected modes
        except Exception as e:
            self.report({'WARNING'}, f"Error getting rotation: {str(e)}")
            return None

    def find_rotation_input(self, node_tree=None, visited=None, depth=0):
        if visited is None:
            visited = set()
        if node_tree is None:
            world = self.scene.world
            if world is None or not world.use_nodes:
                return None
            node_tree = world.node_tree

        if node_tree in visited:
            return None
        visited.add(node_tree)

        for node in node_tree.nodes:
            if node.type == 'GROUP':
                if 'Rotation' in node.inputs:
                    rotation_input = node.inputs['Rotation']
                    if rotation_input.is_linked or rotation_input.default_value is not None:
                        return rotation_input
                # Recursively check inside the node group's node tree
                rotation_input = self.find_rotation_input(node.node_tree, visited, depth + 1)
                if rotation_input:
                    return rotation_input
            elif 'Rotation' in node.inputs:
                rotation_input = node.inputs['Rotation']
                if rotation_input.is_linked or rotation_input.default_value is not None:
                    return rotation_input
        return None

    def find_mapping_node(self):
        world = self.scene.world
        if world is None or not world.use_nodes:
            return None
        node_tree = world.node_tree

        visited_groups = set()
        nodes_to_check = list(node_tree.nodes)

        while nodes_to_check:
            node = nodes_to_check.pop()
            if node.type == 'GROUP':
                if node.node_tree and node.node_tree not in visited_groups:
                    visited_groups.add(node.node_tree)
                    nodes_to_check.extend(node.node_tree.nodes)
            elif node.type == 'MAPPING':
                # Check if this Mapping node is connected to an Environment Texture node
                if self.is_mapping_connected_to_env_texture(node):
                    return node
        return None

    def is_mapping_connected_to_env_texture(self, mapping_node):
        # Check downstream nodes to see if the mapping node ultimately connects to an Environment Texture
        nodes_to_check = [mapping_node]
        visited_nodes = set()

        while nodes_to_check:
            node = nodes_to_check.pop()
            visited_nodes.add(node)

            if node.type == 'TEX_ENVIRONMENT':
                return True

            for output in node.outputs:
                for link in output.links:
                    next_node = link.to_node
                    if next_node not in visited_nodes:
                        nodes_to_check.append(next_node)
                    if next_node.type == 'GROUP':
                        # Include nodes inside the group
                        if next_node.node_tree:
                            nodes_to_check.extend(next_node.node_tree.nodes)

        return False

    def set_custom_hdri_rotation(self, rotation_value):
        if isinstance(self.rotation_input.default_value, (mathutils.Euler, mathutils.Vector)):
            self.rotation_input.default_value = rotation_value
        elif isinstance(self.rotation_input.default_value, (float, int)):
            self.rotation_input.default_value = rotation_value
        else:
            self.report({'ERROR'}, "Unsupported rotation input type.")
            return
        
        # Sync to built-in HDRI if enabled and same texture detected
        if self.should_sync_hdri_rotation():
            # Convert rotation to radians for built-in HDRI
            if isinstance(rotation_value, (mathutils.Euler, mathutils.Vector)):
                rotation_rad = rotation_value.z
            else:
                rotation_rad = math.radians(rotation_value)
            self.sync_world_to_builtin_rotation(rotation_rad)
        
        # Force update of the scene to ensure the change takes effect
        bpy.context.view_layer.update()
        # Redraw the viewport
        self.safe_redraw()

    def set_mapping_node_rotation(self, rotation_value):
        if isinstance(self.mapping_node.inputs['Rotation'].default_value, mathutils.Vector):
            rotation = self.mapping_node.inputs['Rotation'].default_value.copy()
            if isinstance(rotation_value, mathutils.Vector):
                rotation[2] = rotation_value[2]
            else:
                rotation[2] = rotation_value  # Degrees
            self.mapping_node.inputs['Rotation'].default_value = rotation
        elif isinstance(self.mapping_node.inputs['Rotation'].default_value, mathutils.Euler):
            rotation = self.mapping_node.inputs['Rotation'].default_value.copy()
            if isinstance(rotation_value, mathutils.Euler):
                rotation.z = rotation_value.z
            else:
                rotation.z = rotation_value  # Degrees
            self.mapping_node.inputs['Rotation'].default_value = rotation
        elif isinstance(self.mapping_node.inputs['Rotation'].default_value, (float, int)):
            self.mapping_node.inputs['Rotation'].default_value = rotation_value  # Degrees
        else:
            self.report({'ERROR'}, "Unsupported rotation input type in mapping node.")
            return
        
        # Sync to built-in HDRI if enabled and same texture detected
        if self.should_sync_hdri_rotation():
            # Convert rotation to radians for built-in HDRI
            if isinstance(rotation_value, (mathutils.Euler, mathutils.Vector)):
                rotation_rad = rotation_value.z
            else:
                rotation_rad = math.radians(rotation_value)
            self.sync_world_to_builtin_rotation(rotation_rad)
        
        # Force update
        bpy.context.view_layer.update()
        self.safe_redraw()

    def get_builtin_hdr_rotation(self):
        # Get the built-in HDRI rotation in degrees
        rotation_rad = self.shading.studiolight_rotate_z
        rotation_deg = math.degrees(rotation_rad)
        return rotation_deg

    def set_builtin_hdr_rotation(self, rotation_value):
        # Set the built-in HDRI rotation
        rotation_rad = math.radians(rotation_value)
        # Wrap rotation to -pi to pi
        rotation_rad_wrapped = (rotation_rad + math.pi) % (2 * math.pi) - math.pi
        self.shading.studiolight_rotate_z = rotation_rad_wrapped
        
        # Sync to World HDRI if enabled and same texture detected
        if self.should_sync_hdri_rotation():
            self.sync_builtin_to_world_rotation(rotation_rad_wrapped)
        
        self.safe_redraw()

    def calculate_new_direction(self, start_direction, rot_x, rot_z):
        """Calculate new light direction based on mouse movement"""
        # Create rotation matrices
        rot_x_mat = mathutils.Matrix.Rotation(rot_x, 4, 'X')
        rot_z_mat = mathutils.Matrix.Rotation(rot_z, 4, 'Z')
        
        # Apply rotations in correct order
        new_direction = start_direction.copy()
        new_direction.rotate(rot_z_mat)  # First rotate around Z axis
        new_direction.rotate(rot_x_mat)  # Then rotate around X axis
        
        # Normalize the vector
        if new_direction.length_squared != 0:
            new_direction.normalize()
        else:
            new_direction = mathutils.Vector((0.0, 0.0, -1.0))
            
        return new_direction

    def set_studio_world_space_rotation(self, rotation_value):
        """Set the Studio World Space Lighting rotation value"""
        # Convert to radians for Blender's internal representation
        rotation_rad = math.radians(rotation_value)
        # Wrap rotation to -pi to pi
        rotation_rad_wrapped = (rotation_rad + math.pi) % (2 * math.pi) - math.pi
        # Apply the rotation
        self.shading.studiolight_rotate_z = rotation_rad_wrapped
        
        # Sync to World HDRI if enabled and same texture detected
        if self.should_sync_hdri_rotation():
            self.sync_builtin_to_world_rotation(rotation_rad_wrapped)
        
        # Force update
        self.safe_redraw()
    
    def should_sync_hdri_rotation(self):
        """Check if HDRI rotation sync should be enabled"""
        try:
            addon_prefs = get_addon_prefs()
            if not addon_prefs or not addon_prefs.enable_hdri_sync:
                return False
            
            # Check if we have a World with nodes enabled
            world = self.scene.world
            if not world or not world.use_nodes:
                return False
            
            # Check if the World uses the same HDRI as the built-in
            return self.is_same_hdri_texture()
        except:
            return False
    
    def is_same_hdri_texture(self):
        """Check if the World HDRI uses the same texture as the current built-in HDRI"""
        try:
            # Get current built-in HDRI name
            current_builtin_hdri = self.shading.studio_light
            if not current_builtin_hdri:
                return False
            
            # Get World HDRI texture
            world = self.scene.world
            if not world or not world.use_nodes:
                return False
            
            # Find environment texture node in world
            env_texture_node = self.find_environment_texture_node(world.node_tree)
            if not env_texture_node or not env_texture_node.image:
                return False
            
            # Get the image name from the environment texture node
            world_image = env_texture_node.image
            if not world_image:
                return False
            
            # Compare file names (case-insensitive)
            world_hdri_name = os.path.basename(world_image.filepath).lower()
            builtin_hdri_name = current_builtin_hdri.lower()
            
            # Also check if the image name matches (for cases where filepath might be empty)
            world_image_name = world_image.name.lower()
            
            # More flexible matching - check if the built-in HDRI name is contained in the world image name
            # or vice versa, to handle cases where Shading Plus might add prefixes/suffixes
            return (world_hdri_name == builtin_hdri_name or 
                   world_image_name == builtin_hdri_name or
                   builtin_hdri_name in world_hdri_name or
                   builtin_hdri_name in world_image_name or
                   world_hdri_name in builtin_hdri_name or
                   world_image_name in builtin_hdri_name)
        except Exception as e:
            return False
    
    def find_environment_texture_node(self, node_tree, visited=None):
        """Find Environment Texture node in a node tree, including nested groups"""
        if visited is None:
            visited = set()
        
        if node_tree in visited:
            return None
        visited.add(node_tree)
        
        for node in node_tree.nodes:
            if node.type == 'TEX_ENVIRONMENT':
                return node
            elif node.type == 'GROUP' and node.node_tree:
                result = self.find_environment_texture_node(node.node_tree, visited)
                if result:
                    return result
        return None
    
    def sync_builtin_to_world_rotation(self, rotation_rad):
        """Sync built-in HDRI rotation to World HDRI rotation"""
        try:
            world = self.scene.world
            if not world or not world.use_nodes:
                return
            
            # Find mapping node in world
            mapping_node = self.find_mapping_node_in_world(world.node_tree)
            if mapping_node:
                # Set the Z rotation (Yaw) in the mapping node
                mapping_node.inputs['Rotation'].default_value[2] = rotation_rad
        except Exception as e:
            pass
    
    def sync_world_to_builtin_rotation(self, rotation_rad):
        """Sync World HDRI rotation to built-in HDRI rotation"""
        try:
            # Set the built-in HDRI rotation
            self.shading.studiolight_rotate_z = rotation_rad
        except Exception as e:
            pass
    
    def find_mapping_node_in_world(self, node_tree, visited=None):
        """Find Mapping node in world node tree, including nested groups"""
        if visited is None:
            visited = set()
        
        if node_tree in visited:
            return None
        visited.add(node_tree)
        
        for node in node_tree.nodes:
            if node.type == 'MAPPING':
                return node
            elif node.type == 'GROUP' and node.node_tree:
                result = self.find_mapping_node_in_world(node.node_tree, visited)
                if result:
                    return result
        return None
    
    def sync_world_rotation_to_builtin(self):
        """Sync World HDRI rotation to built-in HDRI when switching to built-in mode"""
        try:
            world = self.scene.world
            if not world or not world.use_nodes:
                return
            
            # Find mapping node in world
            mapping_node = self.find_mapping_node_in_world(world.node_tree)
            if mapping_node:
                # Get the Z rotation from the mapping node
                rotation_value = mapping_node.inputs['Rotation'].default_value
                if isinstance(rotation_value, (mathutils.Vector, mathutils.Euler)):
                    rotation_rad = rotation_value[2] if isinstance(rotation_value, mathutils.Vector) else rotation_value.z
                    # Sync to built-in HDRI
                    self.shading.studiolight_rotate_z = rotation_rad
        except Exception as e:
            pass
    
    def sync_builtin_rotation_to_world(self):
        """Sync built-in HDRI rotation to World HDRI when switching to world mode"""
        try:
            world = self.scene.world
            if not world or not world.use_nodes:
                return
            
            # Get current built-in HDRI rotation
            builtin_rotation_rad = self.shading.studiolight_rotate_z
            
            # Find mapping node in world
            mapping_node = self.find_mapping_node_in_world(world.node_tree)
            if mapping_node:
                # Set the Z rotation in the mapping node
                rotation_value = mapping_node.inputs['Rotation'].default_value
                if isinstance(rotation_value, (mathutils.Vector, mathutils.Euler)):
                    if isinstance(rotation_value, mathutils.Vector):
                        rotation_value[2] = builtin_rotation_rad
                    else:
                        rotation_value.z = builtin_rotation_rad
                    mapping_node.inputs['Rotation'].default_value = rotation_value
        except Exception as e:
            pass

    def execute(self, context):
        self.cleanup()
        return {'FINISHED'}

    def cancel(self, context):
        # Restore original settings if necessary
        if self.mode == 'SHADOW_ROTATION':  # Renamed from LIGHT_DIRECTION
            self.scene.display.light_direction = self.start_light_direction
        elif self.mode == 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION':
            self.set_studio_world_space_rotation(self.start_rotation)
        elif self.mode == 'CUSTOM_HDRI_ROTATION':
            self.set_custom_hdri_rotation(self.start_rotation)
        elif self.mode == 'MAPPING_NODE_ROTATION':
            self.set_mapping_node_rotation(self.start_rotation)
        elif self.mode == 'SKY_TEXTURE_ROTATION':
            self.set_sky_texture_rotation(self.start_rotation)
        elif self.mode == 'HDRI_ROTATION':
            self.set_builtin_hdr_rotation(self.start_rotation)
        self.cleanup()
        return {'CANCELLED'}



    def handle_mode_switch_sync(self):
        """Handle sync when switching between Material and Rendered modes"""
        try:
            # Only handle sync if it's enabled
            if not self.should_sync_hdri_rotation():
                return
            
            # Get current mode info
            if self.shading_type == 'MATERIAL':
                use_scene_world = self.shading.use_scene_world
            else:  # RENDERED
                use_scene_world = self.shading.use_scene_world_render
            
            # If switching to scene world mode, sync from built-in to world
            if use_scene_world:
                self.sync_builtin_rotation_to_world()
            else:
                # If switching to built-in mode, sync from world to built-in
                self.sync_world_rotation_to_builtin()
                
        except Exception as e:
            pass

def register():
    bpy.utils.register_class(HDRI_Rotator)

def unregister():
    bpy.utils.unregister_class(HDRI_Rotator)

