bl_info = {
    "name": "HDRI Rotator",
    "description": "Rotate your HDRI/shadows in the viewport with CTRL+ALT+RMB.",
    "author": "1P2D <me@1p2d.com>",
    "version": (1, 1, 0),
    "blender": (4, 2, 0),
    "category": "Lighting",
    "location": "3D View",
}

import bpy
from . import operators, preferences, draw_handler

def register():
    operators.register()
    preferences.register()
    draw_handler.register()

def unregister():
    draw_handler.unregister()
    operators.unregister()
    preferences.unregister()

if __name__ == "__main__":
    register()
