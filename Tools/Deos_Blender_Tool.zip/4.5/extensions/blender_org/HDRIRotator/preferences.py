'''
HDRI Rotator Preferences
Author: 1P2D - Felix Pierron (me@1p2d.com)
Website: https://1p2d.com

This module defines the preferences for the HDRI Rotator addon.

License: GNU General Public License v3 (GPLv3)
'''

import bpy
import rna_keymap_ui
from . import bl_info
from . import draw_handler

class HDRIRotatorPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__  # Use __package__ to refer to the addon module name

    sensitivity: bpy.props.FloatProperty(
        name="Sensitivity",
        description="Adjust the rotation sensitivity",
        default=0.8,
        min=0.1,
        max=1.0,
    )

    enable_precision: bpy.props.BoolProperty(
        name="Enable Precision Mode",
        description="Hold SHIFT for precise rotation (slower movement)",
        default=True,
    )
    
    # Rotation value overlay settings
    display_rotation_overlay: bpy.props.BoolProperty(
        name="Display Rotation Value Overlay",
        description="Show the current rotation value in the 3D viewport",
        default=True,
        update=lambda self, context: self.update_rotation_overlay_state()
    )
    
    overlay_text_size: bpy.props.IntProperty(
        name="Text Size",
        description="Size of the overlay text",
        default=20,
        min=10,
        max=50,
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_display_duration: bpy.props.FloatProperty(
        name="Display Duration",
        description="How long to display the overlay (seconds)",
        default=2.0,
        min=0.5,
        max=10.0,
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_fade_duration: bpy.props.FloatProperty(
        name="Fade Duration",
        description="How long to fade out the overlay (seconds)",
        default=0.5,
        min=0.1,
        max=5.0,
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_text_color: bpy.props.FloatVectorProperty(
        name="Text Color",
        description="Color of the overlay text",
        default=(1.0, 1.0, 1.0, 1.0),
        size=4,
        min=0.0,
        max=1.0,
        subtype='COLOR',
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_vertical_position: bpy.props.FloatProperty(
        name="Vertical Position",
        description="Vertical position of the overlay (percentage from bottom)",
        default=85.0,
        min=0.0,
        max=100.0,
        subtype='PERCENTAGE',
        update=lambda self, context: self.update_overlay_settings()
    )
    
    overlay_horizontal_position: bpy.props.FloatProperty(
        name="Horizontal Position",
        description="Horizontal position of the overlay (percentage from left)",
        default=50.0,
        min=0.0,
        max=100.0,
        subtype='PERCENTAGE',
        update=lambda self, context: self.update_overlay_settings()
    )
    
    # HDRI Sync settings
    enable_hdri_sync: bpy.props.BoolProperty(
        name="Enable HDRI Rotation Sync",
        description="Automatically sync rotation between World HDRI and Built-in HDRI when they use the same texture source",
        default=True,
    )
    


    def has_shift_in_keymap(self, context):
        wm = context.window_manager
        kc = wm.keyconfigs.user

        for km in kc.keymaps:
            for kmi in km.keymap_items:
                if kmi.idname == 'view3d.hdri_rotator' and kmi.shift:
                    return True
        return False
    
    def update_rotation_overlay_state(self):
        """Update the rotation overlay state based on the preference"""
        # If disabled, make sure to remove any active viewport text
        if not self.display_rotation_overlay:
            draw_handler.remove_handler()
    
    def update_overlay_settings(self):
        """Update the draw handler settings when preferences change"""
        draw_handler.draw_data["size"] = self.overlay_text_size
        draw_handler.draw_data["duration"] = self.overlay_display_duration
        draw_handler.draw_data["fade_duration"] = self.overlay_fade_duration
        draw_handler.draw_data["color"] = list(self.overlay_text_color)
        draw_handler.draw_data["vertical_position"] = self.overlay_vertical_position
        draw_handler.draw_data["horizontal_position"] = self.overlay_horizontal_position

    def draw(self, context):
        layout = self.layout

        # Draw sensitivity slider
        layout.prop(self, "sensitivity")
        
        # Check for SHIFT in keymap
        shift_in_keymap = self.has_shift_in_keymap(context)
        
        # Draw precision mode toggle
        row = layout.row()
        row.enabled = not shift_in_keymap
        row.prop(self, "enable_precision")
        
        # Show warning if SHIFT is in keymap
        if shift_in_keymap:
            warning_row = layout.row()
            warning_row.alert = True
            warning_row.label(text="SHIFT key detected in Keymap - Precision mode disabled")
            self.enable_precision = False
        
        # HDRI Sync Settings
        box = layout.box()
        box.label(text="HDRI Rotation Sync:")
        box.prop(self, "enable_hdri_sync")
        
        # Add some spacing
        layout.separator()
        
        # Rotation Value Overlay Settings
        box = layout.box()
        box.label(text="Rotation Value Overlay:")
        box.prop(self, "display_rotation_overlay")
        
        # Only show settings if overlay is enabled
        if self.display_rotation_overlay:
            sub_box = box.box()
            
            row = sub_box.row()
            row.prop(self, "overlay_text_size")
            row.prop(self, "overlay_text_color")
            
            row = sub_box.row()
            row.prop(self, "overlay_display_duration")
            row.prop(self, "overlay_fade_duration")
            
            row = sub_box.row()
            row.prop(self, "overlay_vertical_position")
            row.prop(self, "overlay_horizontal_position")
        
        # Draw Keymap Settings
        layout.separator()
        self.draw_keymaps(context, layout)

    def draw_keymaps(self, context, layout):
        wm = context.window_manager
        kc = wm.keyconfigs.user

        # Keymap info specific to your addon
        keymaps_info = [
            {
                'km_name': '3D View',
                'space_type': 'VIEW_3D',
                'region_type': 'WINDOW',
                'operator_idname': 'view3d.hdri_rotator',
                'label': 'Keymap',
            },
        ]

        for km_info in keymaps_info:
            km = kc.keymaps.get(km_info['km_name'])
            if not km:
                continue

            for kmi in km.keymap_items:
                if kmi.idname == km_info['operator_idname']:
                    # Draw the keymap item without embedding it in an extra box
                    layout.label(text=km_info['label'])  # Label for the keymap
                    rna_keymap_ui.draw_kmi([], kc, km, kmi, layout, 0)
                    break

addon_keymaps = []

def register_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='3D View', space_type='VIEW_3D')

        # Add the keymap for the operator
        kmi = km.keymap_items.new('view3d.hdri_rotator', 'RIGHTMOUSE', 'PRESS', alt=True, ctrl=True)
        kmi.active = True

        addon_keymaps.append((km, kmi))

def unregister_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        for km, kmi in addon_keymaps:
            km.keymap_items.remove(kmi)
        addon_keymaps.clear()

def register():
    bpy.utils.register_class(HDRIRotatorPreferences)
    register_keymap()
    
    # Initialize overlay settings from preferences
    try:
        addon_prefs = bpy.context.preferences.addons[__package__].preferences
        if addon_prefs:
            addon_prefs.update_overlay_settings()
            
            # Check if overlay should be disabled initially
            if not addon_prefs.display_rotation_overlay:
                draw_handler.remove_handler()
    except:
        # If preferences not available, use defaults
        pass

def unregister():
    unregister_keymap()
    bpy.utils.unregister_class(HDRIRotatorPreferences)
    
    # Make sure to remove any active handlers on addon unregister
    draw_handler.remove_handler()
