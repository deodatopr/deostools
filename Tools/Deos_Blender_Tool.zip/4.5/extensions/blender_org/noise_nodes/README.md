<blockquote class="blockquote">

<span style="color:rgb(108, 117, 125);font-family:-apple-system , BlinkMacSystemFont ,;" color="">This addon is also available at extention.blender.org&nbsp;</span><span style="color:rgb(108, 117, 125);font-family:-apple-system , BlinkMacSystemFont ,;" color="">&nbsp;😊</span>
</blockquote>
<h3></h3>
<h3>Noise Nodes</h3>
<p><span style="border:0px;margin:0px;padding:0px;font-weight:700;vertical-align:initial;">Noise Nodes </span>is
 an add-on for Blender that provides you with custom nodes for creating advance materials. The plugin integrates nicely into the 
Blender interface, meaning that upon installing the add-on, all included
 nodes can be found in the:</p>
<p><font color="#000000" style="background-color: rgb(255, 255, 0);">Shader Nodes &gt; Add Node &gt; Noise Nodes</font></p>
<p><font color="#000000" style="background-color: rgb(255, 255, 0);">Geometery Nodes &gt; Add Node &gt; Noise Nodes</font></p>
<p>Addon Includes <b>14 Custom Nodes</b><br></p>
<ul>
<li>Voxel Noise&nbsp; <br></li>
<li>Cranal Noise</li>
<li>Pixelator</li>
<li>Scratches Noise</li>
<li>Dot Noise</li>
<li>Regular Noise</li>
<li>Streaks Noise</li>
<li>Fractal Noise</li>
<li>Dent Noise</li>
<li>Fluid Noise</li>
<li>Crackle<br></li>
<li>Wavy<br></li>
<li>Perlin<br></li>
<li>Step<br></li>
</ul>
<p><b></b>Image Preview:
 <img src="https://assets.superhivemarket.com/cache/436d0409d5f4be12a4ffd0fdb232837b.png" style="max-width: 100%;">
</p>
