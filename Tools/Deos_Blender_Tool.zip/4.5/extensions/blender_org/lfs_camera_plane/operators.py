# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later

import os

import bpy
from bpy.props import BoolProperty, CollectionProperty, FloatProperty, StringProperty
from bpy_extras.io_utils import ImportHelper

from .props import (
    get_camera,
    get_planes,
)
from .utils.drivers import (
    create_drivers,
)
from .utils.image import (
    add_opacity_to_material,
    create_image_buffer,
    get_selected_images,
    set_blender_image_pixels,
)
from .utils.misc import natural_sort_key


def object_poll(cls, obj):
    select_poll_error = "Select a camera or its plane children"

    if obj is None:
        cls.poll_message_set(select_poll_error)
        return None

    cam = get_camera(obj)
    if cam is None:
        cls.poll_message_set(select_poll_error)
        return None
    return cam


def selected_number_poll(cls, cam, minimum=2):
    selected_children = [
        child for child in cam.children if child.select_get() and "distance" in child.camera_plane
    ]
    if len(selected_children) < minimum:
        cls.poll_message_set(f"Select at least {minimum} image planes")
        return False
    return True


class CAMERA_OT_Camera_Plane_Add_Opacity(bpy.types.Operator):
    """Add opacity setting to a plane, if it wasn't added before"""
    bl_idname = "camera.camera_plane_add_opacity"
    bl_label = "Add Opacity to Plane"
    bl_options = {'REGISTER', 'UNDO'}

    plane: StringProperty()

    def execute(self, context):
        material = bpy.data.objects[self.plane].active_material
        if material is None:
            return {'CANCELLED'}
        add_opacity_to_material(material)
        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Group(bpy.types.Operator):
    """Group multiple plane layers from current camera into one"""
    bl_idname = "camera.camera_plane_group"
    bl_label = "Group Selected Planes"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        if not selected_number_poll(cls, cam):
            return False

        return True

    def execute(self, context):
        objects = context.selected_objects
        objects = [o for o in objects if "distance" in o.camera_plane and "originals" not in o]
        objects.sort(key=lambda o: o.camera_plane.distance, reverse=True)

        objects, images_to_process = get_selected_images(objects)
        first_obj = objects[-1]
        first_image = images_to_process[-1]

        img_sizes = {image.size[:] for image in images_to_process}
        if len(img_sizes) >= 2:
            self.report({'ERROR'}, "Could not group layers, are they the same size?")
            return {'CANCELLED'}

        # Assume all images have the same size!
        size = first_image.size[:]

        new_image = bpy.data.images.new("grouped." + first_image.name, size[0], size[1], alpha=True)

        filepath, ext = os.path.splitext(first_image.filepath)
        new_image.filepath = filepath + ".grouped" + ext

        # Create and link object for new image
        new_obj = first_obj.copy()
        new_obj.name = "grouped." + first_obj.name
        new_mesh = first_obj.data.copy()
        new_mesh.name = "grouped." + first_obj.name
        new_mat = new_obj.material_slots[0].material.copy()
        new_mat.name = "grouped." + first_obj.name
        new_obj.data = new_mesh
        new_obj.material_slots[0].material = new_mat
        for coll in first_obj.users_collection:
            coll.objects.link(new_obj)

        # Create and assign image data
        new_image_buff = create_image_buffer(self, size, images_to_process)
        if type(new_image_buff) is set:
            # Error
            return new_image_buff
        set_blender_image_pixels(new_image, new_image_buff)
        image_node = next(node for node in new_mat.node_tree.nodes if node.type == 'TEX_IMAGE')
        image_node.image = new_image
        new_image.save()

        # Keep track of data in objects
        originals = []
        for obj in objects:
            obj["grouped"] = new_obj
            originals.append(obj)
            for coll in obj.users_collection:
                coll.objects.unlink(obj)
            obj.use_fake_user = True
        new_obj["originals"] = originals

        context.view_layer.objects.active = new_obj

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Update_Groups(bpy.types.Operator):
    """Recreate layer groups from individual layers if the file could not be found"""
    bl_idname = "camera.camera_plane_update_groups"
    bl_label = "Update Groups"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        for child in cam.children:
            if "distance" in child.camera_plane and "originals" in child:
                mat = child.material_slots[0].material
                if mat is None:
                    continue
                image_node = next(node for node in mat.node_tree.nodes if node.type == 'TEX_IMAGE')
                image = image_node.image
                if not image.has_data:
                    return True
        return False

    def execute(self, context):
        planes = get_planes(context.active_object)
        grouped_planes = [p for p in planes if "originals" in p]

        for grouped_plane in grouped_planes:
            originals = grouped_plane["originals"]

            image_node = next(
                node
                for node in grouped_plane.material_slots[0].material.node_tree.nodes
                if node.type == 'TEX_IMAGE'
            )
            image = image_node.image
            if image.has_data:
                continue

            objects, images_to_process = get_selected_images(originals)
            first_image = images_to_process[-1]

            img_sizes = {image.size[:] for image in images_to_process}
            if len(img_sizes) >= 2:
                self.report({'ERROR'}, "Could not group layers, are they the same size?")
                return {'CANCELLED'}

            # Assume all images have the same size!
            size = first_image.size[:]

            # Create and assign image data
            new_image = bpy.data.images.new(image.name, size[0], size[1], alpha=True)
            new_image.name = image.name  # force rename
            new_image.filepath = image.filepath
            new_image_buff = create_image_buffer(self, size, images_to_process)
            if type(new_image_buff) is set:
                # Error
                continue

            set_blender_image_pixels(new_image, new_image_buff)
            new_image.save()
            image_node.image = new_image

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Ungroup(bpy.types.Operator):
    """Ungroup selected group layer to its original ones"""
    bl_idname = "camera.camera_plane_ungroup"
    bl_label = "Ungroup"
    bl_options = {'REGISTER', 'UNDO'}

    group: StringProperty(options={'HIDDEN'})
    keep_original_distance: BoolProperty(
        name="Keep Original Distance",
        description="Use distance from before grouping, or keep ungrouped planes close together",
    )
    offset: FloatProperty(
        name="Offset",
        default=0.01,
        subtype='DISTANCE',
        unit='LENGTH',
        description="Offset between ungrouped planes if not using original distance",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        for obj in bpy.context.view_layer.objects:
            obj.select_set(False)

        obj = bpy.data.objects[self.group]
        for i, orig in enumerate(sorted(obj['originals'], key=lambda o: o.camera_plane.distance)):
            if not self.keep_original_distance:
                # Recalculate plane distance from group
                orig.camera_plane.distance = obj.camera_plane.distance + i * self.offset
                # Delete drivers if they were deleted in the group and copy props
                if obj.animation_data is not None:
                    for prop in {"location", "scale"}:  # TODO handle rotation?
                        for index in range(3):
                            grp_driver = obj.animation_data.drivers.find(prop, index=index)
                            if grp_driver is None:
                                orig_driver = orig.animation_data.drivers.find(prop, index=index)
                                if orig_driver is not None:
                                    orig.animation_data.drivers.remove(orig_driver)
                            getattr(orig, prop)[index] = getattr(obj, prop)[index]
                            if prop == "location" and index == 2:
                                getattr(orig, prop)[index] -= i * self.offset
                        # TODO handle animation...
            del orig["grouped"]
        for coll in obj.users_collection:
            for orig in obj["originals"]:
                coll.objects.link(orig)
                orig.select_set(True)
            coll.objects.unlink(obj)

        context.view_layer.objects.active = orig
        bpy.data.objects.remove(obj)
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "keep_original_distance")
        row = layout.row()
        row.active = not self.keep_original_distance
        row.prop(self, "offset")


class CAMERA_OT_Camera_Plane(bpy.types.Operator, ImportHelper):
    """Import a camera plane"""
    bl_idname = "camera.camera_plane_build"
    bl_label = "Import Camera Plane"
    bl_options = {'REGISTER', 'UNDO'}

    # File props
    files: CollectionProperty(
        type=bpy.types.OperatorFileListElement, options={'HIDDEN', 'SKIP_SAVE'}
    )
    directory: StringProperty(maxlen=1024, subtype='FILE_PATH', options={'HIDDEN', 'SKIP_SAVE'})

    filter_image: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})
    filter_movie: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})
    filter_folder: BoolProperty(default=True, options={'HIDDEN', 'SKIP_SAVE'})

    scale: FloatProperty(
        name="Scale",
        description="Extra scale applied after calculation",
        default=100.0,
        soft_min=0.0,
        soft_max=500.0,
        min=0.0,
        subtype='PERCENTAGE',
    )
    distance: FloatProperty(
        name="Distance",
        description="Distance from the camera to the farthest plane",
        default=25.0,
        soft_max=1000.0,
        min=0.0,
        step=10.0,
        subtype='DISTANCE',
        unit='LENGTH',
    )
    step: FloatProperty(
        name="Step",
        description="Distance between planes",
        default=0.1,
        soft_max=50.0,
        min=0.0,
        step=10.0,
        subtype='DISTANCE',
        unit='LENGTH',
    )
    reverse_order: BoolProperty(
        name="Reverse Order",
        description="Reverse sorting order",
        default=False,
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        return True

    def execute(self, context):
        # Selection Camera
        cam = get_camera(context.active_object)

        files = [os.path.basename(f.name) for f in self.files]
        files.sort(key=natural_sort_key)

        if not self.reverse_order:
            files.reverse()

        imported_planes = []

        for i, f in enumerate(files):
            bpy.ops.image.import_as_mesh_planes(
                files=[{"name": f}],
                directory=self.directory,
                use_transparency=True,
                shader='SHADELESS',
                overwrite_material=False,
            )
            plane = context.active_object
            imported_planes.append(plane)

            # Move plane to camera's collections
            for coll in plane.users_collection:
                coll.objects.unlink(plane)
            for coll in cam.users_collection:
                coll.objects.link(plane)

            # Scale factor: Import images addon imports
            # images with a height of 1
            # this scales it back to a width of 1
            scale_factor = plane.dimensions[0]
            for v in plane.data.vertices:
                v.co /= scale_factor
            plane.parent = cam
            plane.show_wire = True
            plane.matrix_world = cam.matrix_world
            plane.lock_location = (True,) * 3
            plane.lock_rotation = (True,) * 3
            plane.lock_rotation_w = True
            plane.lock_scale = (True,) * 3

            # Multiple planes spacing
            plane.camera_plane.distance = self.distance - i * self.step
            plane.camera_plane.scale = self.scale

            # DRIVERS
            create_drivers(plane=plane, cam=cam)

            # Alpha in material
            add_opacity_to_material(plane.active_material)

        for plane in imported_planes:
            plane.select_set(True)
        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Layers(bpy.types.Operator):
    """Create one view layer per image, to render them separately"""
    bl_idname = "camera.camera_plane_setup_layers"
    bl_label = "Setup Layers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        planes = get_planes(context.active_object, selected=False)

        # Create collections
        for obj in planes:
            if obj.name not in bpy.data.collections:
                coll = bpy.data.collections.new(obj.name)
                coll.objects.link(obj)
                scene.collection.children.link(coll)

        # Create view layers
        for obj in planes:
            layer = scene.view_layers.get(obj.name)
            if layer is None:
                layer = scene.view_layers.new(obj.name)
            for child_coll in layer.layer_collection.children:
                child_coll.exclude = child_coll.name != obj.name
        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Space(bpy.types.Operator):
    """Space planes evenly from closest to farthest"""
    bl_idname = "camera.camera_plane_space"
    bl_label = "Space Equally"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        if not selected_number_poll(cls, cam, minimum=3):
            return False

        return True

    def execute(self, context):
        planes = get_planes(context.active_object, selected=True)
        planes.sort(key=lambda p: p.camera_plane.distance)

        low = planes[0].camera_plane.distance
        high = planes[-1].camera_plane.distance
        current = low

        for plane in planes:
            plane.camera_plane.distance = current
            current += (high - low) / max(len(planes) - 1, 1)
            for driver in plane.animation_data.drivers:
                driver.update()

        # Force viewport update
        plane.location.z = plane.location.z
        plane.update_tag(refresh={'OBJECT'})
        context.view_layer.update()

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Reverse(bpy.types.Operator):
    """Reverse plane order"""
    bl_idname = "camera.camera_plane_reverse"
    bl_label = "Reverse"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object

        cam = object_poll(cls, obj)
        if cam is None:
            return False

        if not selected_number_poll(cls, cam):
            return False

        return True

    def execute(self, context):
        planes = get_planes(context.active_object, selected=True)
        planes.sort(key=lambda p: p.camera_plane.distance)
        planes_dist = [p.camera_plane.distance for p in planes]
        planes_dist.reverse()

        for plane, plane_dist in zip(planes, planes_dist):
            plane.camera_plane.distance = plane_dist
            # current += (high - low) / max(len(planes) - 1, 1)
            for driver in plane.animation_data.drivers:
                driver.update()
        plane.location.z = plane.location.z
        plane.update_tag(refresh={'OBJECT'})
        context.view_layer.update()

        return {'FINISHED'}


class CAMERA_OT_Camera_Plane_Apply(bpy.types.Operator):
    """Apply transformation on selected planes"""
    bl_idname = "camera.camera_plane_apply"
    bl_label = "Apply Camera Plane"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        cam = object_poll(cls, obj)
        if cam is None:
            return False
        if not selected_number_poll(cls, cam, minimum=1):
            return False
        return True

    def execute(self, context):
        for group_plane in get_planes(context.active_object, selected=True):
            if "originals" not in group_plane:
                continue
            bpy.ops.camera.camera_plane_ungroup(group=group_plane.name)

        for plane in get_planes(context.active_object, selected=True):
            # Remove drivers
            for f_curve in plane.animation_data.drivers:
                if f_curve.data_path in {'delta_location', 'delta_scale'}:
                    plane.driver_remove(f_curve.data_path, f_curve.array_index)

            plane.lock_location = (False,) * 3
            plane.lock_rotation = (False,) * 3
            plane.lock_scale = (False,) * 3
            plane.lock_rotation_w = False

            del plane["camera_plane"]

        context.view_layer.objects.active = get_camera(context.active_object)

        return {'FINISHED'}


class CAMERA_OT_Camera_Mapping(bpy.types.Operator):
    """Convert meshes to a setup of camera mapping."""
    bl_idname = "object.camera_mapping"
    bl_label = "Convert to Camera Mapping"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                return True

        cls.poll_message_set("No mesh object found in selection")
        return False

    def execute(self, context):
        scene = context.scene
        camera = None

        for obj in context.selected_objects:
            if obj.type == 'CAMERA':
                camera = obj
                break

        if camera is None:
            self.report({'INFO'}, "No camera found to use as projector. Creating a new one.")
            camera_data = bpy.data.cameras.new("MappingCamera")
            camera = bpy.data.objects.new("MappingCamera", camera_data)
            scene.collection.objects.link(camera)

        for obj in context.selected_objects:
            if obj.type != 'MESH':
                continue

            # Get the subsurface modifier, create a new one if not found
            subsurf_modifier = next((m for m in obj.modifiers if m.type == 'SUBSURF'), None)
            if subsurf_modifier is None:
                subsurf_modifier = obj.modifiers.new(
                    name="Subdivision Camera Mapping", type='SUBSURF'
                )

                # Modifier settings
                subsurf_modifier.levels = 2
                subsurf_modifier.render_levels = 2
                subsurf_modifier.subdivision_type = 'SIMPLE'

            # Get the UVProject modifier, create a new one if not found
            uvproject_modifier = next(
                (m for m in obj.modifiers if m.type == 'UV_PROJECT'), None
            )
            if uvproject_modifier is None:
                uvproject_modifier = obj.modifiers.new(
                    name="UVProject Camera Mapping", type='UV_PROJECT'
                )

                uv_map = (
                    obj.data.uv_layers[0]
                    if len(obj.data.uv_layers) > 0
                    else obj.data.uv_layers.new()
                )

                # Get object's image resolution, fallback to scene resolution.
                _objects, images = get_selected_images((obj,))
                if images:
                    resolution_x, resolution_y = images[0].size
                else:
                    resolution_x, resolution_y = (scene.render.resolution_x, scene.render.resolution_y)

                # Modifier settings
                uvproject_modifier.uv_layer = uv_map.name
                uvproject_modifier.projectors[0].object = camera
                uvproject_modifier.aspect_x = resolution_x
                uvproject_modifier.aspect_y = resolution_y

        return {'FINISHED'}
