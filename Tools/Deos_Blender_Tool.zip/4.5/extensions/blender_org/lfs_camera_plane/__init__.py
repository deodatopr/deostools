# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later

import bpy

from .handlers import camera_plane_group_handler, camera_plane_versioning_handler
from .operators import (
    CAMERA_OT_Camera_Mapping,
    CAMERA_OT_Camera_Plane,
    CAMERA_OT_Camera_Plane_Add_Opacity,
    CAMERA_OT_Camera_Plane_Apply,
    CAMERA_OT_Camera_Plane_Group,
    CAMERA_OT_Camera_Plane_Layers,
    CAMERA_OT_Camera_Plane_Reverse,
    CAMERA_OT_Camera_Plane_Space,
    CAMERA_OT_Camera_Plane_Ungroup,
    CAMERA_OT_Camera_Plane_Update_Groups,
)
from .props import CameraPlaneProperties, CameraPlaneSettings
from .ui import (
    CAMERA_MT_Camera_Plane_Context_Menu,
    CAMERA_PT_Camera_Plane,
    draw_convert_to_camera_mapping,
)

classes = (
    CameraPlaneProperties,
    CameraPlaneSettings,
    CAMERA_PT_Camera_Plane,
    CAMERA_MT_Camera_Plane_Context_Menu,
    CAMERA_OT_Camera_Mapping,
    CAMERA_OT_Camera_Plane,
    CAMERA_OT_Camera_Plane_Add_Opacity,
    CAMERA_OT_Camera_Plane_Apply,
    CAMERA_OT_Camera_Plane_Group,
    CAMERA_OT_Camera_Plane_Layers,
    CAMERA_OT_Camera_Plane_Reverse,
    CAMERA_OT_Camera_Plane_Space,
    CAMERA_OT_Camera_Plane_Ungroup,
    CAMERA_OT_Camera_Plane_Update_Groups,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.WindowManager.camera_plane_settings = bpy.props.PointerProperty(
        type=CameraPlaneSettings,
    )
    bpy.types.Object.camera_plane = bpy.props.PointerProperty(type=CameraPlaneProperties)

    bpy.types.VIEW3D_MT_object_context_menu.append(draw_convert_to_camera_mapping)

    bpy.app.handlers.load_post.append(camera_plane_group_handler)
    bpy.app.handlers.load_post.append(camera_plane_versioning_handler)


def unregister():
    bpy.app.handlers.load_post.remove(camera_plane_group_handler)
    bpy.app.handlers.load_post.remove(camera_plane_versioning_handler)
    del bpy.types.WindowManager.camera_plane_settings
    del bpy.types.Object.camera_plane

    bpy.types.VIEW3D_MT_object_context_menu.remove(draw_convert_to_camera_mapping)

    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
