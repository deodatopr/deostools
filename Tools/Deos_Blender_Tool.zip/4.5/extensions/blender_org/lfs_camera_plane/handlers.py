# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later

import bpy
from bpy.app.handlers import persistent

from .utils.drivers import create_drivers


@persistent
def camera_plane_group_handler(_self):
    """Regenerate missing groups on file load"""
    if bpy.ops.camera.camera_plane_update_groups.poll():
        bpy.ops.camera.camera_plane_update_groups()


@persistent
def camera_plane_versioning_handler(_self):
    """Update old version on file with new version if object is compatible"""
    drivers = {
        ("location", 0): "tan(FOV/2) * distance*2 * shift",
        ("location", 1): "tan(FOV/2) * distance*2 * shift",
        ("location", 2): "-distance",
        ("scale", 0): "tan(FOV/2) * distance*2 * scale/100.0",
        ("scale", 1): "tan(FOV/2) * distance*2 * scale/100.0",
    }

    # Check for the object parent and properties
    for obj in bpy.data.objects:
        if (
            obj.parent is None
            or obj.parent.type != 'CAMERA'
            or 'camera_plane_distance' not in obj
            or 'camera_plane_scale' not in obj
        ):
            continue

        # Check if driver exists and expression is expected
        found_bad_driver = False
        for (data_path, index), expression in drivers.items():
            driver = obj.animation_data.drivers.find(data_path, index=index)
            if driver is None or driver.driver.expression != expression:
                found_bad_driver = True
                break
        if found_bad_driver:
            continue

        for f_curve in obj.animation_data.drivers:
            if f_curve.driver is not None:
                # Assign old properties to new ones
                for variable in f_curve.driver.variables:
                    if "camera_plane_distance" in variable.targets[0].data_path:
                        obj.camera_plane.distance = obj['camera_plane_distance']
                    if "camera_plane_scale" in variable.targets[0].data_path:
                        obj.camera_plane.scale = obj['camera_plane_scale']

            # Remove old drivers and reset transform
            if f_curve.data_path == 'location' or f_curve.data_path == 'scale':
                obj.driver_remove(f_curve.data_path, f_curve.array_index)
                obj.location = (0.0, 0.0, 0.0)
                obj.scale[0] = 1.0
                obj.scale[1] = 1.0

        # create drivers and delete old properties
        create_drivers(plane=obj, cam=obj.parent)
        del obj['camera_plane_distance']
        del obj["camera_plane_scale"]

        print(f"Camera Plane: Updated {obj.name}")
