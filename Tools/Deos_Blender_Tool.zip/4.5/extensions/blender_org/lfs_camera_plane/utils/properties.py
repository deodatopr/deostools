# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later


def get_lock_status(obj) -> str:
    """Get info about an object's transform locks.

    Return 'LOCKED' if all transforms are locked.
    Return 'UNLOCKED' if all transforms are unlocked.
    Return 'MISMATCH' if not all locks are the same.
    """
    lock_loc_x = obj.lock_location[0]

    if obj.rotation_mode in {"AXIS_ANGLE", "QUATERNION"} and lock_loc_x != obj.lock_rotation_w:
        return 'MISMATCH'

    for index in range(3):
        if (
            lock_loc_x != obj.lock_location[index]
            or lock_loc_x != obj.lock_rotation[index]
            or lock_loc_x != obj.lock_scale[index]
        ):
            return 'MISMATCH'

    return 'LOCKED' if lock_loc_x else 'UNLOCKED'


def get_select(self):
    return self.id_data.select_get()


def set_select(self, value):
    self.id_data.select_set(value)


def get_hide(self):
    return self.id_data.hide_viewport and self.id_data.hide_render


def set_hide(self, value):
    self.id_data.hide_viewport = value
    self.id_data.hide_render = value


def get_lock(self):
    return get_lock_status(self.id_data) in {'LOCKED', 'MISMATCH'}


def set_lock(self, value):
    self.id_data.lock_location = (value,) * 3
    self.id_data.lock_rotation = (value,) * 3
    self.id_data.lock_rotation_w = value
    self.id_data.lock_scale = (value,) * 3


def update_distance(self, context):
    # Update planes inside a group
    if "originals" in self:
        for orig in self["originals"]:
            orig.camera_plane.distance = (
                orig["original_distance"] + self.camera_plane.distance - self["original_distance"]
            )
