# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later

import bpy
from bpy_extras.node_utils import connect_sockets
from mathutils import Vector


def get_opacity_node_group():
    if 'Opacity Multiplier' in bpy.data.node_groups:
        return bpy.data.node_groups['Opacity Multiplier']

    node_group = bpy.data.node_groups.new('Opacity Multiplier', 'ShaderNodeTree')

    input_node = node_group.nodes.new('NodeGroupInput')
    input_node.location.x = -200.0
    output_node = node_group.nodes.new('NodeGroupOutput')
    output_node.location.x = 200.0
    math_node = node_group.nodes.new('ShaderNodeMath')
    math_node.operation = 'MULTIPLY'

    base_input = node_group.interface.new_socket(
        name="Base", in_out='INPUT', socket_type='NodeSocketFloat'
    )
    multiplier_input = node_group.interface.new_socket(
        name="Multiplier",
        in_out='INPUT',
        socket_type='NodeSocketFloat',
    )
    opacity_output = node_group.interface.new_socket(
        name="Value",
        in_out='OUTPUT',
        socket_type='NodeSocketFloat',
    )

    multiplier_input.default_value = 1.0
    multiplier_input.max_value = 1.0
    multiplier_input.min_value = 0.0

    connect_sockets(math_node.inputs[0], input_node.outputs[0])
    connect_sockets(math_node.inputs[1], input_node.outputs[1])
    connect_sockets(output_node.inputs[0], math_node.outputs[0])

    return node_group


def add_opacity_to_material(mat):
    """Modify material from Import Images as Planes to add opacity slider"""
    node_tree = mat.node_tree
    if "Opacity Multiplier" in node_tree.nodes:
        return
    image_node = next(node for node in node_tree.nodes if node.type == 'TEX_IMAGE')
    if (image_node is None
            or not image_node.outputs['Alpha'].links
            or not image_node.outputs['Alpha'].links[0].to_node):
        return
    next_node = image_node.outputs['Alpha'].links[0].to_node

    opacity_node = node_tree.nodes.new("ShaderNodeGroup")
    opacity_node.node_tree = get_opacity_node_group()
    opacity_node.label = opacity_node.name = "Opacity Multiplier"
    opacity_node.location = (
        image_node.location
        + Vector((image_node.width, 0.0))
        + next_node.location
        - Vector((opacity_node.width, 0.0))
    ) / 2.0

    to_socket = image_node.outputs['Alpha'].links[0].to_socket
    node_tree.links.remove(image_node.outputs['Alpha'].links[0])
    connect_sockets(to_socket, opacity_node.outputs['Value'])
    connect_sockets(opacity_node.inputs[0], image_node.outputs['Alpha'])


def fix_material_uvs(mat):
    """Modify material to divide UVs by Z, output by the Fix Camera Mapping modifier."""
    node_tree = mat.node_tree
    for node in node_tree.nodes[:]:
        if (
                node.type == "TEX_IMAGE"
                and node.image is not None
                and not node.inputs["Vector"].links
        ):
            # Add UVs to textures not having explicit UV inputs.
            divide_node = node_tree.nodes.new("ShaderNodeVectorMath")
            divide_node.location = node.location - Vector((200.0, 0.0))
            divide_node.operation = 'DIVIDE'
            divide_node["from_camera_plane"] = True

            uv_node = node_tree.nodes.new("ShaderNodeUVMap")
            uv_node.location = divide_node.location - Vector((200.0, 0.0))
            uv_node.uv_map = "UVMap"
            uv_node["from_camera_plane"] = True

            z_node = node_tree.nodes.new("ShaderNodeAttribute")
            z_node.attribute_name = "Camera Z"
            z_node.location = uv_node.location - Vector((0.0, 200.0))
            z_node["from_camera_plane"] = True

            connect_sockets(divide_node.inputs[0], uv_node.outputs["UV"])
            connect_sockets(divide_node.inputs[1], z_node.outputs["Fac"])
            connect_sockets(node.inputs["Vector"], divide_node.outputs["Vector"])

        elif (
                node.type == "UVMAP"
                and node.uv_map == "UVMap"
                and node.outputs["UV"].links
                and not node["from_camera_plane"]
        ):
            # Add fix to existing, connected UV Map nodes.
            divide_node = node_tree.nodes.new("ShaderNodeVectorMath")
            divide_node.location = node.location + Vector((200.0, 0.0))
            divide_node.operation = 'DIVIDE'
            divide_node["from_camera_plane"] = True

            z_node = node_tree.nodes.new("ShaderNodeAttribute")
            z_node.attribute_name = "Camera Z"
            z_node.location = node.location - Vector((0.0, 200.0))
            z_node["from_camera_plane"] = True

            to_sockets = [link.to_socket for link in node.outputs["UV"].links]
            connect_sockets(divide_node.inputs[0], node.outputs["UV"])
            connect_sockets(divide_node.inputs[1], z_node.outputs["Fac"])
            for to_socket in to_sockets:
                connect_sockets(to_socket, divide_node.outputs["Vector"])


def ensure_fix_node_group():
    """Initialize fix_camera_mapping node group.

    Created using the Node to Python add-on by Brendan Parmer.
    """
    node_group_name = "Camera Mapping Fix UVs"
    if node_group_name in bpy.data.node_groups:
        return bpy.data.node_groups[node_group_name]

    fix_camera_mapping = bpy.data.node_groups.new(type='GeometryNodeTree', name=node_group_name)

    fix_camera_mapping.color_tag = 'VECTOR'
    fix_camera_mapping.description = "Edit UVs to compensate for the affine texture mapping, by multiplying them by the camera’s Z depth. It needs to be divided by the \"Camera Z\" attribute again in the Shader Editor."
    fix_camera_mapping.default_group_node_width = 140
    fix_camera_mapping.is_modifier = True

    # fix_camera_mapping interface

    # Socket Geometry
    geometry_socket = fix_camera_mapping.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'
    geometry_socket.default_input = 'VALUE'
    geometry_socket.structure_type = 'AUTO'

    # Socket UV
    uv_socket = fix_camera_mapping.interface.new_socket(name="UV", in_out='OUTPUT', socket_type='NodeSocketVector')
    uv_socket.dimensions = 2
    # Get the socket again, as its default value could have been updated
    uv_socket = fix_camera_mapping.interface.items_tree[uv_socket.index]
    uv_socket.default_value = (0.0, 0.0)
    uv_socket.min_value = -3.4028234663852886e+38
    uv_socket.max_value = 3.4028234663852886e+38
    uv_socket.subtype = 'NONE'
    uv_socket.default_attribute_name = "UVMap"
    uv_socket.attribute_domain = 'CORNER'
    uv_socket.description = "Fixed UV map"
    uv_socket.default_input = 'VALUE'
    uv_socket.structure_type = 'AUTO'

    # Socket Z
    z_socket = fix_camera_mapping.interface.new_socket(name="Z", in_out='OUTPUT', socket_type='NodeSocketFloat')
    z_socket.default_value = 0.0
    z_socket.min_value = 0.0
    z_socket.max_value = 3.4028234663852886e+38
    z_socket.subtype = 'DISTANCE'
    z_socket.default_attribute_name = "Camera Z"
    z_socket.attribute_domain = 'POINT'
    z_socket.description = "Attribute to store the Z values into. In the Shader Editor, vector-divide the UV map by this attribute (as Factor)"
    z_socket.default_input = 'VALUE'
    z_socket.structure_type = 'AUTO'

    # Socket Geometry
    geometry_socket_1 = fix_camera_mapping.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'
    geometry_socket_1.default_input = 'VALUE'
    geometry_socket_1.structure_type = 'AUTO'

    # Socket UV
    uv_socket_1 = fix_camera_mapping.interface.new_socket(name="UV", in_out='INPUT', socket_type='NodeSocketVector')
    uv_socket_1.dimensions = 2
    # Get the socket again, as its default value could have been updated
    uv_socket_1 = fix_camera_mapping.interface.items_tree[uv_socket_1.index]
    uv_socket_1.default_value = (0.0, 0.0)
    uv_socket_1.min_value = -3.4028234663852886e+38
    uv_socket_1.max_value = 3.4028234663852886e+38
    uv_socket_1.subtype = 'XYZ'
    uv_socket_1.default_attribute_name = "UVMap"
    uv_socket_1.attribute_domain = 'POINT'
    uv_socket_1.description = "UV map to fix"
    uv_socket_1.default_input = 'VALUE'
    uv_socket_1.structure_type = 'AUTO'

    # Socket Camera
    camera_socket = fix_camera_mapping.interface.new_socket(name="Camera", in_out='INPUT', socket_type='NodeSocketObject')
    camera_socket.attribute_domain = 'POINT'
    camera_socket.description = "Camera object used for the projection"
    camera_socket.default_input = 'VALUE'
    camera_socket.structure_type = 'AUTO'

    # Initialize fix_camera_mapping nodes

    # Node Group Input
    group_input = fix_camera_mapping.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"
    group_input.outputs[0].hide = True
    group_input.outputs[2].hide = True
    group_input.outputs[3].hide = True

    # Node Group Output
    group_output = fix_camera_mapping.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    # Node Object Info
    object_info = fix_camera_mapping.nodes.new("GeometryNodeObjectInfo")
    object_info.name = "Object Info"
    object_info.transform_space = 'RELATIVE'
    object_info.inputs[1].hide = True
    object_info.outputs[1].hide = True
    object_info.outputs[2].hide = True
    object_info.outputs[3].hide = True
    object_info.outputs[4].hide = True
    # As Instance
    object_info.inputs[1].default_value = False

    # Node Position
    position = fix_camera_mapping.nodes.new("GeometryNodeInputPosition")
    position.name = "Position"

    # Node Invert Matrix
    invert_matrix = fix_camera_mapping.nodes.new("FunctionNodeInvertMatrix")
    invert_matrix.name = "Invert Matrix"

    # Node Transform Point
    transform_point = fix_camera_mapping.nodes.new("FunctionNodeTransformPoint")
    transform_point.name = "Transform Point"

    # Node Separate XYZ
    separate_xyz = fix_camera_mapping.nodes.new("ShaderNodeSeparateXYZ")
    separate_xyz.name = "Separate XYZ"
    separate_xyz.outputs[0].hide = True
    separate_xyz.outputs[1].hide = True

    # Node Vector Math
    vector_math = fix_camera_mapping.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'MULTIPLY'

    # Node Math
    math = fix_camera_mapping.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'MULTIPLY'
    math.use_clamp = False
    # Value_001
    math.inputs[1].default_value = -1.0

    # Node Frame
    frame = fix_camera_mapping.nodes.new("NodeFrame")
    frame.label = "Get Camera Z Depth"
    frame.name = "Frame"
    frame.label_size = 20
    frame.shrink = True

    # Node Reroute
    reroute = fix_camera_mapping.nodes.new("NodeReroute")
    reroute.name = "Reroute"
    reroute.socket_idname = "NodeSocketFloat"
    # Node Frame.001
    frame_001 = fix_camera_mapping.nodes.new("NodeFrame")
    frame_001.label = "Compensate Affine Mapping"
    frame_001.name = "Frame.001"
    frame_001.label_size = 20
    frame_001.shrink = True

    # Node Group Input.001
    group_input_001 = fix_camera_mapping.nodes.new("NodeGroupInput")
    group_input_001.name = "Group Input.001"
    group_input_001.outputs[0].hide = True
    group_input_001.outputs[1].hide = True
    group_input_001.outputs[3].hide = True

    # Node Group Input.002
    group_input_002 = fix_camera_mapping.nodes.new("NodeGroupInput")
    group_input_002.name = "Group Input.002"
    group_input_002.outputs[1].hide = True
    group_input_002.outputs[2].hide = True
    group_input_002.outputs[3].hide = True

    # Set parents
    object_info.parent = frame
    position.parent = frame
    invert_matrix.parent = frame
    transform_point.parent = frame
    separate_xyz.parent = frame
    vector_math.parent = frame_001
    math.parent = frame
    group_input_001.parent = frame

    # Set locations
    group_input.location = (440.0, -400.0)
    group_output.location = (940.0, -380.0)
    object_info.location = (210.0, -116.0)
    position.location = (390.0, -36.0)
    invert_matrix.location = (390.0, -116.0)
    transform_point.location = (570.0, -36.0)
    separate_xyz.location = (750.0, -36.0)
    vector_math.location = (30.0, -36.0)
    math.location = (930.0, -36.0)
    frame.location = (-470.0, -544.0)
    reroute.location = (880.0, -620.0)
    frame_001.location = (650.0, -364.0)
    group_input_001.location = (30.0, -116.0)
    group_input_002.location = (680.0, -280.0)

    # Set dimensions
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    object_info.width, object_info.height = 140.0, 100.0
    position.width, position.height = 140.0, 100.0
    invert_matrix.width, invert_matrix.height = 140.0, 100.0
    transform_point.width, transform_point.height = 140.0, 100.0
    separate_xyz.width, separate_xyz.height = 140.0, 100.0
    vector_math.width, vector_math.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    frame.width, frame.height = 1100.0, 249.0
    reroute.width, reroute.height = 10.0, 100.0
    frame_001.width, frame_001.height = 200.0, 191.0
    group_input_001.width, group_input_001.height = 140.0, 100.0
    group_input_002.width, group_input_002.height = 140.0, 100.0

    # Initialize fix_camera_mapping links

    # group_input_002.Geometry -> group_output.Geometry
    fix_camera_mapping.links.new(group_input_002.outputs[0], group_output.inputs[0])
    # object_info.Transform -> invert_matrix.Matrix
    fix_camera_mapping.links.new(object_info.outputs[0], invert_matrix.inputs[0])
    # invert_matrix.Matrix -> transform_point.Transform
    fix_camera_mapping.links.new(invert_matrix.outputs[0], transform_point.inputs[1])
    # position.Position -> transform_point.Vector
    fix_camera_mapping.links.new(position.outputs[0], transform_point.inputs[0])
    # transform_point.Vector -> separate_xyz.Vector
    fix_camera_mapping.links.new(transform_point.outputs[0], separate_xyz.inputs[0])
    # separate_xyz.Z -> math.Value
    fix_camera_mapping.links.new(separate_xyz.outputs[2], math.inputs[0])
    # math.Value -> vector_math.Vector
    fix_camera_mapping.links.new(math.outputs[0], vector_math.inputs[1])
    # math.Value -> reroute.Input
    fix_camera_mapping.links.new(math.outputs[0], reroute.inputs[0])
    # group_input_001.Camera -> object_info.Object
    fix_camera_mapping.links.new(group_input_001.outputs[2], object_info.inputs[0])
    # vector_math.Vector -> group_output.UV
    fix_camera_mapping.links.new(vector_math.outputs[0], group_output.inputs[1])
    # group_input.UV -> vector_math.Vector
    fix_camera_mapping.links.new(group_input.outputs[1], vector_math.inputs[0])
    # reroute.Output -> group_output.Z
    fix_camera_mapping.links.new(reroute.outputs[0], group_output.inputs[2])

    return fix_camera_mapping
