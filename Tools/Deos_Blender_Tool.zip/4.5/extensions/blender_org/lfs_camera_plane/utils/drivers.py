# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later


def create_drivers(plane, cam):
    # DRIVERS
    ## LOC X AND Y (shift) ##
    for axis in range(2):
        driver = plane.driver_add('delta_location', axis)

        # Driver type
        driver.driver.type = 'SCRIPTED'

        # Variable DISTANCE
        var = driver.driver.variables.new()
        var.name = "distance"
        var.type = 'SINGLE_PROP'
        var.targets[0].id = plane
        var.targets[0].data_path = '["camera_plane"].["distance"]'

        # Variable FOV
        var = driver.driver.variables.new()
        var.name = "FOV"
        var.type = 'SINGLE_PROP'
        var.targets[0].id_type = "OBJECT"
        var.targets[0].id = cam
        var.targets[0].data_path = 'data.angle'

        # Variable scale
        var = driver.driver.variables.new()
        var.name = "shift"
        var.type = 'SINGLE_PROP'
        var.targets[0].id = cam
        var.targets[0].data_path = 'data.shift_' + ('x' if axis == 0 else 'y')

        # Expression
        driver.driver.expression = "tan(FOV/2) * distance*2 * shift"

    ## DISTANCE ##
    driver = plane.driver_add('delta_location', 2)
    # Driver type
    driver.driver.type = 'SCRIPTED'
    # Variable
    var = driver.driver.variables.new()
    var.name = "distance"
    var.type = 'SINGLE_PROP'
    var.targets[0].id = plane
    var.targets[0].data_path = '["camera_plane"].["distance"]'

    # Expression
    driver.driver.expression = "-distance"

    ## SCALE X AND Y ##
    for axis in range(2):
        driver = plane.driver_add('delta_scale', axis)

        # Driver type
        driver.driver.type = 'SCRIPTED'

        # Variable DISTANCE
        var = driver.driver.variables.new()
        var.name = "distance"
        var.type = 'SINGLE_PROP'
        var.targets[0].id = plane
        var.targets[0].data_path = '["camera_plane"].["distance"]'

        # Variable FOV
        var = driver.driver.variables.new()
        var.name = "FOV"
        var.type = 'SINGLE_PROP'
        var.targets[0].id_type = "OBJECT"
        var.targets[0].id = cam
        var.targets[0].data_path = 'data.angle'

        # Variable scale
        var = driver.driver.variables.new()
        var.name = "scale"
        var.type = 'SINGLE_PROP'
        var.targets[0].id = plane
        var.targets[0].data_path = '["camera_plane"].["scale"]'

        # Expression
        driver.driver.expression = "tan(FOV/2) * distance*2 * scale/100.0"
