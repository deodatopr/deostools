# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later

import re


def natural_sort_key(s, _nsre=re.compile('([0-9]+)')):
    """Sort a string in a natural way
    https://stackoverflow.com/a/16090640"""
    return [int(text) if text.isdigit() else text.lower() for text in _nsre.split(s)]
