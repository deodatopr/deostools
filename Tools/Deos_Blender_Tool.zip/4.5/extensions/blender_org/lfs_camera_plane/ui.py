# SPDX-FileCopyrightText: 2016-2025 Les Fées Spéciales
#
# SPDX-License-Identifier: GPL-3.0-or-later

import bpy

from .operators import CAMERA_OT_Camera_Mapping, CAMERA_OT_Camera_Plane_Update_Groups
from .props import get_planes
from .utils.misc import natural_sort_key
from .utils.properties import get_lock_status


class CAMERA_MT_Camera_Plane_Context_Menu(bpy.types.Menu):
    bl_label = "Camera Plane Options"

    def draw(self, context):
        layout = self.layout

        layout.operator("camera.camera_plane_group", icon="GROUP", text="Group Selected")

        layout.separator()
        layout.operator("camera.camera_plane_space")
        layout.operator("camera.camera_plane_reverse")

        layout.separator()
        layout.operator("camera.camera_plane_apply", text="Apply Selected")

        layout.separator()
        layout.operator("camera.camera_plane_setup_layers", icon='RENDERLAYERS')


class CAMERA_PT_Camera_Plane(bpy.types.Panel):
    """Panel to manipulate planes linked to the camera."""

    bl_label = "Camera Plane"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is not None and (
            obj.type == "CAMERA"
            or obj.parent is not None
            and obj.parent.type == "CAMERA"
            and "distance" in obj.camera_plane
        ):
            return True
        return False

    def draw_image_row(self, layout, plane, show_scale=False, show_opacity=False, is_grouped=False):
        row = layout.row(align=True)
        split = row.split(align=True)
        row_name = split.row(align=True)
        lock = get_lock_status(plane)
        if not is_grouped:
            sub = row_name.row(align=True)
            # Warn that visibility state is out of sync
            sub.alert = plane.hide_viewport != plane.hide_render
            sub.prop(
                plane.camera_plane,
                "hide",
                icon_only=True,
                emboss=False,
                icon="RESTRICT_VIEW_ON" if plane.hide_viewport else "RESTRICT_VIEW_OFF",
            )
            row_name.prop(
                plane.camera_plane,
                "select",
                icon_only=True,
                emboss=False,
                icon="RESTRICT_SELECT_OFF" if plane.select_get() else "RESTRICT_SELECT_ON",
            )
            sub = row_name.row(align=True)
            # Warn that lock state is out of sync
            sub.alert = lock == 'MISMATCH'
            sub.prop(
                plane.camera_plane,
                "lock",
                icon_only=True,
                emboss=False,
                invert_checkbox=True,
                icon="LOCKED" if lock in {'LOCKED', 'MISMATCH'} else "UNLOCKED",
            )

            if 'originals' in plane:
                row_name.prop(
                    plane.camera_plane,
                    "show_group",
                    icon_only=True,
                    icon=(
                        "DISCLOSURE_TRI_DOWN"
                        if plane.camera_plane.show_group
                        else "DISCLOSURE_TRI_RIGHT"
                    ),
                )
            row_name.label(text=plane.name, translate=False)
            # Warn that plane is grouped, but outside any group...
            if 'originals' not in plane and ('.grouped' in plane.name or 'grouped.' in plane.name):
                row_warning = row_name.row(align=True)
                row_warning.alert = True
                row_warning.label(text='Outside group?', icon='ERROR')
        else:
            row_name.label(text=plane.name, translate=False)

        row_info = split.row(align=True)

        if is_grouped:
            if show_scale or show_opacity:
                split_factor = 1.0 / 3.0 if show_scale and show_opacity else 0.5
                sub_split = row_info.split(factor=split_factor, align=True)
                sub_distance = sub_split.row(align=True)
                sub_props = sub_split.row(align=True)
            else:
                sub_distance = row_info.row(align=True)
            sub_distance.alignment = 'RIGHT'
            sub_distance.label(text="{:.1f} m".format(plane.camera_plane.distance), translate=False)
        else:
            sub_props = row_info.row(align=True)
            sub_props.prop(plane.camera_plane, "distance", emboss=True, icon_only=True)

        if show_scale:
            sub_props.prop(plane.camera_plane, "scale", emboss=True, icon_only=True)
        if show_opacity and plane.active_material is not None:
            node_tree = plane.active_material.node_tree
            if "Opacity Multiplier" in node_tree.nodes:
                sub_props.prop(
                    node_tree.nodes['Opacity Multiplier'].inputs[1],
                    "default_value",
                    emboss=True,
                    icon_only=True,
                )
            else:
                sub_props.operator(
                    'camera.camera_plane_add_opacity',
                    text="Add Opacity",
                ).plane = plane.name

        plane_visibility = plane.hide_viewport != plane.hide_render
        plane_lock = lock == 'MISMATCH'
        return (plane_lock, plane_visibility)

    def draw(self, context):
        layout = self.layout
        settings = context.window_manager.camera_plane_settings

        planes = get_planes(context.active_object)

        # Sort planes given selected sort type
        if settings.sort_type == 'ALPHABETICAL':
            planes.sort(key=lambda p: natural_sort_key(p.name))
        else:
            planes.sort(key=lambda p: p.camera_plane.distance)

        layout.operator("camera.camera_plane_build", icon='FILE_IMAGE')

        if len(planes) > 0:
            layout.separator()

            box = layout.box()

            row = box.row()
            row.prop(settings, "show_selected")
            row.prop(settings, "filter", text="", icon="VIEWZOOM")
            row.prop(settings, "sort_type", expand=True, icon_only=True)
            row.menu(CAMERA_MT_Camera_Plane_Context_Menu.__name__, icon='DOWNARROW_HLT', text="")

            row = box.row()
            row.prop(settings, "show_scale")
            row.prop(settings, "show_opacity")

            col = box.column(align=True)
            col.use_property_split = True
            col.use_property_decorate = False

            # Column labels
            row_labels = col.row()
            split_labels = row_labels.split()
            sub = split_labels.row()
            sub = split_labels.row()
            if settings.show_scale or settings.show_opacity:
                split_factor = 1.0 / 3.0 if settings.show_scale and settings.show_opacity else 0.5
                sub_split = sub.split(factor=split_factor, align=True)
                sub = sub_split.row()
                sub.alignment = 'CENTER'
                sub.label(text="Distance")
                if settings.show_scale:
                    sub = sub_split.row()
                    sub.alignment = 'CENTER'
                    sub.label(text="Scale")
                if settings.show_opacity:
                    sub = sub_split.row()
                    sub.alignment = 'CENTER'
                    sub.label(text="Opacity")
            else:
                sub.alignment = 'CENTER'
                sub.label(text="Distance")

            visibility_out_of_sync = False
            lock_out_of_sync = False
            for plane in planes:
                # Filter based on selection
                if settings.show_selected and not plane.select_get():
                    continue
                # Filter based on name
                if settings.filter.lower() not in plane.name.lower():
                    continue
                if 'grouped' not in plane:
                    plane_lock, plane_visibility = self.draw_image_row(
                        col, plane, settings.show_scale, settings.show_opacity
                    )
                    visibility_out_of_sync = plane_visibility or visibility_out_of_sync
                    lock_out_of_sync = plane_lock or lock_out_of_sync
                if 'originals' not in plane or not plane.camera_plane.show_group:
                    continue

                # Display planes inside a group
                plane_box = col.box()
                plane_col = plane_box.column(align=True)
                originals = plane['originals'][:]

                # Sort planes given selected sort type
                if settings.sort_type == 'ALPHABETICAL':
                    originals.sort(key=lambda p: natural_sort_key(p.name))
                else:
                    originals.sort(key=lambda p: p.camera_plane.distance)

                if CAMERA_OT_Camera_Plane_Update_Groups.poll(context):
                    update_row = plane_col.row()
                    update_row.alert = True
                    update_row.operator("camera.camera_plane_update_groups", icon="FILE_REFRESH")

                for orig in originals:
                    if settings.filter.lower() in orig.name.lower():
                        self.draw_image_row(
                            plane_col,
                            orig,
                            settings.show_scale,
                            settings.show_opacity,
                            is_grouped=True,
                        )
                plane_col.operator("camera.camera_plane_ungroup").group = plane.name

            if visibility_out_of_sync:
                layout.label(
                    text='Viewport and render visibility out of sync for some planes', icon='ERROR'
                )
            if lock_out_of_sync:
                layout.label(text='Transform locks out of sync for some planes', icon='ERROR')


def draw_convert_to_camera_mapping(self, context):
    self.layout.separator()
    self.layout.operator(CAMERA_OT_Camera_Mapping.bl_idname, icon='CAMERA_DATA')
