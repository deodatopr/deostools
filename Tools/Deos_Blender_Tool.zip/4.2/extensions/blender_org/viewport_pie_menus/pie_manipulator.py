# SPDX-FileCopyrightText: 2016-2024 Blender Foundation
#
# SPDX-License-Identifier: GPL-3.0-or-later

from bpy.types import Menu
from .hotkeys import register_hotkey


class PIE_MT_manipulator(Menu):
    bl_idname = "PIE_MT_manipulator"
    bl_label = "Manipulator"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()

        space = context.space_data

        # 4 - LEFT
        # 6 - RIGHT
        if not space.show_gizmo:
            pie.separator()
            pie.separator()
        else:
            pie.prop(
                space, 'show_gizmo_object_rotate', text="Rotation", icon='CON_ROTLIKE'
            )
            pie.prop(
                space, 'show_gizmo_object_scale', text="Scale", icon='CON_SIZELIKE'
            )

        # 2 - BOTTOM
        pie.prop(space, 'show_gizmo', text="Toggle Gizmo", icon='GIZMO')

        # 8 - TOP
        if not space.show_gizmo:
            pie.separator()
        else:
            pie.prop(
                space,
                'show_gizmo_object_translate',
                text="Location",
                icon='CON_LOCLIKE',
            )


registry = [
    PIE_MT_manipulator,
]


def register():
    register_hotkey(
        'wm.call_menu_pie',
        op_kwargs={'name': 'PIE_MT_manipulator'},
        hotkey_kwargs={'type': "SPACE", 'value': "PRESS", 'alt': True},
        key_cat="3D View",
    )
