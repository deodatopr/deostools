bl_info = {
    'name': 'Selects all UV islands on one UDIM',
    'author': 'Aleksandr Kochkurkin (ailex)',
    'version': (0, 1, 0),
    'blender': (3, 6, 2),
    'category': 'Select',
    'location': 'UV Editor > Select > "Select UDIM-Matching Faces & Islands Alt+L"',
    'description': 'Highlighting UV-islands and faces of the corresponding UDIM.'
}

# Import required modules
import math
import bpy

# Create a class for the operator
class select_face_udim(bpy.types.Operator):
    bl_idname = 'mesh.select_face_equal_udim'
    bl_label = 'Select UDIM-Matching Faces & Islands'
    bl_description = 'Highlighting UV-islands and faces of the corresponding UDIM.'
 
    # Define the execute function to select the faces
    # Определение функции execute для выбора граней
    def execute(self, context):
        # Get the active object(s)
        # Получение активного объекта и его меша
        obj = bpy.context.selected_editable_objects
        # Create a set to store the UV islands
        # Создание множества для хранения UV-островов
        islands = set()
        # Set the minimum and maximum values for x and y coordinates
        # Установка минимальных и максимальных значений координат x и y
        xmin, ymin = float('inf'), float('inf')
        xmax, ymax = float('-inf'), float('-inf')
        
        # check the UV Sync Selection mode, and if it is enabled I give a message. Finish func
        # проверяю режим выбора UV Sync, и если он включен, то выдаю сообщение. Завершение работы функции
        if bpy.context.scene.tool_settings.use_uv_select_sync:
            self.report({'ERROR'}, "Turn off UV Sync Selection")
            return {'FINISHED'}
        
        # Switch to FACE mode
        # Переключение в режим выбора полигонов
        bpy.ops.mesh.select_mode(type='FACE')
        # Switch to OBJECT mode
        # Переключение в режим объекта
        bpy.ops.object.mode_set(mode='OBJECT')
        # Out from select sync mode
        # Выход из режима синхронного выделения
        
        
        print(select_face_udim.bl_label)
        # Loop through each object
        # Проход по каждому обьекту
        for ob in obj:
            # Check the object type
            # Проверяем, тип объекта
            if ob.type != 'MESH':
                continue
            # Get the mesh data and the active UV layer
            # Получение данных меша и активного слоя UV
            meshdata = ob.data
            uv_layer = meshdata.uv_layers.active.data
            # Loop through each polygon in the mesh
            # Проход по каждому полигону меша
            for polygon in meshdata.polygons:
                # Loop through each loop index in the polygon
                # Проход по каждому индексу вершины полигона
                for loopindex in polygon.loop_indices:
                    # Get the UV loop corresponding to the vertex index
                    # Получение UV-петли, соответствующей индексу вершины
                    meshuvloop = uv_layer[loopindex]
                    # If the UV loop is selected, get the x and y coordinates
                    # Если UV-петля выделена, получить координаты x и y
                    if meshuvloop.select:
                        # get the UV coordinates
                        # Получение UV-координат
                        x, y = meshuvloop.uv[0], meshuvloop.uv[1]
                        # Update the minimum and maximum values for x and y coordinates
                        # Обновление минимальных и максимальных значений для координат x и y
                        if x > xmax:
                            xmax = int(x)+1
                        if y > ymax:
                            ymax = int(y)+1
                        if x < xmin:
                            xmin = int(x)
                        if y < ymin:
                            ymin = int(y)
                    # Add the polygon and UV loop to the islands set
                    # Добавление полигона и UV-петли в множество островов
                    islands.add((polygon, meshuvloop))

        # Loop through each island in the islands set
        # Проход по каждому острову в множестве островов
        for island in islands:
            # Deselect the polygon in the island
            # Снятие выделения с полигона на острове
            island[0].select = False
            # If the UV loop of the island is within the UDIM range, select the polygon
            # Если UV-петля острова находится в пределах диапазона UDIM, выделить полигон
            if (xmin <= island[1].uv[0] <= xmax) and (ymin <= island[1].uv[1] <= ymax):
                for loopindex in island[0].loop_indices:
                    island[0].select = True
        islands.clear()

        # Switch to EDIT mode and select linked UV islands
        # Переключение в режим редактирования и выделение связанных UV-островов
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.uv.select_linked()
        bpy.ops.uv.select_all(action='SELECT')
        print('')
        # Return the finished state
        return {'FINISHED'}
 
# Define a function to add the operator to the UV/Image Editor's Select menu
def addToSelectMenu(self, context):
    self.layout.separator()
    self.layout.operator(select_face_udim.bl_idname, icon="FACE_MAPS")
 
addon_keymaps = []
 
# Define the register function to register the operator and add it to the UV/Image Editor's Select menu
def register():
    bpy.utils.register_class(select_face_udim)
    bpy.types.IMAGE_MT_select.append(addToSelectMenu)
    
    # Add the hotkey
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = wm.keyconfigs.addon.keymaps.new(name='UV Editor', space_type='EMPTY')
        kmi = km.keymap_items.new(select_face_udim.bl_idname, type='L', value='PRESS', alt=True)
        addon_keymaps.append((km, kmi))

        
 
# Define the unregister function to unregister the operator and remove it from the UV/Image Editor's Select menu
def unregister():
    bpy.utils.unregister_class(select_face_udim)
    bpy.types.IMAGE_MT_select.remove(addToSelectMenu)
    
    # Remove the hotkey
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()


if __name__ == "__main__" :
    register()