from . import color_preset

def register():
    color_preset.register()

def unregister():
    color_preset.unregister()