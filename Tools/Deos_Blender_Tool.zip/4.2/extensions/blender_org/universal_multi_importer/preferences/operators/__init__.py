from . import log_file

def register():
    log_file.register()

def unregister():
    log_file.unregister()