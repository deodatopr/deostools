# ------------------------------------------------
# TOOL EXPORTER MAPS
# ------------------------------------------------

import bpy  # Python
import os  # Os
from bpy.types import Operator  # Operators


# ------------------------------------------------
# ACTIONS
# ------------------------------------------------

class DeosOperToGameEngine(Operator):

    bl_idname = "deo.to_game_engine"
    bl_label = ""
    bl_description = ""

    def execute(self, context):

    # region GET VALUES FROM UI (_INIT_)

      enum_ToGamengine_Format = bpy.context.scene.deos_ui.enum_ToGamengine_Format
      bool_ToGamengine_Selected = bpy.context.scene.deos_ui.bool_ToGamengine_Selected

      bool_ToGamengine_GD_Up = bpy.context.scene.deos_ui.bool_ToGamengine_GD_Up
      bool_ToGamengine_GD_Maps = bpy.context.scene.deos_ui.bool_ToGamengine_GD_Maps
      bool_ToGamengine_GD_Anim = bpy.context.scene.deos_ui.bool_ToGamengine_GD_Anim

      enum_ToGamengine_Fbx_Up = bpy.context.scene.deos_ui.enum_ToGamengine_Fbx_Up
      enum_ToGamengine_Fbx_Forward = bpy.context.scene.deos_ui.enum_ToGamengine_Fbx_Forward
      bool_ToGamengine_Fbx_BakeAnim = bpy.context.scene.deos_ui.bool_ToGamengine_Fbx_BakeAnimation

      str_ToGamengine_FileName = bpy.context.scene.deos_ui.str_ToGamengine_FileName
      str_ToGamengine_DirPath = bpy.context.scene.deos_ui.str_ToGamengine_DirPath
      enum_ToGamengine_Fbx_Smooth = bpy.context.scene.deos_ui.enum_ToGamengine_Fbx_Smooth

      # endregion


      if bpy.context.selected_objects == None:
        self.report({"WARNING"}, "[ Select at least one object from the scene ]")
      else:

        # region SET VAR VALUES
          
        # PathLocation
        if str_ToGamengine_DirPath == "My File Location":
          vPathDir = ""
        else:
          vPath_RelatToAbs = bpy.path.abspath( bpy.context.scene.deos_ui.str_ToGamengine_DirPath )
          vPathDir = vPath_RelatToAbs.replace( "\\", "\\\\" )            # remplazar '\' por '\\'

        # GLB Textures
        if bool_ToGamengine_GD_Maps == True:
          vGD_Maps = 'EXPORT'
        elif bool_ToGamengine_GD_Maps == False:
          vGD_Maps = 'NONE'

        # FBX Axis Up
        if enum_ToGamengine_Fbx_Up == 'Op1':
          vUpAxis = 'X'
        elif enum_ToGamengine_Fbx_Up == 'Op2':
          vUpAxis = 'Y'
        elif enum_ToGamengine_Fbx_Up == 'Op3':
          vUpAxis = 'Z'
        elif enum_ToGamengine_Fbx_Up == 'Op4':
          vUpAxis = '-X'
        elif enum_ToGamengine_Fbx_Up == 'Op5':
          vUpAxis = '-Y'
        elif enum_ToGamengine_Fbx_Up == 'Op6':
          vUpAxis = '-Z'

        # FBX Axis Forward
        if enum_ToGamengine_Fbx_Forward == 'Op1':
          vForwardAxis = 'X'
        elif enum_ToGamengine_Fbx_Forward == 'Op2':
          vForwardAxis = 'Y'
        elif enum_ToGamengine_Fbx_Forward == 'Op3':
          vForwardAxis = 'Z'
        elif enum_ToGamengine_Fbx_Forward == 'Op4':
          vForwardAxis = '-X'
        elif enum_ToGamengine_Fbx_Forward == 'Op5':
          vForwardAxis = '-Y'
        elif enum_ToGamengine_Fbx_Forward == 'Op6':
          vForwardAxis = '-Z'

        # FBX Smooting Normals
        if enum_ToGamengine_Fbx_Smooth == 'Op1':
          vSmooth = 'OFF'
        elif enum_ToGamengine_Fbx_Smooth == 'Op2':
          vSmooth = 'FACE'
        elif enum_ToGamengine_Fbx_Smooth == 'Op3':
          vSmooth = 'EDGE'

        # endregion

        # EXPORT GLB FORMAT
        if enum_ToGamengine_Format == 'Op1':

          bpy.ops.export_scene.gltf (
            use_selection = bool_ToGamengine_Selected,

            export_yup = bool_ToGamengine_GD_Up,

            export_apply = True,
            export_texcoords = True,
            export_normals = True,
            export_attributes = True,

            export_materials = 'EXPORT',
            export_image_format=vGD_Maps,

            export_animations = bool_ToGamengine_GD_Anim,

            filepath = ( f"{vPathDir}{str_ToGamengine_FileName}{'.glb'}" )
          )
      
        # EXPORT FBX FORMAT
        elif enum_ToGamengine_Format == 'Op2':

          bpy.ops.export_scene.fbx (
            use_selection = bool_ToGamengine_Selected,
            
            axis_up = vUpAxis,
            axis_forward = vForwardAxis,
            bake_space_transform = True,
            
            mesh_smooth_type = vSmooth,
            use_triangles = True,
            bake_anim = bool_ToGamengine_Fbx_BakeAnim,

            filepath = ( f"{vPathDir}{str_ToGamengine_FileName}{'.fbx'}" )
          )



      # INFO
        self.report({"INFO"}, "THE EXPORT IS DONE")

        return {"FINISHED"}
