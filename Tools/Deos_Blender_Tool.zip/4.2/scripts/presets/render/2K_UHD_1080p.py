import bpy
scene = bpy.context.scene

scene.render.fps = 30
scene.render.fps_base = 1.0010000467300415
scene.render.pixel_aspect_x = 10.0
scene.render.pixel_aspect_y = 11.0
scene.render.resolution_percentage = 100
scene.render.resolution_x = 2048
scene.render.resolution_y = 1080
