# SPDX-License-Identifier: GPL-3.0-or-later

"""Rotations for many points at once: (N, 3, 3) matrices with mathutils' conventions.

A row's matrix R rotates a vector as `v.rotate(R)` does: v' = R @ v. Composing turns in the order they are
applied, `Rotation.compose(a, b)` @ v == v.rotate(a); v.rotate(b). Angles are radians, maths in float64; Blender's
float32 routines are ported where their rounding decides a branch. The ports of Blender's own routines
(vec_to_quat, quat_to_mat3, mat3_normalized_to_eul2, compatible_eul) follow math_rotation_c.cc line by line.
"""

from dataclasses import dataclass
from math import pi

import numpy as np

from .geometry import Angles


@dataclass(frozen=True, slots=True)
class FirstTurn:
    """The rotation that brings the z axis onto a direction: its axis, and the cosine of its angle times the
    direction's length."""

    axis: np.ndarray
    cosine: np.ndarray


@dataclass(frozen=True, slots=True)
class EulerSolutions:
    """The two XYZ Euler solutions of a rotation matrix (mat3_normalized_to_eul2)."""

    first: np.ndarray
    second: np.ndarray


class Rotation:
    """(N, 3, 3) rotation matrices about the fixed axes, as Matrix.Rotation(angle, 3, axis) builds them."""

    @staticmethod
    def about(angle: np.ndarray, axis: str) -> np.ndarray:
        """One matrix per angle, about "X", "Y" or "Z"; raises ValueError for another axis."""
        angle = np.asarray(angle, dtype=np.float64)
        c = np.cos(angle)
        s = np.sin(angle)
        one = np.ones_like(c)
        zero = np.zeros_like(c)
        if axis == "X":
            rows = [[one, zero, zero], [zero, c, -s], [zero, s, c]]
        elif axis == "Y":
            rows = [[c, zero, s], [zero, one, zero], [-s, zero, c]]
        elif axis == "Z":
            rows = [[c, -s, zero], [s, c, zero], [zero, zero, one]]
        else:
            raise ValueError(f"rotation axis must be X, Y or Z, not {axis!r}")
        return np.stack([np.stack(row, axis=-1) for row in rows], axis=-2)

    @staticmethod
    def axis_angle(axes: np.ndarray, angle: np.ndarray) -> np.ndarray:
        """One matrix per row: the rotation about the row's unit axis by the row's angle (Rodrigues)."""
        x = axes[:, 0]
        y = axes[:, 1]
        z = axes[:, 2]
        c = np.cos(angle)
        s = np.sin(angle)
        t = 1.0 - c
        return np.stack(
            [
                np.stack([t * x * x + c, t * x * y - s * z, t * x * z + s * y], axis=-1),
                np.stack([t * x * y + s * z, t * y * y + c, t * y * z - s * x], axis=-1),
                np.stack([t * x * z - s * y, t * y * z + s * x, t * z * z + c], axis=-1),
            ],
            axis=-2,
        )

    @staticmethod
    def compose(*turns: np.ndarray) -> np.ndarray:
        """The rotation that applies `turns` in order: the first given is applied first, so R = t_n @ ... @ t_1.

        A turn is (N, 3, 3) or a single (3, 3) matrix, which applies to every row.
        """
        if not turns:
            raise ValueError("compose needs at least one turn")
        result = turns[0]
        for turn in turns[1:]:
            result = turn @ result
        return result

    @staticmethod
    def apply(matrices: np.ndarray, vectors: np.ndarray) -> np.ndarray:
        """Row i of the result is matrices[i] @ vectors[i]."""
        return np.einsum("nij,nj->ni", matrices, vectors)

    @staticmethod
    def unit(vectors: np.ndarray) -> np.ndarray:
        """Each row scaled to length 1 (a zero row stays zero)."""
        length = np.linalg.norm(vectors, axis=1)
        return vectors / np.where(length == 0.0, 1.0, length)[:, None]


class Quaternions:
    """Quaternions as (N, 4) rows of w, x, y, z, with Blender's conventions."""

    SQRT2 = np.sqrt(2.0)

    @classmethod
    def to_matrices(cls, quaternions: np.ndarray) -> np.ndarray:
        """(N, 3, 3) rotation matrices of unit quaternions, Blender's quat_to_mat3 row for row (double maths)."""
        q = np.asarray(quaternions, dtype=np.float64) * cls.SQRT2
        q0 = q[:, 0]
        q1 = q[:, 1]
        q2 = q[:, 2]
        q3 = q[:, 3]
        qda = q0 * q1
        qdb = q0 * q2
        qdc = q0 * q3
        qaa = q1 * q1
        qab = q1 * q2
        qac = q1 * q3
        qbb = q2 * q2
        qbc = q2 * q3
        qcc = q3 * q3
        # Blender stores m[column][row]; these are the rows of R = the matrix that rotates v as R @ v
        return np.stack(
            [
                np.stack([1.0 - qbb - qcc, -qdc + qab, qdb + qac], axis=-1),
                np.stack([qdc + qab, 1.0 - qaa - qcc, -qda + qbc], axis=-1),
                np.stack([-qdb + qac, qda + qbc, 1.0 - qaa - qbb], axis=-1),
            ],
            axis=-2,
        )

    @staticmethod
    def from_matrices(matrices: np.ndarray) -> np.ndarray:
        """(N, 4) unit quaternions (w, x, y, z) of rotation matrices; the sign is the one with w >= 0."""
        m = np.asarray(matrices, dtype=np.float64)
        trace = m[:, 0, 0] + m[:, 1, 1] + m[:, 2, 2]
        # the four branches of Shepperd's method, each stable where its pivot is the largest
        pivot = np.argmax(np.stack([trace, m[:, 0, 0], m[:, 1, 1], m[:, 2, 2]], axis=1), axis=1)
        q = np.empty((len(m), 4))
        # each branch only on the matrices whose pivot it is: there its radicand is positive, so no division by zero
        q[pivot == 0] = Quaternions.shepperd_w(m[pivot == 0], trace[pivot == 0])
        q[pivot == 1] = Quaternions.shepperd_x(m[pivot == 1])
        q[pivot == 2] = Quaternions.shepperd_y(m[pivot == 2])
        q[pivot == 3] = Quaternions.shepperd_z(m[pivot == 3])
        if not np.all(np.isfinite(q)):
            raise ValueError("from_matrices: a matrix is not a rotation (its quaternion is not finite)")
        q = q / np.linalg.norm(q, axis=1)[:, None]
        return np.where((q[:, :1] < 0), -q, q)

    @staticmethod
    def shepperd_w(m: np.ndarray, trace: np.ndarray) -> np.ndarray:
        """Shepperd's branch where the trace is the largest pivot: w first."""
        s = np.sqrt(1.0 + trace) * 2.0
        return np.stack(
            [0.25 * s, (m[:, 2, 1] - m[:, 1, 2]) / s, (m[:, 0, 2] - m[:, 2, 0]) / s, (m[:, 1, 0] - m[:, 0, 1]) / s], 1
        )

    @staticmethod
    def shepperd_x(m: np.ndarray) -> np.ndarray:
        """Shepperd's branch where m[0, 0] is the largest pivot: x first."""
        s = np.sqrt(1.0 + m[:, 0, 0] - m[:, 1, 1] - m[:, 2, 2]) * 2.0
        return np.stack(
            [(m[:, 2, 1] - m[:, 1, 2]) / s, 0.25 * s, (m[:, 0, 1] + m[:, 1, 0]) / s, (m[:, 0, 2] + m[:, 2, 0]) / s], 1
        )

    @staticmethod
    def shepperd_y(m: np.ndarray) -> np.ndarray:
        """Shepperd's branch where m[1, 1] is the largest pivot: y first."""
        s = np.sqrt(1.0 - m[:, 0, 0] + m[:, 1, 1] - m[:, 2, 2]) * 2.0
        return np.stack(
            [(m[:, 0, 2] - m[:, 2, 0]) / s, (m[:, 0, 1] + m[:, 1, 0]) / s, 0.25 * s, (m[:, 1, 2] + m[:, 2, 1]) / s], 1
        )

    @staticmethod
    def shepperd_z(m: np.ndarray) -> np.ndarray:
        """Shepperd's branch where m[2, 2] is the largest pivot: z first."""
        s = np.sqrt(1.0 - m[:, 0, 0] - m[:, 1, 1] + m[:, 2, 2]) * 2.0
        return np.stack(
            [(m[:, 1, 0] - m[:, 0, 1]) / s, (m[:, 0, 2] + m[:, 2, 0]) / s, (m[:, 1, 2] + m[:, 2, 1]) / s, 0.25 * s], 1
        )

    @staticmethod
    def multiply(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Row-wise a * b (Blender's mul_qt_qtqt)."""
        a0 = a[:, 0]
        a1 = a[:, 1]
        a2 = a[:, 2]
        a3 = a[:, 3]
        b0 = b[:, 0]
        b1 = b[:, 1]
        b2 = b[:, 2]
        b3 = b[:, 3]
        return np.stack(
            [
                a0 * b0 - a1 * b1 - a2 * b2 - a3 * b3,
                a0 * b1 + a1 * b0 + a2 * b3 - a3 * b2,
                a0 * b2 + a2 * b0 + a3 * b1 - a1 * b3,
                a0 * b3 + a3 * b0 + a1 * b2 - a2 * b1,
            ],
            axis=-1,
        )


class TrackFrame:
    """Blender's Vector.to_track_quat("Z", "Y"): the rotation that points the z axis along a direction with the y
    axis up, for many directions at once (a port of vec_to_quat: the degenerate directions and the half-angle
    twist included). The model tracks z with y up everywhere."""

    EPS = 1e-4

    @classmethod
    def quaternions(cls, directions: np.ndarray) -> np.ndarray:
        """(N, 4) quaternions (w, x, y, z) of to_track_quat("Z", "Y") for each row of `directions`."""
        # Blender's vectors are float32: the length of a direction a hair's breadth off a pole rounds to 1 there,
        # which decides between the regular and the degenerate branch below
        d = np.asarray(directions, dtype=np.float32).reshape(-1, 3)
        length = np.sqrt(d[:, 0] * d[:, 0] + d[:, 1] * d[:, 1] + d[:, 2] * d[:, 2])
        safe_length = np.where(length == 0.0, np.float32(1.0), length)
        tvec = d  # mathutils passes the positive axes as vec_to_quat's codes 3..5, which keep the vector's sign
        turn = cls._first_turn(tvec)
        angle = np.arccos(np.clip(turn.cosine / safe_length, -1.0, 1.0))
        q = cls._axis_angle(Rotation.unit(turn.axis.astype(np.float64)), angle.astype(np.float64))
        fp = Quaternions.to_matrices(q)[:, :, 2]  # the image of the z axis
        twist = cls._twist(fp)
        q2 = np.concatenate(
            [
                np.cos(twist)[:, None],
                tvec.astype(np.float64) * (np.sin(twist) / safe_length.astype(np.float64))[:, None],
            ],
            axis=1,
        )
        q = Quaternions.multiply(q2, q)
        q[length == 0.0] = [1.0, 0.0, 0.0, 0.0]
        return q

    @classmethod
    def matrices(cls, directions: np.ndarray) -> np.ndarray:
        """(N, 3, 3) matrices of to_track_quat("Z", "Y"), the columns being the rotated x, y and z axes."""
        return Quaternions.to_matrices(cls.quaternions(directions))

    @classmethod
    def _first_turn(cls, tvec: np.ndarray) -> FirstTurn:
        """The rotation onto the z axis: its axis, and the cosine of its angle times the length."""
        x = tvec[:, 0]
        y = tvec[:, 1]
        z = tvec[:, 2]
        nor = np.stack([-y, x, np.zeros_like(x)], axis=1)
        nor[np.abs(x) + np.abs(y) < cls.EPS, 0] = 1.0
        return FirstTurn(nor, z)

    @staticmethod
    def _twist(fp: np.ndarray) -> np.ndarray:
        """The half angle of the twist about the tracked z axis that puts the y axis up."""
        return -0.5 * np.arctan2(-fp[:, 0], -fp[:, 1])

    @staticmethod
    def _axis_angle(axes: np.ndarray, angle: np.ndarray) -> np.ndarray:
        """Quaternions of rotations about unit axes (axis_angle_normalized_to_quat).

        The half angle's sine and cosine are float32 as in Blender: at the poles cosf(pi / 2) is -4.4e-8, not
        +6e-17, and that sign decides which way the twist below turns (atan2 of signed zeros).
        """
        half = (0.5 * angle).astype(np.float32)
        cos = np.cos(half).astype(np.float64)
        sin = np.sin(half).astype(np.float64)
        return np.concatenate([cos[:, None], axes * sin[:, None]], axis=1)


class TrunkFrame:
    """The trunk's growth frame: the direction as Euler((-rx, ry, 0), "XYZ"), the way the trunk grows (growth.py
    level 0): a frame without the roll that TrackFrame would add around a leaning trunk."""

    @staticmethod
    def matrices(directions: np.ndarray) -> np.ndarray:
        """(N, 3, 3) for unit directions."""
        d = np.asarray(directions, dtype=np.float64)
        ry = np.arctan2(d[:, 0], d[:, 2])
        rx = np.arctan2(d[:, 1], np.hypot(d[:, 0], d[:, 2]))
        return Rotation.about(ry, "Y") @ Rotation.about(-rx, "X")


class EulerXYZ:
    """Blender's compatible XYZ Euler angles of rotation matrices (Quaternion.to_euler("XYZ", compatible))."""

    GIMBAL = 16.0 * float(np.finfo(np.float32).eps)

    @classmethod
    def compatible(cls, matrices: np.ndarray, reference: np.ndarray) -> np.ndarray:
        """(N, 3) angles: of the two solutions, the one closer to the reference angles after wrapping.

        Where the middle angle is exactly +-pi the two solutions coincide as rotations; Blender's sign of that
        angle depends on float rounding, so compare rebuilt matrices (EulerXYZ.matrices), not raw angles.
        """
        solutions = cls._two_solutions(matrices)
        first = cls._wrap(solutions.first, reference)
        second = cls._wrap(solutions.second, reference)
        prefer_second = np.abs(first - reference).sum(axis=1) > np.abs(second - reference).sum(axis=1)
        return np.where(prefer_second[:, None], second, first)

    @staticmethod
    def matrices(eulers: np.ndarray) -> np.ndarray:
        """(N, 3, 3) of XYZ Euler angles: x first, then y, then z."""
        return Rotation.about(eulers[:, 2], "Z") @ Rotation.about(eulers[:, 1], "Y") @ Rotation.about(eulers[:, 0], "X")

    @classmethod
    def _two_solutions(cls, r: np.ndarray) -> EulerSolutions:
        """mat3_normalized_to_eul2 for XYZ; Blender's mat[c][r] is r[:, r, c]."""
        cy = np.hypot(r[:, 0, 0], r[:, 1, 0])
        regular = cy > cls.GIMBAL
        first = np.stack(
            [np.arctan2(r[:, 2, 1], r[:, 2, 2]), np.arctan2(-r[:, 2, 0], cy), np.arctan2(r[:, 1, 0], r[:, 0, 0])], 1
        )
        second = np.stack(
            [np.arctan2(-r[:, 2, 1], -r[:, 2, 2]), np.arctan2(-r[:, 2, 0], -cy), np.arctan2(-r[:, 1, 0], -r[:, 0, 0])],
            1,
        )
        gimbal = np.stack([np.arctan2(-r[:, 1, 2], r[:, 1, 1]), np.arctan2(-r[:, 2, 0], cy), np.zeros(len(r))], 1)
        return EulerSolutions(np.where(regular[:, None], first, gimbal), np.where(regular[:, None], second, gimbal))

    @staticmethod
    def _wrap(eul: np.ndarray, old: np.ndarray) -> np.ndarray:
        """compatible_eul: wrap by 2 pi towards the old angles, then flip one axis that turned more than pi."""
        eul = eul.copy()
        tau = Angles.TAU
        deul = eul - old
        high = deul > pi
        eul[high] -= np.floor(deul[high] / tau + 0.5) * tau
        low = deul < -pi
        eul[low] += np.floor(-deul[low] / tau + 0.5) * tau
        deul = eul - old
        size = np.abs(deul)
        for i in range(3):
            j = (i + 1) % 3
            k = (i + 2) % 3
            flip = (size[:, i] > pi) & (size[:, j] < pi / 2) & (size[:, k] < pi / 2)
            eul[flip, i] -= np.where(deul[flip, i] > 0, tau, -tau)
        return eul


class AttractUp:
    """Vertical Attraction: bending growth directions up (attractUp > 0) or down, for many directions at once."""

    @staticmethod
    def apply(vectors: np.ndarray, attract_up: float, segments: int) -> np.ndarray:
        """The bent vectors (lengths kept)."""
        if attract_up == 0.0:
            return vectors
        directions = Rotation.unit(vectors)
        frames = TrackFrame.matrices(directions)
        side_z = np.abs(frames[:, 2, 1])  # the tracked frame's y axis, its z component
        declination = np.arccos(np.clip(directions[:, 2], -1.0, 1.0))
        angle = attract_up * declination * side_z / segments
        angle = np.where(-declination + angle < -pi, -pi + declination, angle)
        angle = np.where(declination - angle < 0.0, declination, angle)
        return Rotation.apply(Rotation.axis_angle(frames[:, :, 0], -angle), vectors)


class BezierBatch:
    """Points and tangents of many cubic Bezier segments at once."""

    @staticmethod
    def points(p1: np.ndarray, h1: np.ndarray, h2: np.ndarray, p2: np.ndarray, t: np.ndarray) -> np.ndarray:
        """Position at parameter t per row (0 = p1, 1 = p2)."""
        t = t[:, None]
        u = 1.0 - t
        return (u**3) * p1 + (3.0 * t * u**2) * h1 + (3.0 * t**2 * u) * h2 + (t**3) * p2

    @staticmethod
    def tangents(p1: np.ndarray, h1: np.ndarray, h2: np.ndarray, p2: np.ndarray, t: np.ndarray) -> np.ndarray:
        """Unit tangent at parameter t per row."""
        t = t[:, None]
        u = 1.0 - t
        derivative = (
            (-3.0 * u**2) * p1 + (-6.0 * t * u + 3.0 * u**2) * h1 + (-3.0 * t**2 + 6.0 * t * u) * h2 + (3.0 * t**2) * p2
        )
        return Rotation.unit(derivative)
