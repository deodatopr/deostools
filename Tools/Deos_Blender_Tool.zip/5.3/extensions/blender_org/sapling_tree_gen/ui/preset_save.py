# SPDX-License-Identifier: GPL-3.0-or-later

"""Saving the panel's settings as a user preset."""

from typing import TYPE_CHECKING, override

from bpy.props import BoolProperty, StringProperty
from bpy.types import Context, Operator

from ..service.presets import PresetService
from ..settings import SettingsError

if TYPE_CHECKING:
    from bpy.stub_internal.rna_enums import OperatorReturnItems


class SavePresetOperator(Operator):
    """Save the current tree settings as a preset"""

    bl_idname = "sapling.preset_save"
    bl_label = "Save Preset"
    bl_options = {"INTERNAL"}

    name: StringProperty(name="Name")
    overwrite: BoolProperty(name="Overwrite")
    settings: StringProperty(name="Settings", options={"HIDDEN"})

    @override
    def execute(self, context: Context) -> "set[OperatorReturnItems]":  # type: ignore[override]  # stub: context is Context | None; Blender always passes one
        try:
            path = PresetService.save(self.name, self.settings, self.overwrite)
        except SettingsError as error:
            self.report({"ERROR"}, str(error))
            return {"CANCELLED"}
        self.report({"INFO"}, f"Saved preset {path.stem}")
        return {"FINISHED"}
