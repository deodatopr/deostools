# SPDX-License-Identifier: GPL-3.0-or-later

"""Tree settings as plain data: read from and written to the operator, presets and trees."""

import json
from collections.abc import Iterable, Mapping, Sequence
from types import MappingProxyType
from typing import Any, Self


class SettingsError(Exception):
    """Settings the user can fix (bad preset, missing leaf object, ...); shown in the UI as an error."""


class TreeSettings:
    """Generation settings keyed by operator property name.

    Values are plain Python (vectors become lists), so they fit presets and JSON.
    """

    # Version of the settings stored on a generated tree (see to_json()).
    VERSION = 1
    # The Armature Rig setting's default (ui/properties.py useRig): what a left-out rig setting means
    RIG_DEFAULT = False
    # Keys of the oldest preset format that no longer exist.
    OBSOLETE_KEYS = ("startCurv", "windGust", "windSpeed")
    # Presets older than the leaf angles used the last branch level's angles for the leaves.
    LEAF_ANGLE_SOURCES = MappingProxyType(
        {
            "leafDownAngle": "downAngle",
            "leafDownAngleV": "downAngleV",
            "leafRotate": "rotate",
            "leafRotateV": "rotateV",
        }
    )

    # Setting ids renamed when the wind moved to Geometry Nodes; presets, stored trees and scripts may use the old
    # ids, which load under the new ones
    RENAMED = MappingProxyType(
        {
            "useArm": "useRig",
            "armAnim": "windAnim",
            "previewArm": "fastPreview",
            "armLevels": "jointLevels",
            "boneStep": "jointStep",
            "leafAnim": "leafFlutter",
            "wind": "windStrength",
            "gust": "gustStrength",
            "gustF": "gustFrequency",
            "frameRate": "animationSpeed",
            "af1": "flutterStrength",
            "af2": "flutterSpeed",
            "af3": "flutterRandomness",
        }
    )

    def __init__(self, values: object) -> None:
        """Settings from `values`, a dictionary keyed by operator property name. Raises SettingsError when `values` is
        not a dictionary."""
        if not isinstance(values, dict):
            raise SettingsError(f"Settings must be a dictionary, not {type(values).__name__}")
        self.values = dict(values)

    @classmethod
    def from_properties(cls, props: Any, names: Iterable[str]) -> Self:
        """The named settings read from props (the operator, or anything with its property names)."""
        return cls({name: cls.plain(getattr(props, name)) for name in names})

    def missing(self, defaults: Mapping[str, Any]) -> list[str]:
        """The settings of `defaults` these settings do not have, sorted."""
        return sorted(name for name in defaults if name not in self.values)

    def complete(self, defaults: Mapping[str, Any]) -> Self:
        """Fill in the settings an older preset does not have, from the defaults."""
        for name, value in defaults.items():
            self.values.setdefault(name, value)
        return self

    def apply_to(self, props: Any, names: Sequence[str]) -> None:
        """Set exactly these settings on props: every name must be given, and nothing else."""
        missing = sorted(set(names) - set(self.values))
        unknown = sorted(set(self.values) - set(names))
        if missing or unknown:
            raise SettingsError(f"Settings do not fit this version: missing {missing}, unknown {unknown}")
        for name in names:
            setattr(props, name, self.values[name])

    def migrate(self) -> Self:
        """Bring settings from presets of older add-on versions up to date; raises SettingsError when the
        settings lack what the migration needs."""
        self.rename_keys()
        v = self.values
        for key in self.OBSOLETE_KEYS:
            v.pop(key, None)  # only the oldest presets have them
        self._check_migratable()
        # attractUp was a single value before it became per level
        if isinstance(v["attractUp"], int | float):
            v["attractUp"] = [0, 0, v["attractUp"], v["attractUp"]]
        if "leafDownAngle" not in v:
            last = self.angle_source_level()
            for leaf_key, branch_key in self.LEAF_ANGLE_SOURCES.items():
                v[leaf_key] = v[branch_key][last]
        return self

    def angle_source_level(self) -> int:
        """The branch level an old preset's leaf angles come from: the last level, at most the fourth."""
        return min(self.values["levels"], 3)

    def _check_migratable(self) -> None:
        """What migrate() reads must be there and have the right shape."""
        v = self.values
        needed = ["levels", "attractUp"]
        if "leafDownAngle" not in v:
            needed += list(self.LEAF_ANGLE_SOURCES.values())
        missing = [key for key in needed if key not in v]
        if missing:
            raise SettingsError(f"Settings do not have {missing}; this version needs them to load the settings")
        if not isinstance(v["levels"], int):
            raise SettingsError(f"levels must be an integer, not {type(v['levels']).__name__}")
        if "leafDownAngle" not in v:
            self._check_angle_sources()

    def _check_angle_sources(self) -> None:
        """An old preset's per-level angles must reach the level its leaf angles come from."""
        last = self.angle_source_level()
        for key in self.LEAF_ANGLE_SOURCES.values():
            values = self.values[key]
            count = 0
            if isinstance(values, list | tuple):
                count = len(values)
            if count <= last:
                raise SettingsError(f"{key} has {count} values; {last + 1} are needed")

    @classmethod
    def forward_old_names(cls, target: Any, props: Any) -> None:
        """Move the values a script gave under old ids (RENAMED) to the new ids on `target` (the operator), and
        unset the old ids on its properties `props`, so the redo panel works on the new ids only. SettingsError
        when an old and a new id disagree. Nothing happens when no old id was given."""
        old = [name for name in cls.RENAMED if props.is_property_set(name)]
        if not old:
            return
        names = [*cls.RENAMED, *cls.RENAMED.values()]
        given = cls({n: cls.plain(getattr(target, n)) for n in names if props.is_property_set(n)})
        given.rename_keys()  # the same rules as for presets and stored trees
        for name in old:
            props.property_unset(name)
        for name, value in given.values.items():
            setattr(target, name, value)

    def rename_keys(self) -> Self:
        """Settings under their old ids (RENAMED) move to the new ids; raises SettingsError when both are given
        with different values."""
        values = self.values
        still = self.old_wind_without_rig(values)
        for old, new in self.RENAMED.items():
            if old not in values:
                continue
            value = values.pop(old)
            if new in values and values[new] != value:
                raise SettingsError(
                    f"Settings give both {old} (the old name of {new}) and {new}, with different values"
                )
            values[new] = value
        if still:
            values["windAnim"] = False
        return self

    @staticmethod
    def old_wind_without_rig(values: Mapping[str, Any]) -> bool:
        """Old settings with armAnim but no armature: the old wind ran on the armature only, so they had none.

        windAnim without the rig now makes the node wind; these settings keep their still tree. A script or preset
        that leaves the rig out has the rig's default, off (as every left-out setting has its default, SWR-0047).
        """
        if not values.get("armAnim"):
            return False
        if "useArm" in values:
            return not values["useArm"]
        if "useRig" in values:
            return not values["useRig"]
        return not TreeSettings.RIG_DEFAULT

    def to_json(self) -> str:
        """The settings as versioned JSON, the form a generated tree stores (read back with from_json())."""
        return json.dumps({"version": self.VERSION, "settings": self.values}, sort_keys=True)

    @classmethod
    def from_json(cls, text: str) -> Self:
        """Settings stored by to_json(); raises SettingsError on invalid JSON or another settings version."""
        try:
            data = json.loads(text)
        except ValueError as error:
            raise SettingsError(f"Invalid settings JSON: {error}") from error
        if not isinstance(data, dict) or data.get("version") != cls.VERSION or "settings" not in data:
            found = type(data).__name__
            if isinstance(data, dict):
                found = f"version {data.get('version')!r}"
            raise SettingsError(f"Settings JSON must be a version {cls.VERSION} settings object; got {found}")
        return cls(data["settings"])

    @classmethod
    def defaults_from_rna(cls, properties: Any, names: Iterable[str]) -> Self:
        """The RNA default of each named property (bpy.types.Property collection)."""
        values = {}
        for name in names:
            prop = properties[name]
            # Only numeric and boolean properties can be arrays (enums and strings have no is_array)
            is_array = prop.type in {"BOOLEAN", "INT", "FLOAT"} and prop.is_array
            values[name] = cls.plain(prop.default_array if is_array else prop.default)
        return cls(values)

    @staticmethod
    def plain(value: Any) -> Any:
        """A property value as plain Python: a number, text or flag as it is; a vector (a bpy array, one level deep,
        as Blender's array properties are) as a list. Raises SettingsError for anything else."""
        if isinstance(value, str | bool | int | float):
            return value
        if not hasattr(value, "__iter__"):
            raise SettingsError(f"a setting's value must be a number, text, flag or vector, not {type(value).__name__}")
        items = list(value)
        for item in items:
            if not isinstance(item, str | bool | int | float):
                raise SettingsError(f"a vector setting's items must be numbers or flags, not {type(item).__name__}")
        return items


class SettingValues:
    """A tree's settings as attributes (settings.levels, ...), the way the model and the generator read them."""

    def __init__(self, settings: TreeSettings) -> None:
        """The values of `settings`, read as attributes."""
        self._values = dict(settings.values)

    def __getattr__(self, name: str) -> Any:
        """The setting's value. Raises AttributeError naming a setting the tree's settings do not have."""
        # only called for a name the object lacks: _values itself always exists after __init__
        if name not in self._values:
            raise AttributeError(f"The settings have no '{name}'")
        return self._values[name]
