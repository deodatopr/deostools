

import math
import re
import time
from bisect import bisect_left, bisect_right
import traceback
from array import array
from contextlib import nullcontext

import blf
import bpy
import gpu
from bpy.app.handlers import persistent
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Euler, Matrix, Quaternion, Vector

try:
    import numpy as np
except ImportError:  
    np = None

try:
    from bpy_extras.anim_utils import action_get_channelbag_for_slot
except ImportError:  
    action_get_channelbag_for_slot = None



PROP_TARGET = "mpp_target"
PROP_BONE = "mpp_bone"

TRANSFORM_PROPS = frozenset((
    "location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "scale",
))



HEAVY_TYPES = frozenset((
    'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'CURVES', 'POINTCLOUD', 'VOLUME', 'GREASEPENCIL',
    'GPENCIL',  
))
_BONE_PATH_RE = re.compile(r'^pose\.bones\["((?:[^"\\]|\\.)*)"\]\.([A-Za-z_]+)$')


SETTLE_TIME = 0.35


_BUSY_PREFIXES = ("TRANSFORM_OT_", "GRAPH_OT_", "ACTION_OT_", "POSE_OT_", "ANIM_OT_", "NLA_OT_")

_OWN_MODALS = frozenset((
    "MOTION_PATH_OT_direct_manipulation",
    "MOTION_PATH_OT_auto_update_motion_paths",
    "AMTH_OT_auto_update_motion_paths",
    "ANIM_OT_generic_offest_keyframes",
    "ANIM_OT_insert_keyframe_selected_fcurves",
))






class _Space:
    """Baked data of one path target (bone or object)."""
    __slots__ = ("P", "fresh", "approx", "deps", "dep_objects", "order", "links", "blocked",
                 "animated", "constrained", "F", "Finv", "O", "PO", "chan", "dirty",
                 "sig", "validated", "no_live", "own_dirty", "own_mode", "has_constraints", "B", "L")

    def __init__(self):
        self.P = {}             
        self.fresh = set()      
        self.approx = False     
        self.deps = set()       
        self.dep_objects = set()
        self.order = []         
        self.links = {}         
        self.blocked = set()    
        self.animated = set()   
        self.constrained = set()  
        self.F = {}             
        self.Finv = {}
        self.O = {}             
        self.PO = {}            
        self.chan = {}          
        self.dirty = set()      
        self.sig = None         
        self.validated = False
        self.no_live = set()    
        self.own_dirty = False  
        
        
        self.own_mode = 'EXACT'
        self.has_constraints = False
        self.B = {}             
        
        
        
        self.L = {}


_spaces = {}    
_pass_basis = {}  
_sigs = {}      
_paths = {}     
_dirty_objects = set()   
_dirty_actions = set()
_last_full_scan = {}     
FULL_SCAN_INTERVAL = 2.0
_busy_checks = []
_rt = {
    "version": 0,          
    "fast_version": -1,    
    "refined_version": -1,  
    "last_change": 0.0,
}
_draw_handles = []


def reset_runtime():
    _spaces.clear()
    _sigs.clear()
    _paths.clear()
    _dirty_objects.clear()
    _dirty_actions.clear()
    _last_full_scan.clear()
    _rt.update(version=0, fast_version=-1, refined_version=-1, last_change=0.0)


def register_busy_check(fn):
    """Extra callable returning True while the user is dragging something."""
    if fn not in _busy_checks:
        _busy_checks.append(fn)


def change_version():
    return _rt["version"]






def _settings():
    return bpy.context.window_manager


_shader_names = {}


def builtin_shader(name):
    """Built-in GPU shader by its Blender 4 name ('UNIFORM_COLOR',
    'POLYLINE_SMOOTH_COLOR' ...). Blender 3.x only knows the old names with a
    '3D_' prefix ('3D_UNIFORM_COLOR' ...): use those there."""
    real = _shader_names.get(name)
    if real is not None:
        return gpu.shader.from_builtin(real)
    try:
        shader = gpu.shader.from_builtin(name)
        real = name
    except ValueError:
        real = "3D_" + name
        shader = gpu.shader.from_builtin(real)
    _shader_names[name] = real
    return shader


def blf_size(font, size):
    try:
        blf.size(font, size)
    except TypeError:   
        blf.size(font, int(round(size)), 72)


def get_anim_fcurves(id_data):
    """F-Curves of the action slot assigned to ``id_data`` (Blender 4.4+ slotted actions,
    the action's own F-Curves on Blender 4.2 / 4.3)."""
    ad = getattr(id_data, "animation_data", None)
    if ad is None or ad.action is None:
        return None
    action = ad.action
    if action_get_channelbag_for_slot is not None:
        slot = getattr(ad, "action_slot", None)
        if slot is None:
            return None
        try:
            cb = action_get_channelbag_for_slot(action, slot)
        except Exception:
            return None
        return cb.fcurves if cb is not None else None
    return getattr(action, "fcurves", None)


def _prefix(bone_name):
    if bone_name:
        return 'pose.bones["%s"].' % bpy.utils.escape_identifier(bone_name)
    return ""


def _own_paths(bone_name):
    pre = _prefix(bone_name)
    return {pre + p for p in TRANSFORM_PROPS}


def _fcurve_signature(fc):
    kps = fc.keyframe_points
    n = len(kps)
    parts = [n, fc.mute, len(fc.modifiers)]
    if n:
        co = array('f', bytes(8 * n))
        hl = array('f', bytes(8 * n))
        hr = array('f', bytes(8 * n))
        kps.foreach_get("co", co)
        kps.foreach_get("handle_left", hl)
        kps.foreach_get("handle_right", hr)
        parts += [co.tobytes(), hl.tobytes(), hr.tobytes()]
        ip = array('i', bytes(4 * n))
        try:
            kps.foreach_get("interpolation", ip)
            parts.append(ip.tobytes())
        except Exception:
            pass
    return hash(tuple(parts))


def selection_hash(ob):
    """Cheap hash of key selection (+ bone selection) of an object's action."""
    if ob is None:
        return None
    parts = []
    fcurves = get_anim_fcurves(ob)
    if fcurves:
        for fc in fcurves:
            n = len(fc.keyframe_points)
            if n:
                sel = array('b', bytes(n))
                fc.keyframe_points.foreach_get("select_control_point", sel)
                parts.append(sel.tobytes())
    if ob.mode == 'POSE' and ob.pose:
        parts.append(tuple(pb.name for pb in ob.pose.bones if _bone_selected(pb)))
    return hash(tuple(parts))


def _bone_selected(pb):
    sel = getattr(pb, "select", None)  
    if sel is None:
        sel = getattr(pb.bone, "select", False)
    return bool(sel)


def is_playing():
    for win in bpy.context.window_manager.windows:
        scr = win.screen
        if scr is not None and scr.is_animation_playing:
            return True
    return False


def _norm_idname(idname):
    if "." in idname:
        a, b = idname.split(".", 1)
        return a.upper() + "_OT_" + b
    return idname


def is_busy():
    """True while the user is still dragging / editing (re-bake must wait)."""
    for fn in _busy_checks:
        try:
            if fn():
                return True
        except Exception:
            pass
    for win in bpy.context.window_manager.windows:
        for op in getattr(win, "modal_operators", ()) or ():
            try:
                idn = _norm_idname(op.bl_idname)
            except Exception:
                continue
            if idn in _OWN_MODALS:
                continue
            if idn.startswith(_BUSY_PREFIXES):
                return True
    return False


def ctx_override():
    return _ctx_override()


def _ctx_override():
    """Give timers a window context so frame_set / depsgraph access work."""
    try:
        if bpy.context.window is not None:
            return nullcontext()
    except Exception:
        pass
    if not hasattr(bpy.context, "temp_override"):   
        return nullcontext()
    for win in bpy.context.window_manager.windows:
        if win.screen is not None:
            return bpy.context.temp_override(window=win)
    return nullcontext()


def tag_redraw():
    for win in bpy.context.window_manager.windows:
        scr = win.screen
        if scr is None:
            continue
        for area in scr.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def keyed_range(obj_name):
    """(first, last) keyframe of everything keyed on an object (all bones), or None."""
    ob = bpy.data.objects.get(obj_name)
    fcurves = get_anim_fcurves(ob) if ob is not None else None
    if not fcurves:
        return None
    lo = hi = None
    for fc in fcurves:
        kps = fc.keyframe_points
        if not len(kps):
            continue
        a, b = kps[0].co[0], kps[-1].co[0]
        lo = a if lo is None else min(lo, a)
        hi = b if hi is None else max(hi, b)
    if lo is None:
        return None
    return int(math.floor(lo)), int(math.ceil(hi))


def path_frames(scene=None, key=None):
    """Frames a path is computed for. ``key`` is needed for the 'All Keys' range."""
    scene = scene or bpy.context.scene
    wm = _settings()
    mode = getattr(wm, "mpp_range_mode", 'SCENE')
    rng = keyed_range(key[0]) if (mode == 'KEYS_ALL' and key is not None) else None
    if rng is not None:
        start, end = rng
    elif mode == 'MANUAL':
        start, end = wm.mpp_frame_start, wm.mpp_frame_end
    elif scene.use_preview_range:
        start, end = scene.frame_preview_start, scene.frame_preview_end
    else:
        start, end = scene.frame_start, scene.frame_end
    if end < start:
        start, end = end, start
    step = max(1, getattr(wm, "mpp_frame_step", 1))
    frames = list(range(start, end + 1, step))
    if frames and frames[-1] != end:
        frames.append(end)
    return frames






def _scan(ob):
    """Return set of changed data paths since the last scan (None = first scan)."""
    fcurves = get_anim_fcurves(ob)
    new = {}
    if fcurves:
        for fc in fcurves:
            new[(fc.data_path, fc.array_index)] = _fcurve_signature(fc)
    old = _sigs.get(ob.name)
    _sigs[ob.name] = new
    if old is None:
        return None
    if old == new:
        return set()
    return {k[0] for k in (old.keys() | new.keys()) if old.get(k) != new.get(k)}


def _path_node(obj_name, data_path):
    """Node whose own transform channel is ``data_path`` (None for anything else)."""
    m = _BONE_PATH_RE.match(data_path)
    if m is not None:
        if m.group(2) in TRANSFORM_PROPS:
            return (obj_name, bpy.utils.unescape_identifier(m.group(1)))
        return None
    if data_path in TRANSFORM_PROPS:
        return (obj_name, "")
    return None


def _classify(space, key, obj_name, changed_paths):
    """(stale, dirty nodes) for a baked path after keys of ``obj_name`` changed.

    stale: the accurate re-bake must run once the edit is finished.
    dirty: nodes the path follows live (parent / Child Of / Copy ... sources)."""
    stale = False
    dirty = set()
    for dp in changed_paths:
        node = _path_node(obj_name, dp)
        if node is None:
            
            if obj_name in space.dep_objects:
                stale = True
            continue
        if node == key:
            space.own_dirty = True
            if space.approx or space.has_constraints:
                stale = True   
            continue
        if node in space.deps:
            stale = True
            if node in space.animated and node not in space.no_live:
                dirty.add(node)
    return stale, dirty


def poll_changes(obj_names, force=False):
    """Scan the actions of the given objects. Marks baked paths stale and
    records which driver bones changed. Returns True if any key changed.

    Objects are only scanned when the depsgraph reported them (or their
    action) as updated, plus a safety scan every FULL_SCAN_INTERVAL seconds,
    so an idle scene costs nothing even with huge actions."""
    any_change = False
    now = time.monotonic()
    scanned_actions = set()
    for name in obj_names:
        ob = bpy.data.objects.get(name)
        if ob is None:
            continue
        ad = ob.animation_data
        act_name = ad.action.name if ad is not None and ad.action is not None else None
        due = (force or name not in _sigs or name in _dirty_objects
               or (act_name is not None and act_name in _dirty_actions)
               or now - _last_full_scan.get(name, 0.0) > FULL_SCAN_INTERVAL)
        if not due:
            continue
        _dirty_objects.discard(name)
        if act_name is not None:
            scanned_actions.add(act_name)
        _last_full_scan[name] = now
        changed = _scan(ob)
        if not changed:
            continue
        any_change = True
        for key, space in _spaces.items():
            if name not in space.dep_objects:
                continue
            stale, dirty = _classify(space, key, name, changed)
            if stale:
                space.fresh.clear()
            if dirty:
                space.dirty |= dirty
    _dirty_actions.difference_update(scanned_actions)
    if any_change:
        _rt["version"] += 1
        _rt["last_change"] = time.monotonic()
    return any_change


def tracked_objects(keys):
    """Objects whose keys can move the given paths (targets + their drivers)."""
    names = set()
    for key in keys:
        names.add(key[0])
        space = _spaces.get(key)
        if space is not None:
            names |= space.dep_objects
    return names
















LINK_RIGID = 'RIGID'
LINK_CHILD_OF = 'CHILD_OF'
LINK_REPLACE = 'REPLACE'
LINK_LOCATION = 'LOCATION'
LINK_ARMATURE = 'ARMATURE'
_CHILD_OF_FLAGS = ("use_location_x", "use_location_y", "use_location_z",
                   "use_rotation_x", "use_rotation_y", "use_rotation_z",
                   "use_scale_x", "use_scale_y", "use_scale_z")


def _constraint_active(c):
    enabled = getattr(c, "enabled", None)
    if enabled is None:
        enabled = not getattr(c, "mute", False)
    return enabled and c.influence > 0.0


def _node_item(node):
    ob = bpy.data.objects.get(node[0])
    if ob is None:
        return None, None
    if node[1]:
        pb = ob.pose.bones.get(node[1]) if ob.pose is not None else None
        return ob, pb
    return ob, ob


def _target_node(target, subtarget=""):
    if not isinstance(target, bpy.types.Object):
        return None
    if subtarget:
        if target.type == 'ARMATURE' and target.pose is not None \
                and target.pose.bones.get(subtarget) is not None:
            return (target.name, subtarget)
        return None  
    return (target.name, "")


def _ik_owners(ob):
    """bone name -> [(owner pose bone, IK constraint)] for every IK chain."""
    out = {}
    if ob.pose is None:
        return out
    for pb in ob.pose.bones:
        for c in pb.constraints:
            if c.type not in {'IK', 'SPLINE_IK'} or not _constraint_active(c):
                continue
            count = c.chain_count
            b = pb
            i = 0
            while b is not None and (count == 0 or i < count):
                out.setdefault(b.name, []).append((pb, c))
                b = b.parent
                i += 1
    return out


_BONE_PREFIX_RE = re.compile(r'^pose\.bones\["((?:[^"\\]|\\.)*)"\]')


def _driver_map(ob, ctx):
    """bone name ("" = the object) -> (driven data paths, nodes the drivers read)."""
    key = ("drivers", ob.name)
    m = ctx.get(key)
    if m is not None:
        return m
    m = {}
    ad = ob.animation_data
    if ad is not None:
        for fc in ad.drivers:
            dp = fc.data_path
            mm = _BONE_PREFIX_RE.match(dp)
            owner = bpy.utils.unescape_identifier(mm.group(1)) if mm else ""
            paths, sources = m.setdefault(owner, (set(), []))
            paths.add(dp)
            for var in fc.driver.variables:
                for t in var.targets:
                    idd = t.id
                    if not isinstance(idd, bpy.types.Object):
                        continue
                    bone = getattr(t, "bone_target", "") or ""
                    if var.type == 'SINGLE_PROP':
                        mb = _BONE_PREFIX_RE.match(t.data_path or "")
                        bone = bpy.utils.unescape_identifier(mb.group(1)) if mb else ""
                    sources.append(_target_node(idd, bone) or (idd.name, ""))
    ctx[key] = m
    return m


def _world_spaces(c):
    return (getattr(c, "owner_space", 'WORLD') == 'WORLD'
            and getattr(c, "target_space", 'WORLD') == 'WORLD')


def _bone_length(node):
    ob, item = _node_item(node)
    return item.bone.length if node[1] and item is not None else 0.0


def _live_link(c, n, node):
    """(kind, data) when Blender's result for this constraint can be redone
    exactly from the target's change, else None (re-baked on release)."""
    bbone = getattr(c, "use_bbone_shape", False) and getattr(c, "head_tail", 0.0) > 0.0
    if c.type == 'CHILD_OF':
        
        
        flags = tuple(bool(getattr(c, a, True)) for a in _CHILD_OF_FLAGS)
        return LINK_CHILD_OF, (c.inverse_matrix.copy(), bool(node[1]), flags, _rotation_order(n))
    if c.type == 'COPY_TRANSFORMS':
        mix = getattr(c, "mix_mode", 'REPLACE')
        if _world_spaces(c) and mix in {'REPLACE', 'BEFORE_FULL', 'AFTER_FULL'} and not bbone:
            return LINK_REPLACE, (c.head_tail * _bone_length(n), mix)
        return None
    if c.type == 'COPY_LOCATION':
        if _world_spaces(c) and not bbone:
            use = tuple(bool(getattr(c, a, True)) for a in ("use_x", "use_y", "use_z"))
            inv = tuple(bool(getattr(c, a, False)) for a in ("invert_x", "invert_y", "invert_z"))
            return LINK_LOCATION, (bool(c.use_offset), c.head_tail * _bone_length(n), use, inv)
        return None
    return None


_EULER_ORDERS = {'XYZ', 'XZY', 'YXZ', 'YZX', 'ZXY', 'ZYX'}


def _rotation_order(node):
    """Euler order Blender uses when it splits a target matrix into channels."""
    _ob, item = _node_item(node)
    mode = getattr(item, "rotation_mode", 'XYZ') if item is not None else 'XYZ'
    return mode if mode in _EULER_ORDERS else 'XYZ'


def _node_links(node, ctx):
    """(live links, other dependencies, has constraints that cannot be redone live) of one node.

    live links: [(kind, ((source node, weight), ...), influence spec, data)] in
    evaluation order. influence spec = (value, object name, F-Curve path) so an
    animated influence (parent switching) is followed per frame."""
    ob, item = _node_item(node)
    links, extra = [], []
    unsupported = False
    if item is None:
        return links, extra, unsupported
    driven, driver_sources = _driver_map(ob, ctx).get(node[1] or "", (set(), []))
    extra.extend(driver_sources)
    if node[1]:
        pb = item
        parent = (ob.name, pb.parent.name) if pb.parent is not None else (ob.name, "")
        links.append((LINK_RIGID, ((parent, 1.0),), (1.0, None, None), None))
        owners = ctx.get(("ik", ob.name))
        if owners is None:
            owners = ctx[("ik", ob.name)] = _ik_owners(ob)
        for owner, c in owners.get(pb.name, ()):
            unsupported = True
            if owner.name != pb.name:
                extra.append((ob.name, owner.name))
            for tgt, sub in ((getattr(c, "target", None), getattr(c, "subtarget", "")),
                             (getattr(c, "pole_target", None), getattr(c, "pole_subtarget", ""))):
                n = _target_node(tgt, sub) or _target_node(tgt)
                if n is not None:
                    extra.append(n)
        constraints = pb.constraints
    else:
        if ob.parent is not None:
            if ob.parent_type == 'BONE' and ob.parent_bone:
                n = _target_node(ob.parent, ob.parent_bone)
            elif ob.parent_type in {'OBJECT', 'ARMATURE'}:
                n = (ob.parent.name, "")
            else:
                n = None  
            if n is not None:
                links.append((LINK_RIGID, ((n, 1.0),), (1.0, None, None), None))
            else:
                extra.append((ob.parent.name, ""))
                unsupported = True
        constraints = ob.constraints

    pre = _prefix(node[1])
    for c in constraints:
        if not _constraint_active(c):
            continue
        infl_path = '%sconstraints["%s"].influence' % (pre, bpy.utils.escape_identifier(c.name))
        wspec = (c.influence, ob.name, infl_path)
        infl_driven = infl_path in driven
        if c.type == 'ARMATURE':
            srcs = []
            for t in c.targets:
                n = _target_node(t.target, t.subtarget)
                if n is not None and n[1] and t.weight > 0.0:
                    srcs.append((n, t.weight))
            if (srcs and node[1] and len(srcs) == len(c.targets) and not infl_driven
                    and not c.use_deform_preserve_volume and not c.use_bone_envelopes
                    and not c.use_current_location):
                rest = {}
                for s, _w in srcs:
                    src_ob = bpy.data.objects.get(s[0])
                    rest[s] = src_ob.data.bones[s[1]].matrix_local.inverted_safe()
                links.append((LINK_ARMATURE, tuple(srcs), wspec, rest))
            else:
                extra.extend(s for s, _w in srcs)
                unsupported = True
            continue
        tgt = getattr(c, "target", None)
        n = _target_node(tgt, getattr(c, "subtarget", ""))
        live = _live_link(c, n, node) if n is not None and not infl_driven else None
        if live is not None:
            links.append((live[0], ((n, 1.0),), wspec, live[1]))
        else:
            unsupported = True
            n = n or _target_node(tgt)
            if n is not None:
                extra.append(n)
            pole = _target_node(getattr(c, "pole_target", None), getattr(c, "pole_subtarget", ""))
            if pole is not None:
                extra.append(pole)
    return links, extra, unsupported


def _freeze(prop, value):
    if prop.type == 'POINTER':
        return value.name if isinstance(value, bpy.types.ID) else None
    if prop.type == 'COLLECTION':
        return tuple((getattr(getattr(t, "target", None), "name", None), getattr(t, "subtarget", None),
                      round(getattr(t, "weight", 0.0), 5)) for t in value)
    if isinstance(value, float):
        return round(value, 5)
    if isinstance(value, (bool, int, str)) or value is None:
        return value
    try:
        flat = []
        for x in value:
            flat.extend(x if hasattr(x, "__len__") else (x,))
        return tuple(round(v, 5) if isinstance(v, float) else v for v in flat)
    except TypeError:
        return None


def _constraint_sig(c):
    out = []
    for p in c.bl_rna.properties:
        if p.is_readonly or p.identifier in ("rna_type", "show_expanded", "active"):
            continue
        try:
            out.append((p.identifier, _freeze(p, getattr(c, p.identifier))))
        except Exception:
            pass
    return tuple(out)


def _node_sig(node, ctx):
    """Everything about a node's setup that the live rules depend on."""
    ob, item = _node_item(node)
    if item is None:
        return (node, None)
    if node[1]:
        b = item.bone
        head = (item.parent.name if item.parent else "", b.use_connect, b.use_inherit_rotation,
                b.inherit_scale, b.use_local_location, b.use_relative_parent, item.rotation_mode)
        constraints = item.constraints
    else:
        head = (ob.parent.name if ob.parent else "", ob.parent_type, ob.parent_bone, item.rotation_mode)
        constraints = ob.constraints
    driven = _driver_map(ob, ctx).get(node[1] or "", (set(), []))[0]
    return (node, head, tuple(_constraint_sig(c) for c in constraints), tuple(sorted(driven)))


def _nla_active(ob):
    ad = ob.animation_data
    if ad is None:
        return False
    if ad.action_influence < 1.0 or ad.action_blend_type != 'REPLACE':
        return True
    if ad.use_tweak_mode:
        return True
    return any(not t.mute and len(t.strips) for t in ad.nla_tracks)


def _animated_paths(ob, cache):
    paths = cache.get(ob.name)
    if paths is None:
        fcurves = get_anim_fcurves(ob)
        paths = cache[ob.name] = {fc.data_path for fc in fcurves} if fcurves else set()
    return paths


def _prepare(key, space):
    """Build the dependency graph of a path target (cheap, done at every bake)."""
    ctx = {}
    info = {}
    stack = [key]
    while stack:
        node = stack.pop()
        if node in info:
            continue
        info[node] = _node_links(node, ctx)
        links, extra, _ = info[node]
        for link in links:
            stack.extend(s for s, _sw in link[1])
        stack.extend(extra)

    
    order, seen = [], set()

    def topo(node):
        if node in seen:
            return
        seen.add(node)
        for link in info.get(node, ((), (), False))[0]:
            for s, _sw in link[1]:
                topo(s)
        order.append(node)

    topo(key)
    order.remove(key)

    path_cache = {}
    animated = set()
    for node in order:
        ob = bpy.data.objects.get(node[0])
        if ob is None:
            continue
        pre = _prefix(node[1])
        own = _animated_paths(ob, path_cache)
        if any(pre + p in own for p in TRANSFORM_PROPS):
            animated.add(node)

    target_ob = bpy.data.objects.get(key[0])
    space.deps = set(info) - {key}
    space.dep_objects = {n[0] for n in info}
    space.order = order
    space.links = {n: info[n][0] for n in order + [key]}
    space.blocked = {n for n in order if info[n][2]}
    space.animated = animated
    space.constrained = {n for n in order + [key]
                         if any(link[0] != LINK_RIGID for link in info[n][0])}
    space.approx = info[key][2] or (target_ob is not None and _nla_active(target_ob))
    space.has_constraints = info[key][2] or key in space.constrained

    sig = (getattr(_settings(), "mpp_point", 'HEADS'),) + tuple(_node_sig(n, ctx) for n in sorted(info))
    if sig != space.sig:
        space.sig = sig
        space.validated = False
        space.no_live = set()
        space.own_mode = 'FREEZE' if space.has_constraints else 'EXACT'






def _constraint_target_objects(constraints, out):
    for c in constraints:
        t = getattr(c, "target", None)
        if isinstance(t, bpy.types.Object):
            out.add(t.name)
        for sub in getattr(c, "targets", ()) or ():  
            t = getattr(sub, "target", None)
            if isinstance(t, bpy.types.Object):
                out.add(t.name)


def _protected_objects(keep):
    """Targets, their parents and every object their constraints point at.
    Their modifiers are left alone so constraints to deformed meshes stay correct."""
    out = set(keep)
    for name in keep:
        ob = bpy.data.objects.get(name)
        if ob is None:
            continue
        _constraint_target_objects(ob.constraints, out)
        if ob.pose is not None:
            for pb in ob.pose.bones:
                _constraint_target_objects(pb.constraints, out)
        parent = ob.parent
        while parent is not None:
            out.add(parent.name)
            parent = parent.parent
    return out


def _mute_heavy(keep):
    """Turn off viewport modifiers (subdivision, armature deform, geometry
    nodes ...) of every other object while baking. Turning modifiers off
    instead of hiding the objects keeps Blender's subdivision caches alive,
    so switching back costs one normal frame instead of a full rebuild."""
    protected = _protected_objects(keep)
    muted = []
    for ob in bpy.context.scene.objects:
        if ob.type not in HEAVY_TYPES or ob.name in protected or PROP_TARGET in ob:
            continue
        for mod in getattr(ob, "modifiers", ()):
            if not mod.show_viewport:
                continue
            try:
                mod.show_viewport = False
                muted.append(mod)
            except Exception:  
                pass
    return muted


def _unmute_heavy(muted):
    for mod in muted:
        try:
            mod.show_viewport = True
        except Exception:
            pass


def _read_tf(x):
    return (tuple(x.location), tuple(x.rotation_euler), tuple(x.rotation_quaternion),
            tuple(x.rotation_axis_angle), tuple(x.scale))


def _snapshot(names):
    snap = []
    for name in names:
        ob = bpy.data.objects.get(name)
        if ob is None:
            continue
        snap.append((ob, _read_tf(ob)))
        if ob.pose is not None:
            snap.extend((pb, _read_tf(pb)) for pb in ob.pose.bones)
    return snap


def _restore_snapshot(snap):
    """Put back un-keyed pose changes that frame_set() would otherwise discard."""
    for x, (loc, eul, quat, aa, scl) in snap:
        try:
            if tuple(x.location) != loc:
                x.location = loc
            if tuple(x.rotation_euler) != eul:
                x.rotation_euler = eul
            if tuple(x.rotation_quaternion) != quat:
                x.rotation_quaternion = quat
            if tuple(x.rotation_axis_angle) != aa:
                x.rotation_axis_angle = aa
            if tuple(x.scale) != scl:
                x.scale = scl
        except Exception:
            pass


def _node_world(depsgraph, node, cache, with_item=False):
    """(world matrix, basis matrix[, evaluated bone/object]) of a node in the evaluated scene."""
    none = (None, None, None) if with_item else (None, None)
    ob_eval = cache.get(node[0])
    if ob_eval is None:
        ob = bpy.data.objects.get(node[0])
        if ob is None:
            return none
        ob_eval = cache[node[0]] = ob.evaluated_get(depsgraph)
    if not ob_eval.is_evaluated:
        return none  
    if node[1]:
        pose = ob_eval.pose
        x = pose.bones.get(node[1]) if pose is not None else None
        if x is None:
            return none
        F = ob_eval.matrix_world @ x.matrix
    else:
        x = ob_eval
        F = ob_eval.matrix_world.copy()
    if with_item:
        return F, x.matrix_basis.copy(), x
    return F, x.matrix_basis.copy()


def _read_chan(x):
    return {"location": tuple(x.location), "rotation_euler": tuple(x.rotation_euler),
            "rotation_quaternion": tuple(x.rotation_quaternion),
            "rotation_axis_angle": tuple(x.rotation_axis_angle), "scale": tuple(x.scale)}


def _pre_world(depsgraph, node, x, cache):
    """World matrix of a node before its own constraints (after parenting)."""
    ob_eval = cache.get(node[0])
    if node[1]:
        pre = ob_eval.convert_space(pose_bone=x, matrix=x.matrix_basis, from_space='LOCAL', to_space='POSE')
        return ob_eval.matrix_world @ pre
    par = ob_eval.parent
    if par is None:
        return ob_eval.matrix_basis.copy()
    par_eval = cache.get(par.name) or par.evaluated_get(depsgraph)
    if ob_eval.parent_type == 'BONE' and ob_eval.parent_bone:
        pb = par_eval.pose.bones.get(ob_eval.parent_bone)
        pm = par_eval.matrix_world @ pb.matrix @ Matrix.Translation((0.0, pb.bone.length, 0.0))
    else:
        pm = par_eval.matrix_world
    return pm @ ob_eval.matrix_parent_inverse @ ob_eval.matrix_basis


def _has_own_constraints(node):
    _ob, item = _node_item(node)
    if item is None:
        return False
    return any(_constraint_active(c) for c in item.constraints)


def _location_space(depsgraph, key, x, cache, space, full, pre):
    """World matrix of the target before its own constraints (after parenting).

    ``result @ basis^-1`` maps the location channels to world space. Without
    own constraints that is the regular parent space. With constraints that
    only turn the target (Track To, Damped Track, Copy Rotation ... very
    common on cameras) the evaluated matrix would add that rotation, so the
    matrix before the constraints is used instead."""
    if key in space.constrained:
        return pre
    if not _has_own_constraints(key):
        return full
    try:
        if not key[1]:
            ob_eval = cache.get(key[0])
            if ob_eval is not None and ob_eval.parent is not None \
                    and ob_eval.parent_type not in {'OBJECT', 'ARMATURE', 'BONE'}:
                return full  
        return _pre_world(depsgraph, key, x, cache)
    except Exception:
        return full


def _head_from(space, key, f, loc):
    """World position of the target's head/origin at frame f for location ``loc``.

    Baked position + location change through the location space: exact when
    the target has no constraints, and when its constraints only turn it."""
    L = space.L.get(f)
    F = space.F.get(key, {}).get(f)
    B = space.B.get(key, {}).get(f)
    if L is None or F is None or B is None:
        P = space.P.get(f)
        return P @ loc if P is not None else None
    return F.translation + L.to_3x3() @ (loc - B.translation)


def location_matrix(key, frame):
    """3x3 matrix: change of the location channels -> world-space move (None if not baked)."""
    space = _spaces.get(key)
    if space is None:
        return None
    m = space.L.get(frame)
    if m is None:
        m = space.P.get(frame)
    return m.to_3x3() if m is not None else None


def _write_tf(x, values):
    loc, eul, quat, aa, scl = values
    x.location = loc
    x.rotation_euler = eul
    x.rotation_quaternion = quat
    x.rotation_axis_angle = aa
    x.scale = scl


def _perturb(x, length):
    """Move, turn and scale a bone/object by a clearly visible amount."""
    x.location = Vector(x.location) + Vector((0.23, -0.17, 0.11)) * max(length, 0.1)
    mode = x.rotation_mode
    if mode == 'QUATERNION':
        x.rotation_quaternion = Quaternion(x.rotation_quaternion) @ Quaternion(Vector((0.3, 0.5, 0.2)).normalized(), 0.4)
    elif mode == 'AXIS_ANGLE':
        aa = list(x.rotation_axis_angle)
        if Vector(aa[1:]).length < 1e-6:
            aa[1:] = [0.0, 1.0, 0.0]
        aa[0] += 0.4
        x.rotation_axis_angle = aa
    else:
        e = x.rotation_euler
        x.rotation_euler = (e[0] + 0.3, e[1] - 0.2, e[2] + 0.25)
    s = x.scale
    x.scale = (s[0] * 1.12, s[1] * 0.93, s[2] * 1.07)


class _FixedBasis:
    """A basis that returns one evaluated matrix (used by the probe)."""

    def __init__(self, m):
        self.m = m

    def matrix(self, f):
        return self.m

    def location(self, f):
        return self.m.translation


def _tracked_points(key):
    """Points of the target the path shows (head or tail)."""
    if key[1] and getattr(_settings(), "mpp_point", 'HEADS') == 'TAILS':
        return (Vector((0.0, _bone_length(key), 0.0)),)
    return (Vector((0.0, 0.0, 0.0)),)


def _validate(context, keys, f):
    """Nudge every followed bone (and each target itself) once and compare
    Blender's real result with what the live solver predicts. Any mismatch
    turns live following off for that bone: the follower keeps its correct
    path while you drag and is re-baked on release."""
    tests = {}
    for key in keys:
        space = _spaces[key]
        space.validated = True
        space.no_live = set()
        for node in space.animated - space.blocked:
            tests.setdefault(node, []).append(key)
        if space.has_constraints:
            tests.setdefault(key, []).append(key)   
    if not tests:
        return
    fcache = {}
    for node, followers in tests.items():
        _ob, x = _node_item(node)
        if x is None:
            continue
        saved = _read_tf(x)
        try:
            _perturb(x, _bone_length(node) or 1.0)
            context.view_layer.update()
            depsgraph = context.evaluated_depsgraph_get()
            cache = {}
            _fx, bx = _node_world(depsgraph, node, cache)
            for key in followers:
                space = _spaces[key]
                if node == key:
                    space.own_mode = _probe_own(space, key, bx, f, depsgraph, cache, fcache)
                    continue
                ok = bx is not None and _probe_ok(space, key, node, bx, f, depsgraph, cache, fcache)
                if not ok:
                    space.no_live.add(node)
                    space.dirty.discard(node)
        except Exception:
            traceback.print_exc()
            for key in followers:
                _spaces[key].no_live.add(node)
        finally:
            _write_tf(x, saved)
    context.view_layer.update()


def _close(space, key, pred_F, true_F):
    if pred_F is None or true_F is None:
        return False
    tol = 1e-4 * (1.0 + true_F.translation.length)
    return all(((pred_F @ p) - (true_F @ p)).length <= tol for p in _tracked_points(key))


def _probe_own(space, key, basis_after, f, depsgraph, cache, fcache):
    """How to show edits of a constrained target's own keys live."""
    if basis_after is None:
        return 'FREEZE'
    true_F, _b = _node_world(depsgraph, key, cache)
    if key in space.constrained and _close(space, key, _solve(space, key, f, {}, fcache, _FixedBasis(basis_after)), true_F):
        return 'SOLVER'
    if key[1] and getattr(_settings(), "mpp_point", 'HEADS') == 'TAILS':
        P = space.P.get(f)
        if P is not None and _close(space, key, P @ basis_after, true_F):
            return 'SIMPLE'
        return 'FREEZE'
    
    pred = _head_from(space, key, f, basis_after.translation)
    if pred is not None and true_F is not None:
        if (pred - true_F.translation).length <= 1e-4 * (1.0 + true_F.translation.length):
            return 'SIMPLE'
    return 'FREEZE'


def _probe_ok(space, key, node, basis_after, f, depsgraph, cache, fcache):
    """Does the live solver reproduce Blender when ``node`` gets ``basis_after``?"""
    true_F, true_basis = _node_world(depsgraph, key, cache)
    if true_F is None:
        return False
    news = {}
    nb = _FixedBasis(basis_after)
    for n in space.order:
        if n in space.blocked:
            continue
        m = _solve(space, n, f, news, fcache, nb if n == node else None)
        if m is not None:
            news[n] = m
    if node not in news:
        return False
    pred_F = _solve(space, key, f, news, fcache, _FixedBasis(true_basis))
    return _close(space, key, pred_F, true_F)


def bake(frames_map, skip_heavy=True, preserve_pose=False):
    """Evaluate the scene at the needed frames and store parent spaces
    (plus the world matrices of the bones/objects each path follows).

    frames_map: {(object name, bone name or ""): iterable of frames}
    """
    by_frame = {}
    for key, frames in frames_map.items():
        space = _spaces.get(key)
        if space is None:
            space = _spaces[key] = _Space()
        _prepare(key, space)
        for f in frames:
            by_frame.setdefault(int(f), []).append(key)
    if not by_frame:
        return 0

    context = bpy.context
    scene = context.scene
    f0, sub0 = scene.frame_current, scene.frame_subframe
    keep = set()
    for key in frames_map:
        keep |= _spaces[key].dep_objects
    snap = _snapshot({k[0] for k in frames_map}) if preserve_pose else None
    muted = _mute_heavy(keep) if skip_heavy else []
    try:
        for f in sorted(by_frame):
            scene.frame_set(f)
            depsgraph = context.evaluated_depsgraph_get()
            cache = {}
            for key in by_frame[f]:
                space = _spaces[key]
                full, basis, x = _node_world(depsgraph, key, cache, with_item=True)
                if full is None:
                    continue
                binv = basis.inverted_safe()
                space.P[f] = full @ binv
                space.F.setdefault(key, {})[f] = full
                space.chan.setdefault(key, {})[f] = _read_chan(x)
                space.B.setdefault(key, {})[f] = basis
                pre = _pre_world(depsgraph, key, x, cache) if key in space.constrained else full
                space.O.setdefault(key, {})[f] = pre
                space.PO.setdefault(key, {})[f] = pre @ binv
                space.L[f] = _location_space(depsgraph, key, x, cache, space, full, pre) @ binv
                space.fresh.add(f)
                for node in space.order:
                    fn, bn, xn = _node_world(depsgraph, node, cache, with_item=True)
                    if fn is None:
                        continue
                    space.F.setdefault(node, {})[f] = fn
                    space.Finv.setdefault(node, {})[f] = fn.inverted_safe()
                    pre = _pre_world(depsgraph, node, xn, cache) if node in space.constrained else fn
                    if node in space.constrained:
                        space.O.setdefault(node, {})[f] = pre
                    if node in space.animated:
                        space.PO.setdefault(node, {})[f] = pre @ bn.inverted_safe()
                        space.chan.setdefault(node, {})[f] = _read_chan(xn)
                        space.B.setdefault(node, {})[f] = bn
        
        f_last = max(by_frame)
        unchecked = [k for k in by_frame[f_last] if not _spaces[k].validated]
        if unchecked:
            _validate(context, unchecked, f_last)
    finally:
        _unmute_heavy(muted)
        scene.frame_set(f0, subframe=sub0)
        if snap:
            _restore_snapshot(snap)
    for key in frames_map:
        space = _spaces[key]
        if space.P and all(f in space.fresh for f in space.P):
            space.dirty.clear()  
            space.own_dirty = False
    return len(by_frame)






def _channel(fcurves, path, index):
    if not fcurves:
        return None
    fc = fcurves.find(path, index=index)
    if fc is None or fc.mute or fc.is_empty:
        return None
    return fc


def _channels(fcurves, path, static):
    prop = path.rsplit(".", 1)[-1]
    return [(_channel(fcurves, path, i), v, prop, i) for i, v in enumerate(static)]


def _eval(chs, f, baked=None):
    """F-Curve value, else the value Blender evaluated at that frame (drivers,
    NLA ...), else the current value."""
    b = baked.get(f) if baked else None
    return [fc.evaluate(f) if fc is not None else (b[prop][i] if b is not None else v)
            for fc, v, prop, i in chs]


class _Basis:
    """Local loc/rot/scale of a bone or object evaluated from its F-Curves."""

    def __init__(self, node, space=None):
        ob, item = _node_item(node)
        self.ok = item is not None
        if not self.ok:
            return
        self.baked = space.chan.get(node) if space is not None else None
        self.memo = {}
        fcurves = get_anim_fcurves(ob)
        pre = _prefix(node[1])
        self.mode = mode = item.rotation_mode
        self.loc = _channels(fcurves, pre + "location", tuple(item.location))
        if mode == 'QUATERNION':
            self.rot = _channels(fcurves, pre + "rotation_quaternion", tuple(item.rotation_quaternion))
        elif mode == 'AXIS_ANGLE':
            self.rot = _channels(fcurves, pre + "rotation_axis_angle", tuple(item.rotation_axis_angle))
        else:
            self.rot = _channels(fcurves, pre + "rotation_euler", tuple(item.rotation_euler))
        self.scl = _channels(fcurves, pre + "scale", tuple(item.scale))
        self.is_object = not node[1]
        self.length = 0.0 if self.is_object else item.bone.length
        
        
        self.connected = not self.is_object and bool(getattr(item.bone, "use_connect", False))
        
        keyed = any(fc is not None for fc, _v, _p, _i in self.loc + self.rot + self.scl)
        self.fixed = space.B.get(node) if (space is not None and not keyed) else None
        if self.is_object:
            self.dloc = Vector(ob.delta_location)
            self.dscl = Vector(ob.delta_scale)
            if mode == 'QUATERNION':
                self.drot = ob.delta_rotation_quaternion.to_matrix()
            elif mode == 'AXIS_ANGLE':
                self.drot = None
            else:
                self.drot = Euler(ob.delta_rotation_euler, mode).to_matrix()

    def location(self, f):
        if self.fixed is not None and f in self.fixed:
            return self.fixed[f].translation
        if self.connected:
            return Vector((0.0, 0.0, 0.0))
        loc = Vector(_eval(self.loc, f, self.baked))
        if self.is_object:
            loc += self.dloc
        return loc

    def rotation(self, f):
        rv = _eval(self.rot, f, self.baked)
        if self.mode == 'QUATERNION':
            rot = Quaternion(rv)
            if rot.magnitude < 1e-8:
                return Quaternion()
            rot.normalize()
            return rot
        if self.mode == 'AXIS_ANGLE':
            axis = Vector(rv[1:])
            return Quaternion(axis.normalized(), rv[0]) if axis.length > 1e-8 else Quaternion()
        return Euler(rv, self.mode)

    def matrix(self, f):
        m = self.memo.get(f)
        if m is not None:
            return m
        if self.fixed is not None and f in self.fixed:
            m = self.memo[f] = self.fixed[f]
            return m
        m = self.memo[f] = self._matrix(f)
        return m

    def _matrix(self, f):
        rot = self.rotation(f)
        scl = Vector(_eval(self.scl, f, self.baked))
        if self.is_object:
            if self.drot is not None:
                rot = self.drot @ rot.to_matrix()
            scl = Vector((scl.x * self.dscl.x, scl.y * self.dscl.y, scl.z * self.dscl.z))
        return Matrix.LocRotScale(self.location(f), rot, scl)


def _weight(wspec, f, fcache):
    """Constraint influence at frame f (follows an animated influence)."""
    value, obj_name, path = wspec
    if path is None:
        return value
    ck = (obj_name, path)
    fc = fcache.get(ck, False)
    if fc is False:
        ob = bpy.data.objects.get(obj_name)
        fcurves = get_anim_fcurves(ob) if ob is not None else None
        fc = fcache[ck] = _channel(fcurves, path, 0) if fcurves else None
    if fc is None:
        return value
    return min(1.0, max(0.0, fc.evaluate(f)))


def _polar(m3):
    """M = U @ P with U orthogonal and P symmetric (like mat3_polar_decompose)."""
    a = np.array(m3, dtype=float)
    W, S, Vt = np.linalg.svd(a)
    U = W @ Vt
    P = Vt.T @ np.diag(S) @ Vt
    if np.linalg.det(U) < 0.0:  
        U, P = -U, -P
    return U, P


def _interp(A, B, w):
    """Blender's constraint influence: interp_m4_m4m4 between two world matrices."""
    a3, b3 = A.to_3x3(), B.to_3x3()
    plain = (a3.is_orthogonal_axis_vectors and b3.is_orthogonal_axis_vectors
             and a3.determinant() > 0.0 and b3.determinant() > 0.0)
    if plain or np is None:  
        la, ra, sa = A.decompose()
        lb, rb, sb = B.decompose()
        return Matrix.LocRotScale(la.lerp(lb, w), ra.slerp(rb, w), sa.lerp(sb, w))
    UA, PA = _polar(A.to_3x3())
    UB, PB = _polar(B.to_3x3())
    q = Matrix(UA.tolist()).to_quaternion().slerp(Matrix(UB.tolist()).to_quaternion(), w)
    R = np.array(q.to_matrix()) @ (PA + (PB - PA) * w)
    M = Matrix(R.tolist()).to_4x4()
    M.translation = A.translation.lerp(B.translation, w)
    return M


def _world(space, node, f, news):
    m = news.get(node)
    return m if m is not None else space.F.get(node, {}).get(f)


def _solve_constraint(space, node, link, cur, f, news):
    """Result of one constraint for owner matrix ``cur`` (world), like Blender."""
    kind, srcs, _wspec, data = link
    if kind == LINK_CHILD_OF:
        inverse, is_bone, flags, order = data
        T = _world(space, srcs[0][0], f, news)
        if T is None:
            return None
        if not all(flags):  
            loc = T.translation.copy()
            eul = T.to_3x3().normalized().to_euler(order)
            scl = T.to_scale()
            for i in range(3):
                if not flags[i]:
                    loc[i] = 0.0
                if not flags[3 + i]:
                    eul[i] = 0.0
                if not flags[6 + i]:
                    scl[i] = 1.0
            T = Matrix.LocRotScale(loc, eul, scl)
        if is_bone:  
            W = _world(space, (node[0], ""), f, news)
            if W is None:
                return None
            sol = T @ inverse @ W.inverted_safe() @ cur
        else:
            sol = T @ inverse @ cur
        for i in range(3):  
            if not flags[i]:
                sol[i][3] = cur[i][3]
        return sol
    if kind == LINK_REPLACE:
        along, mix = data
        T = _world(space, srcs[0][0], f, news)
        if T is None:
            return None
        if along:
            T = T @ Matrix.Translation((0.0, along, 0.0))
        if mix == 'BEFORE_FULL':
            return T @ cur
        if mix == 'AFTER_FULL':
            return cur @ T
        return T.copy()
    if kind == LINK_LOCATION:
        use_offset, along, use, invert = data
        T = _world(space, srcs[0][0], f, news)
        if T is None:
            return None
        sol = cur.copy()
        t = T @ Vector((0.0, along, 0.0))
        for i in range(3):
            if use[i]:
                v = -t[i] if invert[i] else t[i]
                sol[i][3] = v + (cur[i][3] if use_offset else 0.0)
        return sol
    if kind == LINK_ARMATURE:  
        acc = Matrix(((0.0,) * 4,) * 4)
        total = 0.0
        for s, sw in srcs:
            T = _world(space, s, f, news)
            Wt = _world(space, (s[0], ""), f, news)
            if T is None or Wt is None:
                return None
            acc += (T @ data[s] @ Wt.inverted_safe()) * sw
            total += sw
        if total <= 0.0:
            return None
        return (acc * (1.0 / total)) @ cur
    return None


def _solve(space, node, f, news, fcache, basis):
    """New world matrix of ``node`` at frame f.

    news:  new world matrices of the nodes already solved (sources).
    basis: own channels when they may have changed (None = baked ones).
    Returns None when nothing that moves this node changed."""
    links = space.links.get(node, ())
    cons = links
    Dpar = None
    if links and links[0][0] == LINK_RIGID:   
        par = links[0][1][0][0]
        cons = links[1:]
        new_par = news.get(par)
        if new_par is not None:
            Finv = space.Finv.get(par, {}).get(f)
            if Finv is None:
                return None
            Dpar = new_par @ Finv
    if basis is None and Dpar is None and not any(s in news for link in cons for s, _w in link[1]):
        return None
    if basis is not None:
        PO = space.PO.get(node, {}).get(f)
        if PO is None:
            return None
        cur = PO @ basis.matrix(f)
    else:
        cur = space.O.get(node, {}).get(f) if node in space.constrained else space.F.get(node, {}).get(f)
        if cur is None:
            return None
    if Dpar is not None:
        cur = Dpar @ cur
    for link in cons:
        sol = _solve_constraint(space, node, link, cur, f, news)
        if sol is None:
            continue
        w = _weight(link[2], f, fcache)
        if w >= 0.9999:
            cur = sol
        elif w > 0.0001:
            cur = _interp(cur, sol, w)
    return cur


class _Live:
    """New world matrices of the target, computed without changing frames.

    Bones the path follows (parent, Child Of, Copy Transforms, Copy Location,
    Armature) are solved the way Blender does, from their own F-Curves and
    the matrices baked for each frame. Only rules that were checked against
    Blender for this rig are used."""

    def __init__(self, key, space):
        self.key = key
        self.space = space
        self.fcache = {}
        dirty = (space.dirty - space.no_live) - space.blocked
        affected = set(dirty)
        self.order = []
        for node in space.order:
            if node in space.blocked:
                continue
            if node in affected or any(s in affected for link in space.links.get(node, ())
                                       for s, _sw in link[1]):
                affected.add(node)
                self.order.append(node)
        self.basis = {}
        for node in dirty:
            b = _pass_basis.get(node)
            if b is None:
                b = _pass_basis[node] = _Basis(node, space)
            if b.ok:
                self.basis[node] = b

    def final(self, f, key_basis):
        news = {}
        for node in self.order:
            m = _solve(self.space, node, f, news, self.fcache, self.basis.get(node))
            if m is not None:
                news[node] = m
        return _solve(self.space, self.key, f, news, self.fcache, key_basis)


def compute_positions(key, frames, point='HEADS', allow_freeze=False):
    """World positions of a bone head/tail (or object origin).

    Returns None (keep what is shown) when the target's own keys changed in a
    way that cannot be shown exactly before the re-bake (``allow_freeze``)."""
    space = _spaces.get(key)
    if space is None:
        return [], []
    basis = _Basis(key, space)
    if not basis.ok:
        return [], []
    tails = point == 'TAILS' and bool(key[1])
    local = Vector((0.0, basis.length if tails else 0.0, 0.0))
    upstream = (space.dirty - space.no_live) - space.blocked
    own = space.own_dirty
    if allow_freeze and own and space.own_mode == 'FREEZE':
        return None
    live = None
    if upstream or (own and space.own_mode == 'SOLVER'):
        live = _Live(key, space)

    out_frames, out_pos = [], []
    P_get = space.P.get
    for f in frames:
        P = P_get(f)
        if P is None:
            continue
        M = live.final(f, basis) if live is not None else None
        if M is None:
            pos = P @ basis.matrix(f) @ local if tails else _head_from(space, key, f, basis.location(f))
        else:
            pos = M @ local
        out_frames.append(f)
        out_pos.append(pos)
    return out_frames, out_pos


def _key_frames(key, point=None):
    """Frames shown as keyframes on a path, like Blender's own motion paths:
    every key of the bone's channels (or the object's), or of the whole
    action with "All Action Keyframes"."""
    ob = bpy.data.objects.get(key[0])
    if ob is None:
        return set()
    fcurves = get_anim_fcurves(ob)
    if not fcurves:
        return set()
    every = getattr(_settings(), "mpp_keys_all", False)
    bone_pre = _prefix(key[1])[:-1] if key[1] else None   
    out = set()
    for fc in fcurves:
        if not every:
            dp = fc.data_path
            if bone_pre is not None:
                if not dp.startswith(bone_pre):
                    continue
            elif dp.startswith("pose.bones["):
                continue
        n = len(fc.keyframe_points)
        if not n:
            continue
        co = array('f', bytes(8 * n))
        fc.keyframe_points.foreach_get("co", co)
        out.update(int(round(co[j])) for j in range(0, 2 * n, 2))
    return out


def key_points(obj, bone_name, frames, bake_stale=True, bake_missing=True, preserve_pose=True):
    """Used by the keyframe handle tool.

    Returns {frame: (world head position, 3x3 location -> world matrix)}.
    Frames that are not baked are skipped unless baking is allowed:
    bake_stale  - re-bake frames whose parent space may have changed
    bake_missing - bake frames that were never baked
    Never bake while the user is dragging (frame changes would fight the drag)."""
    key = (obj.name, bone_name or "")
    frames = sorted({int(f) for f in frames})
    space = _spaces.get(key)
    if space is None:
        todo = frames if (bake_missing or bake_stale) else []
    elif bake_stale:
        todo = [f for f in frames if f not in space.fresh]
    elif bake_missing:
        todo = [f for f in frames if f not in space.P]
    else:
        todo = []
    if todo:
        bake({key: todo}, skip_heavy=getattr(_settings(), "mpp_skip_meshes", True),
             preserve_pose=preserve_pose)
        space = _spaces.get(key)
    if space is None or not frames:
        return {}
    _pass_basis.clear()
    try:
        fr, pos = compute_positions(key, frames, 'HEADS')
    finally:
        _pass_basis.clear()
    out = {}
    for f, p in zip(fr, pos):
        if p is None:
            continue
        m = space.L.get(f)
        if m is None:
            m = space.P.get(f)
        out[f] = (p, m.to_3x3() if m is not None else Matrix.Identity(3))
    return out


def head_positions(obj, requests, allow_bake=True):
    """Used by the direct manipulation tool.

    requests: {bone name or "": frames}. Returns {bone name or "": {frame: Vector}}.
    Frames that were never baked are always baked; stale frames only when
    ``allow_bake`` is True (the user is not dragging).
    """
    need = {}
    for bone_name, frames in requests.items():
        key = (obj.name, bone_name or "")
        space = _spaces.get(key)
        if space is None:
            todo = list(frames)
        elif allow_bake:
            todo = [f for f in frames if f not in space.fresh]
        else:
            todo = [f for f in frames if f not in space.P]
        if todo:
            need[key] = todo
    if need:
        bake(need, skip_heavy=getattr(_settings(), "mpp_skip_meshes", True))
    out = {}
    _pass_basis.clear()
    for bone_name, frames in requests.items():
        fr, pos = compute_positions((obj.name, bone_name or ""), sorted(frames), 'HEADS')
        out[bone_name] = dict(zip(fr, pos))
    _pass_basis.clear()
    return out






class MPP_PathItem(bpy.types.PropertyGroup):
    """One motion path. Its positions are also kept as custom data on the item
    so the path shows right away when the file is opened again."""
    target: bpy.props.PointerProperty(type=bpy.types.Object)
    bone: bpy.props.StringProperty()


def path_objects(scene=None):
    """All motion path items of the scene."""
    scene = scene or bpy.context.scene
    coll = getattr(scene, "mpp_paths", None)
    return list(coll) if coll is not None else []


def has_paths(scene=None):
    return bool(path_objects(scene))


def path_key(item):
    tgt = item.target
    if tgt is None:
        return None
    return (tgt.name, item.bone or "")


def find_path(obj, bone_name="", scene=None):
    for item in path_objects(scene):
        if item.target == obj and (item.bone or "") == (bone_name or ""):
            return item
    return None


def ensure_path(scene, obj, bone_name=""):
    item = find_path(obj, bone_name, scene)
    if item is None:
        item = scene.mpp_paths.add()
        item.target = obj
        item.bone = bone_name or ""
        item.name = obj.name + (" : " + bone_name if bone_name else "")
    return item


def _store(item, frames, positions):
    item["frames"] = list(frames)
    item["positions"] = [c for p in positions for c in (p[0], p[1], p[2])]


def _cached(item, key, point='HEADS'):
    """Runtime positions of a path, read back from the scene after loading a file."""
    info = _paths.get(key)
    if info is None and "positions" in item:
        flat = list(item["positions"])
        frames = list(item.get("frames", ()))
        pos = [Vector(flat[i:i + 3]) for i in range(0, len(flat) - 2, 3)]
        info = _paths[key] = {"frames": frames[:len(pos)], "positions": pos,
                              "keys": _key_frames(key)}
    return info


def remove_path(scene, item):
    key = path_key(item)
    if key is not None:
        _paths.pop(key, None)
    coll = scene.mpp_paths
    for i, it in enumerate(coll):
        if it == item:
            coll.remove(i)
            break


def _path_items(keys=None):
    scene = bpy.context.scene
    items = []
    for item in path_objects(scene):
        key = path_key(item)
        if key is None or scene.objects.get(key[0]) is None:
            continue
        if keys is not None and key not in keys:
            continue
        items.append((item, key))
    return items


def update_paths(keys=None, refine=False, bake_missing=True, preserve_pose=False):
    """Recompute motion paths.

    refine=False: fast, F-Curves only (bakes frames never baked if bake_missing).
    refine=True : re-bake stale frames first (accurate, slower).
    """
    items = _path_items(keys)
    if not items:
        return 0
    wm = _settings()
    point = getattr(wm, "mpp_point", 'HEADS')
    frames_of = {key: path_frames(key=key) for _item, key in items}

    need = {}
    for _item, key in items:
        space = _spaces.get(key)
        frames = frames_of[key]
        if refine:
            todo = [f for f in frames if space is None or f not in space.fresh]
        elif bake_missing:
            todo = [f for f in frames if space is None or f not in space.P]
        else:
            todo = []
        if todo:
            need.setdefault(key, set()).update(todo)
    if need:
        bake(need, skip_heavy=getattr(wm, "mpp_skip_meshes", True), preserve_pose=preserve_pose)

    _pass_basis.clear()
    for item, key in items:
        if _spaces.get(key) is None:
            continue  
        res = compute_positions(key, frames_of[key], point, allow_freeze=not refine)
        if res is None:
            continue  
        fr, pos = res
        _store(item, fr, pos)
        _paths[key] = {"frames": fr, "positions": pos, "keys": _key_frames(key)}
    _pass_basis.clear()
    tag_redraw()
    return len(items)


def refresh_keys(key):
    """Re-read which frames of a path are keyframes (after keys were added)."""
    info = _paths.get(key)
    if info is not None:
        info["keys"] = _key_frames(key)
        tag_redraw()


def needs_refine(frames=None):
    for _item, key in _path_items():
        space = _spaces.get(key)
        if space is None:
            return True
        fresh = space.fresh
        if any(f not in fresh for f in (frames if frames is not None else path_frames(key=key))):
            return True
    return False


def get_path_points(obj, bone_name=""):
    """[(frame, world position)] of the motion path of a bone/object (creates nothing)."""
    item = find_path(obj, bone_name)
    if item is None:
        return []
    key = path_key(item)
    info = _cached(item, key, getattr(_settings(), "mpp_point", 'HEADS'))
    if info is None:
        update_paths(keys={key})
        info = _paths.get(key)
    if info is None:
        return []
    return list(zip(info["frames"], info["positions"]))


def selection_targets(context, kind='AUTO'):
    """[(object, bone name or "")] from the selection.
    kind: 'AUTO' (bones in Pose Mode, objects otherwise), 'BONE' or 'OBJECT'."""
    ob = context.active_object
    if ob is None:
        return []
    if kind == 'BONE' and ob.mode != 'POSE':
        return []
    if kind == 'BONE' or (kind == 'AUTO' and ob.mode == 'POSE'):
        bones = list(context.selected_pose_bones or [])
        if not bones and context.active_pose_bone is not None:
            bones = [context.active_pose_bone]
        return [(pb.id_data, pb.name) for pb in bones]
    objs = [o for o in (context.selected_objects or []) if PROP_TARGET not in o]
    if not objs and PROP_TARGET not in ob:
        objs = [ob]
    return [(o, "") for o in objs]


def create_paths(context, targets):
    scene = context.scene
    keys = set()
    for obj, bone_name in targets:
        ensure_path(scene, obj, bone_name)
        keys.add((obj.name, bone_name or ""))
    poll_changes({obj.name for obj, _ in targets}, force=True)
    update_paths(keys=keys, refine=True, preserve_pose=True)
    
    poll_changes(tracked_objects(keys), force=True)
    return keys


def clear_paths(context, only_selected=False):
    scene = context.scene
    if only_selected:
        wanted = {(o.name, b) for o, b in selection_targets(context)}
        doomed = [it for it in path_objects(scene) if path_key(it) in wanted]
    else:
        doomed = path_objects(scene)
    for item in reversed(doomed):
        remove_path(scene, item)
    if not only_selected:
        _paths.clear()
    tag_redraw()
    return len(doomed)


LEGACY_COLLECTION = "MPP Motion Paths"
LEGACY_MATERIAL = "MPP Motion Path"


def migrate_legacy():
    """Version 2.2 / 2.3 used curve objects in an "MPP Motion Paths" collection.
    Move those paths into the scene list and delete the objects and collection."""
    try:
        found = [ob for ob in bpy.data.objects
                 if ob.type == 'CURVE' and ob.library is None and PROP_TARGET in ob]
    except Exception:
        return 0
    col = bpy.data.collections.get(LEGACY_COLLECTION)
    if not found and col is None:
        return 0
    for ob in found:
        tgt = ob.get(PROP_TARGET)
        bone = ob.get(PROP_BONE, "") or ""
        if isinstance(tgt, bpy.types.Object):
            for sc in (ob.users_scene or (bpy.context.scene,)):
                if hasattr(sc, "mpp_paths"):
                    ensure_path(sc, tgt, bone)
        data = ob.data
        bpy.data.objects.remove(ob, do_unlink=True)
        if data is not None and data.users == 0:
            bpy.data.curves.remove(data)
    if col is not None and col.library is None and not col.all_objects and not col.children:
        bpy.data.collections.remove(col)
    mat = bpy.data.materials.get(LEGACY_MATERIAL)
    if mat is not None and mat.library is None and mat.users == 0:
        bpy.data.materials.remove(mat)
    return max(len(found), 1)


def _migrate_timer():
    try:
        with _ctx_override():
            if migrate_legacy():
                tag_redraw()
    except Exception:
        traceback.print_exc()
    return None






def _tick():
    try:
        wm = bpy.context.window_manager
    except Exception:
        return None
    if wm is None or not getattr(wm, "auto_update_active", False):
        return None
    interval = max(0.05, getattr(wm, "auto_update_timer_interval", 0.1))
    try:
        with _ctx_override():
            _tick_body(wm)
    except Exception:
        traceback.print_exc()
    return interval


def _tick_body(wm):
    job_running = getattr(bpy.app, "is_job_running", None)
    if is_playing() or (job_running is not None and job_running('RENDER')):
        return
    items = _path_items()
    if not items:
        return
    poll_changes(tracked_objects(key for _, key in items))
    version = _rt["version"]
    live = getattr(wm, "update_mode", 'TIMER') == 'TIMER'

    if live and version != _rt["fast_version"]:
        update_paths(refine=False, bake_missing=False)
        _rt["fast_version"] = version

    
    settled = (time.monotonic() - _rt["last_change"]) >= SETTLE_TIME
    if settled and version != _rt["refined_version"] and not is_busy():
        _rt["refined_version"] = _rt["fast_version"] = version  
        update_paths(refine=True)


def start_auto_update():
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=0.05)


def stop_auto_update():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)











_CIRCLE = [(math.cos(i * 2.0 * math.pi / 12), math.sin(i * 2.0 * math.pi / 12)) for i in range(12)]


def _rgb(owner, name, fallback):
    try:
        v = getattr(owner, name)
        return (float(v[0]), float(v[1]), float(v[2]))
    except Exception:
        return fallback


def theme_colors():
    """Colours Blender uses for motion paths, read from the active theme."""
    try:
        th = bpy.context.preferences.themes[0]
    except Exception:
        th = None
    v3d = getattr(th, "view_3d", None)
    space = getattr(v3d, "space", None)
    anim = getattr(getattr(th, "common", None), "anim", None)
    
    
    default_before = (0.949, 0.180, 0.137)
    default_after = (0.471, 0.949, 0.267)
    cur = _rgb(anim, "playhead", None)   
    if cur is None:
        cur = _rgb(v3d, "frame_current", (0.376, 0.753, 0.251))
    bg = (0.239, 0.239, 0.239)
    try:
        bg = _rgb(space.gradients, "high_gradient", bg)
    except Exception:
        pass
    return {
        "before": _rgb(v3d, "before_current_frame", default_before),
        "after": _rgb(v3d, "after_current_frame", default_after),
        "current": cur,
        "key": _rgb(v3d, "vertex_select", (1.0, 0.478, 0.0)),
        "background": bg,
        "text": _rgb(space, "text_hi", (1.0, 1.0, 1.0)),
    }


def ui_scale():
    try:
        s = bpy.context.preferences.system.ui_scale
        return s if s > 0.0 else 1.0
    except Exception:
        return 1.0


def pixel_size():
    try:
        s = bpy.context.preferences.system.pixel_size
        return s if s > 0.0 else 1.0
    except Exception:
        return 1.0


def _target_selected(item, key):
    ob = item.target
    try:
        if key[1]:
            pb = ob.pose.bones.get(key[1]) if ob.pose is not None else None
            return pb is not None and _bone_selected(pb)
        return ob.select_get()
    except Exception:
        return False


def _visible_paths(ctx):
    """[(key, info, selected)] of the paths drawn in this viewport."""
    wm = ctx.window_manager
    if not getattr(wm, "mpp_show_paths", True):
        return []
    space = ctx.space_data
    if space is None or not space.overlay.show_overlays:
        return []
    point = getattr(wm, "mpp_point", 'HEADS')
    out = []
    for item in path_objects(ctx.scene):
        key = path_key(item)
        if key is None:
            continue
        try:
            if not item.target.visible_get():
                continue  
        except Exception:
            continue
        info = _cached(item, key, point)
        if info is not None and info["positions"]:
            out.append((key, info, _target_selected(item, key)))
    return out


def has_visible_path(key):
    """True if this target has a curve path that is drawn (avoids double frame numbers)."""
    if not getattr(_settings(), "mpp_show_paths", True):
        return False
    return any(path_key(item) == key for item in path_objects())


def display_range(wm, frames, cur):
    """(first index, end index, start frame, end frame) of the part of a path
    that is shown: everything ('In Range') or a window around the current
    frame ('Around Frame')."""
    if not frames:
        return 0, 0, cur, cur
    if getattr(wm, "mpp_display_type", 'RANGE') == 'CURRENT_FRAME':
        lo = cur - max(0, getattr(wm, "mpp_frames_before", 10))
        hi = cur + max(0, getattr(wm, "mpp_frames_after", 10))
        return bisect_left(frames, lo), bisect_right(frames, hi), lo, hi
    return 0, len(frames), frames[0], frames[-1]


def _mix(a, b, t):
    return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t)


def _vivid(c):
    """Full-brightness version of a theme colour, slightly lifted towards white."""
    m = max(c[0], c[1], c[2])
    if m < 1e-4:
        return c
    return _mix((c[0] / m, c[1] / m, c[2] / m), (1.0, 1.0, 1.0), 0.12)


def _line_colors(frames, cur, start, end, selected, wm, th):
    """Per-frame line colours, like Blender's motion path shader: full colour
    far from the current frame, fading a little into the background near it,
    with a highlight on the current frame itself."""
    custom = getattr(wm, "mpp_use_custom_color", False)
    pre = tuple(wm.mpp_color) if custom else _vivid(th["before"])
    post = tuple(wm.mpp_color_post) if custom else _vivid(th["after"])
    bg, cc = th["background"], th["current"]
    
    lo, hi = (0.0, 0.35) if selected else (0.2, 0.5)
    out = []
    for f in frames:
        if f < cur:
            if custom:
                c = pre
            else:
                far = min(1.0, (cur - f) / float(max(cur - start, 1)))
                c = _mix(pre, bg, lo + (hi - lo) * (1.0 - far))
        elif f > cur:
            if custom:
                c = post
            else:
                far = min(1.0, (f - cur) / float(max(end - cur, 1)))
                c = _mix(post, bg, lo + (hi - lo) * (1.0 - far))
        else:
            c = _mix(bg, cc, 0.92 if selected else 0.75)
        out.append((c[0], c[1], c[2], 1.0))
    return out


def _draw_lines():
    try:
        ctx = bpy.context
        wm = ctx.window_manager
        if not getattr(wm, "mpp_show_lines", True):
            return
        paths = _visible_paths(ctx)
        if not paths:
            return
        region = ctx.region
        cur = ctx.scene.frame_current
        th = theme_colors()
        style = (cur, wm.mpp_display_type, wm.mpp_frames_before, wm.mpp_frames_after,
                 wm.mpp_use_custom_color, tuple(wm.mpp_color), tuple(wm.mpp_color_post),
                 tuple(th.values()))
        shader = builtin_shader('POLYLINE_SMOOTH_COLOR')
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_mask_set(False)
        gpu.state.depth_test_set('NONE' if getattr(wm, "mpp_in_front", True) else 'LESS_EQUAL')
        shader.bind()
        shader.uniform_float("viewportSize", (region.width, region.height))
        shader.uniform_float("lineWidth", float(getattr(wm, "mpp_line_width", 2.0)) * pixel_size())
        for _key, info, selected in paths:
            sig = style + (selected,)
            cached = info.get("line")
            if cached is None or cached[0] != sig:
                frames = info["frames"]
                i0, i1, start, end = display_range(wm, frames, cur)
                batch = None
                if i1 - i0 >= 2:
                    fr = frames[i0:i1]
                    pos = [tuple(p) for p in info["positions"][i0:i1]]
                    cols = _line_colors(fr, cur, start, end, selected, wm, th)
                    batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": pos, "color": cols})
                cached = info["line"] = (sig, batch)
            if cached[1] is not None:
                cached[1].draw(shader)
        gpu.state.depth_test_set('NONE')
        gpu.state.blend_set('NONE')
    except Exception as e:  
        print("Motion Path Pro: line drawing error:", e)


def add_dot(verts, cols, x, y, r, col):
    """Filled circle in pixel space (appended as triangles)."""
    n = len(_CIRCLE)
    center = (x, y, 0.0)
    ring = [(x + r * c, y + r * s, 0.0) for c, s in _CIRCLE]
    for i in range(n):
        verts.extend((center, ring[i], ring[(i + 1) % n]))
        cols.extend((col, col, col))


def draw_dots(*layers):
    """Draw [(verts, cols), ...] layers of dots made by add_dot (pixel space)."""
    verts, cols = [], []
    for v, c in layers:
        verts += v
        cols += c
    if not verts:
        return
    shader = builtin_shader('FLAT_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {"pos": verts, "color": cols})
    gpu.state.blend_set('ALPHA')
    shader.bind()
    batch.draw(shader)
    gpu.state.blend_set('NONE')


def draw_labels(labels):
    """[(x, y, text, rgb)] in pixel space, with an outline like Blender's overlay text."""
    if not labels:
        return
    font = 0
    scale = ui_scale()
    blf_size(font, 11.0 * scale)
    blf.enable(font, blf.SHADOW)
    try:
        blf.shadow(font, 6, 0.0, 0.0, 0.0, 1.0)  
        blf.shadow_offset(font, 0, 0)
    except Exception:
        blf.shadow(font, 3, 0.0, 0.0, 0.0, 1.0)
        blf.shadow_offset(font, 1, -1)
    off = 4.0 * scale
    for x, y, text, c in labels:
        blf.color(font, c[0], c[1], c[2], 1.0)
        blf.position(font, x + off, y + off * 0.5, 0.0)
        blf.draw(font, text)
    blf.disable(font, blf.SHADOW)


def _draw_dots():
    try:
        ctx = bpy.context
        wm = ctx.window_manager
        show_points = getattr(wm, "mpp_show_dots", True)
        show_keys = getattr(wm, "mpp_show_keyframes", True)
        show_fnum = getattr(wm, "mpp_show_frame_numbers", False)
        show_knum = show_keys and getattr(wm, "mpp_show_keyframe_numbers", False)
        if not (show_points or show_keys or show_fnum or show_knum):
            return
        paths = _visible_paths(ctx)
        if not paths:
            return
        region, rv3d = ctx.region, ctx.region_data
        if region is None or rv3d is None:
            return
        cur = ctx.scene.frame_current
        th = theme_colors()
        px = pixel_size()
        
        pt = max(int(round(getattr(wm, "mpp_line_width", 2.0))) - 1, 1)
        r_frame, r_key, r_cur = (pt + 2) * 0.5 * px, (pt + 5) * 0.5 * px, (pt + 8) * 0.5 * px
        col_frame = (0.0, 0.0, 0.0, 1.0)   
        col_key = th["key"] + (1.0,)
        col_cur = th["current"] + (1.0,)
        to_2d = view3d_utils.location_3d_to_region_2d
        small, keys, current = ([], []), ([], []), ([], [])
        labels = []
        for _key, info, _sel in paths:
            frames, positions, key_frames = info["frames"], info["positions"], info["keys"]
            i0, i1, _s, _e = display_range(wm, frames, cur)
            for i in range(i0, i1):
                f = frames[i]
                p = positions[i]
                s = to_2d(region, rv3d, p)
                if s is None:
                    continue
                is_key = f in key_frames
                if show_keys and f == cur:
                    add_dot(*current, s.x, s.y, r_cur, col_cur)
                elif show_keys and is_key:
                    add_dot(*keys, s.x, s.y, r_key, col_key)
                elif show_points:
                    add_dot(*small, s.x, s.y, r_frame, col_frame)
                if show_knum and is_key:
                    labels.append((s.x, s.y, str(f), th["key"]))
                elif show_fnum:
                    
                    if (i == i0 or p != positions[i - 1]
                            or (i + 1 < i1 and p != positions[i + 1])):
                        labels.append((s.x, s.y, str(f), th["key"] if (show_keys and is_key) else th["text"]))
        draw_dots(small, keys, current)
        draw_labels(labels)
    except Exception as e:  
        print("Motion Path Pro: dot drawing error:", e)






@persistent
def _on_depsgraph_update(_scene, depsgraph):
    """Remember which objects / actions changed, so idle ticks scan nothing."""
    try:
        for update in depsgraph.updates:
            idd = update.id
            if isinstance(idd, bpy.types.Object):
                _dirty_objects.add(idd.name)
            elif isinstance(idd, bpy.types.Action):
                _dirty_actions.add(idd.name)
    except Exception:
        pass


@persistent
def _on_load_post(*_args):
    reset_runtime()
    try:
        migrate_legacy()
    except Exception:
        traceback.print_exc()
    try:
        wm = bpy.context.window_manager
        if getattr(wm, "auto_update_active", False):
            start_auto_update()
    except Exception:
        pass


def _refresh_after_undo():
    try:
        with _ctx_override():
            items = _path_items()
            if items:
                poll_changes(tracked_objects(key for _, key in items))
                update_paths(refine=False, bake_missing=False)
    except Exception:
        traceback.print_exc()
    return None


@persistent
def _on_undo_redo(*_args):
    if _paths and not bpy.app.timers.is_registered(_refresh_after_undo):
        bpy.app.timers.register(_refresh_after_undo, first_interval=0.01)






class MOTIONPATH_OT_CurvePathCreate(bpy.types.Operator):
    """Create a motion path for the selected bones (Pose Mode) or the selected objects.
Never leaves Pose Mode and adds nothing to the Outliner"""
    bl_idname = "motion_path.curve_create"
    bl_label = "Create Motion Path"
    bl_options = {'REGISTER', 'UNDO'}

    kind: bpy.props.EnumProperty(
        name="Kind",
        items=[('AUTO', "Auto", "Bones in Pose Mode, objects otherwise"),
               ('BONE', "Bone", "Selected pose bones"),
               ('OBJECT', "Object", "Selected objects")],
        default='AUTO', options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.mode in {'POSE', 'OBJECT'}

    def execute(self, context):
        targets = selection_targets(context, self.kind)
        if not targets:
            if self.kind == 'BONE':
                self.report({'WARNING'}, "Enter Pose Mode and select a bone first")
            else:
                self.report({'WARNING'}, "Select a bone (Pose Mode) or an object first")
            return {'CANCELLED'}
        t0 = time.perf_counter()
        create_paths(context, targets)
        self.report({'INFO'}, "Motion path for %d target(s) in %.2fs" % (len(targets), time.perf_counter() - t0))
        return {'FINISHED'}


class MOTIONPATH_OT_CurvePathUpdate(bpy.types.Operator):
    """Re-bake all motion paths (use after changing the frame range,
parents or anything outside the action)"""
    bl_idname = "motion_path.curve_update"
    bl_label = "Update Motion Paths"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        items = _path_items()
        if not items:
            self.report({'WARNING'}, "No motion paths yet: create one with Bone / Object")
            return {'CANCELLED'}
        for _, key in items:
            space = _spaces.get(key)
            if space is not None:
                space.fresh.clear()
        poll_changes(tracked_objects(key for _, key in items), force=True)
        t0 = time.perf_counter()
        update_paths(refine=True, preserve_pose=True)
        _rt["refined_version"] = _rt["fast_version"] = _rt["version"]
        self.report({'INFO'}, "Updated %d motion path(s) in %.2fs" % (len(items), time.perf_counter() - t0))
        return {'FINISHED'}


classes = (
    MPP_PathItem,
    MOTIONPATH_OT_CurvePathCreate,
    MOTIONPATH_OT_CurvePathUpdate,
)






def _on_style_changed(self, context):
    tag_redraw()


def _on_keys_changed(self, context):
    for key, info in _paths.items():
        info["keys"] = _key_frames(key)
    tag_redraw()


def _on_range_changed(self, context):
    
    _rt["version"] += 1
    _rt["last_change"] = time.monotonic()


_PROPS = {
    
    "mpp_range_mode": lambda: bpy.props.EnumProperty(
        name="Frame Range",
        items=[('SCENE', "Scene", "Scene frame range (or the preview range when it is enabled)"),
               ('KEYS_ALL', "All Keys", "From the first to the last keyframe of the object / armature"),
               ('MANUAL', "Manual", "Custom frame range")],
        default='SCENE', update=_on_range_changed),
    "mpp_frame_start": lambda: bpy.props.IntProperty(
        name="Start", default=1, update=_on_range_changed),
    "mpp_frame_end": lambda: bpy.props.IntProperty(
        name="End", default=250, update=_on_range_changed),
    "mpp_frame_step": lambda: bpy.props.IntProperty(
        name="Step", description="Frames between path points", default=1, min=1, max=100,
        update=_on_range_changed),
    "mpp_point": lambda: bpy.props.EnumProperty(
        name="Bake To",
        items=[('HEADS', "Heads", "Path follows the bone head"),
               ('TAILS', "Tails", "Path follows the bone tail")],
        default='HEADS', update=_on_range_changed),
    "mpp_skip_meshes": lambda: bpy.props.BoolProperty(
        name="Skip Meshes While Baking",
        description="Turn off mesh modifiers (subdivision, armature deform, geometry nodes ...) "
                    "while baking the path. Much faster on heavy rigs. Objects the rig is "
                    "constrained to are left alone",
        default=True),
    
    "mpp_show_paths": lambda: bpy.props.BoolProperty(
        name="Show Paths", description="Show the motion paths in the viewport",
        default=True, update=_on_style_changed),
    "mpp_display_type": lambda: bpy.props.EnumProperty(
        name="Display Range",
        items=[('RANGE', "In Range", "Show the whole path"),
               ('CURRENT_FRAME', "Around Frame", "Show only a number of frames around the current frame")],
        default='RANGE', update=_on_style_changed),
    "mpp_frames_before": lambda: bpy.props.IntProperty(
        name="Before", description="Frames shown before the current frame",
        default=10, min=0, soft_max=500, update=_on_style_changed),
    "mpp_frames_after": lambda: bpy.props.IntProperty(
        name="After", description="Frames shown after the current frame",
        default=10, min=0, soft_max=500, update=_on_style_changed),
    "mpp_show_frame_numbers": lambda: bpy.props.BoolProperty(
        name="Frame Numbers", description="Show the frame number next to every path point",
        default=False, update=_on_style_changed),
    "mpp_show_keyframes": lambda: bpy.props.BoolProperty(
        name="Keyframes", description="Highlight keyframes and the current frame on the path",
        default=True, update=_on_style_changed),
    "mpp_keys_all": lambda: bpy.props.BoolProperty(
        name="+ Non-Grouped Keyframes",
        description="Highlight keyframes of every channel of the action, not only the bone's / object's own",
        default=False, update=_on_keys_changed),
    "mpp_show_keyframe_numbers": lambda: bpy.props.BoolProperty(
        name="Keyframe Numbers", description="Show the frame number next to every keyframe",
        default=False, update=_on_style_changed),
    "mpp_show_lines": lambda: bpy.props.BoolProperty(
        name="Lines", description="Draw the line between the path points",
        default=True, update=_on_style_changed),
    "mpp_show_dots": lambda: bpy.props.BoolProperty(
        name="Frame Points", description="Draw a dot for every frame of the path",
        default=True, update=_on_style_changed),
    "mpp_line_width": lambda: bpy.props.FloatProperty(
        name="Thickness", description="Line thickness in pixels (also sets the point size)",
        default=2.0, min=1.0, max=10.0, update=_on_style_changed),
    "mpp_in_front": lambda: bpy.props.BoolProperty(
        name="In Front", description="Draw the lines on top of everything (off: hidden behind meshes)",
        default=True, update=_on_style_changed),
    "mpp_use_custom_color": lambda: bpy.props.BoolProperty(
        name="Custom Colors", description="Use your own colors instead of the theme colors",
        default=False, update=_on_style_changed),
    "mpp_color": lambda: bpy.props.FloatVectorProperty(
        name="Before", description="Path color before the current frame", subtype='COLOR_GAMMA',
        size=3, min=0.0, max=1.0, default=(1.0, 0.45, 0.1), update=_on_style_changed),
    "mpp_color_post": lambda: bpy.props.FloatVectorProperty(
        name="After", description="Path color after the current frame", subtype='COLOR_GAMMA',
        size=3, min=0.0, max=1.0, default=(0.1, 0.65, 1.0), update=_on_style_changed),
    "mpp_show_settings": lambda: bpy.props.BoolProperty(name="Motion Path Settings", default=False),
    "mpp_show_display": lambda: bpy.props.BoolProperty(name="Display", default=True),
}


def draw_calculation(layout, context):
    wm = context.window_manager
    col = layout.column()
    col.use_property_split = True
    col.use_property_decorate = False
    col.prop(wm, "mpp_range_mode")
    if wm.mpp_range_mode == 'MANUAL':
        sub = col.column(align=True)
        sub.prop(wm, "mpp_frame_start", text="Frame Range Start")
        sub.prop(wm, "mpp_frame_end", text="End")
    col.prop(wm, "mpp_frame_step")
    col.prop(wm, "mpp_point")
    col.prop(wm, "mpp_skip_meshes")


def draw_display(layout, context):
    """Same layout as Blender's Motion Paths > Display panel."""
    wm = context.window_manager
    col = layout.column()
    col.use_property_split = True
    col.use_property_decorate = False
    col.prop(wm, "mpp_display_type", text="Range")
    if wm.mpp_display_type == 'CURRENT_FRAME':
        sub = col.column(align=True)
        sub.prop(wm, "mpp_frames_before", text="Frame Range Before")
        sub.prop(wm, "mpp_frames_after", text="After")
    col = layout.column(heading="Show")
    col.use_property_split = True
    col.use_property_decorate = False
    col.prop(wm, "mpp_show_frame_numbers")
    col.prop(wm, "mpp_show_keyframes")
    sub = col.column()
    sub.enabled = wm.mpp_show_keyframes
    sub.prop(wm, "mpp_keys_all")
    sub.prop(wm, "mpp_show_keyframe_numbers")
    col.prop(wm, "mpp_show_lines")
    col.prop(wm, "mpp_show_dots")
    col = layout.column()
    col.use_property_split = True
    col.use_property_decorate = False
    col.prop(wm, "mpp_line_width")
    col.prop(wm, "mpp_in_front")
    col.prop(wm, "mpp_use_custom_color")
    if wm.mpp_use_custom_color:
        sub = col.column(align=True)
        sub.prop(wm, "mpp_color")
        sub.prop(wm, "mpp_color_post")


def draw_settings(layout, context):
    draw_calculation(layout, context)
    layout.separator()
    layout.label(text="Display", icon='HIDE_OFF')
    draw_display(layout, context)






def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mpp_paths = bpy.props.CollectionProperty(type=MPP_PathItem)
    for name, make in _PROPS.items():
        setattr(bpy.types.WindowManager, name, make())
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if _on_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph_update)
    for hlist in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo_redo not in hlist:
            hlist.append(_on_undo_redo)
    if not _draw_handles and not bpy.app.background:
        _draw_handles.append(bpy.types.SpaceView3D.draw_handler_add(_draw_lines, (), 'WINDOW', 'POST_VIEW'))
        _draw_handles.append(bpy.types.SpaceView3D.draw_handler_add(_draw_dots, (), 'WINDOW', 'POST_PIXEL'))
    
    bpy.app.timers.register(_migrate_timer, first_interval=0.2)


def unregister():
    stop_auto_update()
    for fn in (_refresh_after_undo, _migrate_timer):
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    for handle in _draw_handles:
        bpy.types.SpaceView3D.draw_handler_remove(handle, 'WINDOW')
    _draw_handles.clear()
    for hlist in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo_redo in hlist:
            hlist.remove(_on_undo_redo)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    if _on_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph_update)
    for name in _PROPS:
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    if hasattr(bpy.types.Scene, "mpp_paths"):
        del bpy.types.Scene.mpp_paths
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    reset_runtime()
