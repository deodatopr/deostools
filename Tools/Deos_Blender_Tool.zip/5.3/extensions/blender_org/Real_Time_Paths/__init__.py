
bl_info = {
    "name" : "Motion-path pro",
    "author" : "Hamdi Amer",
    "description" : "Update motion path in real time from graph editor and viewport",
    "blender" : (3, 0, 0),
    "version" : (3, 2, 0),
    "location" : "Graph Editor",
    "warning" : "",
    "doc_url": "",
    "tracker_url": "",
    "category" : "Graph"
}


import bpy
import mathutils
from bpy.app.handlers import persistent
from bpy_extras import view3d_utils

from . import curve_path
from . import handles
from . import onion
from . import hud


def get_id_fcurves(id_data):
    """F-Curves of the action slot assigned to ``id_data``.

    Always use the assigned slot: an action can hold several slots (a camera
    object and its lens, for example) and the first one is not always yours."""
    fcurves = curve_path.get_anim_fcurves(id_data)
    return fcurves if fcurves is not None else []


def channel_path(obj_or_bone, prop):
    """Data path of a transform channel of an object or a pose bone."""
    if isinstance(obj_or_bone, bpy.types.PoseBone):
        return 'pose.bones["%s"].%s' % (bpy.utils.escape_identifier(obj_or_bone.name), prop)
    return prop


def _offset_channel(obj_or_bone, prop, delta):
    """Offset every key of a transform channel (Smart Offset)."""
    fcurves = get_id_fcurves(obj_or_bone.id_data)
    if not fcurves:
        return
    path = channel_path(obj_or_bone, prop)
    for i, dv in enumerate(delta):
        fc = fcurves.find(path, index=i)
        if fc is None or not dv:
            continue
        for kp in fc.keyframe_points:
            kp.co[1] += dv
            kp.handle_left[1] += dv
            kp.handle_right[1] += dv
        fc.update()


class AutoMOTIONPATHSPanel(bpy.types.Panel):
    bl_label = 'Motion Paths'
    bl_idname = 'FRO_PT_MOTION_PATHS_8176B'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Motion Path Pro'
    bl_order = 1

 

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        
        box = layout.box()
        row = box.row()
        row.label(text="Curve Path", icon='CURVE_PATH')
        row.prop(wm, "mpp_show_paths", text="", emboss=False,
                 icon='HIDE_OFF' if wm.mpp_show_paths else 'HIDE_ON')
        
        obj = context.active_object
        flow = box.grid_flow(align=True)
        flow.operator('motion_path.curve_create', text="Object", icon='OBJECT_DATA').kind = 'OBJECT'
        sub = flow.row(align=True)
        sub.enabled = obj is not None and obj.mode == 'POSE'
        sub.operator('motion_path.curve_create', text="Bone", icon='BONE_DATA').kind = 'BONE'
        
        row = box.row(align=True)
        row.operator('kro.delet_path_6e947', text="", icon='X')
        row.operator('motion_path.curve_update', text="Update", icon='FILE_REFRESH')
        row.operator('kro.delet_allpath_b6bbf', text="", icon='TRASH')

        
        box = layout.box()
        row = box.row()
        row.label(text="Auto Update", icon='TIME')
        
        
        col = box.column()
        col.use_property_split = True
        col.use_property_decorate = False
        col.prop(wm, "update_mode", text="Mode")
        
        if wm.update_mode == 'TIMER':
            col.prop(wm, "auto_update_timer_interval", text="Interval")
        
        
        row = box.row(align=True)
        row.label(text="Update From Graph Editor")
        icon = 'PAUSE' if wm.auto_update_active else 'PLAY'
        text = "Stop" if wm.auto_update_active else "Start"
        row.operator("amth.auto_update_activate" if not wm.auto_update_active else "amth.auto_update_deactivate",
                     text=text, icon=icon)

        


def clear_native_paths(only_selected):
    """Also clear Blender's own motion paths left over from older versions."""
    obj = bpy.context.active_object
    if obj is None:
        return
    try:
        if obj.mode == 'POSE':
            bpy.ops.pose.paths_clear(only_selected=only_selected)
        bpy.ops.object.paths_clear(only_selected=only_selected)
    except Exception:
        pass


class FRO_OT_Delet_Path_6E947(bpy.types.Operator):
    bl_idname = "kro.delet_path_6e947"
    bl_label = "delet_path"
    bl_description = "Delete the curve paths of the selected bones or objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        curve_path.clear_paths(context, only_selected=True)
        clear_native_paths(only_selected=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class FRO_OT_Delet_Allpath_B6Bbf(bpy.types.Operator):
    bl_idname = "kro.delet_allpath_b6bbf"
    bl_label = "Delet_All-path"
    bl_description = "Delete all curve paths"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        curve_path.clear_paths(context, only_selected=False)
        clear_native_paths(only_selected=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)

class AMTH_OT_AutoUpdateMotionPaths(bpy.types.Operator):
    """Auto-update the curve paths while you edit keys"""
    bl_idname = "amth.auto_update_motion_paths"
    bl_label = "Auto Update Motion Paths (Improved)"
    bl_description = "Update the curve paths in real time while you edit keys"

    def execute(self, context):
        context.window_manager.auto_update_active = True
        curve_path.start_auto_update()
        return {'FINISHED'}

    def invoke(self, context, event):
        return self.execute(context)


class AMTH_OT_AutoUpdateActivate(bpy.types.Operator):
    bl_idname = "amth.auto_update_activate"
    bl_label = "Activate Auto Update"
    bl_description = ("Update the curve paths in real time while you edit keys in the Graph Editor "
                      "(creates a path for the selection if there is none)")
    bl_options = {'REGISTER', 'UNDO'}

    bl_icon = 'PLAY'

    def execute(self, context):
        context.window_manager.auto_update_active = True
        if not curve_path.path_objects():
            targets = curve_path.selection_targets(context)
            if targets:
                curve_path.create_paths(context, targets)
            else:
                self.report({'INFO'}, "Auto update is on: select a bone or object and press Bone / Object")
        curve_path.start_auto_update()
        return {'FINISHED'}


class AMTH_OT_AutoUpdateDeactivate(bpy.types.Operator):
    bl_idname = "amth.auto_update_deactivate"
    bl_label = "Deactivate Auto Update"
    bl_description = "Stop updating the curve paths"
    bl_icon = 'PAUSE'
    
    def execute(self, context):
        context.window_manager.auto_update_active = False
        curve_path.stop_auto_update()
        return {'FINISHED'}




class FRO_OT_Delet_Path001_C28Ef(bpy.types.Operator):
    bl_idname = "kro.delet_path001_c28ef"
    bl_label = "delet_path.001"
    bl_description = "delete all path from selected bone or object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            bpy.ops.pose.paths_clear(only_selected=True)
        if bpy.context.active_object:
            bpy.ops.object.paths_clear(only_selected=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class FRO_OT_Delet_Allpath001_C61F5(bpy.types.Operator):
    bl_idname = "kro.delet_allpath001_c61f5"
    bl_label = "Delet_All-path.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            bpy.ops.pose.paths_clear(only_selected=False)
        if bpy.context.active_object:
            bpy.ops.object.paths_clear(only_selected=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)






SMART_PROPS = ("location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "scale")


def smart_offset_targets(context):
    """Selected bones (Pose Mode) or selected objects, and the active one."""
    ob = context.active_object
    if ob is None:
        return []
    if ob.mode == 'POSE':
        items = list(context.selected_pose_bones or [])
        apb = context.active_pose_bone
        if apb is not None and apb not in items:
            items.append(apb)
        return items
    if ob.mode == 'OBJECT':
        items = list(context.selected_objects or [])
        if ob not in items:
            items.append(ob)
        return items
    return []


def smart_offset(item, frame):
    """Offset every key of a transform channel by the difference between its
    value in the viewport and what its keys give on the current frame.

    That difference only exists when you moved, turned or scaled the bone /
    object yourself: changing frames, editing keys (Graph Editor, keyframe
    handles), undo ... never trigger an offset. Returns True if keys moved."""
    ob = item.id_data
    fcurves = get_id_fcurves(ob)
    if not fcurves or curve_path._nla_active(ob):
        return False
    ad = ob.animation_data
    drivers = ad.drivers if ad is not None else None
    moved = False
    for prop in SMART_PROPS:
        path = channel_path(item, prop)
        value = getattr(item, prop)
        delta = []
        for i in range(len(value)):
            fc = fcurves.find(path, index=i)
            if (fc is None or fc.mute or not len(fc.keyframe_points)
                    or (drivers is not None and drivers.find(path, index=i) is not None)):
                delta.append(0.0)
                continue
            d = value[i] - fc.evaluate(frame)
            delta.append(d if abs(d) > 1e-5 * max(1.0, abs(value[i])) else 0.0)
        if any(delta):
            _offset_channel(item, prop, delta)
            moved = True
    return moved


class GenericOffestKeyframesOperator(bpy.types.Operator):
    """Offset All Keys (Smart Offset): move / turn / scale a keyed bone or object
    and every key of that channel moves with it"""
    bl_idname = "anim.generic_offest_keyframes"
    bl_label = "Offset All Keys"
    bl_options = {'INTERNAL'}

    _timer = None
    interval = 0.1

    def modal(self, context, event):
        if not context.window_manager.generic_offest_active:
            self.cancel(context)
            return {'CANCELLED'}
        if event.type == 'TIMER' and not curve_path.is_playing():
            try:
                self.update(context)
            except Exception:
                import traceback
                traceback.print_exc()
        return {'PASS_THROUGH'}

    def update(self, context):
        items = smart_offset_targets(context)
        if not items:
            return
        
        context.view_layer.update()
        scene = context.scene
        frame = scene.frame_current + scene.frame_subframe
        moved = False
        for item in items:
            moved = smart_offset(item, frame) or moved
        if moved:
            curve_path.tag_redraw()

    
    def update_item(self, context, item):
        scene = context.scene
        return smart_offset(item, scene.frame_current + scene.frame_subframe)

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(self.interval, window=context.window)
        wm.modal_handler_add(self)
        wm.generic_offest_active = True
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        context.window_manager.generic_offest_active = False
        curve_path.tag_redraw()
        return {'CANCELLED'}


class GenericOffestKeyframesActivate(bpy.types.Operator):
    bl_idname = "new_amth.generic_offest_activate"
    bl_label = "Offset All Keys"
    bl_description = ("Offset All Keys (Smart Offset): move / turn / scale a keyed bone or object in the "
                      "viewport and all its keys move with it. With Edit Keys on Path, dragging any point "
                      "or handle moves the whole motion path with all its keys and handles")

    def execute(self, context):
        context.window_manager.generic_offest_active = True
        bpy.ops.anim.generic_offest_keyframes('INVOKE_DEFAULT')
        curve_path.tag_redraw()
        return {'FINISHED'}


class GenericOffestKeyframesDeactivate(bpy.types.Operator):
    bl_idname = "new_amth.generic_offest_deactivate"
    bl_label = "Stop Offsetting Keys"
    bl_description = "Stop Offset All Keys (Smart Offset): moving a bone / object no longer moves its keys"

    def execute(self, context):
        context.window_manager.generic_offest_active = False
        curve_path.tag_redraw()
        return {'FINISHED'}


class MotionPathPanel(bpy.types.Panel):
    """Motion paths, keyframe handles and display options in the 3D Viewport"""
    bl_idname = "VIEW3D_PT_motion_path"
    bl_label = "Motion Path Pro"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Motion Path'

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        obj = context.active_object

        
        hud.draw_sidebar(layout, context)

        
        box = layout.box()
        row = box.row()
        row.label(text="Motion Paths", icon='CURVE_PATH')
        row.prop(wm, "mpp_show_paths", text="", emboss=False,
                 icon='HIDE_OFF' if wm.mpp_show_paths else 'HIDE_ON')
        row = box.row(align=True)
        row.operator('motion_path.curve_create', text="Object", icon='OBJECT_DATA').kind = 'OBJECT'
        sub = row.row(align=True)
        sub.enabled = obj is not None and obj.mode == 'POSE'
        sub.operator('motion_path.curve_create', text="Bone", icon='BONE_DATA').kind = 'BONE'
        row = box.row(align=True)
        row.operator('kro.delet_path_6e947', text="", icon='X')
        row.operator('motion_path.curve_update', text="Update", icon='FILE_REFRESH')
        row.operator('kro.delet_allpath_b6bbf', text="", icon='TRASH')
        row = box.row()
        row.prop(wm, "mpp_show_settings", text="Settings",
                 icon='TRIA_DOWN' if wm.mpp_show_settings else 'TRIA_RIGHT', emboss=False)
        if wm.mpp_show_settings:
            curve_path.draw_calculation(box, context)

        
        row = layout.row(align=True)
        row.prop(wm, "show_handles_expanded", text="",
                 icon='TRIA_DOWN' if wm.show_handles_expanded else 'TRIA_RIGHT', emboss=False)
        row.label(text="Keyframe Handles", icon='HANDLE_AUTO')
        if wm.show_handles_expanded:
            box = layout.box()
            
            row = box.row(align=True)
            row.scale_y = 1.2
            if not wm.direct_manipulation_active:
                row.operator("motion_path.direct_manipulation_toggle", text="Edit Keys on Path", icon='PLAY')
            else:
                row.operator("motion_path.direct_manipulation_toggle", text="Stop Editing Keys", icon='PAUSE',
                             depress=True)
                row = box.row(align=True)
                row.operator("motion_path.handles_add_selected", text="Add Selected", icon='ADD')
                row.operator("motion_path.handles_remove_selected", text="Remove Selected", icon='REMOVE')
                box.label(text="Handles on: " + handles.describe(handles.handle_keys()), icon='BONE_DATA')
            col = box.column(align=True)
            if wm.anim_deactivate_keyframe_operator:
                col.operator("anim.deactivate_keyframe_operator", text="Stop Inserting Keys", icon='PAUSE',
                             depress=True)
            else:
                col.operator("anim.insert_keyframe_selected_fcurves", text="Insert Keys on Path", icon='PLAY')
            if wm.generic_offest_active:
                col.operator("new_amth.generic_offest_deactivate", text="Stop Offsetting Keys", icon='PAUSE',
                             depress=True)
            else:
                col.operator("new_amth.generic_offest_activate", text="Offset All Keys", icon='PLAY')

            col = box.column(align=True)
            col.prop(wm, "handle_type", text="Handle Type")
            col.operator("motion_path.set_handle_type", text="Set on Selected Keys").handle_type = wm.handle_type
            col.operator("motion_path.set_handle_type_all", text="Set on All Keys").handle_type = wm.handle_type

            col = box.column(align=True)
            col.prop(wm, "show_all_handles", text="Show Handles on All Keys")
            col.prop(wm, "show_only_selected_handles", text="Show Handles on Selected Keys")

            
            sub = box.box()
            row = sub.row(align=True)
            row.prop(wm, "mpp_onion", text="Onion Skin",
                     icon='ONIONSKIN_ON' if wm.mpp_onion else 'ONIONSKIN_OFF')
            if wm.mpp_onion:
                if not wm.direct_manipulation_active:
                    sub.label(text="Shown while Edit Keys on Path is on", icon='INFO')
                onion.draw_settings(sub, context)



        
        row = layout.row(align=True)
        row.prop(wm, "mpp_show_display", text="",
                 icon='TRIA_DOWN' if wm.mpp_show_display else 'TRIA_RIGHT', emboss=False)
        row.label(text="Display", icon='OVERLAY')
        if wm.mpp_show_display:
            box = layout.box()
            curve_path.draw_display(box, context)


TRANSFORM_PROPS = ("location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "scale")


def transform_fcurves(ob, bone=""):
    """Every F-Curve of the transform channels of a bone / object: its
    "available" channels (like Blender's Available keying set)."""
    fcurves = get_id_fcurves(ob)
    if not fcurves:
        return []
    pre = 'pose.bones["%s"].' % bpy.utils.escape_identifier(bone) if bone else ""
    paths = {pre + p for p in TRANSFORM_PROPS}
    return [fc for fc in fcurves if fc.data_path in paths]


def path_point_at_mouse(context, event, view):
    """(object, bone name, frame) of the shown motion path point under the mouse."""
    wm = context.window_manager
    if not getattr(wm, "mpp_show_paths", True):
        return None
    region, rv3d = view[1], view[2]
    mouse = mathutils.Vector((event.mouse_x - region.x, event.mouse_y - region.y))
    cur = context.scene.frame_current
    best, best_d = None, 8.0 * curve_path.ui_scale()
    for ob, bone in curve_path.selection_targets(context):
        try:
            if not ob.visible_get():
                continue
        except Exception:
            continue
        points = curve_path.get_path_points(ob, bone)
        if not points:
            continue
        i0, i1, _start, _end = curve_path.display_range(wm, [f for f, _p in points], cur)
        for frame, pos in points[i0:i1]:
            s = view3d_utils.location_3d_to_region_2d(region, rv3d, pos)
            if s is None:
                continue
            d = (s - mouse).length
            if d < best_d:
                best, best_d = (ob, bone, frame), d
    return best


def insert_keys_on_path(ob, bone, frame):
    """Key every available transform channel of a bone / object on ``frame``
    with its current curve value, selected or not. The keys on that frame end
    up selected. Returns (new keys, channels)."""
    fcs = transform_fcurves(ob, bone)
    added = 0
    for fc in fcs:
        kps = fc.keyframe_points
        n = len(kps)
        if n:
            zeros = [False] * n
            kps.foreach_set("select_control_point", zeros)
            kps.foreach_set("select_left_handle", zeros)
            kps.foreach_set("select_right_handle", zeros)
        kp = next((k for k in kps if abs(k.co[0] - frame) < 0.5), None)
        if kp is None:
            kp = kps.insert(frame, fc.evaluate(frame), options={'FAST'})
            added += 1
        kp.select_control_point = kp.select_left_handle = kp.select_right_handle = True
        fc.update()
    return added, len(fcs)


class InsertKeyframeOnSelectedFcurves(bpy.types.Operator):
    """Click a point on the motion path of a selected bone / object to key all of its
transform channels there (with the keyframe handles on, drag it right away)"""
    bl_idname = "anim.insert_keyframe_selected_fcurves"
    bl_label = "Insert Keys on Path"
    bl_description = ("Insert Keys on Path: click a point on the motion path of a selected bone / object to "
                      "key all of its transform channels (location, rotation, scale) on that frame. "
                      "Stays on until you press Stop Inserting Keys")
    bl_options = {'REGISTER'}
    active = False
    operator_ref = None

    def modal(self, context, event):
        if not self.active:
            return {'CANCELLED', 'PASS_THROUGH'}
        if event.type != 'LEFTMOUSE' or event.value != 'PRESS' or event.alt or handles.is_busy():
            return {'PASS_THROUGH'}
        view = handles.view_under_mouse(context, event)
        if view is None:
            return {'PASS_THROUGH'}
        hit = path_point_at_mouse(context, event, view)
        if hit is None:
            return {'PASS_THROUGH'}
        ob, bone, frame = hit
        try:
            added, channels = insert_keys_on_path(ob, bone, frame)
        except Exception as e:
            self.report({'WARNING'}, "Could not insert keys: %s" % e)
            return {'RUNNING_MODAL'}
        if not channels:
            self.report({'WARNING'}, "%s has no keyed transform channels" % (bone or ob.name))
            return {'RUNNING_MODAL'}
        key = (ob.name, bone)
        if added:
            try:
                bpy.ops.ed.undo_push(message="Insert Keyframes on Motion Path")
            except Exception:
                pass
        curve_path.poll_changes({ob.name}, force=True)
        curve_path.update_paths(keys={key}, refine=False, bake_missing=False)
        curve_path.refresh_keys(key)
        
        if context.window_manager.direct_manipulation_active:
            handles.grab_key(context, event, view, key, frame)
        curve_path.tag_redraw()
        return {'RUNNING_MODAL'}

    def execute(self, context):
        if InsertKeyframeOnSelectedFcurves.operator_ref is not None:
            InsertKeyframeOnSelectedFcurves.operator_ref.active = False
        obj = context.active_object
        if obj is not None and obj.mode in {'POSE', 'OBJECT'}:
            missing = [(o, b) for o, b in curve_path.selection_targets(context)
                       if curve_path.find_path(o, b) is None]
            if missing:
                curve_path.create_paths(context, missing)
        context.window_manager.modal_handler_add(self)
        self.active = True
        InsertKeyframeOnSelectedFcurves.operator_ref = self
        context.window_manager.anim_deactivate_keyframe_operator = True
        curve_path.tag_redraw()
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        self.active = False
        if InsertKeyframeOnSelectedFcurves.operator_ref is self:
            InsertKeyframeOnSelectedFcurves.operator_ref = None
        context.window_manager.anim_deactivate_keyframe_operator = False
        curve_path.tag_redraw()
        return {'CANCELLED'}


class DeactivateKeyframeOperator(bpy.types.Operator):
    """Stop Insert Keys on Path: clicking the motion path no longer inserts keys"""
    bl_idname = "anim.deactivate_keyframe_operator"
    bl_label = "Stop Inserting Keys"

    def execute(self, context):
        operator = InsertKeyframeOnSelectedFcurves.operator_ref
        if operator and operator.active:
            operator.cancel(context)
            self.report({'INFO'}, "Stopped inserting keys on the path")
        else:
            context.window_manager.anim_deactivate_keyframe_operator = False
            self.report({'INFO'}, "Insert Keys on Path was not running")
        curve_path.tag_redraw()
        return {'FINISHED'}


class MOTIONPATH_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__

    compatibility_mode: bpy.props.BoolProperty(
        name="Compatibility Mode",
        description="Enable compatibility mode to work better with other addons (may reduce performance)",
        default=True,
    )

    skip_cache_building: bpy.props.BoolProperty(
        name="Skip Cache Building",
        description="Skip building position cache when other animation addons are detected",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Compatibility Settings:")
        layout.prop(self, "compatibility_mode")
        layout.prop(self, "skip_cache_building")


classes = (
    FRO_OT_Delet_Path_6E947,
    FRO_OT_Delet_Allpath_B6Bbf,
    FRO_OT_Delet_Path001_C28Ef,
    FRO_OT_Delet_Allpath001_C61F5,
    AMTH_OT_AutoUpdateMotionPaths,
    AMTH_OT_AutoUpdateActivate,
    AMTH_OT_AutoUpdateDeactivate,
    DeactivateKeyframeOperator,
    GenericOffestKeyframesOperator,
    GenericOffestKeyframesActivate,
    GenericOffestKeyframesDeactivate,
    InsertKeyframeOnSelectedFcurves,
    MOTIONPATH_AddonPreferences,
    AutoMOTIONPATHSPanel,
    MotionPathPanel,
)


_RUNTIME_FLAGS = ("generic_offest_active",
                  "anim_deactivate_keyframe_operator")


@persistent
def _on_load_post(*_args):
    """Modal tools do not survive loading a file: show them as stopped."""
    try:
        wm = bpy.context.window_manager
        for name in _RUNTIME_FLAGS:
            if getattr(wm, name, False):
                setattr(wm, name, False)
    except Exception:
        pass


_WM_PROPS = {
    "auto_update_active": lambda: bpy.props.BoolProperty(default=False),
    "auto_update_timer_interval": lambda: bpy.props.FloatProperty(
        name="Timer Interval", description="Interval in seconds for the auto-update timer",
        default=0.1, min=0.1, max=1.0),
    "update_mode": lambda: bpy.props.EnumProperty(
        name="Update Mode", description="Choose between timer-based and event-based update modes",
        items=[('TIMER', "Real_Time", "Update motion paths in real time Suitable for medium or powerful devices"),
               ('EVENT', "After_Change", "Update motion paths after moving the keyframes Suitable for weak devices")],
        default='TIMER'),
    "new_auto_update_active": lambda: bpy.props.BoolProperty(default=False),
    "new_auto_update_timer_interval": lambda: bpy.props.FloatProperty(
        name="Timer Interval", description="Interval in seconds for the new auto-update timer",
        default=0.1, min=0.1, max=1.0),
    "new_update_mode": lambda: bpy.props.EnumProperty(
        name="Update Mode", description="Choose between timer-based and event-based update modes",
        items=[('TIMER', "Real_Time", "Update motion paths in real time Suitable for medium or powerful devices"),
               ('EVENT', "After_Change", "Update motion paths after moving the keyframes Suitable for weak devices")],
        default='TIMER'),
    "generic_offest_active": lambda: bpy.props.BoolProperty(default=False),
    "anim_deactivate_keyframe_operator": lambda: bpy.props.BoolProperty(
        name="Deactivate Keyframe Operator", default=False),
    "direct_manipulation_active": lambda: bpy.props.BoolProperty(
        name="Keyframe Handles Active",
        description="Show and drag keyframes and handles on the motion path", default=False),
    "auto_sapty_active": lambda: bpy.props.BoolProperty(name="Auto Update Active", default=False),
    "auto_midawq_timer_interval": lambda: bpy.props.FloatProperty(
        name="Timer Interval", description="How often the keyframe handles check for changes (seconds)",
        default=0.1, min=0.05, max=1.0),
    "update_hamdionz": lambda: bpy.props.EnumProperty(
        name="Update Mode", description="Update mode",
        items=[('TIMER', "Real-time", "Update continuously (resource intensive)"),
               ('EVENT', "On Change", "Update only when keyframes change")],
        default='TIMER'),
    "handle_type": lambda: bpy.props.EnumProperty(
        name="Handle Type", description="Handle type to apply to the location keyframes",
        items=handles.HANDLE_TYPES, default='AUTO_CLAMPED', update=lambda self, ctx: curve_path.tag_redraw()),
    "show_all_handles": lambda: bpy.props.BoolProperty(
        name="Show All Handles", description="Show handles for all keyframe points",
        default=True, update=lambda self, ctx: curve_path.tag_redraw()),
    "show_only_selected_handles": lambda: bpy.props.BoolProperty(
        name="Show Only Selected Handles", description="Show handles only for selected keyframe points",
        default=False, update=lambda self, ctx: curve_path.tag_redraw()),
    "show_handles_expanded": lambda: bpy.props.BoolProperty(
        name="Show Handles Expanded", description="Expand or collapse the handles controls",
        default=True),
}


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    for name, make in _WM_PROPS.items():
        setattr(bpy.types.WindowManager, name, make())
    curve_path.register()
    handles.register()
    hud.register()
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)


def unregister():
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    hud.unregister()
    handles.unregister()
    curve_path.unregister()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    for name in _WM_PROPS:
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
