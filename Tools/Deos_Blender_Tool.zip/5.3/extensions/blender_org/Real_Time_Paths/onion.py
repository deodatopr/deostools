

import time
import traceback

import bpy
import gpu
from bpy.app.handlers import persistent
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from . import curve_path

try:
    import numpy as np
except ImportError:  
    np = None


MAX_INFLUENCES = 4      

CUT_TYPES = frozenset(('ARMATURE', 'SUBSURF', 'MULTIRES'))


FORMS = (('SOLID', "Solid"), ('WIREFRAME', "Wireframe"), ('DOTS', "Dots"))
FORM_LABELS = dict(FORMS)
WIRE_WIDTH = 1.25       






class _MeshData:
    """Cage of a mesh: local coordinates, triangles, edges and bone weights."""
    __slots__ = ("sig", "co", "tris", "edges", "idx", "w", "unweighted", "ibo")


class _Owner:
    """A rig (or object) that ghosts are drawn for."""
    __slots__ = ("name", "is_rig", "sig", "names", "index", "parent", "rest_inv",
                 "deform", "parts", "kind")


class _Part:
    __slots__ = ("name", "mesh", "base", "bone", "neg", "M")


class _Ghost:
    __slots__ = ("owner", "frame", "stale", "parts", "line_pos", "line_bone",
                 "offset", "gpu", "dirty", "S", "W")

    def __init__(self, owner, frame):
        self.owner, self.frame = owner, frame
        self.stale = False
        self.parts = []
        self.line_pos = None    
        self.line_bone = None   
        self.offset = Vector()  
        self.gpu = None         
        self.dirty = True
        self.S = None           
        self.W = None           


class _State:
    def __init__(self):
        self.ghosts = {}        
        self.owners = {}        
        self.keys = {}          
        self.version = -1
        self.expect = set()     
        self.expect_bump = False  
        self.drag = None
        self.last_bake = 0.0


_g = _State()
_mesh_cache = {}                
_draw_handle = []
_provider = None                
_fmt = None


def set_provider(fn):
    global _provider
    _provider = fn


def enabled(wm=None):
    wm = wm or bpy.context.window_manager
    return (np is not None and bool(getattr(wm, "mpp_onion", False))
            and bool(getattr(wm, "direct_manipulation_active", False)))


def clear(meshes=False):
    _g.__init__()
    if meshes:
        _mesh_cache.clear()
    curve_path.tag_redraw()


def stats():
    return len(_g.ghosts), _g.last_bake






def _mat(m):
    return np.array(m, dtype=np.float32)


def _xform(M, P):
    return (P @ M[:3, :3].T + M[:3, 3]).astype(np.float32)


def _deformed_by(ob, rig):
    for mod in ob.modifiers:
        if mod.type == 'ARMATURE' and mod.object == rig and mod.show_viewport:
            return True
    return ob.parent == rig and ob.parent_type == 'ARMATURE'


def _visible(ob):
    try:
        return ob.visible_get()
    except Exception:
        return False


def _make_owner(ob):
    """Owner of the ghosts: a rig with the meshes it deforms / carries, or a
    single object."""
    o = _Owner()
    o.name = ob.name
    o.kind = ob.type
    o.is_rig = ob.type == 'ARMATURE' and ob.pose is not None
    o.parts = []
    o.sig = None
    if o.is_rig:
        pbs = ob.pose.bones
        n = len(pbs)
        o.names = [pb.name for pb in pbs]
        o.sig = hash(tuple(o.names))
        o.index = {name: i for i, name in enumerate(o.names)}
        o.parent = np.array([o.index[pb.parent.name] if pb.parent is not None else -1 for pb in pbs],
                            dtype=np.int32)
        rest = np.empty(n * 16, dtype=np.float32)
        ob.data.bones.foreach_get("matrix_local", rest)
        rest = rest.reshape(n, 4, 4).transpose(0, 2, 1)       
        dindex = {b.name: i for i, b in enumerate(ob.data.bones)}
        rest = rest[[dindex[name] for name in o.names]]
        o.rest_inv = np.linalg.inv(rest).astype(np.float32)
        o.deform = {pb.name: i for i, pb in enumerate(pbs) if pb.bone.use_deform}
        for m in bpy.context.scene.objects:
            if m.type != 'MESH' or m == ob or not _visible(m):
                continue
            if _deformed_by(m, ob):
                o.parts.append((m.name, 'DEFORM', -1))
            elif m.parent == ob:
                bone = o.index.get(m.parent_bone, -1) if m.parent_type == 'BONE' else -1
                o.parts.append((m.name, 'RIGID', bone))
    elif ob.type == 'MESH':
        o.parts.append((ob.name, 'RIGID', -1))
    return o


def _cut(ob):
    for i, mod in enumerate(ob.modifiers):
        if mod.type in CUT_TYPES:
            return i
    return len(ob.modifiers)


def _mesh_sig(ob, owner, kind):
    me = ob.data
    mods = tuple((m.name, m.type, m.show_viewport) for m in list(ob.modifiers)[:_cut(ob)])
    return (me.name, len(me.vertices), len(me.polygons), mods,
            owner.sig if kind == 'DEFORM' else None)


def _read_mesh(ob, me, owner, kind, sig):
    d = _MeshData()
    d.sig, d.ibo = sig, None
    n = len(me.vertices)
    co = np.empty(n * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    d.co = co.reshape(n, 3)
    try:
        me.calc_loop_triangles()
    except AttributeError:
        pass
    nt = len(me.loop_triangles)
    tris = np.empty(nt * 3, dtype=np.int32)
    me.loop_triangles.foreach_get("vertices", tris)
    d.tris = tris.reshape(nt, 3)
    ne = len(me.edges)
    edges = np.empty(ne * 2, dtype=np.int32)
    me.edges.foreach_get("vertices", edges)
    d.edges = edges         
    d.idx = d.w = d.unweighted = None
    if kind == 'DEFORM' and owner.is_rig:
        gmap = [owner.deform.get(vg.name, -1) for vg in ob.vertex_groups]
        ng = len(gmap)
        if any(b >= 0 for b in gmap):
            K = MAX_INFLUENCES
            idx = np.zeros((n, K), dtype=np.int32)
            w = np.zeros((n, K), dtype=np.float32)
            for i, v in enumerate(me.vertices):
                gs = [(g.weight, gmap[g.group]) for g in v.groups
                      if g.group < ng and gmap[g.group] >= 0 and g.weight > 0.0]
                if not gs:
                    continue
                if len(gs) > K:
                    gs.sort(reverse=True)
                    del gs[K:]
                for k, (wt, b) in enumerate(gs):
                    idx[i, k] = b
                    w[i, k] = wt
            total = w.sum(axis=1)
            ok = total > 1e-4
            w[ok] /= total[ok, None]
            w[~ok] = 0.0
            d.idx, d.w, d.unweighted = idx, w, ~ok
    return d


def _extract(context, need):
    """Read the cage of meshes: modifiers before the first Armature /
    Subdivision / Multires (Mirror ...), basis shape. Returns the modifiers it
    turned off (turned back on with the bake's own muting)."""
    toggled = []
    shapes = []
    for name in need:
        ob = bpy.data.objects[name]
        for mod in list(ob.modifiers)[_cut(ob):]:
            if mod.show_viewport:
                try:
                    mod.show_viewport = False
                    toggled.append(mod)
                except Exception:
                    pass
        if ob.data.shape_keys is not None and not ob.show_only_shape_key:
            shapes.append((ob, ob.active_shape_key_index))
            ob.active_shape_key_index = 0
            ob.show_only_shape_key = True    
    try:
        context.view_layer.update()
        dg = context.evaluated_depsgraph_get()
        for name, (owner, kind, sig) in need.items():
            ob = bpy.data.objects[name]
            ob_eval = ob.evaluated_get(dg)
            me = ob_eval.to_mesh()
            try:
                _mesh_cache[name] = _read_mesh(ob, me, owner, kind, sig)
            except Exception:
                traceback.print_exc()
            finally:
                ob_eval.to_mesh_clear()
    finally:
        for ob, index in shapes:
            ob.show_only_shape_key = False
            ob.active_shape_key_index = index
    return toggled


def _mute(owner_names):
    """Turn off the modifiers of every heavy object while baking (see
    curve_path._mute_heavy). Mesh owners only need their matrix, so theirs go too."""
    muted = curve_path._mute_heavy(set(owner_names))
    for name in owner_names:
        ob = bpy.data.objects.get(name)
        if ob is None or ob.type not in curve_path.HEAVY_TYPES:
            continue
        for mod in ob.modifiers:
            if mod.show_viewport:
                try:
                    mod.show_viewport = False
                    muted.append(mod)
                except Exception:
                    pass
    return muted


def _object_lines(ob, W, scene):
    """Small outline of a non-rig object without a mesh: camera frame or axes
    (None for a mesh: the mesh itself is drawn)."""
    if ob.type == 'MESH':
        return None
    pts = []
    if ob.type == 'CAMERA':
        try:
            c = [Vector(v) for v in ob.data.view_frame(scene=scene)]
            o = Vector()
            for i in range(4):
                pts += [o, c[i], c[i], c[(i + 1) % 4]]
        except Exception:
            pts = []
    if not pts:
        s = float(getattr(ob, "empty_display_size", 1.0) or 1.0)
        for axis in range(3):
            a, b = Vector(), Vector()
            a[axis], b[axis] = -s, s
            pts += [a, b]
    P = np.array([tuple(p) for p in pts], dtype=np.float32)
    return _xform(W, P)


def _lbs(mesh, S, W, C, rows=None):
    """Linear blend skinning of the cage (rows: only these vertices)."""
    if rows is None:
        co, idx, w, unw = mesh.co, mesh.idx, mesh.w, mesh.unweighted
    else:
        co, idx, w, unw = mesh.co[rows], mesh.idx[rows], mesh.w[rows], mesh.unweighted[rows]
    v = _xform(C, co)                                    
    acc = np.zeros_like(v)
    for k in range(idx.shape[1]):
        wk = w[:, k]
        if not wk.any():
            continue
        Sk = S[idx[:, k]]
        acc += wk[:, None] * (np.einsum('nij,nj->ni', Sk[:, :3, :3], v) + Sk[:, :3, 3])
    acc[unw] = v[unw]
    return _xform(W, acc)


def _deform(mesh, S, W, M, prev=None, prev_S=None):
    """World positions of a cage deformed by the bones. With the positions of
    an earlier evaluation (``prev``, skinned with ``prev_S``) only the vertices
    of the bones that moved since are computed again."""
    C = np.linalg.inv(W) @ M
    if prev is not None and prev_S is not None and prev_S.shape == S.shape:
        moved = np.nonzero(np.abs(S - prev_S).reshape(len(S), -1).max(axis=1) > 1e-6)[0]
        if not len(moved):
            return prev
        rows = np.nonzero((np.isin(mesh.idx, moved) & (mesh.w > 0.0)).any(axis=1))[0]
        if len(rows) < 0.6 * len(mesh.co):
            pos = prev.copy()
            if len(rows):
                pos[rows] = _lbs(mesh, S, W, C, rows)
            return pos
    return _lbs(mesh, S, W, C)


def _build(dg, owner, frame, scene, prev=None):
    """Ghost of an owner at the frame the scene is at (``prev``: the same
    ghost evaluated before, to redo only what moved)."""
    g = _Ghost(owner.name, frame)
    ob = bpy.data.objects.get(owner.name)
    ob_eval = ob.evaluated_get(dg)
    W = _mat(ob_eval.matrix_world)
    S = None
    if owner.is_rig:
        n = len(owner.names)
        buf = np.empty(n * 16, dtype=np.float32)
        ob_eval.pose.bones.foreach_get("matrix", buf)
        pose = buf.reshape(n, 4, 4).transpose(0, 2, 1)
        S = pose @ owner.rest_inv
        g.S = S
    else:
        lp = _object_lines(ob, W, scene)
        if lp is not None:
            g.line_pos = lp
            g.line_bone = np.full(len(lp), -1, dtype=np.int32)

    g.W = W
    reuse = (prev is not None and prev.S is not None and S is not None and prev.W is not None
             and np.allclose(prev.W, W, atol=1e-6))
    prev_parts = {p.name: p for p in prev.parts} if reuse else {}
    for name, kind, bone in owner.parts:
        mesh = _mesh_cache.get(name)
        part_ob = bpy.data.objects.get(name)
        if mesh is None or part_ob is None or not len(mesh.co):
            continue
        M = _mat(part_ob.evaluated_get(dg).matrix_world)
        if kind == 'DEFORM' and S is not None and mesh.idx is not None:
            old = prev_parts.get(name)
            if old is not None and old.M is not None and np.allclose(old.M, M, atol=1e-6):
                pos = _deform(mesh, S, W, M, old.base, prev.S)
            else:
                pos = _deform(mesh, S, W, M)
        else:
            pos = _xform(M, mesh.co)
        p = _Part()
        p.name, p.mesh, p.base, p.bone, p.M = name, mesh, np.ascontiguousarray(pos), bone, M
        p.neg = bool(np.linalg.det(M[:3, :3]) < 0.0)
        g.parts.append(p)
    return g






def shown_frames(wm, frames, cur):
    if getattr(wm, "mpp_onion_range", 'ALL') == 'NEAR':
        before = [f for f in frames if f < cur][-max(0, wm.mpp_onion_before):] if wm.mpp_onion_before else []
        after = [f for f in frames if f > cur][:max(0, wm.mpp_onion_after)]
        return before + after
    return list(frames)


def bake(context, todo):
    """Evaluate the rigs at the frames in ``todo`` ({owner: [frames]})."""
    scene = context.scene
    wm = context.window_manager
    owners = {}
    for name in todo:
        ob = bpy.data.objects.get(name)
        if ob is not None:
            owners[name] = _g.owners[name] = _make_owner(ob)
    if not owners:
        return 0
    need = {}
    for o in owners.values():
        for name, kind, _bone in o.parts:
            ob = bpy.data.objects.get(name)
            sig = _mesh_sig(ob, o, kind)
            cached = _mesh_cache.get(name)
            if cached is None or cached.sig != sig:
                need[name] = (o, kind, sig)
    t0 = time.perf_counter()
    f0, sub0 = scene.frame_current, scene.frame_subframe
    snap = curve_path._snapshot(set(owners))
    toggled, muted = [], []
    frames = sorted({f for fs in todo.values() for f in fs})
    try:
        if need:
            toggled = _extract(context, need)
        if getattr(wm, "mpp_skip_meshes", True):
            muted = _mute(owners)
        for f in frames:
            scene.frame_set(f)
            dg = context.evaluated_depsgraph_get()
            for name, fs in todo.items():
                if name in owners and f in fs:
                    try:
                        _g.ghosts[(name, f)] = _build(dg, owners[name], f, scene)
                    except Exception:
                        traceback.print_exc()
    finally:
        curve_path._unmute_heavy(muted + toggled)
        scene.frame_set(f0, subframe=sub0)
        if snap:
            curve_path._restore_snapshot(snap)
    _g.last_bake = time.perf_counter() - t0
    curve_path.tag_redraw()
    return len(frames)


def sync(context, force=False):
    """Bake the ghosts that are missing or out of date (never while editing)."""
    wm = context.window_manager
    if not enabled(wm):
        if _g.ghosts or _g.owners:
            clear()
        return False
    if _g.drag is not None:
        return False
    only_sel = wm.mpp_onion_selected
    keys = {}
    for t in (_provider() if _provider is not None else ()):
        fs = keys.setdefault(t.key[0], set())
        fs.update(p.frame for p in t.points if p.sel or not only_sel)
    _g.keys = {o: sorted(fs) for o, fs in keys.items() if fs}

    version = curve_path.change_version()
    if version != _g.version:
        if _g.expect_bump:      
            for k in _g.expect:
                if k in _g.ghosts:
                    _g.ghosts[k].stale = True
        else:
            for gh in _g.ghosts.values():
                gh.stale = True
        _g.version = version
    _g.expect = set()
    _g.expect_bump = False
    for k in [k for k in _g.ghosts if k[0] not in _g.keys]:
        del _g.ghosts[k]

    cur = context.scene.frame_current
    todo = {}
    missing = False
    for owner, frames in _g.keys.items():
        for f in shown_frames(wm, frames, cur):
            gh = _g.ghosts.get((owner, f))
            if gh is None or gh.stale:
                todo.setdefault(owner, []).append(f)
                missing = missing or gh is None
    if not todo:
        return False
    if curve_path.is_playing() or curve_path.is_busy():
        return False
    
    if (not force and not missing
            and time.monotonic() - curve_path._rt["last_change"] < curve_path.SETTLE_TIME):
        return False
    bake(context, todo)
    return True


def _sync_timer():
    try:
        with curve_path.ctx_override():
            sync(bpy.context, force=True)
    except Exception:
        traceback.print_exc()
    return None


def request_sync():
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, first_interval=0.01)














LIVE_MIN_INTERVAL = 1.0 / 30.0   
LIVE_DUTY = 1.5                  


def _subtree(owner, b):
    sub = np.zeros(len(owner.parent), dtype=bool)
    sub[b] = True
    has_parent = owner.parent >= 0
    parent = np.maximum(owner.parent, 0)
    while True:
        nxt = sub | (has_parent & sub[parent])
        if (nxt == sub).all():
            return sub
        sub = nxt


def _live_mute():
    """Character meshes show their cage while dragging in real time: subdivision
    and the modifiers after the armature are turned off, so every evaluation
    is only the rigs and the armature deform. Turned back on when you let go."""
    muted = []
    for ob in bpy.context.scene.objects:
        if ob.type != 'MESH':
            continue
        mods = list(ob.modifiers)
        last_arm = max((i for i, m in enumerate(mods) if m.type == 'ARMATURE'), default=-1)
        for i, m in enumerate(mods):
            heavy = m.type in {'SUBSURF', 'MULTIRES'} or (last_arm >= 0 and i > last_arm)
            if heavy and m.show_viewport:
                try:
                    m.show_viewport = False
                    muted.append(m)
                except Exception:
                    pass
    return muted


def drag_begin(d, t):
    """d: handles._Drag, t: its target."""
    _g.drag = None
    if not enabled() or d.kind != 'POINT':
        return
    wm = bpy.context.window_manager
    owner = _g.owners.get(d.key[0])
    if owner is None:
        return
    pts = {p.frame: p for p in t.points}
    orig = {f: pts[f].pos.copy() for f in d.frames if f in pts and (owner.name, f) in _g.ghosts}
    if not orig:
        return
    sub = None                                  
    if owner.is_rig and d.key[1]:
        b = owner.index.get(d.key[1])
        if b is None:
            return
        sub = _subtree(owner, b)
    svals = {}
    for name, kind, bone in owner.parts:
        mesh = _mesh_cache.get(name)
        if mesh is None:
            continue
        if sub is None:
            svals[name] = 1.0
        elif kind == 'DEFORM' and mesh.idx is not None:
            svals[name] = (mesh.w * sub[mesh.idx]).sum(axis=1).astype(np.float32)[:, None]
        elif bone >= 0:
            svals[name] = 1.0 if sub[bone] else 0.0
        else:
            svals[name] = 0.0
    follow = getattr(wm, "mpp_onion_follow", 'REALTIME')
    saved = {}
    for f in orig:
        gh = _g.ghosts[(owner.name, f)]
        saved[f] = (gh.parts, gh.line_pos, gh.line_bone, gh.S, gh.W)
    muted = _live_mute() if follow == 'REALTIME' and getattr(wm, "mpp_skip_meshes", True) else []
    _g.drag = {"owner": owner.name, "orig": orig, "sub": sub, "s": svals, "follow": follow,
               "delta": {}, "eval_delta": {f: Vector() for f in orig}, "saved": saved,
               "pending": False, "last": 0.0, "cost": 0.0, "muted": muted, "evals": 0}


def drag_update(t):
    d = _g.drag
    if d is None:
        return
    pts = {p.frame: p for p in t.points}
    moved = False
    for f, o in d["orig"].items():
        p = pts.get(f)
        gh = _g.ghosts.get((d["owner"], f))
        if p is None or gh is None:
            continue
        delta = p.pos - o
        d["delta"][f] = delta.copy()
        if d["follow"] == 'RELEASE':
            continue
        
        
        off = delta - d["eval_delta"][f]
        if (gh.offset - off).length > 1e-7:
            gh.offset = off
            gh.dirty = True
            moved = True
    if d["follow"] == 'REALTIME':
        d["pending"] = True
        _live_maybe()
    if moved:
        curve_path.tag_redraw()


def _live_wait(d):
    return max(LIVE_MIN_INTERVAL, LIVE_DUTY * d["cost"]) - (time.monotonic() - d["last"])


def _live_maybe():
    d = _g.drag
    if d is None or not d["pending"]:
        return
    if _live_wait(d) <= 0.0:
        _live_eval()
    elif not bpy.app.timers.is_registered(_live_timer):
        bpy.app.timers.register(_live_timer, first_interval=max(0.005, _live_wait(d)))


def _live_timer():
    """Catches up when the mouse stops between two updates."""
    d = _g.drag
    if d is None or not d["pending"]:
        return None
    wait = _live_wait(d)
    if wait > 0.0:
        return wait
    try:
        with curve_path.ctx_override():
            _live_eval()
    except Exception:
        traceback.print_exc()
    return None


def _live_eval():
    """Evaluate the rig at the dragged keys and rebuild their ghosts (only the
    vertices of the bones that moved are skinned again)."""
    d = _g.drag
    if d is None:
        return
    ctx = bpy.context
    scene = ctx.scene
    owner = _g.owners.get(d["owner"])
    if owner is None:
        d["pending"] = False
        return
    cur, sub = scene.frame_current, scene.frame_subframe
    t0 = time.perf_counter()
    try:
        for f in d["orig"]:
            gh = _g.ghosts.get((d["owner"], f))
            if gh is None:
                continue
            scene.frame_set(f)
            dg = ctx.evaluated_depsgraph_get()
            new = _build(dg, owner, f, scene, prev=gh)
            gh.parts, gh.line_pos, gh.line_bone, gh.S, gh.W = new.parts, new.line_pos, new.line_bone, new.S, new.W
            d["eval_delta"][f] = d["delta"].get(f, Vector()).copy()
            gh.offset = Vector()
            gh.dirty = True
    except Exception:
        traceback.print_exc()
    finally:
        scene.frame_set(cur, subframe=sub)
    d["cost"] = time.perf_counter() - t0
    d["last"] = time.monotonic()
    d["pending"] = False
    d["evals"] += 1
    curve_path.tag_redraw()


def _moved_lines(gh, d):
    if gh.line_pos is None:
        return None
    if d["sub"] is None:
        return np.ones(len(gh.line_pos), dtype=bool)
    lb = gh.line_bone
    return (lb >= 0) & d["sub"][np.maximum(lb, 0)]


def drag_end(commit):
    d = _g.drag
    if d is None:
        return
    if commit and d["follow"] == 'REALTIME' and d["pending"]:
        _live_eval()                              
    _g.drag = None
    if bpy.app.timers.is_registered(_live_timer):
        bpy.app.timers.unregister(_live_timer)
    curve_path._unmute_heavy(d["muted"])
    _g.expect_bump = True                         
    for f in d["orig"]:
        gh = _g.ghosts.get((d["owner"], f))
        if gh is None:
            continue
        if not commit:
            gh.parts, gh.line_pos, gh.line_bone, gh.S, gh.W = d["saved"][f]
        else:
            off = np.array(gh.offset, dtype=np.float32)
            if off.any():
                for part in gh.parts:
                    part.base = np.ascontiguousarray(part.base + d["s"].get(part.name, 0.0) * off)
                mask = _moved_lines(gh, d)
                if mask is not None:
                    gh.line_pos = gh.line_pos.copy()
                    gh.line_pos[mask] += off
                gh.S = None                       
            if d["follow"] != 'REALTIME' or off.any():
                _g.expect.add((d["owner"], f))    
        gh.offset = Vector()
        gh.dirty = True
    curve_path.tag_redraw()


def drag_info():
    """(follow mode, real time updates done, cost of the last one) of the drag."""
    d = _g.drag
    return (d["follow"], d["evals"], d["cost"]) if d is not None else None






def _format():
    global _fmt
    if _fmt is None:
        _fmt = gpu.types.GPUVertFormat()
        _fmt.attr_add(id="pos", comp_type='F32', len=3, fetch_mode='FLOAT')
    return _fmt


def live_positions(gh, part):
    """World positions of a ghost part as drawn (with the offset of a drag)."""
    d = _g.drag
    if d is not None and d["owner"] == gh.owner and gh.frame in d["orig"] and gh.offset.length:
        return part.base + d["s"].get(part.name, 0.0) * np.array(gh.offset, dtype=np.float32)
    return part.base


def _vbo(pos):
    vbo = gpu.types.GPUVertBuf(_format(), len(pos))
    vbo.attr_fill("pos", pos)
    return vbo


def _upload(gh, line_shader, form):
    """Send a ghost to the GPU in the given form: SOLID (triangles),
    WIREFRAME (the mesh edges as lines) or DOTS (one point per vertex)."""
    d = _g.drag
    live = d is not None and d["owner"] == gh.owner and gh.frame in d["orig"]
    off = np.array(gh.offset, dtype=np.float32) if live else None
    if off is not None and not off.any():
        off = None
    items = []
    for part in gh.parts:
        pos = part.base
        if off is not None:
            pos = np.ascontiguousarray(pos + d["s"].get(part.name, 0.0) * off, dtype=np.float32)
        mesh = part.mesh
        if form == 'WIREFRAME':
            if mesh.edges is None or not len(mesh.edges):
                continue
            lp = np.ascontiguousarray(pos[mesh.edges], dtype=np.float32)
            items.append((gpu.types.GPUBatch(type='LINES', buf=_vbo(lp)), part.neg))
        elif form == 'DOTS':
            if not len(pos):
                continue
            items.append((gpu.types.GPUBatch(type='POINTS', buf=_vbo(pos)), part.neg))
        else:
            if not len(mesh.tris):
                continue
            if mesh.ibo is None:
                try:
                    mesh.ibo = gpu.types.GPUIndexBuf(type='TRIS', seq=mesh.tris)
                except (TypeError, ValueError):     
                    mesh.ibo = gpu.types.GPUIndexBuf(type='TRIS', seq=mesh.tris.tolist())
            items.append((gpu.types.GPUBatch(type='TRIS', buf=_vbo(pos), elem=mesh.ibo), part.neg))
    lines = None
    if gh.line_pos is not None and len(gh.line_pos):
        lp = gh.line_pos
        if off is not None:
            lp = lp.copy()
            lp[_moved_lines(gh, d)] += off
        lines = batch_for_shader(line_shader, 'LINES', {"pos": lp})
    gh.gpu = (form, items, lines)
    gh.dirty = False


_point_name = []


def _point_shader():
    """Round points ('POINT_UNIFORM_COLOR'), square ones if it is missing."""
    if not _point_name:
        try:
            curve_path.builtin_shader('POINT_UNIFORM_COLOR')
            _point_name.append('POINT_UNIFORM_COLOR')
        except Exception:
            _point_name.append('UNIFORM_COLOR')
    return curve_path.builtin_shader(_point_name[0])


def _smooth_lines(shader):
    try:
        shader.uniform_bool("lineSmooth", True)
    except Exception:
        pass


def _draw():
    try:
        ctx = bpy.context
        wm = ctx.window_manager
        if not enabled(wm) or not _g.ghosts:
            return
        space = ctx.space_data
        if space is None or not space.overlay.show_overlays:
            return
        region = ctx.region
        cur = ctx.scene.frame_current
        form = getattr(wm, "mpp_onion_form", 'SOLID')
        items = []
        for owner, frames in _g.keys.items():
            shown = shown_frames(wm, frames, cur)
            before = [f for f in shown if f < cur][::-1]
            after = [f for f in shown if f > cur]
            for side, fs in (('B', before), ('A', after)):
                for rank, f in enumerate(fs):
                    items.append((rank, len(fs), side, owner, f))
        if not items:
            return
        items.sort(key=lambda it: -it[0])      
        opacity = wm.mpp_onion_opacity
        cb, ca = tuple(wm.mpp_onion_color_before), tuple(wm.mpp_onion_color_after)
        tri_shader = curve_path.builtin_shader('UNIFORM_COLOR')
        line_shader = curve_path.builtin_shader('POLYLINE_UNIFORM_COLOR')
        gpu.state.blend_set('ALPHA')
        gpu.state.depth_mask_set(False)
        gpu.state.depth_test_set('NONE' if wm.mpp_onion_in_front else 'LESS_EQUAL')
        px = curve_path.pixel_size()
        lines = []      
        wires = []      
        dots = []       
        for rank, count, side, owner, f in items:
            gh = _g.ghosts.get((owner, f))
            if gh is None:
                continue
            if gh.dirty or gh.gpu is None or gh.gpu[0] != form:
                _upload(gh, line_shader, form)
            fade = 1.0 - 0.6 * rank / (count - 1) if count > 1 else 1.0
            c = cb if side == 'B' else ca
            alpha = opacity * fade
            _form, batches, batch_lines = gh.gpu
            if batches and form == 'WIREFRAME':
                
                col = (c[0], c[1], c[2], min(1.0, 0.1 + alpha * 2.0))
                wires.extend((batch, col) for batch, _neg in batches)
            elif batches and form == 'DOTS':
                col = (c[0], c[1], c[2], min(1.0, 0.2 + alpha * 2.5))
                dots.extend((batch, col) for batch, _neg in batches)
            elif batches:
                culling = getattr(gpu.state, "face_culling_set", None)
                flip = getattr(gpu.state, "front_facing_set", None)
                if culling is not None:
                    culling('BACK')
                tri_shader.bind()
                tri_shader.uniform_float("color", (c[0], c[1], c[2], alpha))
                for batch, neg in batches:
                    if neg and flip is not None:
                        flip(True)
                    batch.draw(tri_shader)
                    if neg and flip is not None:
                        flip(False)
                if culling is not None:
                    culling('NONE')
            if batch_lines is not None:
                lines.append((batch_lines, (c[0], c[1], c[2], min(1.0, 0.25 + alpha * 2.5))))
        if wires or lines:
            line_shader.bind()
            line_shader.uniform_float("viewportSize", (region.width, region.height))
            if wires:
                _smooth_lines(line_shader)
                line_shader.uniform_float("lineWidth", WIRE_WIDTH * px)
                for batch, col in wires:
                    line_shader.uniform_float("color", col)
                    batch.draw(line_shader)
            if lines:
                line_shader.uniform_float("lineWidth", 2.0 * px)
                for batch, col in lines:
                    line_shader.uniform_float("color", col)
                    batch.draw(line_shader)
        if dots:
            
            
            
            size = max(1.0, float(getattr(wm, "mpp_onion_dot_size", 3)) * px)
            point_shader = _point_shader()
            program_size = getattr(gpu.state, "program_point_size_set", None)
            if program_size is not None:
                program_size(False)
            gpu.state.point_size_set(size)
            point_shader.bind()
            try:
                point_shader.uniform_float("size", size)
            except (ValueError, TypeError, AttributeError):
                pass
            for batch, col in dots:
                point_shader.uniform_float("color", col)
                batch.draw(point_shader)
            gpu.state.point_size_set(1.0)
        gpu.state.depth_test_set('NONE')
        gpu.state.blend_set('NONE')
    except Exception as e:  
        print("Motion Path Pro: onion skin drawing error:", e)






def _on_redraw(self, context):
    curve_path.tag_redraw()


def _on_resync(self, context):
    request_sync()
    curve_path.tag_redraw()


_PROPS = {
    "mpp_onion": lambda: bpy.props.BoolProperty(
        name="Onion Skin",
        description="Show a see-through copy of the character on every keyframe of the keyframe "
                    "handles. It follows the key while you drag it",
        default=False, update=_on_resync),
    "mpp_onion_form": lambda: bpy.props.EnumProperty(
        name="Form",
        description="How the ghosts of the character's meshes are drawn",
        items=[('SOLID', "Solid", "See-through surface of the meshes (back faces hidden)", 'FACESEL', 0),
               ('WIREFRAME', "Wireframe", "The edges of the meshes", 'EDGESEL', 1),
               ('DOTS', "Dots", "A dot on every vertex of the meshes", 'VERTEXSEL', 2)],
        default='SOLID', update=_on_redraw),
    "mpp_onion_dot_size": lambda: bpy.props.IntProperty(
        name="Dot Size", description="Size of the onion skin dots, in pixels",
        default=3, min=1, max=12, subtype='PIXEL', update=_on_redraw),
    "mpp_onion_range": lambda: bpy.props.EnumProperty(
        name="Keys",
        items=[('ALL', "All Keys", "A ghost on every keyframe"),
               ('NEAR', "Around Frame", "Only the keyframes nearest to the current frame (lighter)")],
        default='ALL', update=_on_resync),
    "mpp_onion_before": lambda: bpy.props.IntProperty(
        name="Before", description="Keyframes shown before the current frame",
        default=2, min=0, soft_max=10, update=_on_resync),
    "mpp_onion_after": lambda: bpy.props.IntProperty(
        name="After", description="Keyframes shown after the current frame",
        default=2, min=0, soft_max=10, update=_on_resync),
    "mpp_onion_follow": lambda: bpy.props.EnumProperty(
        name="Follow Drag",
        items=[('REALTIME', "Real Time",
                "While you drag a key, the rig is evaluated at that key so the ghost follows it "
                "exactly, also when the body follows the control by IK or constraints (Rigify, "
                "Auto-Rig Pro ...). Updates as fast as the rig allows; the characters show their "
                "low resolution cage while you drag"),
               ('FAST', "Fast",
                "No evaluation: the ghost moves with the dragged bone and its children only "
                "(the lightest). Parts that follow by IK or constraints update when you let go"),
               ('RELEASE', "On Release", "The ghost updates when you let go of the mouse")],
        default='REALTIME'),
    "mpp_onion_selected": lambda: bpy.props.BoolProperty(
        name="Only Selected Keys", description="Ghosts only on the selected keyframes",
        default=False, update=_on_resync),
    "mpp_onion_opacity": lambda: bpy.props.FloatProperty(
        name="Opacity", default=0.25, min=0.02, max=1.0, subtype='FACTOR', update=_on_redraw),
    "mpp_onion_in_front": lambda: bpy.props.BoolProperty(
        name="In Front", description="Draw the ghosts on top of everything (off: hidden behind meshes)",
        default=False, update=_on_redraw),
    "mpp_onion_color_before": lambda: bpy.props.FloatVectorProperty(
        name="Before", description="Ghost color before the current frame", subtype='COLOR_GAMMA',
        size=3, min=0.0, max=1.0, default=(1.0, 0.32, 0.22), update=_on_redraw),
    "mpp_onion_color_after": lambda: bpy.props.FloatVectorProperty(
        name="After", description="Ghost color after the current frame", subtype='COLOR_GAMMA',
        size=3, min=0.0, max=1.0, default=(0.25, 0.85, 0.35), update=_on_redraw),
}


def draw_settings(layout, context):
    wm = context.window_manager
    row = layout.row(align=True)
    row.prop(wm, "mpp_onion_form", expand=True)
    col = layout.column()
    col.use_property_split = True
    col.use_property_decorate = False
    if wm.mpp_onion_form == 'DOTS':
        col.prop(wm, "mpp_onion_dot_size")
    col.prop(wm, "mpp_onion_follow")
    col.prop(wm, "mpp_onion_range")
    if wm.mpp_onion_range == 'NEAR':
        sub = col.column(align=True)
        sub.prop(wm, "mpp_onion_before", text="Keys Before")
        sub.prop(wm, "mpp_onion_after", text="After")
    col.prop(wm, "mpp_onion_selected")
    col.prop(wm, "mpp_onion_opacity")
    col.prop(wm, "mpp_onion_in_front")
    sub = col.column(align=True)
    sub.prop(wm, "mpp_onion_color_before", text="Color Before")
    sub.prop(wm, "mpp_onion_color_after", text="After")
    layout.operator("motion_path.onion_refresh", icon='FILE_REFRESH')


class MOTIONPATH_OT_OnionRefresh(bpy.types.Operator):
    """Read the meshes again and rebuild the onion skin (after editing the meshes,
    their weights or modifiers)"""
    bl_idname = "motion_path.onion_refresh"
    bl_label = "Refresh Onion Skin"

    def execute(self, context):
        if not enabled(context.window_manager):
            self.report({'WARNING'}, "Turn on Edit Keys on Path and Onion Skin first")
            return {'CANCELLED'}
        clear(meshes=True)
        sync(context, force=True)
        n, t = stats()
        self.report({'INFO'}, "Onion skin: %d ghost(s) in %.2fs" % (n, t))
        return {'FINISHED'}


classes = (MOTIONPATH_OT_OnionRefresh,)


@persistent
def _on_load_post(*_args):
    clear(meshes=True)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    for name, make in _PROPS.items():
        setattr(bpy.types.WindowManager, name, make())
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not _draw_handle and not bpy.app.background:
        _draw_handle.append(bpy.types.SpaceView3D.draw_handler_add(_draw, (), 'WINDOW', 'POST_VIEW'))


def unregister():
    for fn in (_sync_timer, _live_timer):
        if bpy.app.timers.is_registered(fn):
            bpy.app.timers.unregister(fn)
    for h in _draw_handle:
        bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
    _draw_handle.clear()
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    for name in _PROPS:
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    clear(meshes=True)
