


import time
import traceback
from array import array

import bpy
import gpu
from bpy.app.handlers import persistent
from bpy_extras import view3d_utils
from gpu_extras.batch import batch_for_shader
from mathutils import Vector

from . import curve_path
from . import onion

try:
    from bpy_extras.anim_utils import action_ensure_channelbag_for_slot
except ImportError:  
    action_ensure_channelbag_for_slot = None


PICK_RADIUS = 10.0              
PATH_UPDATE_RATE = 1.0 / 30.0   
AUTO_TYPES = frozenset(('AUTO', 'AUTO_CLAMPED'))
SYNTH_MIN = 0.03                
SYNTH_LEN = 0.25                






class _Point:
    """One location keyframe as shown in the viewport."""
    __slots__ = ("frame", "pos", "J", "hl", "hr", "sel", "tl", "tr",
                 "use_l", "use_r", "syn_l", "syn_r")

    def __init__(self, frame, pos, J):
        self.frame = frame
        self.pos = pos          
        self.J = J              
        self.hl = Vector()      
        self.hr = Vector()      
        self.sel = False
        self.tl = self.tr = 'AUTO_CLAMPED'
        self.use_l = self.use_r = False   
        self.syn_l = self.syn_r = None    


class _Target:
    __slots__ = ("key", "points")

    def __init__(self, key):
        self.key = key          
        self.points = []


class _Press:
    """Mouse button down on a point / handle, before it turns into a drag."""
    __slots__ = ("ident", "view", "mouse", "grab", "shift", "ctrl", "was_sel", "added")


class _Drag:
    __slots__ = ("ident", "key", "kind", "side", "frames", "view", "grab", "depth",
                 "key_pos", "Jinv", "orig", "inserted", "locks", "smart", "Jinv_grab")


class _State:
    def __init__(self):
        self.targets = []
        self.watch = None
        self.version = -1
        self.sel_sig = None
        self.incomplete = False
        self.dirty = True
        self.hover = None       
        self.press = None
        self.drag = None
        self.token = 0          
        self.path_t = 0.0

    def clear(self):
        token = self.token
        self.__init__()
        self.token = token


_st = _State()
_draw_handle = []




_keys = []


def is_busy():
    return _st.drag is not None or _st.press is not None






def loc_path(bone):
    if bone:
        return 'pose.bones["%s"].location' % bpy.utils.escape_identifier(bone)
    return "location"


def item_of(key):
    ob = bpy.data.objects.get(key[0])
    if ob is None:
        return None, None
    if key[1]:
        pb = ob.pose.bones.get(key[1]) if ob.pose is not None else None
        return ob, pb
    return ob, ob


def loc_fcurves(ob, bone, include_muted=False):
    """[X, Y, Z] location F-Curves of the assigned action slot (None where missing)."""
    fcurves = curve_path.get_anim_fcurves(ob) if ob is not None else None
    if not fcurves:
        return [None, None, None]
    path = loc_path(bone)
    out = []
    for i in range(3):
        fc = fcurves.find(path, index=i)
        if fc is not None and fc.mute and not include_muted:
            fc = None
        out.append(fc)
    return out


def key_index_map(fc, lo=None, hi=None):
    """{frame: key index} of an F-Curve (optionally within [lo, hi])."""
    kps = fc.keyframe_points
    n = len(kps)
    if not n:
        return {}
    co = array('f', bytes(8 * n))
    kps.foreach_get("co", co)
    out = {}
    for j in range(n):
        f = int(round(co[2 * j]))
        if (lo is None or lo <= f <= hi) and f not in out:
            out[f] = j
    return out


def locked_axes(ob, item, bone, fcs):
    """Axes a drag must not change: locked, driven, muted, connected bones."""
    try:
        locks = [bool(v) for v in item.lock_location]
    except Exception:
        locks = [False, False, False]
    if bone and getattr(item.bone, "use_connect", False):
        return [True, True, True]   
    ad = ob.animation_data
    drivers = ad.drivers if ad is not None else None
    path = loc_path(bone)
    for i in range(3):
        if drivers is not None and drivers.find(path, index=i) is not None:
            locks[i] = True
        if fcs[i] is not None and fcs[i].mute:
            locks[i] = True
    return locks


def _ensure_channelbag(action, slot):
    """Channel bag of ``slot`` in the action (created when missing).

    Blender 4.4 / 4.5 have no action_ensure_channelbag_for_slot(): go through
    the layer / strip API instead. The legacy ``action.fcurves`` must not be
    used on slotted actions: it always writes into the channels of the *first*
    slot, so on a shared action (camera object + lens, two objects ...) the
    new keys would land on the wrong object."""
    if action_ensure_channelbag_for_slot is not None:
        return action_ensure_channelbag_for_slot(action, slot)
    layer = action.layers[0] if len(action.layers) else action.layers.new("Layer")
    strip = layer.strips[0] if len(layer.strips) else layer.strips.new(type='KEYFRAME')
    return strip.channelbag(slot, ensure=True)


def _new_fcurve(ob, path, index, group):
    ad = ob.animation_data
    if ad is None or ad.action is None:
        return None
    action = ad.action
    try:
        if curve_path.action_get_channelbag_for_slot is None:
            
            return action.fcurves.new(path, index=index, action_group=group)
        
        slot = getattr(ad, "action_slot", None)
        if slot is None:
            return None
        cb = _ensure_channelbag(action, slot)
        fcurves = cb.fcurves
        if hasattr(fcurves, "ensure"):            
            return fcurves.ensure(path, index=index, group_name=group)
        fc = fcurves.find(path, index=index)       
        if fc is None:
            fc = fcurves.new(path, index=index)
        if group and fc.group is None:
            grp = cb.groups.get(group)
            if grp is None:
                grp = cb.groups.new(group)
            fc.group = grp
        return fc
    except Exception:
        traceback.print_exc()
        return None


def ensure_keys(ob, item, bone, frames, locks, missing_curves_only=False):
    """Give every free axis a key on the dragged frames, so the point can move
    in every direction (keys made with "Only Insert Needed" often miss axes).
    missing_curves_only: only axes without any F-Curve get one (Smart Offset).
    Returns [(axis, frame, F-Curve created)] for cancelling."""
    inserted = []
    path = loc_path(bone)
    group = bone if bone else "Object Transforms"
    for i in range(3):
        if locks[i]:
            continue
        fcurves = curve_path.get_anim_fcurves(ob)
        fc = fcurves.find(path, index=i) if fcurves else None
        if fc is not None and missing_curves_only:
            continue
        created = False
        static = 0.0
        if fc is None:
            fc = _new_fcurve(ob, path, i, group)
            if fc is None:
                continue
            created = True
            try:
                static = float(item.location[i])
            except Exception:
                static = 0.0
        have = key_index_map(fc)
        added = False
        for f in frames:
            if f in have:
                continue
            value = static if created else fc.evaluate(f)
            fc.keyframe_points.insert(f, value, options={'FAST'})
            inserted.append((i, f, created))
            added = True
        if added:
            fc.update()
    return inserted


def remove_inserted(ob, bone, inserted):
    fcurves = curve_path.get_anim_fcurves(ob)
    if not fcurves:
        return
    path = loc_path(bone)
    created_axes = set()
    for i, f, created in inserted:
        fc = fcurves.find(path, index=i)
        if fc is None:
            continue
        j = key_index_map(fc).get(f)
        if j is not None:
            fc.keyframe_points.remove(fc.keyframe_points[j])
        if created:
            created_axes.add(i)
    for i in created_axes:
        fc = fcurves.find(path, index=i)
        if fc is not None and not len(fc.keyframe_points):
            try:
                fcurves.remove(fc)
            except Exception:
                pass


def deselect_all(obj_names):
    for name in obj_names:
        ob = bpy.data.objects.get(name)
        fcurves = curve_path.get_anim_fcurves(ob) if ob is not None else None
        if not fcurves:
            continue
        for fc in fcurves:
            kps = fc.keyframe_points
            n = len(kps)
            if not n:
                continue
            zeros = [False] * n
            kps.foreach_set("select_control_point", zeros)
            kps.foreach_set("select_left_handle", zeros)
            kps.foreach_set("select_right_handle", zeros)


def select_frames(key, frames, state=True):
    ob = bpy.data.objects.get(key[0])
    for fc in loc_fcurves(ob, key[1], include_muted=True):
        if fc is None:
            continue
        m = key_index_map(fc)
        for f in frames:
            j = m.get(f)
            if j is None:
                continue
            kp = fc.keyframe_points[j]
            kp.select_control_point = state
            kp.select_left_handle = state
            kp.select_right_handle = state






def path_targets(context):
    """[(object name, bone name or "")] of every motion path shown in the viewport."""
    wm = context.window_manager
    if not getattr(wm, "mpp_show_paths", True):
        return []
    out = []
    for item in curve_path.path_objects(context.scene):
        key = curve_path.path_key(item)
        if key is None:
            continue
        ob = item.target
        try:
            if not ob.visible_get():
                continue
        except Exception:
            continue
        if key[1] and (ob.pose is None or ob.pose.bones.get(key[1]) is None):
            continue
        out.append(key)
    return out


def context_targets(context):
    """Sorted [(object name, bone name or "")] that Set on Selected Keys looks
    at: bones / objects with handles or a motion path, plus the selection.
    (Only used to find selected keys, never to decide where handles show.)"""
    out = set(path_targets(context))
    out.update(selected_targets(context))
    out.update(handle_targets(context))
    return sorted(out)


def handle_targets(context=None):
    """Sorted [(object name, bone name or "")] the keyframe handles are shown
    on: only the bones / objects picked with Edit Keys on Path or Add Selected
    (skipping deleted or hidden ones). The current selection plays no part."""
    out = []
    for key in _keys:
        ob = bpy.data.objects.get(key[0])
        if ob is None:
            continue
        try:
            if not ob.visible_get():
                continue
        except Exception:
            continue
        if key[1] and (ob.pose is None or ob.pose.bones.get(key[1]) is None):
            continue
        out.append(key)
    return sorted(out)


def handle_keys():
    """Every bone / object picked for handles (including hidden ones)."""
    return list(_keys)


def picked_targets(context):
    """Sorted [(object name, bone name or "")] of the selection, picked with the
    same rule as Calculate Path (the Bone / Object buttons): the selected bones
    in Pose Mode, the selected objects in Object Mode."""
    ob = getattr(context, "active_object", None)
    if ob is None or ob.mode not in {'POSE', 'OBJECT'}:
        return []
    try:
        targets = curve_path.selection_targets(context)
    except Exception:
        traceback.print_exc()
        return []
    return sorted({(o.name, b or "") for o, b in targets})


def describe(keys):
    """'"Hand.L"', '3 bones', '2 bones and 1 object' ..."""
    keys = list(keys)
    if not keys:
        return "nothing"
    if len(keys) == 1:
        return '"%s"' % (keys[0][1] or keys[0][0])
    bones = sum(1 for k in keys if k[1])
    objs = len(keys) - bones
    parts = []
    if bones:
        parts.append("%d bone%s" % (bones, "" if bones == 1 else "s"))
    if objs:
        parts.append("%d object%s" % (objs, "" if objs == 1 else "s"))
    return " and ".join(parts)


def selected_targets(context):
    """Sorted [(object name, bone name or "")]: selected bones in Pose Mode,
    selected objects (+ the active one) in Object Mode."""
    try:
        ob = context.active_object
    except Exception:
        ob = None
    if ob is None:
        return []
    out = set()
    if ob.mode == 'POSE':
        bones = None
        try:
            bones = context.selected_pose_bones
        except Exception:
            pass
        if bones is None:
            bones = []
            for o in context.view_layer.objects:
                if o.mode == 'POSE' and o.pose is not None:
                    bones += [pb for pb in o.pose.bones if curve_path._bone_selected(pb)]
        for pb in bones:
            out.add((pb.id_data.name, pb.name))
        try:
            apb = context.active_pose_bone
        except Exception:
            apb = None
        if apb is not None:
            out.add((apb.id_data.name, apb.name))
    elif ob.mode == 'OBJECT':
        objs = None
        try:
            objs = context.selected_objects
        except Exception:
            pass
        if objs is None:
            objs = [o for o in context.view_layer.objects if o.select_get()]
        for o in list(objs) + [ob]:
            if curve_path.PROP_TARGET not in o:
                out.add((o.name, ""))
    return sorted(out)


def _read_point(p, fcs, idx):
    """Handles, selection and handle types of a key from its F-Curves."""
    hl = Vector((0.0, 0.0, 0.0))
    hr = Vector((0.0, 0.0, 0.0))
    sel = use_l = use_r = False
    tl = tr = None
    for i in range(3):
        fc = fcs[i]
        if fc is None:
            continue
        j = idx[i].get(p.frame)
        if j is None:
            continue
        kps = fc.keyframe_points
        kp = kps[j]
        co = kp.co[1]
        hl[i] = co - kp.handle_left[1]
        hr[i] = kp.handle_right[1] - co
        sel = sel or kp.select_control_point
        if tl is None:
            tl, tr = kp.handle_left_type, kp.handle_right_type
        
        if kp.interpolation == 'BEZIER' and j + 1 < len(kps):
            use_r = True
        if j > 0 and kps[j - 1].interpolation == 'BEZIER':
            use_l = True
    p.hl, p.hr, p.sel = hl, hr, sel
    p.tl, p.tr = tl or 'FREE', tr or 'FREE'
    p.use_l, p.use_r = use_l, use_r


def _synthesize(points):
    """Flat handles (first / last key, Auto Clamped extremes) have no length in
    3D. Show a grabbable placeholder pointing to the neighbour key instead."""
    for k, p in enumerate(points):
        p.syn_l = p.syn_r = None
        for side, nb, use in (('L', points[k - 1] if k > 0 else None, p.use_l),
                              ('R', points[k + 1] if k + 1 < len(points) else None, p.use_r)):
            if nb is None or not use:
                continue
            gap = nb.pos - p.pos
            if gap.length < 1e-6:
                continue
            real = p.J @ (p.hl if side == 'L' else p.hr)
            if real.length < SYNTH_MIN * gap.length:
                if side == 'L':
                    p.syn_l = gap * SYNTH_LEN
                else:
                    p.syn_r = gap * SYNTH_LEN


def reread(t):
    """Re-read handles / selection of a target from its keys (positions unchanged)."""
    ob = bpy.data.objects.get(t.key[0])
    fcs = loc_fcurves(ob, t.key[1])
    idx = [key_index_map(fc) if fc is not None else {} for fc in fcs]
    for p in t.points:
        _read_point(p, fcs, idx)
    _synthesize(t.points)


def build_target(key, allow_bake):
    """(target, complete). complete is False when frames still need a bake."""
    t = _Target(key)
    ob = bpy.data.objects.get(key[0])
    if ob is None:
        return t, True
    fcs = loc_fcurves(ob, key[1])
    if not any(fc is not None for fc in fcs):
        return t, True
    frames = curve_path.path_frames(key=key)
    if not frames:
        return t, True
    lo, hi = frames[0], frames[-1]
    idx = [key_index_map(fc, lo, hi) if fc is not None else {} for fc in fcs]
    all_frames = sorted(set(idx[0]) | set(idx[1]) | set(idx[2]))
    if not all_frames:
        return t, True
    got = curve_path.key_points(ob, key[1], all_frames,
                                bake_stale=allow_bake, bake_missing=allow_bake)
    complete = True
    for f in all_frames:
        g = got.get(f)
        if g is None:
            complete = False
            continue
        p = _Point(f, g[0], g[1])
        _read_point(p, fcs, idx)
        t.points.append(p)
    _synthesize(t.points)
    return t, complete


def rebuild(targets, allow_bake):
    new = []
    complete = True
    for key in targets:
        try:
            t, ok = build_target(key, allow_bake)
        except Exception:
            traceback.print_exc()
            t, ok = _Target(key), False
        new.append(t)
        complete = complete and ok
    _st.targets = new
    
    _st.incomplete = (not complete) and not allow_bake


def _selection_sig(targets):
    parts = []
    for key in targets:
        ob = bpy.data.objects.get(key[0])
        for fc in loc_fcurves(ob, key[1]):
            if fc is None:
                parts.append(None)
                continue
            n = len(fc.keyframe_points)
            sel = array('b', bytes(n))
            if n:
                fc.keyframe_points.foreach_get("select_control_point", sel)
            parts.append(sel.tobytes())
    return hash(tuple(parts))


def refresh(context, force=False):
    """Rebuild the shown keys when the selection, the keys or the range changed."""
    if _st.drag is not None or _st.press is not None:
        return False
    wm = context.window_manager
    scene = context.scene
    targets = tuple(handle_targets(context))
    watch = (targets, scene.name, wm.mpp_range_mode, wm.mpp_frame_start, wm.mpp_frame_end,
             scene.frame_start, scene.frame_end, scene.use_preview_range,
             scene.frame_preview_start, scene.frame_preview_end)
    if targets:
        curve_path.poll_changes(curve_path.tracked_objects(targets))
    version = curve_path.change_version()
    sel = _selection_sig(targets)
    busy = curve_path.is_busy()
    if not (force or _st.dirty or watch != _st.watch or version != _st.version
            or sel != _st.sel_sig or (_st.incomplete and not busy)):
        return False
    _st.watch, _st.sel_sig, _st.dirty = watch, sel, False
    rebuild(targets, allow_bake=not busy)
    _st.version = curve_path.change_version()
    try:
        onion.sync(context)
    except Exception:
        traceback.print_exc()
    curve_path.tag_redraw()
    return True


def find_point(key, frame):
    for t in _st.targets:
        if t.key == key:
            for p in t.points:
                if p.frame == frame:
                    return t, p
            return t, None
    return None, None


def handle_world(p, side):
    if side == 'L':
        if p.syn_l is not None:
            return p.pos + p.syn_l
        return p.pos - p.J @ p.hl
    if p.syn_r is not None:
        return p.pos + p.syn_r
    return p.pos + p.J @ p.hr


def shown_sides(wm, p):
    if not (wm.show_all_handles or (wm.show_only_selected_handles and p.sel)):
        return ()
    return tuple(side for side, use in (('L', p.use_l), ('R', p.use_r)) if use)






def _tick():
    try:
        wm = bpy.context.window_manager
    except Exception:
        return None
    if wm is None or not getattr(wm, "direct_manipulation_active", False):
        return None
    interval = max(0.05, getattr(wm, "auto_midawq_timer_interval", 0.1))
    if _st.drag is not None or _st.press is not None or curve_path.is_playing():
        return interval
    try:
        with curve_path.ctx_override():
            refresh(bpy.context)
            onion.sync(bpy.context)
    except Exception:
        traceback.print_exc()
    return interval


def start_tick():
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, first_interval=0.05)


def stop_tick():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)






_HANDLE_THEME = {'FREE': "handle_free", 'AUTO': "handle_auto", 'VECTOR': "handle_vect",
                 'ALIGNED': "handle_align", 'AUTO_CLAMPED': "handle_auto_clamped"}
_HANDLE_DEFAULT = {'FREE': ((0.455, 0.349, 0.0), (1.0, 0.765, 0.0)),
                   'AUTO': ((0.455, 0.051, 0.0), (1.0, 0.098, 0.0)),
                   'VECTOR': ((0.137, 0.137, 0.455), (0.267, 0.267, 1.0)),
                   'ALIGNED': ((0.082, 0.439, 0.0), (0.447, 1.0, 0.341)),
                   'AUTO_CLAMPED': ((0.502, 0.188, 0.376), (0.941, 0.565, 0.627))}


def handle_theme():
    """Graph Editor colours: handle lines per handle type, key and handle vertices."""
    rgb = curve_path._rgb
    try:
        th = bpy.context.preferences.themes[0]
    except Exception:
        th = None
    src = getattr(getattr(th, "common", None), "curves", None)   
    if src is None or not hasattr(src, "handle_auto"):
        src = getattr(th, "graph_editor", None)                   
    ge = getattr(th, "graph_editor", None)
    out = {}
    for htype, name in _HANDLE_THEME.items():
        d0, d1 = _HANDLE_DEFAULT[htype]
        sel = rgb(src, name.replace("handle_", "handle_sel_"), d1)
        
        out[(htype, False)] = curve_path._mix(rgb(src, name, d0), sel, 0.6)
        out[(htype, True)] = sel
    out["hvert"] = rgb(src, "handle_vertex", (0.0, 0.0, 0.0))
    out["hvert_sel"] = rgb(src, "handle_vertex_select", (1.0, 0.522, 0.0))
    out["key"] = rgb(ge, "vertex", (0.0, 0.0, 0.0))
    out["key_sel"] = rgb(ge, "vertex_select", (1.0, 0.522, 0.0))
    return out


def _rgba(c, a=1.0):
    return (c[0], c[1], c[2], a)


_DARK = (0.0, 0.0, 0.0, 0.9)
_LIGHT = (0.85, 0.85, 0.85, 0.95)
_WHITE = (1.0, 1.0, 1.0, 1.0)


def _draw():
    try:
        ctx = bpy.context
        wm = ctx.window_manager
        if not getattr(wm, "direct_manipulation_active", False) or not _st.targets:
            return
        space = ctx.space_data
        if space is None or not space.overlay.show_overlays:
            return
        region, rv3d = ctx.region, ctx.region_data
        if region is None or rv3d is None:
            return
        _draw_overlay(ctx, wm, region, rv3d)
    except Exception as e:  
        print("Motion Path Pro: handle drawing error:", e)


def _draw_overlay(ctx, wm, region, rv3d):
    ui = curve_path.ui_scale()
    px = curve_path.pixel_size()
    ht = handle_theme()
    th = curve_path.theme_colors()
    to_2d = view3d_utils.location_3d_to_region_2d
    hover = _st.hover
    active = _st.drag.ident if _st.drag is not None else (_st.press.ident if _st.press is not None else None)
    show_knum = getattr(wm, "mpp_show_keyframes", True) and getattr(wm, "mpp_show_keyframe_numbers", False)
    r_key, r_handle, ring = 4.5 * ui, 3.5 * ui, 1.25 * px

    line_pos, line_col = [], []
    h_out, h_in = ([], []), ([], [])
    k_glow, k_out, k_in = ([], []), ([], []), ([], [])
    labels = []
    for t in _st.targets:
        numbers = show_knum and not curve_path.has_visible_path(t.key)
        for p in t.points:
            s = to_2d(region, rv3d, p.pos)
            if s is None:
                continue
            for side in shown_sides(wm, p):
                hs = to_2d(region, rv3d, handle_world(p, side))
                if hs is None:
                    continue
                placeholder = (p.syn_l if side == 'L' else p.syn_r) is not None
                htype = p.tl if side == 'L' else p.tr
                c = _rgba(ht.get((htype, p.sel), ht[('FREE', p.sel)]), 0.5 if placeholder else 1.0)
                line_pos += [(s.x, s.y, 0.0), (hs.x, hs.y, 0.0)]
                line_col += [c, c]
                ident = (t.key, p.frame, 'HANDLE', side)
                hot = ident == hover or ident == active
                fill = _WHITE if hot else _rgba(ht["hvert_sel"] if p.sel else ht["hvert"])
                curve_path.add_dot(*h_out, hs.x, hs.y, r_handle + ring, _DARK if (p.sel or hot) else _LIGHT)
                curve_path.add_dot(*h_in, hs.x, hs.y, r_handle, fill)
            ident = (t.key, p.frame, 'POINT', None)
            if ident == active:
                fill = _WHITE
            else:
                fill = _rgba(ht["key_sel"] if p.sel else ht["key"])
            if ident == hover or ident == active:
                curve_path.add_dot(*k_glow, s.x, s.y, r_key + ring + 2.0 * px, _WHITE)
            curve_path.add_dot(*k_out, s.x, s.y, r_key + ring, _DARK if p.sel else _LIGHT)
            curve_path.add_dot(*k_in, s.x, s.y, r_key, fill)
            if numbers:
                labels.append((s.x + r_key * 0.5, s.y, str(p.frame), th["key"]))

    if line_pos:
        shader = curve_path.builtin_shader('POLYLINE_SMOOTH_COLOR')
        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float("viewportSize", (region.width, region.height))
        shader.uniform_float("lineWidth", 1.5 * px)
        batch_for_shader(shader, 'LINES', {"pos": line_pos, "color": line_col}).draw(shader)
        gpu.state.blend_set('NONE')
    curve_path.draw_dots(h_out, h_in, k_glow, k_out, k_in)
    curve_path.draw_labels(labels)






_ui_blocker = [None]


def set_ui_blocker(fn):
    """fn(area, region, x, y) -> True when (x, y) (region pixels) is on an
    on-screen panel (the HUD): clicks there are not for the keyframe handles."""
    _ui_blocker[0] = fn


def _blocked(area, region, mx, my):
    fn = _ui_blocker[0]
    if fn is None:
        return False
    try:
        return bool(fn(area, region, mx - region.x, my - region.y))
    except Exception:
        return False


def view_under_mouse(context, event):
    """(area, region, region_3d) of the 3D viewport under the mouse, or None
    over headers, toolbars, sidebars and the HUD. Works for every 3D view of
    the window and for each quad-view region."""
    win = context.window
    if win is None or win.screen is None:
        return None
    mx, my = event.mouse_x, event.mouse_y
    for area in win.screen.areas:
        if area.type != 'VIEW_3D':
            continue
        if not (area.x <= mx < area.x + area.width and area.y <= my < area.y + area.height):
            continue
        hit = None
        for r in area.regions:
            if not (r.x <= mx < r.x + r.width and r.y <= my < r.y + r.height):
                continue
            if r.type == 'WINDOW':
                hit = hit or r
            elif r.width > 1 and r.height > 1:
                return None   
        if hit is None or _blocked(area, hit, mx, my):
            return None
        rv3d = getattr(hit, "data", None)
        if rv3d is None:       
            rv3d = getattr(area.spaces.active, "region_3d", None)
        if rv3d is not None:
            return (area, hit, rv3d)
        return None
    return None


def pick(region, rv3d, mx, my, wm):
    """((key, frame, kind, side), screen position) of the closest point / handle."""
    m = Vector((mx, my))
    best, best_d = None, PICK_RADIUS * curve_path.ui_scale()
    to_2d = view3d_utils.location_3d_to_region_2d
    for t in _st.targets:
        for p in t.points:
            s = to_2d(region, rv3d, p.pos)
            if s is not None:
                d = (s - m).length
                if d < best_d:
                    best, best_d = ((t.key, p.frame, 'POINT', None), s), d
            for side in shown_sides(wm, p):
                hs = to_2d(region, rv3d, handle_world(p, side))
                if hs is None:
                    continue
                d = (hs - m).length
                if d < best_d:
                    best, best_d = ((t.key, p.frame, 'HANDLE', side), hs), d
    return best


def _target_names():
    return {t.key[0] for t in _st.targets}


def _reread_all():
    for t in _st.targets:
        reread(t)
    _st.sel_sig = _selection_sig([t.key for t in _st.targets])


def press(context, event, hit, view):
    (key, frame, kind, side), s2d = hit
    t, p = find_point(key, frame)
    if p is None:
        return False
    region = view[1]
    pr = _Press()
    pr.ident = (key, frame, kind, side)
    pr.view = view
    pr.mouse = (event.mouse_x, event.mouse_y)
    pr.grab = s2d - Vector((event.mouse_x - region.x, event.mouse_y - region.y))
    pr.shift, pr.ctrl = event.shift, event.ctrl
    pr.was_sel = p.sel
    pr.added = False
    if kind == 'POINT':
        if event.ctrl and not event.shift:     
            frames = [q.frame for q in t.points if q.sel] + [frame]
            lo, hi = min(frames), max(frames)
            select_frames(key, [q.frame for q in t.points if lo <= q.frame <= hi])
        elif event.shift:
            
            if not p.sel:
                select_frames(key, [frame])
                pr.added = True
        else:
            
            
            
            
            deselect_all(_target_names())
            select_frames(key, [frame])
    else:
        if not p.sel:
            if not event.shift:
                deselect_all(_target_names())
            select_frames(key, [frame])
            pr.added = True
    _reread_all()
    _st.press = pr
    curve_path.tag_redraw()
    return True


def grab_key(context, event, view, key, frame):
    """Press a key point from code (Insert Keys on Path): a key just added on
    the path can then be dragged in the same click."""
    _st.dirty = True
    refresh(context, force=True)
    _t, p = find_point(key, frame)
    if p is None:
        return False
    s = view3d_utils.location_3d_to_region_2d(view[1], view[2], p.pos)
    if s is None:
        return False
    return press(context, event, ((key, frame, 'POINT', None), s), view)


def click(context):
    """Mouse released without dragging."""
    pr = _st.press
    _st.press = None
    if pr is None:
        return
    key, frame, kind, _side = pr.ident
    if kind == 'POINT' and not pr.ctrl:
        if pr.shift:
            if pr.was_sel and not pr.added:
                select_frames(key, [frame], False)
        elif pr.was_sel:
            deselect_all(_target_names())
            select_frames(key, [frame])
    _reread_all()
    curve_path.tag_redraw()


def begin_drag(context):
    pr = _st.press
    key, frame, kind, side = pr.ident
    t, p = find_point(key, frame)
    ob, item = item_of(key)
    if p is None or ob is None or item is None:
        _st.press = None
        return False
    smart = bool(getattr(context.window_manager, "generic_offest_active", False))
    locks = locked_axes(ob, item, key[1], loc_fcurves(ob, key[1], include_muted=True))
    if smart:
        
        
        inserted = ensure_keys(ob, item, key[1], [frame], locks, missing_curves_only=True)
        frames = sorted({f for fc in loc_fcurves(ob, key[1], include_muted=True) if fc is not None
                         for f in key_index_map(fc)} | {frame})
        kind = 'POINT'
    else:
        if kind == 'POINT':
            frames = sorted({q.frame for q in t.points if q.sel} | {frame})
        else:
            frames = [frame]
        inserted = ensure_keys(ob, item, key[1], frames, locks)
    orig = {}
    for i, fc in enumerate(loc_fcurves(ob, key[1], include_muted=True)):
        if fc is None or locks[i]:
            continue
        m = key_index_map(fc)
        for f in frames:
            j = m.get(f)
            if j is None:
                continue
            kp = fc.keyframe_points[j]
            orig[(i, f)] = (tuple(kp.co), tuple(kp.handle_left), tuple(kp.handle_right),
                            kp.handle_left_type, kp.handle_right_type,
                            kp.select_left_handle, kp.select_control_point, kp.select_right_handle)
    pts = {q.frame: q for q in t.points}
    d = _Drag()
    d.ident = pr.ident
    d.key, d.kind, d.side = key, kind, side
    d.smart = smart
    d.frames = list(frames) if smart else [f for f in frames if f in pts]
    d.view, d.grab = pr.view, pr.grab
    d.key_pos = p.pos.copy()
    grabbed_handle = pr.ident[2] == 'HANDLE'
    d.depth = handle_world(p, side) if grabbed_handle else p.pos.copy()
    d.Jinv = {f: pts[f].J.inverted_safe() for f in d.frames if f in pts}
    d.Jinv_grab = p.J.inverted_safe()
    d.orig, d.inserted, d.locks = orig, inserted, locks
    _st.drag = d
    _st.press = None
    onion.drag_begin(d, t)
    try:
        context.window.cursor_modal_set('SCROLL_XY')
    except Exception:
        pass
    return True


def _apply_point_move(fcs, d, delta):
    
    
    smart_dv = d.Jinv_grab @ delta if d.smart else None
    for i, fc in enumerate(fcs):
        if fc is None or d.locks[i]:
            continue
        m = key_index_map(fc)
        for f in d.frames:
            o = d.orig.get((i, f))
            j = m.get(f)
            if o is None or j is None:
                continue
            dv = smart_dv[i] if smart_dv is not None else (d.Jinv[f] @ delta)[i]
            kp = fc.keyframe_points[j]
            kp.co = (o[0][0], o[0][1] + dv)
            kp.handle_left = (o[1][0], o[1][1] + dv)
            kp.handle_right = (o[2][0], o[2][1] + dv)


def _apply_handle_move(fcs, d, vec):
    """vec: world vector key -> handle (left handles: handle -> key)."""
    f = d.frames[0]
    local = d.Jinv[f] @ vec
    for i, fc in enumerate(fcs):
        if fc is None or d.locks[i]:
            continue
        o = d.orig.get((i, f))
        j = key_index_map(fc).get(f)
        if o is None or j is None:
            continue
        kp = fc.keyframe_points[j]
        tl, tr = o[3], o[4]
        if tl in AUTO_TYPES or tr in AUTO_TYPES:   
            tl = tr = 'ALIGNED'
        co = o[0][1]
        if d.side == 'L':
            if tl == 'VECTOR':
                tl = 'FREE'
            kp.handle_left_type, kp.handle_right_type = tl, tr
            kp.handle_left = (o[1][0], co - local[i])
            kp.handle_right = o[2]
            kp.select_left_handle, kp.select_right_handle = True, False   
        else:
            if tr == 'VECTOR':
                tr = 'FREE'
            kp.handle_left_type, kp.handle_right_type = tl, tr
            kp.handle_right = (o[2][0], co + local[i])
            kp.handle_left = o[1]
            kp.select_left_handle, kp.select_right_handle = False, True
        kp.co = o[0]


def apply_drag(world_target):
    """Move the dragged keys / handle so the grabbed element sits at ``world_target``."""
    d = _st.drag
    ob, _item = item_of(d.key)
    if ob is None:
        return False
    fcs = loc_fcurves(ob, d.key[1], include_muted=True)
    if d.kind == 'POINT':
        _apply_point_move(fcs, d, world_target - d.depth)
    else:
        vec = (world_target - d.key_pos) if d.side == 'R' else (d.key_pos - world_target)
        _apply_handle_move(fcs, d, vec)
    for fc in fcs:
        if fc is not None:
            fc.update()
    _refresh_dragged()
    return True


def _refresh_dragged():
    d = _st.drag
    t, _p = find_point(d.key, d.frames[0])
    ob = bpy.data.objects.get(d.key[0])
    if t is None or ob is None:
        return
    got = curve_path.key_points(ob, d.key[1], [p.frame for p in t.points],
                                bake_stale=False, bake_missing=False)
    for p in t.points:
        g = got.get(p.frame)
        if g is not None:
            p.pos, p.J = g
    reread(t)
    onion.drag_update(t)
    now = time.monotonic()
    if now - _st.path_t >= PATH_UPDATE_RATE and curve_path.has_paths():
        _st.path_t = now
        curve_path.poll_changes({d.key[0]}, force=True)
        curve_path.update_paths(refine=False, bake_missing=False)


def update_drag(context, event):
    d = _st.drag
    region, rv3d = d.view[1], d.view[2]
    m = Vector((event.mouse_x - region.x, event.mouse_y - region.y)) + d.grab
    w = view3d_utils.region_2d_to_location_3d(region, rv3d, m, d.depth)
    if w is None:
        return
    apply_drag(w)
    curve_path.tag_redraw()


def after_edit(context, names):
    """Bring the curve paths and the shown keys up to date after an edit."""
    wm = context.window_manager
    try:
        curve_path.poll_changes(names, force=True)
        if curve_path.has_paths():
            if getattr(wm, "auto_update_active", False):
                curve_path.update_paths(refine=False, bake_missing=False)  
            else:
                curve_path.update_paths(refine=True, preserve_pose=True)
    except Exception:
        traceback.print_exc()
    _st.dirty = True
    refresh(context, force=True)


def _restore_cursor(context):
    try:
        context.window.cursor_modal_restore()
    except Exception:
        pass


def finish_drag(context):
    d = _st.drag
    _st.drag = None
    _st.press = None
    _restore_cursor(context)
    onion.drag_end(commit=True)
    if d is None:
        return
    try:
        bpy.ops.ed.undo_push(message="Smart Offset Motion Path" if d.smart
                             else ("Move Motion Path Handle" if d.kind == 'HANDLE' else "Move Motion Path Keys"))
    except Exception:
        pass
    after_edit(context, {d.key[0]})


def cancel_drag(context):
    """Put the keys back the way they were before the drag."""
    d = _st.drag
    _st.drag = None
    _st.press = None
    _restore_cursor(context)
    onion.drag_end(commit=False)
    if d is None:
        return
    ob, _item = item_of(d.key)
    if ob is not None:
        fcs = loc_fcurves(ob, d.key[1], include_muted=True)
        for i, fc in enumerate(fcs):
            if fc is None:
                continue
            m = key_index_map(fc)
            for (axis, f), o in d.orig.items():
                j = m.get(f)
                if axis != i or j is None:
                    continue
                kp = fc.keyframe_points[j]
                kp.handle_left_type, kp.handle_right_type = o[3], o[4]
                kp.co, kp.handle_left, kp.handle_right = o[0], o[1], o[2]
                kp.select_left_handle, kp.select_control_point, kp.select_right_handle = o[5], o[6], o[7]
        remove_inserted(ob, d.key[1], d.inserted)
        for fc in loc_fcurves(ob, d.key[1], include_muted=True):
            if fc is not None:
                fc.update()
    after_edit(context, {d.key[0]})


class MOTIONPATH_DirectManipulation(bpy.types.Operator):
    """Drag keyframes and their handles on the motion path"""
    bl_idname = "motion_path.direct_manipulation"
    bl_label = "Motion Path Keyframe Handles"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        _st.token += 1
        self._token = _st.token
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _alive(self, context):
        return (getattr(context.window_manager, "direct_manipulation_active", False)
                and getattr(self, "_token", -1) == _st.token)

    def modal(self, context, event):
        if not self._alive(context):
            if _st.drag is not None:
                cancel_drag(context)
            _st.press = None
            return {'CANCELLED', 'PASS_THROUGH'}
        try:
            return self._modal(context, event)
        except Exception:
            traceback.print_exc()
            try:
                if _st.drag is not None:
                    cancel_drag(context)
            except Exception:
                traceback.print_exc()
            _st.drag = _st.press = None
            _restore_cursor(context)
            return {'PASS_THROUGH'}

    def _modal(self, context, event):
        et, ev = event.type, event.value
        wm = context.window_manager

        if _st.press is None and _st.drag is None:
            if et == 'MOUSEMOVE':
                self._hover(context, event)
                return {'PASS_THROUGH'}
            if et == 'LEFTMOUSE' and ev == 'PRESS' and not event.alt and not event.oskey:
                view = view_under_mouse(context, event)
                if view is None:
                    return {'PASS_THROUGH'}
                if _st.dirty:
                    refresh(context)
                if not _st.targets:
                    return {'PASS_THROUGH'}
                region = view[1]
                hit = pick(region, view[2], event.mouse_x - region.x, event.mouse_y - region.y, wm)
                if hit is None or not press(context, event, hit, view):
                    return {'PASS_THROUGH'}
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}

        
        if et in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            if _st.drag is None:
                pr = _st.press
                threshold = context.preferences.inputs.drag_threshold_mouse * curve_path.ui_scale()
                moved = Vector((event.mouse_x - pr.mouse[0], event.mouse_y - pr.mouse[1])).length
                if moved >= max(1.0, threshold):
                    begin_drag(context)
            if _st.drag is not None:
                update_drag(context, event)
            return {'RUNNING_MODAL'}
        if et == 'LEFTMOUSE' and ev == 'RELEASE':
            if _st.drag is not None:
                finish_drag(context)
            else:
                click(context)
            return {'RUNNING_MODAL'}
        if et in {'RIGHTMOUSE', 'ESC'} and ev == 'PRESS':
            if _st.drag is not None:
                cancel_drag(context)
            else:
                _st.press = None
            curve_path.tag_redraw()
            return {'RUNNING_MODAL'}
        if et in {'TIMER', 'TIMER_REPORT', 'WINDOW_DEACTIVATE'}:
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}   

    def _hover(self, context, event):
        ident = None
        if _st.targets:
            view = view_under_mouse(context, event)
            if view is not None:
                region = view[1]
                hit = pick(region, view[2], event.mouse_x - region.x, event.mouse_y - region.y,
                           context.window_manager)
                ident = hit[0] if hit is not None else None
        if ident != _st.hover:
            _st.hover = ident
            curve_path.tag_redraw()

    def cancel(self, context):
        
        try:
            if _st.drag is not None:
                cancel_drag(context)
        except Exception:
            traceback.print_exc()
        _st.drag = _st.press = None


def start(context, keys):
    """Start the keyframe handles on ``keys`` [(object name, bone name or "")]."""
    wm = context.window_manager
    wm.direct_manipulation_active = True
    wm.auto_sapty_active = True
    _st.clear()
    _keys[:] = sorted(set(keys))
    bpy.ops.motion_path.direct_manipulation('INVOKE_DEFAULT')
    start_tick()
    refresh(context, force=True)


def stop(context):
    wm = context.window_manager
    wm.direct_manipulation_active = False
    wm.auto_sapty_active = False
    _st.token += 1
    stop_tick()
    _st.clear()
    _keys.clear()
    onion.clear()
    curve_path.tag_redraw()


def _keys_changed(context):
    _st.dirty = True
    _st.hover = None
    refresh(context, force=True)
    curve_path.tag_redraw()


_NOTHING_SELECTED = "Select the bones (Pose Mode) or objects first"


class MOTIONPATH_DirectManipulationToggle(bpy.types.Operator):
    """Show the location keyframes of the selected bones / objects on the motion path
and drag them (and their handles) with the mouse"""
    bl_idname = "motion_path.direct_manipulation_toggle"
    bl_label = "Edit Keys on Path"
    bl_description = ("Edit Keys on Path: add keyframe handles to the bones / objects selected now "
                      "(like Calculate Path: selecting other bones later adds nothing; use Add Selected). "
                      "Drag: move one key. Shift+click: add keys. Shift+drag: move the selected keys together. "
                      "Click again to stop editing")

    def execute(self, context):
        if context.window_manager.direct_manipulation_active:
            stop(context)
            self.report({'INFO'}, "Stopped editing keys on the path")
            return {'FINISHED'}
        keys = picked_targets(context)
        if not keys:
            self.report({'WARNING'}, _NOTHING_SELECTED)
            return {'CANCELLED'}
        start(context, keys)
        self.report({'INFO'}, "Keyframe handles on %s" % describe(keys))
        return {'FINISHED'}


class MOTIONPATH_HandlesAddSelected(bpy.types.Operator):
    """Add keyframe handles to the selected bones / objects (starts Edit Keys on Path if it is off)"""
    bl_idname = "motion_path.handles_add_selected"
    bl_label = "Add Selected"
    bl_description = ("Add keyframe handles to the selected bones / objects, "
                      "keeping the ones that already have handles")

    def execute(self, context):
        keys = picked_targets(context)
        if not keys:
            self.report({'WARNING'}, _NOTHING_SELECTED)
            return {'CANCELLED'}
        if not context.window_manager.direct_manipulation_active:
            start(context, keys)
            self.report({'INFO'}, "Keyframe handles on %s" % describe(keys))
            return {'FINISHED'}
        new = [k for k in keys if k not in _keys]
        if not new:
            self.report({'INFO'}, "%s already %s handles" % (describe(keys), "has" if len(keys) == 1 else "have"))
            return {'FINISHED'}
        _keys[:] = sorted(set(_keys) | set(new))
        _keys_changed(context)
        self.report({'INFO'}, "Added keyframe handles to %s" % describe(new))
        return {'FINISHED'}


class MOTIONPATH_HandlesRemoveSelected(bpy.types.Operator):
    """Remove the keyframe handles from the selected bones / objects"""
    bl_idname = "motion_path.handles_remove_selected"
    bl_label = "Remove Selected"
    bl_description = ("Remove the keyframe handles from the selected bones / objects "
                      "(the others keep theirs)")

    def execute(self, context):
        keys = set(picked_targets(context))
        if not keys:
            self.report({'WARNING'}, _NOTHING_SELECTED)
            return {'CANCELLED'}
        gone = [k for k in _keys if k in keys]
        if not gone:
            self.report({'INFO'}, "The selection has no keyframe handles")
            return {'CANCELLED'}
        if _st.drag is not None:
            cancel_drag(context)
        _st.press = None
        _keys[:] = [k for k in _keys if k not in keys]
        if not _keys:
            stop(context)
            self.report({'INFO'}, "Removed the last keyframe handles: stopped editing keys on the path")
            return {'FINISHED'}
        _keys_changed(context)
        self.report({'INFO'}, "Removed keyframe handles from %s" % describe(gone))
        return {'FINISHED'}






HANDLE_TYPES = [
    ('FREE', "Free", "Handles can be moved independently"),
    ('ALIGNED', "Aligned", "Handles stay in line (smooth)"),
    ('VECTOR', "Vector", "Handles point to the neighbour keys"),
    ('AUTO', "Auto", "Automatic smooth handles"),
    ('AUTO_CLAMPED', "Auto Clamped", "Automatic handles without overshoot"),
]


def set_handle_types(context, handle_type, only_selected=True):
    """only_selected: the selected keys of every shown bone / object.
    Otherwise: every key of the selected bones / objects."""
    count = 0
    names = set()
    for key in (context_targets(context) if only_selected else selected_targets(context)):
        ob = bpy.data.objects.get(key[0])
        for fc in loc_fcurves(ob, key[1], include_muted=True):
            if fc is None:
                continue
            touched = False
            for kp in fc.keyframe_points:
                if only_selected and not kp.select_control_point:
                    continue
                kp.handle_left_type = handle_type
                kp.handle_right_type = handle_type
                touched = True
                count += 1
            if touched:
                fc.update()
                names.add(key[0])
    if names:
        after_edit(context, names)
    return count


class MOTIONPATH_SetHandleType(bpy.types.Operator):
    """Set the handle type of the selected location keyframes"""
    bl_idname = "motion_path.set_handle_type"
    bl_label = "Set Handle Type on Selected Keys"
    bl_options = {'REGISTER', 'UNDO'}

    handle_type: bpy.props.EnumProperty(name="Type", items=HANDLE_TYPES, default='AUTO_CLAMPED')

    def execute(self, context):
        n = set_handle_types(context, self.handle_type, only_selected=True)
        if not n:
            self.report({'WARNING'}, "No selected location keyframes")
            return {'CANCELLED'}
        return {'FINISHED'}


class MOTIONPATH_SetHandleTypeAll(bpy.types.Operator):
    """Set the handle type of every location keyframe of the selected bones / objects"""
    bl_idname = "motion_path.set_handle_type_all"
    bl_label = "Set Handle Type on All Keys"
    bl_options = {'REGISTER', 'UNDO'}

    handle_type: bpy.props.EnumProperty(name="Type", items=HANDLE_TYPES, default='AUTO_CLAMPED')

    def execute(self, context):
        n = set_handle_types(context, self.handle_type, only_selected=False)
        if not n:
            self.report({'WARNING'}, "No location keyframes found")
            return {'CANCELLED'}
        self.report({'INFO'}, "Set %d keyframes to %s" % (n, self.handle_type.replace('_', ' ').title()))
        return {'FINISHED'}






@persistent
def _on_undo_redo(*_args):
    _st.dirty = True
    _st.hover = None


@persistent
def _on_load_post(*_args):
    _st.token += 1
    _st.clear()
    _keys.clear()
    stop_tick()
    try:
        wm = bpy.context.window_manager
        wm.direct_manipulation_active = False
        wm.auto_sapty_active = False
    except Exception:
        pass


classes = (
    MOTIONPATH_DirectManipulation,
    MOTIONPATH_DirectManipulationToggle,
    MOTIONPATH_HandlesAddSelected,
    MOTIONPATH_HandlesRemoveSelected,
    MOTIONPATH_SetHandleType,
    MOTIONPATH_SetHandleTypeAll,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    curve_path.register_busy_check(is_busy)
    onion.set_provider(lambda: _st.targets)
    onion.register()
    for hlist in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo_redo not in hlist:
            hlist.append(_on_undo_redo)
    if _on_load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load_post)
    if not _draw_handle and not bpy.app.background:
        _draw_handle.append(bpy.types.SpaceView3D.draw_handler_add(_draw, (), 'WINDOW', 'POST_PIXEL'))


def unregister():
    stop_tick()
    onion.unregister()
    onion.set_provider(None)
    for h in _draw_handle:
        bpy.types.SpaceView3D.draw_handler_remove(h, 'WINDOW')
    _draw_handle.clear()
    for hlist in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if _on_undo_redo in hlist:
            hlist.remove(_on_undo_redo)
    if _on_load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load_post)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    _st.token += 1
    _st.clear()
    _keys.clear()
