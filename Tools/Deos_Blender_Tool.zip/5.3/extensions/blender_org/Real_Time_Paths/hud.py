


import math
import traceback

import bpy
import blf
import gpu
from gpu_extras.batch import batch_for_shader

from . import curve_path
from . import handles






PANEL_W = 280.0
COLLAPSED_W = 206.0
PAD = 10.0
HEADER_H = 34.0
SEC_H = 24.0
ROW_H = 24.0
BIG_H = 30.0
GAP = 6.0
SEC_GAP = 10.0
FOOTER_H = 26.0
R_PANEL = 10.0
R_WIDGET = 6.0

FONT = 0
SIZE_TITLE = 12.5
SIZE_TEXT = 10.5
SIZE_SMALL = 9.5
SIZE_CAPS = 9.0

DEFAULT_X = 12.0
DEFAULT_Y = 58.0

HANDLE_SEGMENTS = (('FREE', "Free"), ('ALIGNED', "Aligned"), ('VECTOR', "Vector"),
                   ('AUTO', "Auto"), ('AUTO_CLAMPED', "Clamped"))
RANGE_SEGMENTS = (('RANGE', "In Range"), ('CURRENT_FRAME', "Around Frame"))
ONION_RANGE_SEGMENTS = (('ALL', "All Keys"), ('NEAR', "Around Frame"))
ONION_FORM_SEGMENTS = (('SOLID', "Solid"), ('WIREFRAME', "Wireframe"), ('DOTS', "Dots"))


LABEL_START = "Edit Keys on Path"
LABEL_STOP = "Stop Editing Keys"
LABEL_INSERT = "Insert Keys on Path"
LABEL_INSERT_STOP = "Stop Inserting Keys"
LABEL_OFFSET = "Offset All Keys"
LABEL_OFFSET_STOP = "Stop Offsetting Keys"
LABEL_SET_SEL = "Set on Selected Keys"
LABEL_SET_ALL = "Set on All Keys"
LABEL_ADD_SEL = "+ Add Selected"
LABEL_REMOVE_SEL = "- Remove Selected"


CHIP_PROPS = {
    "chip:show_all": "show_all_handles",
    "chip:show_sel": "show_only_selected_handles",
    "chip:onion": "mpp_onion",
    "chip:keys": "mpp_show_keyframes",
    "chip:keynums": "mpp_show_keyframe_numbers",
    "chip:framenums": "mpp_show_frame_numbers",
    "chip:custom": "mpp_use_custom_color",
    "chip:onion_sel": "mpp_onion_selected",
}

STEP_PROPS = {"before": "mpp_frames_before", "after": "mpp_frames_after",
              "obefore": "mpp_onion_before", "oafter": "mpp_onion_after",
              "odot": "mpp_onion_dot_size"}
STEP_MIN = {"odot": 1}      


COLOR_TARGETS = {
    'PATH_BEFORE': "mpp_color",
    'PATH_AFTER': "mpp_color_post",
    'ONION_BEFORE': "mpp_onion_color_before",
    'ONION_AFTER': "mpp_onion_color_after",
}

SLIDER_PROP = ("mpp_line_width", 1.0, 10.0)


HINTS = {
    "move": "Drag the title bar to move the HUD",
    "fold": "Fold / unfold the HUD",
    "sec:handles": "Fold / unfold Keyframe Handles",
    "sec:display": "Fold / unfold Display",
    "more:handles": "Handle and Onion Skin settings",
    "more:display": "All display settings and path colors",
    "btn:start": "Handles on the bones selected now (like Calculate Path)",
    "btn:stop": "Stop editing keys on the path",
    "btn:h_add": "Add handles to the selected bones / objects",
    "btn:h_remove": "Remove handles from the selected bones / objects",
    "btn:advanced": "Click the path to key every transform channel",
    "btn:advanced_stop": "Stop inserting keys by clicking the path",
    "btn:smart": "Move a keyed bone / object: all its keys follow",
    "btn:smart_stop": "Stop offsetting: keys stay where they are",
    "ht": "Handle type set by the two buttons below",
    "btn:apply_sel": "Set this handle type on the selected keys",
    "btn:apply_all": "Set this handle type on every key",
    "chip:show_all": "Show the handles of every key",
    "chip:show_sel": "Show the handles of the selected keys",
    "chip:onion": "Ghost of the character on each keyframe",
    "onion_form:SOLID": "Ghosts as see-through solid meshes",
    "onion_form:WIREFRAME": "Ghosts as the edges of the meshes",
    "onion_form:DOTS": "Ghosts as a dot on every vertex",
    "odot": "Size of the dots in pixels",
    "onion_range:ALL": "A ghost on every keyframe",
    "onion_range:NEAR": "Ghosts only on the keys nearest the frame",
    "obefore": "Ghosted keyframes before the current frame",
    "oafter": "Ghosted keyframes after the current frame",
    "chip:onion_sel": "Ghosts only on the selected keyframes",
    "color:ONION_BEFORE": "Ghost color before the frame (click to edit)",
    "color:ONION_AFTER": "Ghost color after the frame (click to edit)",
    "color:PATH_BEFORE": "Path color before the frame (click to edit)",
    "color:PATH_AFTER": "Path color after the frame (click to edit)",
    "range:RANGE": "Show the whole path",
    "range:CURRENT_FRAME": "Show only frames around the current frame",
    "before": "Frames shown before the current frame",
    "after": "Frames shown after the current frame",
    "chip:keys": "Highlight keyframes and the current frame",
    "chip:keynums": "Frame number next to every keyframe",
    "chip:framenums": "Frame number next to every path point",
    "chip:custom": "Use your own path colors",
    "slider:width": "Line thickness  ·  Shift: fine  ·  Ctrl: snap",
}
DEFAULT_HINT = "Drag the title bar to move  ·  Shift: fine steps"






def _rgba(c, a=1.0):
    return (c[0], c[1], c[2], a)


def _mix(a, b, t):
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(4))


def _fade(c, f):
    return (c[0], c[1], c[2], c[3] * f)


def _lift(c, f):
    """Brighter (f > 0) or darker (f < 0) version of a colour."""
    if f >= 0.0:
        return (c[0] + (1.0 - c[0]) * f, c[1] + (1.0 - c[1]) * f, c[2] + (1.0 - c[2]) * f, c[3])
    return (c[0] * (1.0 + f), c[1] * (1.0 + f), c[2] * (1.0 + f), c[3])


def _visible_color(c):
    """Theme colour that stays visible on the dark HUD (the 'Free' handle colour is black)."""
    c = _rgba(c)
    if max(c[0], c[1], c[2]) < 0.2:
        return (0.78, 0.78, 0.80, 1.0)
    return c


def _theme_accent():
    """Blender's 'active button' colour (blue in the default theme)."""
    try:
        c = bpy.context.preferences.themes[0].user_interface.wcol_option.inner_sel
        return (float(c[0]), float(c[1]), float(c[2]), 1.0)
    except Exception:
        return (0.278, 0.447, 0.702, 1.0)


class _Palette:
    def __init__(self, wm):
        op = max(0.2, min(1.0, getattr(wm, "mpp_hud_opacity", 0.94)))
        self.op = op
        self.panel = (0.082, 0.086, 0.098, 0.94 * op)
        self.panel_border = (1.0, 1.0, 1.0, 0.10)
        self.shadow = (0.0, 0.0, 0.0, 0.42 * op)
        self.divider = (1.0, 1.0, 1.0, 0.07)
        self.text = (0.93, 0.94, 0.96, 1.0)
        self.text_dim = (0.64, 0.67, 0.72, 1.0)
        self.text_faint = (0.44, 0.47, 0.52, 1.0)
        self.caps = (0.56, 0.60, 0.67, 1.0)
        self.widget = (0.165, 0.172, 0.192, max(0.55, op))
        self.widget_hot = (0.215, 0.224, 0.250, max(0.6, op))
        self.widget_down = (0.118, 0.122, 0.138, max(0.6, op))
        self.widget_border = (1.0, 1.0, 1.0, 0.07)
        self.track = (0.047, 0.050, 0.058, max(0.6, op))
        self.accent = _theme_accent()
        self.accent_text = (1.0, 1.0, 1.0, 1.0)
        self.live = (0.30, 0.84, 0.50, 1.0)
        self.stop = (0.84, 0.29, 0.27, 1.0)
        self.white = (1.0, 1.0, 1.0, 1.0)









_SDF_VERT = """
void main()
{
  vec2 grow = vec2(u_params.z * 2.0 + 1.5);
  vec2 p = u_rect.xy + pos * (u_rect.zw + grow);
  v_local = p - u_rect.xy;
  /* pixel space -> clip space (2D, no rotation: scale xy, offset zw) */
  gl_Position = vec4(p * u_xform.xy + u_xform.zw, 0.0, 1.0);
}
"""

_SDF_FRAG = """
float mpp_round_box(vec2 p, vec2 b, float r)
{
  vec2 q = abs(p) - b + vec2(r);
  return min(max(q.x, q.y), 0.0) + length(max(q, vec2(0.0))) - r;
}

vec4 mpp_to_framebuffer(vec4 col)
{
  if (srgbTarget) {
    vec3 c = max(col.rgb, vec3(0.0));
    vec3 c1 = c * (1.0 / 12.92);
    vec3 c2 = pow((c + 0.055) * (1.0 / 1.055), vec3(2.4));
    col.rgb = mix(c1, c2, step(vec3(0.04045), c));
  }
  return col;
}

void main()
{
  float r = min(u_params.x, min(u_rect.z, u_rect.w));
  float d = mpp_round_box(v_local, u_rect.zw, r);
  vec4 col;
  if (u_params.z > 0.0) {
    /* soft shadow / glow */
    float a = 1.0 - smoothstep(-u_params.z, u_params.z, d);
    col = vec4(u_fill.rgb, u_fill.a * a * a);
  }
  else {
    float cover = clamp(0.5 - d, 0.0, 1.0);
    vec4 c = u_fill;
    if (u_params.w != 0.0) {
      /* vertical gradient: lighter at the top */
      float t = clamp(v_local.y / max(u_rect.w, 1.0), -1.0, 1.0);
      c.rgb = clamp(c.rgb * (1.0 + u_params.w * t), 0.0, 1.0);
    }
    if (u_params.y > 0.0) {
      /* border drawn over the fill */
      float inner = clamp(0.5 - (d + u_params.y), 0.0, 1.0);
      float ba = u_border.a * (1.0 - inner);
      float oa = ba + c.a * (1.0 - ba);
      vec3 rgb = (u_border.rgb * ba + c.rgb * c.a * (1.0 - ba)) / max(oa, 1e-5);
      c = vec4(rgb, oa);
    }
    col = vec4(c.rgb, c.a * cover);
  }
  FragColor = mpp_to_framebuffer(col);
}
"""


class _GPU:
    shader = None
    batch = None
    failed = False


def _sdf_shader():
    if _GPU.failed:
        return None
    if _GPU.shader is None:
        try:
            iface = gpu.types.GPUStageInterfaceInfo("mpp_hud_iface")
            iface.smooth('VEC2', "v_local")
            info = gpu.types.GPUShaderCreateInfo()
            
            
            info.push_constant('VEC4', "u_xform")
            info.push_constant('VEC4', "u_rect")
            info.push_constant('VEC4', "u_params")
            info.push_constant('VEC4', "u_fill")
            info.push_constant('VEC4', "u_border")
            info.push_constant('BOOL', "srgbTarget")
            info.vertex_in(0, 'VEC2', "pos")
            info.vertex_out(iface)
            info.fragment_out(0, 'VEC4', "FragColor")
            info.vertex_source(_SDF_VERT)
            info.fragment_source(_SDF_FRAG)
            shader = gpu.shader.create_from_info(info)
            batch = batch_for_shader(shader, 'TRIS', {"pos": ((-1.0, -1.0), (1.0, -1.0), (1.0, 1.0), (-1.0, 1.0))},
                                     indices=((0, 1, 2), (0, 2, 3)))
            _GPU.shader, _GPU.batch = shader, batch
        except Exception as e:
            _GPU.failed = True
            print("Motion Path Pro HUD: smooth shapes unavailable, using plain ones:", e)
            return None
    return _GPU.shader


def _round_points(x, y, w, h, r, seg=6):
    r = max(0.0, min(r, w * 0.5, h * 0.5))
    pts = []
    for cx, cy, a0 in ((x + w - r, y + h - r, 0.0), (x + r, y + h - r, 90.0),
                       (x + r, y + r, 180.0), (x + w - r, y + r, 270.0)):
        for i in range(seg + 1):
            a = math.radians(a0 + 90.0 * i / seg)
            pts.append((cx + r * math.cos(a), cy + r * math.sin(a), 0.0))
    return pts


_metrics = {}


def _font_size(size):
    curve_path.blf_size(FONT, size)


def text_width(text, size):
    key = (text, round(size, 2))
    w = _metrics.get(key)
    if w is None:
        _font_size(size)
        w = blf.dimensions(FONT, text)[0]
        if len(_metrics) > 4000:
            _metrics.clear()
        _metrics[key] = w
    return w


def _cap(size):
    key = ("\0cap", round(size, 2))
    h = _metrics.get(key)
    if h is None:
        _font_size(size)
        h = blf.dimensions(FONT, "H")[1]
        _metrics[key] = h
    return h


def fit_text(text, size, max_w):
    """(text, size) that fits in max_w: shrink a little, then cut with an ellipsis."""
    if max_w <= 0:
        return "", size
    if text_width(text, size) <= max_w:
        return text, size
    for f in (0.93, 0.86):
        if text_width(text, size * f) <= max_w:
            return text, size * f
    size *= 0.86
    while len(text) > 1 and text_width(text + "…", size) > max_w:
        text = text[:-1]
    return text.rstrip() + "…", size


def _smooth_lines(shader):
    """Anti-aliased polylines (Blender 4.x+ polyline shaders have a switch)."""
    try:
        shader.uniform_bool("lineSmooth", True)
    except Exception:
        pass


class Painter:
    """Immediate drawing in region pixel space."""

    def __init__(self, viewport_w, viewport_h):
        self.vw, self.vh = max(1.0, float(viewport_w)), max(1.0, float(viewport_h))
        self.sdf = _sdf_shader()
        self.px = curve_path.pixel_size()
        m = gpu.matrix.get_projection_matrix() @ gpu.matrix.get_model_view_matrix()
        self.xform = (m[0][0], m[1][1], m[0][3], m[1][3])

    
    def box(self, x, y, w, h, r, fill, border=None, bw=1.0, grad=0.0):
        if w <= 0.0 or h <= 0.0:
            return
        sh = self.sdf
        gpu.state.blend_set('ALPHA')
        if sh is not None:
            sh.bind()
            sh.uniform_float("u_xform", self.xform)
            sh.uniform_float("u_rect", (x + w * 0.5, y + h * 0.5, w * 0.5, h * 0.5))
            sh.uniform_float("u_params", (r, bw if border is not None else 0.0, 0.0, grad))
            sh.uniform_float("u_fill", fill)
            sh.uniform_float("u_border", border if border is not None else (0.0, 0.0, 0.0, 0.0))
            _GPU.batch.draw(sh)
            return
        pts = _round_points(x, y, w, h, r)
        c = (x + w * 0.5, y + h * 0.5, 0.0)
        tris = []
        for i in range(len(pts)):
            tris += [c, pts[i], pts[(i + 1) % len(pts)]]
        self._uniform('TRIS', tris, fill)
        self.polyline(pts + [pts[0]], border if border is not None else fill, 1.0)

    def circle(self, cx, cy, r, fill, border=None, bw=1.0):
        self.box(cx - r, cy - r, 2.0 * r, 2.0 * r, r, fill, border, bw)

    def shadow(self, x, y, w, h, r, soft, col):
        sh = self.sdf
        if sh is None:
            for i in range(3):
                g = soft * (i + 1) / 3.0
                self.box(x - g * 0.5, y - g * 0.5, w + g, h + g, r + g * 0.5, _fade(col, 0.25))
            return
        gpu.state.blend_set('ALPHA')
        sh.bind()
        sh.uniform_float("u_xform", self.xform)
        sh.uniform_float("u_rect", (x + w * 0.5, y + h * 0.5, w * 0.5, h * 0.5))
        sh.uniform_float("u_params", (r, 0.0, max(soft, 0.5), 0.0))
        sh.uniform_float("u_fill", col)
        sh.uniform_float("u_border", (0.0, 0.0, 0.0, 0.0))
        _GPU.batch.draw(sh)

    def _uniform(self, prim, verts, col):
        if not verts:
            return
        sh = curve_path.builtin_shader('UNIFORM_COLOR')
        gpu.state.blend_set('ALPHA')
        sh.bind()
        sh.uniform_float("color", col)
        batch_for_shader(sh, prim, {"pos": verts}).draw(sh)

    def triangle(self, pts, col):
        verts = [(p[0], p[1], 0.0) for p in pts]
        self._uniform('TRIS', verts, col)
        self.polyline(verts + [verts[0]], col, 1.0)   

    def polyline(self, pts, col, width):
        if len(pts) < 2:
            return
        sh = curve_path.builtin_shader('POLYLINE_UNIFORM_COLOR')
        gpu.state.blend_set('ALPHA')
        sh.bind()
        sh.uniform_float("viewportSize", (self.vw, self.vh))
        sh.uniform_float("lineWidth", width)
        _smooth_lines(sh)
        sh.uniform_float("color", col)
        verts = [(p[0], p[1], 0.0) for p in pts]
        batch_for_shader(sh, 'LINE_STRIP', {"pos": verts}).draw(sh)

    def polyline_colors(self, pts, cols, width):
        sh = curve_path.builtin_shader('POLYLINE_SMOOTH_COLOR')
        gpu.state.blend_set('ALPHA')
        sh.bind()
        sh.uniform_float("viewportSize", (self.vw, self.vh))
        sh.uniform_float("lineWidth", width)
        _smooth_lines(sh)
        verts = [(p[0], p[1], 0.0) for p in pts]
        batch_for_shader(sh, 'LINE_STRIP', {"pos": verts, "color": cols}).draw(sh)

    
    def text(self, x, cy, text, size, col, align='LEFT', spacing=0.0):
        """Text vertically centred on cy. align: LEFT (x = left), CENTER, RIGHT (x = right)."""
        if not text:
            return
        _font_size(size)
        if spacing:
            w = sum(text_width(ch, size) for ch in text) + spacing * (len(text) - 1)
        else:
            w = text_width(text, size)
        if align == 'CENTER':
            x -= w * 0.5
        elif align == 'RIGHT':
            x -= w
        y = cy - _cap(size) * 0.5
        _font_size(size)
        blf.color(FONT, col[0], col[1], col[2], col[3])
        if spacing:
            for ch in text:
                blf.position(FONT, round(x), round(y), 0.0)
                blf.draw(FONT, ch)
                x += text_width(ch, size) + spacing
                _font_size(size)
        else:
            blf.position(FONT, round(x), round(y), 0.0)
            blf.draw(FONT, text)
        return w




def _chevron(P, cx, cy, size, col, direction, s):
    h = size * 0.5
    if direction == 'DOWN':
        pts = ((cx - h, cy + h * 0.5), (cx, cy - h * 0.5), (cx + h, cy + h * 0.5))
    elif direction == 'UP':
        pts = ((cx - h, cy - h * 0.5), (cx, cy + h * 0.5), (cx + h, cy - h * 0.5))
    elif direction == 'LEFT':
        pts = ((cx + h * 0.5, cy + h), (cx - h * 0.5, cy), (cx + h * 0.5, cy - h))
    else:
        pts = ((cx - h * 0.5, cy + h), (cx + h * 0.5, cy), (cx - h * 0.5, cy - h))
    P.polyline(pts, col, 1.6 * s)


def _play(P, cx, cy, size, col):
    h = size * 0.5
    P.triangle(((cx - h * 0.75, cy - h), (cx - h * 0.75, cy + h), (cx + h, cy)), col)


def _stop(P, cx, cy, size, col, s):
    h = size * 0.42
    P.box(cx - h, cy - h, 2 * h, 2 * h, 1.6 * s, col)


def _check(P, cx, cy, size, col, s):
    h = size * 0.5
    P.polyline(((cx - h * 0.85, cy + h * 0.02), (cx - h * 0.25, cy - h * 0.55), (cx + h * 0.9, cy + h * 0.6)),
               col, 1.7 * s)


def _dots3(P, cx, cy, s, col):
    for i in (-1, 0, 1):
        P.circle(cx + i * 4.2 * s, cy, 1.45 * s, col)


def _grip(P, cx, cy, s, col):
    for i in (-1, 1):
        for j in (-1, 0, 1):
            P.circle(cx + i * 2.2 * s, cy + j * 4.0 * s, 1.05 * s, col)


def _led(P, cx, cy, s, on, pal):
    r = 3.2 * s
    if on:
        P.shadow(cx - r, cy - r, 2 * r, 2 * r, r, 3.5 * s, _fade(pal.live, 0.55))
        P.circle(cx, cy, r, pal.live)
    else:
        P.circle(cx, cy, r, (0.0, 0.0, 0.0, 0.0), _fade(pal.text_faint, 0.9), 1.2 * s)


def _pill(P, x, cy, text, col, s, solid=False):
    """Small status pill ('LIVE'), x = right edge. Returns its left edge."""
    size = SIZE_CAPS * 0.92 * s
    sp = 0.9 * s
    tw = sum(text_width(ch, size) for ch in text) + sp * (len(text) - 1)
    w = tw + 18.0 * s
    h = 15.0 * s
    left = x - w
    P.box(left, cy - h * 0.5, w, h, h * 0.5, _fade(col, 0.95 if solid else 0.16),
          _fade(col, 0.45), 1.0)
    P.circle(left + 6.5 * s, cy, 2.2 * s, col if not solid else (1.0, 1.0, 1.0, 1.0))
    P.text(left + 11.0 * s, cy, text, size, col if not solid else (1.0, 1.0, 1.0, 1.0), spacing=sp)
    return left


def _logo(P, x, cy, s):
    """A tiny motion path: before / after colours, keys and the current frame."""
    th = curve_path.theme_colors()
    before = _rgba(curve_path._vivid(th["before"]))
    after = _rgba(curve_path._vivid(th["after"]))
    pts, cols = [], []
    n = 14
    for i in range(n + 1):
        t = i / n
        px = x + t * 20.0 * s
        py = cy + math.sin((t - 0.5) * math.pi * 1.6) * 5.0 * s
        pts.append((px, py))
        cols.append(before if t < 0.5 else after)
    P.polyline_colors(pts, cols, 1.8 * s)
    key = _rgba(th["key"])
    for i in (0, n):
        P.circle(pts[i][0], pts[i][1], 2.3 * s, key, (0.0, 0.0, 0.0, 0.8), 0.9)
    mid = pts[n // 2]
    P.circle(mid[0], mid[1], 3.0 * s, _rgba(th["current"]), (0.0, 0.0, 0.0, 0.8), 1.0)






class _Item:
    __slots__ = ("kind", "key", "x", "y", "w", "h", "data")

    def __init__(self, kind, key, x, y, w, h, data):
        self.kind, self.key, self.x, self.y, self.w, self.h, self.data = kind, key, x, y, w, h, data


class Layout:
    """Rectangles of the HUD in region pixel space (origin bottom left)."""

    def __init__(self, s, rect, items, zones, wm, region_w, region_h):
        self.s = s
        self.rect = rect          
        self.items = items        
        self.zones = zones        
        self.wm = wm
        self.vw, self.vh = region_w, region_h

    def hit(self, x, y):
        """(part index, key) under (x, y) in region pixels, or None outside the HUD."""
        for i, (key, zx, zy, zw, zh) in enumerate(self.zones):
            if zx <= x < zx + zw and zy <= y < zy + zh:
                return i, key
        rx, ry, rw, rh = self.rect
        if rx <= x < rx + rw and ry <= y < ry + rh:
            return len(self.zones), "bg"
        return None

    def item(self, key):
        for it in self.items:
            if it.key == key:
                return it
        return None


class _Builder:
    def __init__(self, s):
        self.s = s
        self.items = []
        self.zones = []

    def add(self, kind, x, y, w, h, key=None, zone=True, **data):
        self.items.append(_Item(kind, key, x, y, w, h, data))
        if key is not None and zone:
            self.zones.append((key, x, y, w, h))

    def zone(self, key, x, y, w, h):
        self.zones.append((key, x, y, w, h))


def visible_rect(area, region):
    """(left, bottom, right, top) of the part of the viewport region that is
    not covered by the toolbar, sidebar or headers drawn over it (Region
    Overlap), in region pixels."""
    l, b, r, t = 0.0, 0.0, float(region.width), float(region.height)
    if area is None:
        return l, b, r, t
    rx0, ry0 = region.x, region.y
    rx1, ry1 = rx0 + region.width, ry0 + region.height
    for ar in area.regions:
        try:
            if ar.type in {'WINDOW', 'HUD'} or ar.width <= 1 or ar.height <= 1:
                continue
            side = ar.alignment
            if side not in {'LEFT', 'RIGHT', 'TOP', 'BOTTOM'}:
                continue
            if ar.x >= rx1 or ar.x + ar.width <= rx0 or ar.y >= ry1 or ar.y + ar.height <= ry0:
                continue   
            if side == 'LEFT':
                l = max(l, float(ar.x + ar.width - rx0))
            elif side == 'RIGHT':
                r = min(r, float(ar.x - rx0))
            elif side == 'TOP':
                t = min(t, float(ar.y - ry0))
            else:
                b = max(b, float(ar.y + ar.height - ry0))
        except Exception:
            continue
    if r - l < 40.0 or t - b < 40.0:   
        return 0.0, 0.0, float(region.width), float(region.height)
    return l, b, r, t


def hud_scale(wm):
    return curve_path.ui_scale() * max(0.5, min(2.5, getattr(wm, "mpp_hud_scale", 1.0)))


def _build_handles(B, wm, x, y, w):
    s = B.s
    g = GAP * s
    sh = SEC_H * s
    is_open = wm.mpp_hud_open_handles
    live = bool(wm.direct_manipulation_active)
    B.zone("more:handles", x + w - 26.0 * s, y + (sh - 20.0 * s) * 0.5, 26.0 * s, 20.0 * s)
    B.add('section', x, y, w, sh, key="sec:handles", title="KEYFRAME HANDLES", open=is_open,
          live=live, more="more:handles")
    y += sh + 4.0 * s
    if not is_open:
        return y

    
    rh = ROW_H * s
    hw = (w - g) * 0.5
    bh = BIG_H * s
    B.add('primary', x, y, w, bh, key="btn:start", on=live)
    y += bh + g
    if live:
        B.add('button', x, y, hw, rh, key="btn:h_add", label=LABEL_ADD_SEL)
        B.add('button', x + hw + g, y, hw, rh, key="btn:h_remove", label=LABEL_REMOVE_SEL)
        y += rh + g
    inserting = bool(wm.anim_deactivate_keyframe_operator)
    offsetting = bool(wm.generic_offest_active)
    B.add('toggle', x, y, hw, rh + 2.0 * s, key="btn:advanced",
          label=LABEL_INSERT_STOP if inserting else LABEL_INSERT, on=inserting)
    B.add('toggle', x + hw + g, y, hw, rh + 2.0 * s, key="btn:smart",
          label=LABEL_OFFSET_STOP if offsetting else LABEL_OFFSET, on=offsetting)
    y += rh + 2.0 * s + g

    
    B.add('caption', x, y, w, 14.0 * s, text="HANDLE TYPE")
    y += 14.0 * s + 3.0 * s
    ht = handles.handle_theme()
    opts = [("ht:" + v, label, v, _visible_color(ht.get((v, True), (1.0, 1.0, 1.0))))
            for v, label in HANDLE_SEGMENTS]
    _segmented(B, x, y, w, rh + 2.0 * s, opts, wm.handle_type, underline=True)
    y += rh + 2.0 * s + g

    B.add('button', x, y, hw, rh, key="btn:apply_sel", label=LABEL_SET_SEL)
    B.add('button', x + hw + g, y, hw, rh, key="btn:apply_all", label=LABEL_SET_ALL)
    y += rh + g

    
    B.add('chip', x, y, hw, rh, key="chip:show_all", label="Handles: All Keys", on=wm.show_all_handles)
    B.add('chip', x + hw + g, y, hw, rh, key="chip:show_sel", label="Handles: Selected",
          on=wm.show_only_selected_handles)
    y += rh + g
    onion = bool(getattr(wm, "mpp_onion", False))
    if onion and not live:
        detail = "shown while editing keys"
    else:
        detail = dict(ONION_FORM_SEGMENTS).get(getattr(wm, "mpp_onion_form", 'SOLID'), "Solid")
    B.add('chip', x, y, w, rh, key="chip:onion", label="Onion Skin", on=onion, detail=detail)
    y += rh
    if onion:
        y = _build_onion(B, wm, x, y + 5.0 * s, w)
    return y


def _build_onion(B, wm, x, y, w):
    """Onion skin options, in an inset box under the Onion Skin chip."""
    s = B.s
    g = GAP * s
    rh = ROW_H * s
    pad = 6.0 * s
    box = _Item('inset', None, x, y, w, 0.0, {})
    B.items.append(box)
    xi, wi = x + pad, w - 2.0 * pad
    hw = (wi - g) * 0.5
    top = y
    y += pad
    form = getattr(wm, "mpp_onion_form", 'SOLID')
    opts = [("onion_form:" + v, label, v, None) for v, label in ONION_FORM_SEGMENTS]
    _segmented(B, xi, y, wi, rh, opts, form)
    y += rh + g
    if form == 'DOTS':
        _stepper(B, wm, "odot", "Dot Size", xi, y, wi, rh)
        y += rh + g
    opts = [("onion_range:" + v, label, v, None) for v, label in ONION_RANGE_SEGMENTS]
    _segmented(B, xi, y, wi, rh, opts, wm.mpp_onion_range)
    y += rh + g
    if wm.mpp_onion_range == 'NEAR':
        _stepper(B, wm, "obefore", "Before", xi, y, hw, rh)
        _stepper(B, wm, "oafter", "After", xi + hw + g, y, hw, rh)
        y += rh + g
    B.add('chip', xi, y, wi, rh, key="chip:onion_sel", label="Only Selected Keys",
          on=wm.mpp_onion_selected)
    y += rh + g
    _color_pair(B, wm, 'ONION', xi, y, wi, rh)
    y += rh + pad
    box.h = y - top
    return y


def _build_display(B, wm, x, y, w):
    s = B.s
    g = GAP * s
    sh = SEC_H * s
    rh = ROW_H * s
    is_open = wm.mpp_hud_open_display
    B.zone("more:display", x + w - 26.0 * s, y + (sh - 20.0 * s) * 0.5, 26.0 * s, 20.0 * s)
    B.add('section', x, y, w, sh, key="sec:display", title="DISPLAY", open=is_open, live=False,
          more="more:display")
    y += sh + 4.0 * s
    if not is_open:
        return y

    opts = [("range:" + v, label, v, None) for v, label in RANGE_SEGMENTS]
    _segmented(B, x, y, w, rh, opts, wm.mpp_display_type)
    y += rh + g

    hw = (w - g) * 0.5
    if wm.mpp_display_type == 'CURRENT_FRAME':
        _stepper(B, wm, "before", "Before", x, y, hw, rh)
        _stepper(B, wm, "after", "After", x + hw + g, y, hw, rh)
        y += rh + g

    keys_on = bool(wm.mpp_show_keyframes)
    B.add('chip', x, y, hw, rh, key="chip:keys", label="Keyframes", on=keys_on)
    B.add('chip', x + hw + g, y, hw, rh, key="chip:keynums", label="Key Numbers",
          on=wm.mpp_show_keyframe_numbers, dim=not keys_on)
    y += rh + g
    B.add('chip', x, y, hw, rh, key="chip:framenums", label="Frame Numbers", on=wm.mpp_show_frame_numbers)
    custom = bool(wm.mpp_use_custom_color)
    if custom:
        swatches = (_rgba(wm.mpp_color), _rgba(wm.mpp_color_post))
    else:
        th = curve_path.theme_colors()
        swatches = (_rgba(curve_path._vivid(th["before"])), _rgba(curve_path._vivid(th["after"])))
    B.add('chip', x + hw + g, y, hw, rh, key="chip:custom", label="Custom Colors", on=custom,
          swatches=swatches)
    y += rh + g
    if custom:
        _color_pair(B, wm, 'PATH', x, y, w, rh)
        y += rh + g

    prop, lo, hi = SLIDER_PROP
    B.add('slider', x, y, w, rh, key="slider:width", label="Thickness",
          value=float(getattr(wm, prop)), lo=lo, hi=hi)
    y += rh
    return y


def _stepper(B, wm, name, label, x, y, w, h):
    s = B.s
    B.add('stepper', x, y, w, h, key=name, zone=False, label=label, value=int(getattr(wm, STEP_PROPS[name])))
    aw = 22.0 * s
    B.zone(name + ":-", x, y, aw, h)
    B.zone(name + ":+", x + w - aw, y, aw, h)
    B.zone(name + ":=", x + aw, y, w - 2.0 * aw, h)


def _color_pair(B, wm, group, x, y, w, h):
    """Before / After colour buttons of 'PATH' or 'ONION'."""
    g = GAP * B.s
    hw = (w - g) * 0.5
    for i, (side, label) in enumerate((("BEFORE", "Before"), ("AFTER", "After"))):
        target = group + "_" + side
        B.add('color', x + i * (hw + g), y, hw, h, key="color:" + target, label=label,
              color=_rgba(getattr(wm, COLOR_TARGETS[target])))


def _segmented(B, x, y, w, h, opts, current, underline=False):
    s = B.s
    inset = 2.0 * s
    n = len(opts)
    sw = (w - 2.0 * inset) / n
    for i, (key, label, value, color) in enumerate(opts):
        B.zone(key, x + inset + i * sw, y, sw, h)
    B.add('segmented', x, y, w, h, key=None, segs=opts, current=current, underline=underline)


def _layout(wm, area, region):
    """Layout of the HUD in this viewport region."""
    s = hud_scale(wm)
    collapsed = bool(wm.mpp_hud_collapsed)
    W = round((COLLAPSED_W if collapsed else PANEL_W) * s)
    B = _Builder(s)
    pad = PAD * s
    iw = W - 2.0 * pad
    hh = HEADER_H * s

    
    B.zone("fold", W - 32.0 * s, (hh - 26.0 * s) * 0.5, 28.0 * s, 26.0 * s)
    B.add('header', 0.0, 0.0, W, hh, key="move", collapsed=collapsed,
          live=bool(wm.direct_manipulation_active))
    y = hh
    if not collapsed:
        y += 8.0 * s
        y = _build_handles(B, wm, pad, y, iw)
        y += SEC_GAP * s
        B.add('divider', pad, y - SEC_GAP * s * 0.5, iw, 1.0)
        y = _build_display(B, wm, pad, y, iw)
        y += 10.0 * s
        B.add('footer', 0.0, y, W, FOOTER_H * s)
        y += FOOTER_H * s
    H = round(y)

    
    l, b, r, t = visible_rect(area, region)
    ox, oy = wm.mpp_hud_x * s, wm.mpp_hud_y * s
    px = l + ox if wm.mpp_hud_side == 'LEFT' else r - ox - W
    top = t - oy
    px = max(l, min(px, r - W))
    top = min(t, max(top, b + H))
    px, top = round(px), round(top)

    def conv(x, y, w, h):
        return px + x, top - y - h, w, h

    items = []
    for it in B.items:
        it.x, it.y, it.w, it.h = conv(it.x, it.y, it.w, it.h)
        items.append(it)
    zones = [(key,) + conv(x, y, w, h) for key, x, y, w, h in B.zones]
    return Layout(s, (px, top - H, W, H), items, zones, wm, region.width, region.height)


def set_position(wm, area, region, px, top, W, H):
    """Store a new panel position (left edge, top edge in region pixels),
    relative to the nearest side so it stays put when the viewport is resized."""
    s = hud_scale(wm)
    l, b, r, t = visible_rect(area, region)
    px = max(l, min(px, r - W))
    top = min(t, max(top, b + H))
    if px + W * 0.5 < (l + r) * 0.5:
        side, ox = 'LEFT', px - l
    else:
        side, ox = 'RIGHT', r - (px + W)
    wm.mpp_hud_side = side
    wm.mpp_hud_x = max(0.0, ox / s)
    wm.mpp_hud_y = max(0.0, (t - top) / s)






def hud_visible(wm, space, region):
    if not getattr(wm, "mpp_hud_show", False):
        return False
    if space is None or getattr(space, "type", None) != 'VIEW_3D':
        return False
    try:
        if not space.show_gizmo or not space.overlay.show_overlays:
            return False
    except Exception:
        return False
    if region is None or region.type != 'WINDOW':
        return False
    try:
        if len(space.region_quadviews):
            
            rv3d = getattr(region, "data", None)
            if rv3d is None or rv3d.as_pointer() != space.region_3d.as_pointer():
                return False
    except Exception:
        pass
    return True


def layout_for_context(context):
    wm = context.window_manager
    area, region = context.area, context.region
    if not hud_visible(wm, context.space_data, region):
        return None
    return _layout(wm, area, region)


def over_hud(area, region, x, y):
    """True if (x, y) (region pixels) is on the HUD: the add-on's own modal
    tools (keyframe handles, insert keys on the path) leave such clicks alone."""
    try:
        wm = bpy.context.window_manager
        space = area.spaces.active if area is not None else None
        if not hud_visible(wm, space, region):
            return False
        return _layout(wm, area, region).hit(x, y) is not None
    except Exception:
        return False






def _state_fill(pal, hot, down, base=None):
    base = base if base is not None else pal.widget
    if down:
        return pal.widget_down
    if hot:
        return pal.widget_hot if base is pal.widget else _lift(base, 0.10)
    return base


def _draw_header(P, L, it, pal, hot, down_key):
    s = L.s
    cy = it.y + it.h * 0.5
    if not it.data["collapsed"]:
        P.box(it.x + 1.0, it.y, it.w - 2.0, 1.0, 0.0, pal.divider)
    _logo(P, it.x + 13.0 * s, cy, s)
    tx = it.x + 42.0 * s
    tw = P.text(tx, cy, "Motion Path", SIZE_TITLE * s, pal.text) or 0.0
    
    bx = tx + tw + 6.0 * s
    bw, bh = 27.0 * s, 15.0 * s
    P.box(bx, cy - bh * 0.5, bw, bh, 4.0 * s, pal.accent, grad=0.12)
    P.text(bx + bw * 0.5, cy, "PRO", SIZE_CAPS * 0.9 * s, pal.accent_text, align='CENTER', spacing=0.8 * s)

    
    fx = it.x + it.w - 18.0 * s
    if hot == "fold" or down_key == "fold":
        P.circle(fx, cy, 11.0 * s, pal.widget_hot)
    _chevron(P, fx, cy, 9.0 * s, pal.text if hot == "fold" else pal.text_dim,
             'RIGHT' if it.data["collapsed"] else 'DOWN', s)
    gx = fx - 22.0 * s
    _grip(P, gx, cy, s, pal.text if hot == "move" or down_key == "move" else pal.text_faint)
    if it.data["collapsed"] and it.data["live"]:
        _led(P, gx - 13.0 * s, cy, s, True, pal)


def _draw_section(P, L, it, pal, hot, down_key):
    s = L.s
    cy = it.y + it.h * 0.5
    key = it.key
    more = it.data["more"]
    is_hot = hot == key
    if is_hot or down_key == key:
        P.box(it.x - 4.0 * s, it.y, it.w + 8.0 * s, it.h, R_WIDGET * s, _fade(pal.widget_hot, 0.55))
    col = pal.text if is_hot else pal.caps
    _chevron(P, it.x + 5.0 * s, cy, 7.0 * s, col, 'DOWN' if it.data["open"] else 'RIGHT', s)
    P.text(it.x + 15.0 * s, cy, it.data["title"], SIZE_CAPS * s, col, spacing=1.15 * s)
    mx = it.x + it.w - 13.0 * s
    if hot == more or down_key == more:
        P.box(mx - 13.0 * s, cy - 10.0 * s, 26.0 * s, 20.0 * s, R_WIDGET * s, pal.widget_hot)
    _dots3(P, mx, cy, s, pal.text if hot == more else pal.text_dim)
    if it.data["live"]:
        _pill(P, mx - 18.0 * s, cy, "LIVE", pal.live, s)


def _draw_caption(P, L, it, pal, hot, down_key):
    P.text(it.x + 2.0 * L.s, it.y + it.h * 0.5, it.data["text"], SIZE_CAPS * 0.92 * L.s, pal.text_faint,
           spacing=1.0 * L.s)


def _draw_divider(P, L, it, pal, hot, down_key):
    P.box(it.x, it.y, it.w, 1.0, 0.0, pal.divider)


def _draw_primary(P, L, it, pal, hot, down_key):
    s = L.s
    on = it.data["on"]
    base = pal.stop if on else pal.accent
    is_hot, down = hot == it.key, down_key == it.key
    fill = _lift(base, -0.18) if down else (_lift(base, 0.10) if is_hot else base)
    if not down:
        P.shadow(it.x, it.y - 1.0 * s, it.w, it.h, R_WIDGET * s, 4.0 * s, _fade(base, 0.35))
    P.box(it.x, it.y, it.w, it.h, R_WIDGET * s, fill, (1.0, 1.0, 1.0, 0.16), 1.0, grad=0.10)
    label = LABEL_STOP if on else LABEL_START
    size = SIZE_TEXT * 1.05 * s
    tw = text_width(label, size)
    icon = 9.0 * s
    total = icon + 7.0 * s + tw
    cx = it.x + (it.w - total) * 0.5
    cy = it.y + it.h * 0.5
    if on:
        _stop(P, cx + icon * 0.5, cy, icon, pal.white, s)
    else:
        _play(P, cx + icon * 0.5, cy, icon, pal.white)
    P.text(cx + icon + 7.0 * s, cy, label, size, pal.white)


def _draw_toggle(P, L, it, pal, hot, down_key):
    s = L.s
    on = it.data["on"]
    is_hot, down = hot == it.key, down_key == it.key
    if on:
        fill = _mix(pal.widget, pal.accent, 0.30)
        fill = _lift(fill, 0.08) if is_hot and not down else (_lift(fill, -0.15) if down else fill)
        border = _fade(pal.accent, 0.75)
    else:
        fill = _state_fill(pal, is_hot, down)
        border = pal.widget_border
    P.box(it.x, it.y, it.w, it.h, R_WIDGET * s, fill, border, 1.0, grad=0.05)
    cy = it.y + it.h * 0.5
    _led(P, it.x + 11.0 * s, cy, s, on, pal)
    text, size = fit_text(it.data["label"], SIZE_TEXT * s, it.w - 26.0 * s)
    P.text(it.x + 20.0 * s + (it.w - 26.0 * s - text_width(text, size)) * 0.5, cy, text, size,
           pal.text if (on or is_hot) else pal.text_dim)


def _draw_button(P, L, it, pal, hot, down_key):
    s = L.s
    is_hot, down = hot == it.key, down_key == it.key
    P.box(it.x, it.y, it.w, it.h, R_WIDGET * s, _state_fill(pal, is_hot, down), pal.widget_border, 1.0,
          grad=0.05)
    text, size = fit_text(it.data["label"], SIZE_TEXT * s, it.w - 12.0 * s)
    P.text(it.x + it.w * 0.5, it.y + it.h * 0.5, text, size, pal.text if is_hot else _mix(pal.text, pal.text_dim, 0.4),
           align='CENTER')


def _draw_chip(P, L, it, pal, hot, down_key):
    s = L.s
    d = it.data
    on = bool(d["on"])
    dim = d.get("dim", False)
    is_hot, down = hot == it.key, down_key == it.key
    r = it.h * 0.5
    if on:
        fill = _mix(pal.widget, pal.accent, 0.22 if not dim else 0.10)
        fill = _lift(fill, 0.08) if is_hot and not down else (_lift(fill, -0.15) if down else fill)
        border = _fade(pal.accent, 0.65 if not dim else 0.3)
    else:
        fill = _state_fill(pal, is_hot, down)
        border = pal.widget_border
    P.box(it.x, it.y, it.w, it.h, r, fill, border, 1.0)
    cy = it.y + it.h * 0.5
    cx = it.x + 12.0 * s
    cr = 6.0 * s
    if on:
        P.circle(cx, cy, cr, pal.accent if not dim else _mix(pal.accent, pal.widget, 0.5))
        _check(P, cx, cy, 6.6 * s, pal.white if not dim else pal.text_dim, s)
    else:
        P.circle(cx, cy, cr, (0.0, 0.0, 0.0, 0.25), pal.text_faint, 1.3 * s)
    right = it.x + it.w - 10.0 * s
    sw = d.get("swatches")
    if sw:
        q = 8.0 * s
        for i, c in enumerate(reversed(sw)):
            sx = right - q - i * (q + 3.0 * s)
            P.box(sx, cy - q * 0.5, q, q, 2.0 * s, c if on else _mix(c, pal.widget, 0.45), (0.0, 0.0, 0.0, 0.6), 1.0)
        right -= 2.0 * q + 8.0 * s
    detail = d.get("detail")
    tx = it.x + 23.0 * s
    if detail:
        dsize = SIZE_SMALL * s
        dw = min(text_width(detail, dsize), (right - tx) * 0.55)
        text, dsize = fit_text(detail, dsize, dw)
        P.text(right, cy, text, dsize, pal.text_faint if not on else pal.text_dim, align='RIGHT')
        right -= dw + 8.0 * s
    text, size = fit_text(d["label"], SIZE_TEXT * s, right - tx)
    col = pal.text if (on and not dim) or is_hot else pal.text_dim
    if dim and not is_hot:
        col = pal.text_faint
    P.text(tx, cy, text, size, col)


def _draw_inset(P, L, it, pal, hot, down_key):
    s = L.s
    P.box(it.x, it.y, it.w, it.h, (R_WIDGET + 2.0) * s, _fade(pal.track, 0.55), pal.widget_border, 1.0)


def _draw_color(P, L, it, pal, hot, down_key):
    s = L.s
    is_hot, down = hot == it.key, down_key == it.key
    P.box(it.x, it.y, it.w, it.h, R_WIDGET * s, _state_fill(pal, is_hot, down), pal.widget_border, 1.0,
          grad=0.05)
    cy = it.y + it.h * 0.5
    q = it.h - 10.0 * s
    sx = it.x + 6.0 * s
    c = it.data["color"]
    P.box(sx, cy - q * 0.5, 2.0 * q, q, 3.0 * s, c, (0.0, 0.0, 0.0, 0.7), 1.0)
    P.box(sx + 1.0, cy - q * 0.5 + 1.0, 2.0 * q - 2.0, q - 2.0, 2.5 * s, (0.0, 0.0, 0.0, 0.0),
          (1.0, 1.0, 1.0, 0.18), 1.0)
    tx = sx + 2.0 * q + 7.0 * s
    text, size = fit_text(it.data["label"], SIZE_TEXT * s, it.x + it.w - 18.0 * s - tx)
    P.text(tx, cy, text, size, pal.text if is_hot else pal.text_dim)
    _chevron(P, it.x + it.w - 10.0 * s, cy, 6.0 * s, pal.text if is_hot else pal.text_faint, 'DOWN', s)


def _draw_segmented(P, L, it, pal, hot, down_key):
    s = L.s
    d = it.data
    P.box(it.x, it.y, it.w, it.h, R_WIDGET * s + 1.0 * s, pal.track, pal.widget_border, 1.0)
    inset = 2.0 * s
    sw = (it.w - 2.0 * inset) / len(d["segs"])
    for i, (key, label, value, color) in enumerate(d["segs"]):
        sx = it.x + inset + i * sw
        sel = value == d["current"]
        is_hot, down = hot == key, down_key == key
        sy, sh = it.y + inset, it.h - 2.0 * inset
        if sel:
            P.box(sx + 0.5, sy, sw - 1.0, sh, R_WIDGET * s - 1.0 * s, _lift(pal.accent, 0.06 if is_hot else 0.0),
                  (1.0, 1.0, 1.0, 0.14), 1.0, grad=0.10)
        elif is_hot or down:
            P.box(sx + 0.5, sy, sw - 1.0, sh, R_WIDGET * s - 1.0 * s,
                  pal.widget_down if down else pal.widget_hot)
        cy = it.y + it.h * 0.5 + (1.5 * s if d["underline"] else 0.0)
        text, size = fit_text(label, SIZE_TEXT * 0.98 * s, sw - 6.0 * s)
        col = pal.accent_text if sel else (pal.text if is_hot else pal.text_dim)
        P.text(sx + sw * 0.5, cy, text, size, col, align='CENTER')
        if d["underline"] and color is not None:
            bw = min(14.0 * s, sw * 0.4)
            P.box(sx + (sw - bw) * 0.5, sy + 3.0 * s, bw, 2.0 * s, 1.0 * s,
                  color if sel or is_hot else _fade(color, 0.55))


def _draw_stepper(P, L, it, pal, hot, down_key):
    s = L.s
    name = it.key
    hot_part = hot[len(name):] if isinstance(hot, str) and hot.startswith(name + ":") else None
    down_part = down_key[len(name):] if isinstance(down_key, str) and down_key.startswith(name + ":") else None
    P.box(it.x, it.y, it.w, it.h, R_WIDGET * s, _state_fill(pal, hot_part == ":=", down_part == ":="),
          pal.widget_border, 1.0)
    aw = 22.0 * s
    cy = it.y + it.h * 0.5
    for part, ax, direction in ((":-", it.x, 'LEFT'), (":+", it.x + it.w - aw, 'RIGHT')):
        if hot_part == part or down_part == part:
            P.box(ax + 2.0 * s, it.y + 2.0 * s, aw - 4.0 * s, it.h - 4.0 * s, R_WIDGET * s - 2.0 * s,
                  pal.widget_down if down_part == part else pal.widget_hot)
        _chevron(P, ax + aw * 0.5, cy, 7.0 * s, pal.text if hot_part == part else pal.text_dim, direction, s)
    label = it.data["label"]
    value = str(it.data["value"])
    size = SIZE_TEXT * s
    lw, vw = text_width(label, SIZE_SMALL * s), text_width(value, size)
    gap = 5.0 * s
    x0 = it.x + (it.w - (lw + gap + vw)) * 0.5
    P.text(x0, cy, label, SIZE_SMALL * s, pal.text_dim)
    P.text(x0 + lw + gap, cy, value, size, pal.text)


def slider_track(it, s):
    """(left, right) of the slider track inside its row (shared by drawing and dragging)."""
    return it.x + 82.0 * s, it.x + it.w - 66.0 * s


def _draw_slider(P, L, it, pal, hot, down_key):
    s = L.s
    d = it.data
    is_hot, down = hot == it.key, down_key == it.key
    lo, hi = d["lo"], d["hi"]
    f = max(0.0, min(1.0, (d["value"] - lo) / (hi - lo)))
    P.box(it.x, it.y, it.w, it.h, R_WIDGET * s, _state_fill(pal, is_hot and not down, False),
          pal.widget_border, 1.0, grad=0.05)
    cy = it.y + it.h * 0.5
    P.text(it.x + 10.0 * s, cy, d["label"], SIZE_TEXT * s, pal.text if (is_hot or down) else pal.text_dim)
    P.text(it.x + it.w - 10.0 * s, cy, "%.2f px" % d["value"], SIZE_TEXT * s, pal.text, align='RIGHT')
    x0, x1 = slider_track(it, s)
    th = 4.0 * s
    P.box(x0, cy - th * 0.5, x1 - x0, th, th * 0.5, pal.track, (1.0, 1.0, 1.0, 0.06), 1.0)
    kx = x0 + (x1 - x0) * f
    if kx - x0 > 0.5:
        P.box(x0, cy - th * 0.5, kx - x0, th, th * 0.5, pal.accent)
    r = 6.0 * s
    if is_hot or down:
        P.circle(kx, cy, r + 3.0 * s, _fade(pal.accent, 0.35))
    P.shadow(kx - r, cy - r - 1.0 * s, 2.0 * r, 2.0 * r, r, 2.0 * s, (0.0, 0.0, 0.0, 0.5))
    P.circle(kx, cy, r, pal.white, _fade(pal.accent, 0.9) if down else (0.0, 0.0, 0.0, 0.25), 1.0)


def _draw_footer(P, L, it, pal, hot, down_key):
    s = L.s
    P.box(it.x + 1.0, it.y + it.h - 1.0, it.w - 2.0, 1.0, 0.0, pal.divider)
    cy = it.y + it.h * 0.5 + 0.5 * s
    key = down_key or hot
    hint = None
    if key is not None:
        wm = L.wm
        if key == "btn:start" and wm.direct_manipulation_active:
            key = "btn:stop"
        elif key == "btn:advanced" and wm.anim_deactivate_keyframe_operator:
            key = "btn:advanced_stop"
        elif key == "btn:smart" and wm.generic_offest_active:
            key = "btn:smart_stop"
        hint = HINTS.get(key) or HINTS.get(key.split(":")[0])
    P.circle(it.x + 14.0 * s, cy, 2.4 * s, pal.accent if hint else _fade(pal.text_faint, 0.8))
    text, size = fit_text(hint or DEFAULT_HINT, SIZE_SMALL * s, it.w - 34.0 * s)
    P.text(it.x + 23.0 * s, cy, text, size, pal.text_dim if hint else pal.text_faint)


_DRAW = {
    'header': _draw_header,
    'section': _draw_section,
    'caption': _draw_caption,
    'divider': _draw_divider,
    'primary': _draw_primary,
    'toggle': _draw_toggle,
    'button': _draw_button,
    'chip': _draw_chip,
    'segmented': _draw_segmented,
    'inset': _draw_inset,
    'color': _draw_color,
    'stepper': _draw_stepper,
    'slider': _draw_slider,
    'footer': _draw_footer,
}


def draw_layout(L, hot=None, down_key=None):
    """Draw the HUD. hot: key under the mouse, down_key: key being pressed."""
    pal = _Palette(L.wm)
    P = Painter(L.vw, L.vh)
    s = L.s
    x, y, w, h = L.rect
    blf.disable(FONT, blf.SHADOW)
    P.shadow(x, y - 3.0 * s, w, h, R_PANEL * s, 12.0 * s, pal.shadow)
    P.box(x, y, w, h, R_PANEL * s, pal.panel, pal.panel_border, 1.0)
    for it in L.items:
        fn = _DRAW.get(it.kind)
        if fn is not None:
            fn(P, L, it, pal, hot, down_key)
    gpu.state.blend_set('NONE')






def _redraw():
    curve_path.tag_redraw()


def _ctx_pointers(context):
    def ptr(v):
        return v.as_pointer() if v is not None else 0
    return ptr(context.window), ptr(context.area), ptr(context.region)


def _find_context(ptrs):
    wp, ap, rp = ptrs
    for win in bpy.context.window_manager.windows:
        if win.as_pointer() != wp or win.screen is None:
            continue
        for area in win.screen.areas:
            if area.as_pointer() != ap:
                continue
            for region in area.regions:
                if region.as_pointer() == rp:
                    return win, area, region
            return win, area, None
        return win, None, None
    return None, None, None


def _call_panel(context, name):
    
    if not bpy.app.background and getattr(context, "window", None) is not None:
        bpy.ops.wm.call_panel(name=name, keep_open=True)


def _run_button(context, key):
    wm = context.window_manager
    if key == "btn:start":
        bpy.ops.motion_path.direct_manipulation_toggle()
    elif key == "btn:h_add":
        bpy.ops.motion_path.handles_add_selected()
    elif key == "btn:h_remove":
        bpy.ops.motion_path.handles_remove_selected()
    elif key == "btn:advanced":
        if wm.anim_deactivate_keyframe_operator:
            bpy.ops.anim.deactivate_keyframe_operator()
        else:
            bpy.ops.anim.insert_keyframe_selected_fcurves('INVOKE_DEFAULT')
    elif key == "btn:smart":
        if wm.generic_offest_active:
            bpy.ops.new_amth.generic_offest_deactivate()
        else:
            bpy.ops.new_amth.generic_offest_activate()
    elif key == "btn:apply_sel":
        bpy.ops.motion_path.set_handle_type(handle_type=wm.handle_type)
    elif key == "btn:apply_all":
        bpy.ops.motion_path.set_handle_type_all(handle_type=wm.handle_type)
    elif key == "more:handles":
        _call_panel(context, MPP_PT_hud_handles.bl_idname)
    elif key == "more:display":
        _call_panel(context, MPP_PT_hud_display.bl_idname)
    elif key.startswith("color:") and key[6:] in COLOR_TARGETS:
        wm.mpp_hud_color_target = key[6:]
        _call_panel(context, MPP_PT_hud_color.bl_idname)


def _defer_button(context, key):
    """Run a button once the click is over, outside the gizmo event handling
    (operators that start their own modal handlers or open popups)."""
    ptrs = _ctx_pointers(context)

    def run():
        try:
            win, area, region = _find_context(ptrs)
            if win is not None:
                kw = {"window": win}
                if area is not None:
                    kw["area"] = area
                if region is not None:
                    kw["region"] = region
                with bpy.context.temp_override(**kw):
                    _run_button(bpy.context, key)
        except Exception as e:
            print("Motion Path Pro HUD: %s: %s" % (key, e))
        _redraw()
        return None

    bpy.app.timers.register(run, first_interval=0.0)


def _press_value(wm, key, event):
    """Controls that act as soon as they are pressed. True if handled."""
    if key == "fold":
        wm.mpp_hud_collapsed = not wm.mpp_hud_collapsed
    elif key == "sec:handles":
        wm.mpp_hud_open_handles = not wm.mpp_hud_open_handles
    elif key == "sec:display":
        wm.mpp_hud_open_display = not wm.mpp_hud_open_display
    elif key in CHIP_PROPS:
        prop = CHIP_PROPS[key]
        setattr(wm, prop, not getattr(wm, prop))
    elif key.startswith("ht:"):
        wm.handle_type = key[3:]
    elif key.startswith("range:"):
        wm.mpp_display_type = key[6:]
    elif key.startswith("onion_range:"):
        wm.mpp_onion_range = key[12:]
    elif key.startswith("onion_form:"):
        wm.mpp_onion_form = key[11:]
    elif key.endswith((":-", ":+")) and key[:-2] in STEP_PROPS:
        prop = STEP_PROPS[key[:-2]]
        step = 10 if getattr(event, "ctrl", False) else (5 if getattr(event, "shift", False) else 1)
        value = getattr(wm, prop) + (step if key.endswith("+") else -step)
        setattr(wm, prop, max(STEP_MIN.get(key[:-2], 0), value))
    else:
        return False
    return True


class Interaction:
    """Press / drag / release on the HUD (driven by the gizmo)."""

    def __init__(self):
        self.active = None     
        self.over = False      
        self.drag = None
        self.mouse = (0, 0)

    def down_key(self):
        if self.active is None:
            return None
        if self.drag is not None or self.over:
            return self.active
        return None

    
    def press(self, context, event, L=None):
        wm = context.window_manager
        L = L if L is not None else layout_for_context(context)
        mx, my = event.mouse_region_x, event.mouse_region_y
        hit = L.hit(mx, my) if L is not None else None
        if hit is None:
            return {'PASS_THROUGH'}
        key = hit[1]
        self.active, self.over, self.mouse, self.drag = key, True, (mx, my), None

        if key == "move":
            px, py, W, H = L.rect
            self.drag = {"kind": 'MOVE', "mx": mx, "my": my, "x": px, "top": py + H, "W": W, "H": H,
                         "orig": (wm.mpp_hud_side, wm.mpp_hud_x, wm.mpp_hud_y)}
        elif key == "slider:width":
            it = L.item(key)
            prop, lo, hi = SLIDER_PROP
            value = float(getattr(wm, prop))
            x0, x1 = slider_track(it, L.s)
            raw = value
            if not event.shift and x0 - 8.0 * L.s <= mx <= x1 + 8.0 * L.s:
                
                raw = lo + (hi - lo) * (mx - x0) / max(1.0, x1 - x0)
            self.drag = {"kind": 'SLIDER', "prop": prop, "lo": lo, "hi": hi, "w": x1 - x0, "orig": value,
                         "raw": max(lo, min(hi, raw)), "last": mx}
            self._set_slider(wm, event.ctrl)
        elif key.endswith(":=") and key[:-2] in STEP_PROPS:
            prop = STEP_PROPS[key[:-2]]
            self.drag = {"kind": 'SCRUB', "prop": prop, "orig": int(getattr(wm, prop)), "raw": 0.0,
                         "last": mx, "min": STEP_MIN.get(key[:-2], 0)}
        else:
            _press_value(wm, key, event)
        _redraw()
        return {'RUNNING_MODAL'}

    
    def move(self, context, event, precise=False, snap=False, L=None):
        if event.type not in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
            return {'RUNNING_MODAL'}
        wm = context.window_manager
        mx, my = event.mouse_region_x, event.mouse_region_y
        self.mouse = (mx, my)
        d = self.drag
        if d is None:
            L = L if L is not None else layout_for_context(context)
            hit = L.hit(mx, my) if L is not None else None
            over = hit is not None and hit[1] == self.active
            if over != self.over:
                self.over = over
                _redraw()
            return {'RUNNING_MODAL'}
        s = hud_scale(wm)
        if d["kind"] == 'MOVE':
            set_position(wm, context.area, context.region, d["x"] + mx - d["mx"], d["top"] + my - d["my"],
                         d["W"], d["H"])
        elif d["kind"] == 'SLIDER':
            dx = mx - d["last"]
            d["last"] = mx
            d["raw"] += dx / max(1.0, d["w"]) * (d["hi"] - d["lo"]) * (0.1 if precise else 1.0)
            self._set_slider(wm, snap)
        elif d["kind"] == 'SCRUB':
            dx = mx - d["last"]
            d["last"] = mx
            d["raw"] += dx / (7.0 * s) * (0.25 if precise else 1.0)
            setattr(wm, d["prop"], max(d["min"], int(round(d["orig"] + d["raw"]))))
        _redraw()
        return {'RUNNING_MODAL'}

    def _set_slider(self, wm, snap):
        d = self.drag
        v = max(d["lo"], min(d["hi"], d["raw"]))
        v = round(v * 2.0) / 2.0 if snap else round(v, 2)
        if abs(getattr(wm, d["prop"]) - v) > 1e-6:
            setattr(wm, d["prop"], v)

    
    def release(self, context, cancel):
        key, d, over = self.active, self.drag, self.over
        self.active, self.drag, self.over = None, None, False
        wm = context.window_manager
        if d is not None:
            if cancel:
                if d["kind"] == 'MOVE':
                    wm.mpp_hud_side, wm.mpp_hud_x, wm.mpp_hud_y = d["orig"]
                else:
                    setattr(wm, d["prop"], d["orig"])
        elif not cancel and over and key is not None and key.startswith(("btn:", "more:", "color:")):
            _defer_button(context, key)
        _redraw()






class MPP_GT_hud(bpy.types.Gizmo):
    """The whole HUD: drawing, hover and clicks."""
    bl_idname = "MPP_GT_hud"

    def setup(self):
        self.use_draw_modal = True
        try:
            self.use_tooltip = False
        except Exception:
            pass
        self.mpp_hot = None
        self.mpp_ui = Interaction()

    def _ui(self):
        ui = getattr(self, "mpp_ui", None)
        if ui is None:
            ui = self.mpp_ui = Interaction()
        return ui

    def test_select(self, context, location):
        try:
            L = layout_for_context(context)
            hit = L.hit(location[0], location[1]) if L is not None else None
        except Exception:
            traceback.print_exc()
            hit = None
        self.mpp_hot = hit[1] if hit is not None else None
        return hit[0] if hit is not None else -1

    def draw(self, context):
        try:
            L = layout_for_context(context)
            if L is None:
                return
            ui = self._ui()
            if ui.active is not None:
                hot = ui.active if (ui.drag is not None or ui.over) else None
            else:
                hot = getattr(self, "mpp_hot", None) if self.is_highlight else None
            draw_layout(L, hot, ui.down_key())
        except Exception as e:   
            print("Motion Path Pro HUD: drawing error:", e)

    def invoke(self, context, event):
        try:
            return self._ui().press(context, event)
        except Exception:
            traceback.print_exc()
            return {'PASS_THROUGH'}

    def modal(self, context, event, tweak):
        try:
            return self._ui().move(context, event, precise='PRECISE' in tweak, snap='SNAP' in tweak)
        except Exception:
            traceback.print_exc()
            return {'RUNNING_MODAL'}

    def exit(self, context, cancel):
        try:
            self._ui().release(context, cancel)
        except Exception:
            traceback.print_exc()


class MPP_GGT_hud(bpy.types.GizmoGroup):
    bl_idname = "MPP_GGT_hud"
    bl_label = "Motion Path Pro HUD"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    
    bl_options = {'PERSISTENT', 'SHOW_MODAL_ALL'}

    @classmethod
    def poll(cls, context):
        try:
            return hud_visible(context.window_manager, context.space_data, context.region)
        except Exception:
            return False

    def setup(self, context):
        self.gizmos.new(MPP_GT_hud.bl_idname)






class MPP_PT_hud_handles(bpy.types.Panel):
    """Every keyframe handle option, opened from the HUD"""
    bl_idname = "MPP_PT_hud_handles"
    bl_label = "Keyframe Handles"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 13

    def draw(self, context):
        from . import onion
        layout = self.layout
        wm = context.window_manager
        col = layout.column(align=True)
        col.prop(wm, "show_all_handles", text="Show Handles on All Keys")
        col.prop(wm, "show_only_selected_handles", text="Show Handles on Selected Keys")
        box = layout.box()
        box.prop(wm, "mpp_onion", text="Onion Skin",
                 icon='ONIONSKIN_ON' if wm.mpp_onion else 'ONIONSKIN_OFF')
        if wm.mpp_onion:
            if not wm.direct_manipulation_active:
                box.label(text="Shown while Edit Keys on Path is on", icon='INFO')
            onion.draw_settings(box, context)


class MPP_PT_hud_display(bpy.types.Panel):
    """Every display option of the motion paths, opened from the HUD"""
    bl_idname = "MPP_PT_hud_display"
    bl_label = "Display"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 13

    def draw(self, context):
        curve_path.draw_display(self.layout, context)


class MPP_PT_hud_color(bpy.types.Panel):
    """Colour wheel for a path or ghost colour, opened from a HUD swatch"""
    bl_idname = "MPP_PT_hud_color"
    bl_label = "Color"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_ui_units_x = 10

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        target = wm.mpp_hud_color_target
        group = 'PATH' if target.startswith('PATH') else 'ONION'
        layout.label(text="Path Colors" if group == 'PATH' else "Onion Skin Colors",
                     icon='CURVE_PATH' if group == 'PATH' else 'ONIONSKIN_ON')
        row = layout.row(align=True)
        row.prop_enum(wm, "mpp_hud_color_target", group + "_BEFORE", text="Before")
        row.prop_enum(wm, "mpp_hud_color_target", group + "_AFTER", text="After")
        prop = COLOR_TARGETS[target]
        layout.template_color_picker(wm, prop, value_slider=True)
        layout.prop(wm, prop, text="")
        if group == 'PATH':
            layout.prop(wm, "mpp_use_custom_color")


class MOTIONPATH_OT_HudToggle(bpy.types.Operator):
    """Show or hide the Motion Path Pro HUD in the 3D viewport"""
    bl_idname = "motion_path.hud_toggle"
    bl_label = "Toggle Motion Path HUD"

    def execute(self, context):
        wm = context.window_manager
        wm.mpp_hud_show = not wm.mpp_hud_show
        return {'FINISHED'}


class MOTIONPATH_OT_HudReset(bpy.types.Operator):
    """Put the HUD back in the top left corner of the viewport, at its normal size"""
    bl_idname = "motion_path.hud_reset"
    bl_label = "Reset HUD"

    def execute(self, context):
        wm = context.window_manager
        wm.mpp_hud_side = 'LEFT'
        wm.mpp_hud_x = DEFAULT_X
        wm.mpp_hud_y = DEFAULT_Y
        wm.mpp_hud_scale = 1.0
        wm.mpp_hud_opacity = 0.94
        wm.mpp_hud_collapsed = False
        wm.mpp_hud_show = True
        _redraw()
        return {'FINISHED'}


def draw_sidebar(layout, context):
    """HUD options for the sidebar panel."""
    wm = context.window_manager
    box = layout.box()
    row = box.row(align=True)
    row.prop(wm, "mpp_hud_show", text="Viewport HUD", toggle=True,
             icon='HIDE_OFF' if wm.mpp_hud_show else 'HIDE_ON')
    row.operator("motion_path.hud_reset", text="", icon='LOOP_BACK')
    if wm.mpp_hud_show:
        row = box.row(align=True)
        row.prop(wm, "mpp_hud_scale", text="Size", slider=True)
        row.prop(wm, "mpp_hud_opacity", text="Opacity", slider=True)






def _on_redraw(self, context):
    _redraw()


_PROPS = {
    "mpp_hud_show": lambda: bpy.props.BoolProperty(
        name="Viewport HUD", description="Show the Motion Path Pro HUD in the 3D viewport",
        default=False, update=_on_redraw),
    "mpp_hud_collapsed": lambda: bpy.props.BoolProperty(
        name="Fold HUD", description="Show only the title bar of the HUD", default=False, update=_on_redraw),
    "mpp_hud_open_handles": lambda: bpy.props.BoolProperty(
        name="Keyframe Handles", default=True, update=_on_redraw),
    "mpp_hud_open_display": lambda: bpy.props.BoolProperty(
        name="Display", default=True, update=_on_redraw),
    "mpp_hud_color_target": lambda: bpy.props.EnumProperty(
        name="Color", description="Colour edited in the HUD colour pop-over",
        items=[('PATH_BEFORE', "Before", "Path color before the current frame"),
               ('PATH_AFTER', "After", "Path color after the current frame"),
               ('ONION_BEFORE', "Before", "Ghost color before the current frame"),
               ('ONION_AFTER', "After", "Ghost color after the current frame")],
        default='PATH_BEFORE'),
    "mpp_hud_side": lambda: bpy.props.EnumProperty(
        name="HUD Side", items=[('LEFT', "Left", ""), ('RIGHT', "Right", "")], default='LEFT'),
    "mpp_hud_x": lambda: bpy.props.FloatProperty(name="HUD X", default=DEFAULT_X, min=0.0),
    "mpp_hud_y": lambda: bpy.props.FloatProperty(name="HUD Y", default=DEFAULT_Y, min=0.0),
    "mpp_hud_scale": lambda: bpy.props.FloatProperty(
        name="HUD Size", description="Size of the HUD (on top of the interface scale)",
        default=1.0, min=0.6, max=2.0, update=_on_redraw),
    "mpp_hud_opacity": lambda: bpy.props.FloatProperty(
        name="HUD Opacity", description="Opacity of the HUD background",
        default=0.94, min=0.2, max=1.0, subtype='FACTOR', update=_on_redraw),
}

classes = (
    MPP_GT_hud,
    MPP_GGT_hud,
    MPP_PT_hud_handles,
    MPP_PT_hud_display,
    MPP_PT_hud_color,
    MOTIONPATH_OT_HudToggle,
    MOTIONPATH_OT_HudReset,
)


def register():
    for name, make in _PROPS.items():
        setattr(bpy.types.WindowManager, name, make())
    for cls in classes:
        bpy.utils.register_class(cls)
    handles.set_ui_blocker(over_hud)


def unregister():
    handles.set_ui_blocker(None)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    for name in _PROPS:
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    _GPU.shader = _GPU.batch = None
    _GPU.failed = False
    _metrics.clear()
