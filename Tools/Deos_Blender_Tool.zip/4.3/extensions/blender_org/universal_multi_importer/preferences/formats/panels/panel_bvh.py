from . import draw_panel

class IMPORT_SCENE_BVHSettings():
    def draw(self, operator, module_name, layout):
        layout.use_property_split = True
        layout.use_property_decorate = False

        layout.prop(operator, 'target')

        op = [[operator, 'global_scale'],
              [operator, 'rotate_mode'],
              [operator, 'axis_forward'],
              [operator, 'axis_up']]
        
        draw_panel(layout, op, 'BVHSettings_Transform', 'Transform', icon='OBJECT_DATA')

        op = [[operator, 'frame_start'],
              [operator, 'use_fps_scale'],
              [operator, 'use_cyclic'],
              [operator, 'update_scene_fps'],
              [operator, 'update_scene_duration']]
        
        draw_panel(layout, op, 'BVHSettings_Animation', 'Animation', icon='ARMATURE_DATA')