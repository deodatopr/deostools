#------------------------------------------------
# TOOL VERTEX EDGE
#------------------------------------------------

import bpy                      # Python
import bmesh                    # Mesh Data
from bpy.types import Operator  # Operators


#------------------------------------------------
# DEFINITIONS
#------------------------------------------------

def CalleLineaVertices(vObj, vOffset):
		
		#Asegurando de que el único objeto seleccionado es el que será procesado
		bpy.ops.object.select_all(action='DESELECT')
		vObj.select_set(True)
		
		# Duplicate obj
		bpy.ops.object.duplicate_move(OBJECT_OT_duplicate={"linked":False, "mode":'TRANSLATION'})

		# Select 
		objCopy = bpy.context.selected_objects[0]
		bpy.data.objects[objCopy.name].select_set(True)

		# Edit Mode
		bpy.ops.object.mode_set(mode='EDIT')

		# Mesh Data
		bm = bmesh.from_edit_mesh(objCopy.data)

		# Long Edge vars
		max_length = 0
		longest_edge = None

		# Mesh data to get long edge
		for edge in bm.edges:
				v1, v2 = edge.verts
				length = (v1.co - v2.co).length
				if length > max_length:
						max_length = length
						longest_edge = edge

		# Clear edge selection
		for edge in bm.edges:
				edge.select_set(False)

		# Select long edge
		if longest_edge is not None:
				longest_edge.select_set(True)

		# update mesh
		bmesh.update_edit_mesh(objCopy.data)

		# Get loop edge from the selected edge
		bpy.ops.mesh.loop_multi_select(ring=False)

		# update mesh on the copy obj
		bmesh.update_edit_mesh(objCopy.data)

		#create edge
		bpy.ops.mesh.offset_edge_loops_slide(
				MESH_OT_offset_edge_loops={"use_cap_endpoint":False}, 
				TRANSFORM_OT_edge_slide={"value": vOffset, "single_side":True, "use_even":False,"flipped":False}
		)
						
		# Duplicate edge
		bpy.ops.mesh.duplicate_move(
				MESH_OT_duplicate={"mode":1}, 
				TRANSFORM_OT_translate={"value":(0, 0, 0), "orient_type":'GLOBAL'}
		)

		# Separate Dup Edge
		bpy.ops.mesh.separate(type='SELECTED')
		bpy.ops.object.mode_set(mode='OBJECT',toggle = True)

		# Rename
		bpy.context.selected_objects[1].name = vObj.name + " (Vrts)"
		
		# Delete copy
		bpy.data.objects.remove(objCopy, do_unlink=True)

#------------------------------------------------
# ACTIONS
#------------------------------------------------

class PanisOper_VertexEdge (Operator):
	bl_idname = "pani.vertfile_edge"
	bl_label = ""
	bl_description = "Pani's tool to create an edge to use it as Spline in a Game Engine"

	def execute(self, context):

		if not bpy.context.selectable_objects == None:

			# GET VALUES FROM UI (_INIT_)
			sldr_VertFileEdge_Offset = bpy.context.scene.deoPropertyGrp.sldr_VertFileEdge_Offset

			# Get Selected Objs.
			objsOrig = bpy.context.selected_objects

			# Create EdgeObject and Offset Val.
			for obj in objsOrig:
					CalleLineaVertices(obj, sldr_VertFileEdge_Offset)

			# Clean Selection
			bpy.ops.object.select_all(action='DESELECT')
			bpy.data.objects[objsOrig[0].name].select_set(True)
			bpy.context.view_layer.objects.active = objsOrig[0]

			# Info
			self.report({'INFO'}, "[EDGE CREATED ON MESH(ES)] SELECTED ")

		return {'FINISHED'}
