# ------------------------------------------------
# TOOL EXPORTER MAPS
# ------------------------------------------------

import bpy  # Python
import os  # Os
from bpy.types import Operator  # Operators


# ------------------------------------------------
# ACTIONS
# ------------------------------------------------

class DeosOperToGameEngine(Operator):

    bl_idname = "deo.to_game_engine"
    bl_label = ""
    bl_description = "Export to Mesh(es) to Game Engine"

    def execute(self, context):

      # region GET VALUES FROM UI (_INIT_)

      enum_ToGamengine_Format = bpy.context.scene.deoPropertyGrp.enum_ToGamengine_Format
      bool_ToGamengine_Selected = bpy.context.scene.deoPropertyGrp.bool_ToGamengine_Selected

      bool_ToGamengine_GD_Up = bpy.context.scene.deoPropertyGrp.bool_ToGamengine_GD_Up
      bool_ToGamengine_GD_Maps = bpy.context.scene.deoPropertyGrp.bool_ToGamengine_GD_Maps
      bool_ToGamengine_GD_Anim = bpy.context.scene.deoPropertyGrp.bool_ToGamengine_GD_Anim

      enum_ToGamengine_Fbx_Up = bpy.context.scene.deoPropertyGrp.enum_ToGamengine_Fbx_Up
      enum_ToGamengine_Fbx_Forward = bpy.context.scene.deoPropertyGrp.enum_ToGamengine_Fbx_Forward
      enum_ToGamengine_Fbx_Smooth = bpy.context.scene.deoPropertyGrp.enum_ToGamengine_Fbx_Smooth
      bool_ToGamengine_Fbx_BakeAnim = bpy.context.scene.deoPropertyGrp.bool_ToGamengine_Fbx_BakeAnimation

      str_ToGamengine_FileName = bpy.context.scene.deoPropertyGrp.str_ToGamengine_FileName
      str_ToGamengine_DirPath =  bpy.context.scene.deoPropertyGrp.str_ToGamengine_DirPath

      # endregion


      # Validate mesh selection
      if bpy.context.object.type != 'MESH':
        self.report({"WARNING"}, "[ Select at least a Mesh from the scene ]")
      else:

        # Validate FileName
        if str_ToGamengine_FileName == "" or str_ToGamengine_FileName == "Name":
          self.report({"WARNING"}, "'Write a File Name' -> Inside of the Export Panel")
        else:

          # Validate DirPath
          if str_ToGamengine_DirPath == "Add Folder Location" or str_ToGamengine_DirPath == "":
            self.report({"WARNING"}, "'Load a Folder Location' -> inside of the Export Panel")
          else:
           
            # Path with a string location
            vPath_RelatToAbs = bpy.path.abspath( str_ToGamengine_DirPath )
            vPathDir = vPath_RelatToAbs.replace( "\\", "\\\\" )            # remplazar '\' por '\\'

            # GLB UI TOGGLER ---------------------------------------
            
            # Textures
            if bool_ToGamengine_GD_Maps == True:
              vGD_Maps = 'EXPORT'
            elif bool_ToGamengine_GD_Maps == False:
              vGD_Maps = 'NONE'


            # FBX UI TOGGLER ---------------------------------------
            
            # Up Axis
            if enum_ToGamengine_Fbx_Up == 'Op1':
              vUpAxis = 'X'
            elif enum_ToGamengine_Fbx_Up == 'Op2':
              vUpAxis = 'Y'
            elif enum_ToGamengine_Fbx_Up == 'Op3':
              vUpAxis = 'Z'
            elif enum_ToGamengine_Fbx_Up == 'Op4':
              vUpAxis = '-X'
            elif enum_ToGamengine_Fbx_Up == 'Op5':
              vUpAxis = '-Y'
            elif enum_ToGamengine_Fbx_Up == 'Op6':
              vUpAxis = '-Z'

            # Forward Axis
            if enum_ToGamengine_Fbx_Forward == 'Op1':
              vForwardAxis = 'X'
            elif enum_ToGamengine_Fbx_Forward == 'Op2':
              vForwardAxis = 'Y'
            elif enum_ToGamengine_Fbx_Forward == 'Op3':
              vForwardAxis = 'Z'
            elif enum_ToGamengine_Fbx_Forward == 'Op4':
              vForwardAxis = '-X'
            elif enum_ToGamengine_Fbx_Forward == 'Op5':
              vForwardAxis = '-Y'
            elif enum_ToGamengine_Fbx_Forward == 'Op6':
              vForwardAxis = '-Z'

            # Smoting Normals
            if enum_ToGamengine_Fbx_Smooth == 'Op1':
              vSmooth = 'OFF'
            elif enum_ToGamengine_Fbx_Smooth == 'Op2':
              vSmooth = 'FACE'
            elif enum_ToGamengine_Fbx_Smooth == 'Op3':
              vSmooth = 'EDGE'

            if enum_ToGamengine_Format == 'Op1':
            # GLB EXPORT SETTINGS  ---------------------------------------
              bpy.ops.export_scene.gltf (
                use_selection = bool_ToGamengine_Selected,

                export_yup = bool_ToGamengine_GD_Up,

                export_apply = True,
                export_texcoords = True,
                export_normals = True,
                export_attributes = True,

                export_materials = 'EXPORT',
                export_image_format=vGD_Maps,

                export_animations = bool_ToGamengine_GD_Anim,

                filepath = ( f"{vPathDir}{str_ToGamengine_FileName}{'.glb'}" )
              )

            elif enum_ToGamengine_Format == 'Op2':
            # FBX EXPORT SETTINGS  ---------------------------------------
              bpy.ops.export_scene.fbx (
                use_selection = bool_ToGamengine_Selected,
                
                axis_up = vUpAxis,
                axis_forward = vForwardAxis,
                bake_space_transform = True,
                
                mesh_smooth_type = vSmooth,
                use_triangles = True,
                bake_anim = bool_ToGamengine_Fbx_BakeAnim,

                filepath = ( f"{vPathDir}{str_ToGamengine_FileName}{'.fbx'}" )
              )


            # Info
            self.report({"INFO"}, "THE EXPORT IS DONE")
            
      # End
      return {"FINISHED"}