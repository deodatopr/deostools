#------------------------------------------------
# TOOL SCULPT ORBRUSHES
#------------------------------------------------

# Python
import bpy

# Operadores
from bpy.types import Operator



#------------------------------------------------
# DEF - METHODS
#------------------------------------------------

# [DELETE BRUSHES]
def ORB_Brushes_Del():
	# Delete Brushes
	for ORB_Brush in bpy.data.brushes :
		if ORB_Brush.name.startswith ("Orb_") :
			bpy.data.brushes.remove(ORB_Brush)

	# Delete Images
	for ORB_Images in bpy.data.images :
		if ORB_Images.name.startswith ("Orb_") :
			bpy.data.images.remove(ORB_Images)   
				
	# Delete Textures
	for ORB_Texture in bpy.data.textures :
		if ORB_Texture.name.startswith ("Orb_") :
			bpy.data.textures.remove(ORB_Texture)

	
#------------------------------------------------
# OPERATOR
#------------------------------------------------

# [ADD BRUSHES]
class DeosOperSculptORBrushesAdd (Operator):
	bl_idname = "deo.sculpt_orbrushes_add"
	bl_label = ""
	bl_description = "Add ORBrushes into the 'Brush Panel"


	def execute(self, context):

		# ---------------------
		# APEEND BY PREF_ NAMES
		# ---------------------
		
		# Remover paquete de ORBs
		ORB_Brushes_Del ()

		# Cargar Paquete de ORBs
		Path_Brushes = bpy.utils.resource_path('USER') + "\\scripts\\addons\\deostools\\SculptOrbrushes\\Orbs.blend"

		# APPEND ALL BY NAME
		with bpy.data.libraries.load(Path_Brushes, link=False) as (data_from, data_to) : 
			data_to.brushes = [vBrush for vBrush in data_from.brushes if vBrush.startswith("Orb_")]
	
		"""
		# APPEND ONE BY NAME 
	
		# Append_Name = "Orb_Slash_clean"
		Path_Brushes = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\SculptOrbrushes\Orbs.blend\\Brush\\"
		bpy.ops.wm.append(filename = Append_Name, directory = Path_Brushes)
	
		# --------------------
		# LOAD FULL FILE
		# --------------------

		# File Path
		ORBrushes = bpy.utils.resource_path('USER') + "\scripts\\addons\deostools\brushes\Orbs.blend"

		# Load File
		with bpy.data.libraries.load(ORBrushes) as (data_from, data_to):
			for attr in dir(data_to):
				setattr(data_to, attr, getattr(data_from, attr))

		"""

		# INFO
		self.report({'INFO'}, "[The 'ORBrushes was Added' in the Sculpting Brush Panel]")
		return {'FINISHED'}


# [DELETE BRUSHES]
class DeosOperSculptORBrushesDel (Operator):
	bl_idname = "deo.sculpt_orbrushes_del"
	bl_label = ""
	bl_description = "Delete The ORBrushes's Library"

	
	def execute(self, context):

		# Remover paquete de ORBs
		ORB_Brushes_Del ()

		# INFO
		self.report({'INFO'}, "[The 'ORBrushes was Deleted' from the Context]")
		
		return {'FINISHED'}
