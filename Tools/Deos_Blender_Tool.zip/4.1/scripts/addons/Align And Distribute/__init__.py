bl_info = {
    "name": "Align And Distribute",
    "author": "Amandeep",
    "description": "Aligning and Distributing utilities",
    "blender": (2, 90, 0),
    "version": (2, 0, 0),
    "location": "N-Panel > Item > Align and Distribute",
    "warning": "",
    "category": "Object",
}

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

import bpy
import os
from mathutils import Vector
import random
class AAD_PT_ALIGN_AND_DISTRIBUTE(bpy.types.Panel):
    bl_label = "Align And Distribute"
    bl_idname = "OBJECT_PT_ALIGN_AND_DISTRIBUTE"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Align"
    
    def draw(self, context):
        layout= self.layout
        aad_props=context.scene.aad_props
        layout.label(text="Align")
        # layout.row().prop(aad_props,'task',expand=True)
        
        # layout.row().prop(aad_props,"axis",expand=True)
        mesh_type=all([a.type=='MESH' for a in context.selected_objects])
        if mesh_type:
            layout.row().prop(aad_props,'method',expand=True)    

            if aad_props.method=="Bounding Box":
                layout.row().prop(aad_props,'direction',expand=True)
        row=layout.row(align=True)
        op=row.operator("aad.align",text="X")
        op.align=True
        op.axis_x=True
        op=row.operator("aad.align",text="Y")
        op.align=True
        op.axis_y=True
        op=row.operator("aad.align",text="Z")
        op.align=True
        op.axis_z=True
        #row.prop(aad_props,'axis_x',toggle=True)
        #row.prop(aad_props,'axis_y',toggle=True)
        #row.prop(aad_props,'axis_z',toggle=True)
        layout.label(text="Distribute")
        layout.row().prop(aad_props,'distribute_pattern',expand=True)
        if aad_props.distribute_pattern=="1D":
            if mesh_type:
                layout.row().prop(aad_props,'dmethod',expand=True) 
        
        if aad_props.distribute_pattern=="1D":
            if mesh_type:
                if aad_props.dmethod=="Bounding Box":
                    layout.row().prop(aad_props,'linear_method',expand=True)
            row=layout.row(align=True)
            op=row.operator("aad.align",text="X")
            op.distribute=True
            op.daxis_x=True
            op=row.operator("aad.align",text="Y")
            op.distribute=True
            op.daxis_y=True
            op=row.operator("aad.align",text="Z")
            op.distribute=True
            op.daxis_z=True
            #row.prop(aad_props,'daxis_x',toggle=True)
            #row.prop(aad_props,'daxis_y',toggle=True)
            #row.prop(aad_props,'daxis_z',toggle=True)
        elif aad_props.distribute_pattern=="2D":
            
            #layout.row().prop(aad_props,'plane',expand=True)
            layout.prop(aad_props,'grid_2d')
            #layout.prop(aad_props,'grid_y')
            layout.prop(aad_props,'size_2d')
            #layout.prop(aad_props,'size_y')
            layout.row().prop(aad_props,'h_dir',expand=True)
            layout.row().prop(aad_props,'v_dir',expand=True)
            row=layout.row(align=True)
            op=row.operator("aad.align",text="X")
            op.distribute=True
            op.plane="X"
            op=row.operator("aad.align",text="Y")
            op.distribute=True
            op.plane="Y"
            op=row.operator("aad.align",text="Z")
            op.distribute=True
            op.plane="Z"
        layout.label(text="Rearrange")
        layout.operator("aad.randomize")
        layout.operator("aad.swap")
        #layout.operator("aad.temp")

        #layout.operator("aad.align")
class AAD_Temp(bpy.types.Operator):
    bl_idname = "aad.temp"
    bl_label = "Align And Distribute"
    bl_description = "Create Assets Panel"
    bl_options = {'REGISTER', 'UNDO'}
    def draw(self,context):
        layout= self.layout
        aad_props=context.scene.aad_props
        layout.label(text="Align And Distribute")
        #layout.row().prop(aad_props,'task',expand=True)
        
        #layout.row().prop(aad_props,"axis",expand=True)
        
        layout.row().prop(aad_props,'method',expand=True)    
        if aad_props.method=="Bounding Box":
            layout.row().prop(aad_props,'direction',expand=True)
        row=layout.row(align=True)
        op=row.operator("aad.align",text="X")
        op.align=True
        op.axis_x=True
        op=row.operator("aad.align",text="Y")
        op.align=True
        op.axis_y=True
        op=row.operator("aad.align",text="Z")
        op.align=True
        op.axis_z=True
        #row.prop(aad_props,'axis_x',toggle=True)
        #row.prop(aad_props,'axis_y',toggle=True)
        #row.prop(aad_props,'axis_z',toggle=True)
        layout.label(text="Distribute")
        layout.row().prop(aad_props,'distribute_pattern',expand=True)
        if aad_props.distribute_pattern=="1D":
                layout.row().prop(aad_props,'dmethod',expand=True) 
        
        if aad_props.distribute_pattern=="1D":
            if aad_props.dmethod=="Bounding Box":
                layout.row().prop(aad_props,'linear_method',expand=True)
            row=layout.row(align=True)
            op=row.operator("aad.align",text="X")
            op.distribute=True
            op.daxis_x=True
            op=row.operator("aad.align",text="Y")
            op.distribute=True
            op.daxis_y=True
            op=row.operator("aad.align",text="Z")
            op.distribute=True
            op.daxis_z=True
            #row.prop(aad_props,'daxis_x',toggle=True)
            #row.prop(aad_props,'daxis_y',toggle=True)
            #row.prop(aad_props,'daxis_z',toggle=True)
        elif aad_props.distribute_pattern=="2D":
            
            #layout.row().prop(aad_props,'plane',expand=True)
            layout.prop(aad_props,'grid_2d')
            #layout.prop(aad_props,'grid_y')
            layout.prop(aad_props,'size_2d')
            #layout.prop(aad_props,'size_y')
            layout.row().prop(aad_props,'h_dir',expand=True)
            layout.row().prop(aad_props,'v_dir',expand=True)
            row=layout.row(align=True)
            op=row.operator("aad.align",text="X")
            op.distribute=True
            op.plane="X"
            op=row.operator("aad.align",text="Y")
            op.distribute=True
            op.plane="Y"
            op=row.operator("aad.align",text="Z")
            op.distribute=True
            op.plane="Z"
        layout.label(text="Rearrange")
        layout.operator("aad.Randomize")
        layout.operator("aad.swap")
    def invoke(self, context,event):
        #bpy.ops.wm.call_panel(name='OBJECT_PT_Bake_Tools')
        #return {'FINISHED'}
        return context.window_manager.invoke_popup(self)
    def execute(self, context):

        #        bpy.ops.wm.call_panel(name="RT_PT_Append_Panel")
        return {'FINISHED'}
def calc_center(obj):
    corners=[(obj.matrix_world @Vector(corner)) for corner in obj.bound_box]
    total=Vector((0,0,0))
    for c in corners:
        total=total+c
    return total/8
def rightmost_obj(objs,axis):
    rightmost_obj=objs[0]
    for obj in objs:
        if obj.location[axis]>rightmost_obj.location[axis]:
            rightmost_obj=obj
    return rightmost_obj
def leftmost_obj(objs,axis):
    leftmost_obj=objs[0]
    for obj in objs:
        if obj.location[axis]<leftmost_obj.location[axis]:
            leftmost_obj=obj
    return leftmost_obj
def generate_points(point_a,point_b,count):
    diff=point_b-point_a
    diff=diff/(count+1)
    points=[]
    for a in range(count):
        points.append(point_a+diff*(a+1))
    #print(points)
    return points
def generate_points_for_grid(point_a,point_b,count):
    diff=point_b-point_a
    diff=diff/(count+1)
    points=[point_a]
    for a in range(count):
        points.append(point_a+diff*(a+1))
    #print(points)
    points.append(point_b)
    return points
def generate_points_bb(left,right,objs,axis,context):
    min_x=min([(left.matrix_world @Vector(corner.co))[axis] for corner in left.data.vertices])
    max_x=max(([(right.matrix_world @Vector(corner.co))[axis] for corner in right.data.vertices]))
    max_x_left=max([(left.matrix_world @Vector(corner.co))[axis] for corner in left.data.vertices])
    available_width=max_x-min_x
    combined_width=0
    for obj in [left,]+objs+[right,]:
        obj=obj.evaluated_get(context.evaluated_depsgraph_get())
       # print([(obj.matrix_world @Vector(corner.co)) for corner in obj.bound_box])
        min_obj=min([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices])
        max_obj=max(([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices]))
        #print(obj,max_obj,min_obj)
        combined_width+=max_obj-min_obj
    #print(combined_width,available_width)
    gap=(available_width-combined_width)/(len(objs)+1)
    generated_points=[]
    all_objs=[left,]+objs+[right,]
    last_pos=max_x_left
    for i,obj in enumerate(objs):
        obj=obj.evaluated_get(context.evaluated_depsgraph_get())
        try:
            min_obj=min(([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices]))
            max_obj=max(([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices]))
            obj_width=max_obj-min_obj
            obj_center=(max_obj+min_obj)/2
            actual_center=obj.location[axis]
            diff_center=obj_center-actual_center
            #print(obj,obj_center,actual_center,diff_center)
            #next_min_obj=min(([(all_objs[i+1].matrix_world @Vector(corner))[axis] for corner in all_objs[i+1].bound_box]))
            #next_max_obj=max(([(all_objs[i+1].matrix_world @Vector(corner))[axis] for corner in all_objs[i+1].bound_box]))
            #next_width=next_max_obj-next_min_obj
            #print(obj_width,last_pos,gap,obj_width/2,diff_center)
            
            generated_points.append(last_pos+gap+obj_width/2-diff_center)
            #print(last_pos+gap+obj_width/2-diff_center)
            last_pos=last_pos+gap+obj_width
            #print(last_pos)
        except:
            pass
    return generated_points
def points_from_corners_2d(corners,size_x,size_y,flow):
    a,b,c,d=corners
    if flow==0:
        atob=generate_points_for_grid(a,b,size_x-2)
        ctod=generate_points_for_grid(c,d,size_x-2)
        #print("A",a,b,atob,"B",c,d,ctod)
        points=[]
        for i,point in enumerate(atob):
            points.extend(generate_points_for_grid(point,ctod[i],size_y-2))
    else:
        atob=generate_points_for_grid(a,c,size_x-2)
        ctod=generate_points_for_grid(b,d,size_x-2)
        #print("A",a,b,atob,"B",c,d,ctod)
        points=[]
        for i,point in enumerate(atob):
            points.extend(generate_points_for_grid(point,ctod[i],size_y-2))
    #print(points)
    return points
def generate_grid_points(grid_x,grid_y,size_x,size_y,active,plane,direction,flow=0):
    if plane=="Z":
        if direction=="LEFTDOWN":
            corners=[active.location,active.location-Vector((grid_x*size_x,0,0)),active.location-Vector((0,grid_y*size_y,0)),active.location-Vector((grid_x*size_x,grid_y*size_y,0))]
        elif direction=="RIGHTDOWN":
            corners=[active.location,active.location+Vector((grid_x*size_x,0,0)),active.location-Vector((0,grid_y*size_y,0)),active.location-Vector((-grid_x*size_x,grid_y*size_y,0))]
        if direction=="LEFTUP":
            corners=[active.location,active.location-Vector((grid_x*size_x,0,0)),active.location+Vector((0,grid_y*size_y,0)),active.location-Vector((grid_x*size_x,-grid_y*size_y,0))]
        elif direction=="RIGHTUP":
            corners=[active.location,active.location+Vector((grid_x*size_x,0,0)),active.location+Vector((0,grid_y*size_y,0)),active.location-Vector((-grid_x*size_x,-grid_y*size_y,0))]
    elif plane=="X":
        if direction=="LEFTDOWN":
            corners=[active.location,active.location-Vector((0,0,grid_x*size_x)),active.location-Vector((0,grid_y*size_y,0)),active.location-Vector((0,grid_y*size_y,grid_x*size_x))]
        elif direction=="RIGHTDOWN":
            corners=[active.location,active.location+Vector((0,0,grid_x*size_x)),active.location-Vector((0,grid_y*size_y,0)),active.location-Vector((0,grid_y*size_y,-grid_x*size_x))]
        if direction=="LEFTUP":
            corners=[active.location,active.location-Vector((0,0,grid_x*size_x)),active.location+Vector((0,grid_y*size_y,0)),active.location-Vector((0,-grid_y*size_y,grid_x*size_x))]
        elif direction=="RIGHTUP":
            corners=[active.location,active.location+Vector((0,0,grid_x*size_x)),active.location+Vector((0,grid_y*size_y,0)),active.location-Vector((0,-grid_y*size_y,-grid_x*size_x))]
    elif plane=="Y":
        if direction=="LEFTDOWN":
            corners=[active.location,active.location-Vector((grid_x*size_x,0,0)),active.location-Vector((0,0,grid_y*size_y)),active.location-Vector((grid_x*size_x,0,grid_y*size_y))]
        elif direction=="RIGHTDOWN":
            corners=[active.location,active.location+Vector((grid_x*size_x,0,0)),active.location-Vector((0,0,grid_y*size_y)),active.location-Vector((-grid_x*size_x,0,grid_y*size_y))]
        if direction=="LEFTUP":
            corners=[active.location,active.location-Vector((grid_x*size_x,0,0)),active.location+Vector((0,0,grid_y*size_y)),active.location-Vector((grid_x*size_x,0,-grid_y*size_y))]
        elif direction=="RIGHTUP":
            corners=[active.location,active.location+Vector((grid_x*size_x,0,0)),active.location+Vector((0,0,grid_y*size_y)),active.location-Vector((-grid_x*size_x,0,-grid_y*size_y))]
    #print(direction,corners)
    generated_points=points_from_corners_2d(corners,grid_x,grid_y,flow)
    return generated_points
def find_middle(obj,axis,context):
    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
    min_obj=min([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices])
    max_obj=max([(obj.matrix_world @Vector(corner.co))[axis] for corner in obj.data.vertices])
    return (max_obj+min_obj)/2
class AAD_OT_Align(bpy.types.Operator):
    bl_idname = "aad.align"
    bl_label = "Align"
    bl_description = "Align"
    bl_options = {"REGISTER","UNDO"}
    align:bpy.props.BoolProperty(name="Align",options={'SKIP_SAVE'})
    distribute:bpy.props.BoolProperty(name="Distribute",options={'SKIP_SAVE'})
    method:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    dmethod:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    #task:bpy.props.EnumProperty(items=(("Align","Align","Align"),("Distribute","Distribute","Distribute")))
    direction:bpy.props.EnumProperty(items=(("R To L","R To L","Align Right(+ve) edge of the selected objects to the Left(-ve) edge of the Active Object"),("L To L","L To L","Align Left(-ve) edge of the selected objects to the Left(-ve) edge of the Active Object"),("Center","Center","Align Centers of the selected objects to the Center of the Active Object"),("R To R","R To R","Align Right(+ve) edge of the selected objects to the Right(+ve) edge of the Active Object"),("L To R","L To R","Align Left(-ve) edge of the selected objects to the Right(+ve) edge of the Active Object")))
    axis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))#,("-X","-X","-X"),("-Y","-Y","-Y"),("-Z","-Z","-Z")
    axis_x:bpy.props.BoolProperty(name="X",options={'SKIP_SAVE'})
    axis_y:bpy.props.BoolProperty(name="Y",options={'SKIP_SAVE'})
    axis_z:bpy.props.BoolProperty(name="Z",options={'SKIP_SAVE'})
    daxis_x:bpy.props.BoolProperty(name="X",options={'SKIP_SAVE'})
    daxis_y:bpy.props.BoolProperty(name="Y",options={'SKIP_SAVE'})
    daxis_z:bpy.props.BoolProperty(name="Z",options={'SKIP_SAVE'})
    distribute_pattern:bpy.props.EnumProperty(items=(("1D","1D","1D"),("2D","2D","2D")),options={'SKIP_SAVE'})#,("3D","3D","3D")
    daxis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))
    plane:bpy.props.EnumProperty(items=(("X","X","X"),("Y","Y","Y"),("Z","Z","Z")),options={'SKIP_SAVE'})
    linear_method:bpy.props.EnumProperty(items=(("Equal Distance","Equal Distance","Equal Distance"),("Equal Gap","Equal Gap","Equal Gap")))
    grid_2d:bpy.props.IntVectorProperty(size=2,min=2,default=[2,2],name="Grid Size")
    #grid_y:bpy.props.IntProperty(default=3,min=2)
    #grid_z:bpy.props.IntProperty(default=3,min=2)
    size_2d:bpy.props.FloatVectorProperty(size=2,default=[1,1],name="Cell Size")
    #size_y:bpy.props.FloatProperty(default=1)
    #size_z:bpy.props.FloatProperty(default=1)
    h_dir:bpy.props.EnumProperty(items=(("RIGHT","RIGHT","RIGHT"),("LEFT","LEFT","LEFT")))
    v_dir:bpy.props.EnumProperty(items=(("DOWN","DOWN","DOWN"),("UP","UP","UP")))
    flow_switch:bpy.props.BoolProperty(default=False,name="Switch Flow",description="Switch between Row and Column flow")
    @classmethod
    def poll(cls, context):
        return context.active_object
    def draw(self, context):
        layout= self.layout
        layout.prop(self,'align',toggle=True,icon="TRIA_DOWN")
        #layout.row().prop(self,'task',expand=True)
        
        #layout.row().prop(self,"axis",expand=True)
        
        if self.align:
            if not self.disable_non_mesh_options:
                layout.row().prop(self,'method',expand=True)    
            if self.method=="Bounding Box":
                layout.row().prop(self,'direction',expand=True)
            row=layout.row(align=True)

            row.prop(self,'axis_x',toggle=True)
            row.prop(self,'axis_y',toggle=True)
            row.prop(self,'axis_z',toggle=True)
        layout.prop(self,'distribute',toggle=True,icon="TRIA_DOWN")
        if self.distribute:
            layout.row().prop(self,'distribute_pattern',expand=True)
            if self.distribute_pattern=="1D":
                if not self.disable_non_mesh_options:
                    layout.row().prop(self,'dmethod',expand=True) 
            if self.distribute_pattern=="1D":

                if self.dmethod=="Bounding Box":
                    if not self.disable_non_mesh_options:
                        layout.row().prop(self,'linear_method',expand=True)
                row=layout.row(align=True)

                row.prop(self,'daxis_x',toggle=True)
                row.prop(self,'daxis_y',toggle=True)
                row.prop(self,'daxis_z',toggle=True)
            elif self.distribute_pattern=="2D":
                layout.row().prop(self,'plane',expand=True)
                layout.prop(self,'grid_2d')
                #layout.prop(self,'grid_y')
                layout.prop(self,'size_2d')
                #layout.prop(self,'size_y')
                layout.row().prop(self,'h_dir',expand=True)
                layout.row().prop(self,'v_dir',expand=True)
                layout.prop(self,'flow_switch',toggle=True)
    def execute(self,context):
        active=context.active_object
        #objs=[a for a in [a for a in context.selected_objects if a.type=='MESH'] if a !=active]
        objs=[a for a in context.selected_objects if a !=active]
        if self.align and (self.axis_x or self.axis_y or self.axis_z):
            if not self.disable_non_mesh_options:
                active_evaluated=active.evaluated_get(context.evaluated_depsgraph_get())
                min_x=min([(active.matrix_world @Vector(corner.co))[0] for corner in active_evaluated.data.vertices])
                min_y=min([(active.matrix_world @Vector(corner.co))[1] for corner in active_evaluated.data.vertices])
                min_z=min([(active.matrix_world @Vector(corner.co))[2] for corner in active_evaluated.data.vertices])
                max_x=max([(active.matrix_world @Vector(corner.co))[0] for corner in active_evaluated.data.vertices])
                max_y=max([(active.matrix_world @Vector(corner.co))[1] for corner in active_evaluated.data.vertices])
                max_z=max([(active.matrix_world @Vector(corner.co))[2] for corner in active_evaluated.data.vertices])
                active_center=Vector(((min_x+max_x)/2,(min_y+max_y)/2,(min_z+max_z)/2))
            distances=[]
            if self.method=="Origin":
                
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,obj.location[0]-active.location[0],"x"))
                    if self.axis_y:
                        distances.append((og_obj,obj.location[1]-active.location[1],"y"))
                    if self.axis_z:
                        distances.append((og_obj,obj.location[2]-active.location[2],"z"))
            elif self.direction=="Center":
                
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,calc_center(obj)[0]-active_center[0],"x"))
                    if self.axis_y:
                        distances.append((og_obj,calc_center(obj)[1]-active_center[1],"y"))
                    if self.axis_z:
                        distances.append((og_obj,calc_center(obj)[2]-active_center[2],"z"))
            elif self.direction=="L To R":
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[0] for corner in obj.data.vertices])-max_x,"x"))
                    if self.axis_y:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[1] for corner in obj.data.vertices])-max_y,"y"))
                    if self.axis_z:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[2] for corner in obj.data.vertices])-max_z,"z"))
            elif self.direction=="L To L":
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[0] for corner in obj.data.vertices])-min_x,"x"))
                    if self.axis_y:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[1] for corner in obj.data.vertices])-min_y,"y"))
                    if self.axis_z:
                        distances.append((og_obj,min([(obj.matrix_world @Vector(corner.co))[2] for corner in obj.data.vertices])-min_z,"z"))
            elif self.direction=="R To L":
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[0] for corner in obj.data.vertices])-min_x,"x"))
                    if self.axis_y:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[1] for corner in obj.data.vertices])-min_y,"y"))
                    if self.axis_z:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[2] for corner in obj.data.vertices])-min_z,"z"))
            elif self.direction=="R To R":
                for obj in objs:
                    og_obj=obj
                    obj=obj.evaluated_get(context.evaluated_depsgraph_get())
                    if self.axis_x:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[0] for corner in obj.data.vertices])-max_x,"x"))
                    if self.axis_y:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[1] for corner in obj.data.vertices])-max_y,"y"))
                    if self.axis_z:
                        distances.append((og_obj,max([(obj.matrix_world @Vector(corner.co))[2] for corner in obj.data.vertices])-max_z,"z"))
            #print(distances)
            for obj,distance,axis in distances:
                #print(obj,distance,axis)
                distance_vector=Vector((distance if axis=="x" else 0,distance if axis=="y" else 0,distance if axis=="z" else 0))
                #print(distance_vector)
                obj.location-=distance_vector
        if self.distribute:
            #print(self.distribute_pattern,self.dmethod,self.daxis)
            if self.distribute_pattern=="1D":
                if self.dmethod=="Origin":
                    if self.daxis_x:
                        left_obj=leftmost_obj([a for a in context.selected_objects],0)
                        right_obj=rightmost_obj([a for a in context.selected_objects],0)
                        middle_objs=[a for a in [a for a in context.selected_objects] if a!=left_obj and a!=right_obj]
                        middle_objs=sorted(middle_objs,key=lambda v:v.location[0])
                        count=len(middle_objs)
                        locations_generated=generate_points(left_obj.location[0],right_obj.location[0],count)
                        
                        for i,obj in enumerate(middle_objs):
                            obj.location[0]=locations_generated[i]
                    if self.daxis_y:
                        left_obj=leftmost_obj([a for a in context.selected_objects],1)
                        right_obj=rightmost_obj([a for a in context.selected_objects],1)
                        middle_objs=[a for a in [a for a in context.selected_objects] if a!=left_obj and a!=right_obj]
                        middle_objs=sorted(middle_objs,key=lambda v:v.location[1])
                        count=len(middle_objs)
                        locations_generated=generate_points(left_obj.location[1],right_obj.location[1],count)
                        
                        for i,obj in enumerate(middle_objs):
                            obj.location[1]=locations_generated[i]
                    if self.daxis_z:
                        left_obj=leftmost_obj([a for a in context.selected_objects],2)
                        right_obj=rightmost_obj([a for a in context.selected_objects],2)
                        middle_objs=[a for a in [a for a in context.selected_objects] if a!=left_obj and a!=right_obj]
                        middle_objs=sorted(middle_objs,key=lambda v:v.location[2])
                        count=len(middle_objs)
                        locations_generated=generate_points(left_obj.location[2],right_obj.location[2],count)
                        
                        for i,obj in enumerate(middle_objs):
                            obj.location[2]=locations_generated[i]
                        
                elif self.dmethod=="Bounding Box":
                    if self.daxis_x:
                        left_obj=leftmost_obj([a for a in context.selected_objects if a.type=='MESH'],0)
                        right_obj=rightmost_obj([a for a in context.selected_objects if a.type=='MESH'],0)
                        middle_objs=[a for a in [a for a in context.selected_objects if a.type=='MESH'] if a!=left_obj and a!=right_obj]
                        middle_objs=sorted(middle_objs,key=lambda v:v.location[0])
                        count=len(middle_objs)
                        if self.linear_method=="Equal Gap":
                            locations_generated=generate_points_bb(left_obj,right_obj,middle_objs,0,context)
                            for i,obj in enumerate(middle_objs):
                                obj.location[0]=locations_generated[i]
                        else:
                            locations_generated=generate_points(left_obj.location[0],right_obj.location[0],count)
                            for i,obj in enumerate(middle_objs):
                                middle=find_middle(obj,0,context)
                                obj_middle=obj.location[0]
                                diff_middle=middle-obj_middle
                                obj.location[0]=locations_generated[i]-diff_middle
                    if self.daxis_y:
                        left_obj=leftmost_obj([a for a in context.selected_objects if a.type=='MESH'],1)
                        right_obj=rightmost_obj([a for a in context.selected_objects if a.type=='MESH'],1)
                        middle_objs=[a for a in [a for a in context.selected_objects if a.type=='MESH'] if a!=left_obj and a!=right_obj]
                        middle_objs=sorted(middle_objs,key=lambda v:v.location[1])
                        count=len(middle_objs)
                        if self.linear_method=="Equal Gap":
                            locations_generated=generate_points_bb(left_obj,right_obj,middle_objs,1,context)
                            for i,obj in enumerate(middle_objs):
                                obj.location[1]=locations_generated[i]
                        else:
                            locations_generated=generate_points(left_obj.location[1],right_obj.location[1],count)
                            for i,obj in enumerate(middle_objs):
                                middle=find_middle(obj,1,context)
                                obj_middle=obj.location[1]
                                diff_middle=middle-obj_middle
                                obj.location[1]=locations_generated[i]-diff_middle
                        
                    if self.daxis_z:
                        left_obj=leftmost_obj([a for a in context.selected_objects if a.type=='MESH'],2)
                        right_obj=rightmost_obj([a for a in context.selected_objects if a.type=='MESH'],2)
                        middle_objs=[a for a in [a for a in context.selected_objects if a.type=='MESH'] if a!=left_obj and a!=right_obj]
                        middle_objs=sorted(middle_objs,key=lambda v:v.location[2])
                        count=len(middle_objs)
                        if self.linear_method=="Equal Gap":
                            locations_generated=generate_points_bb(left_obj,right_obj,middle_objs,2,context)
                            for i,obj in enumerate(middle_objs):
                                obj.location[2]=locations_generated[i]
                        else:
                            locations_generated=generate_points(left_obj.location[2],right_obj.location[2],count)
                            for i,obj in enumerate(middle_objs):
                                middle=find_middle(obj,2,context)
                                obj_middle=obj.location[2]
                                
                                obj.location[2]=locations_generated[i]+(middle-obj_middle)
            
            elif self.distribute_pattern=="2D":
                    objs=[a for a in context.selected_objects]
                    
                    locations_generated=generate_grid_points(self.grid_2d[0],self.grid_2d[1],self.size_2d[0],self.size_2d[1],active,plane=self.plane,direction=self.h_dir+self.v_dir,flow=1 if self.flow_switch else 0)
                    for i,obj in enumerate(objs):
                        if self.plane=="Z":
                            obj.location=(locations_generated[i%len(locations_generated)][0],locations_generated[i%len(locations_generated)][1],obj.location[2])
                        elif self.plane=="Y":
                            obj.location=(locations_generated[i%len(locations_generated)][0],obj.location[1],locations_generated[i%len(locations_generated)][2])
                        elif self.plane=="X":
                            obj.location=(obj.location[0],locations_generated[i%len(locations_generated)][1],locations_generated[i%len(locations_generated)][2])
        return {'FINISHED'}
    def invoke(self, context,event):
        aad_props=context.scene.aad_props
        self.method=aad_props.method
        self.dmethod=aad_props.dmethod
        self.distribute_pattern=aad_props.distribute_pattern
        self.linear_method=aad_props.linear_method
        self.v_dir=aad_props.v_dir
        self.h_dir=aad_props.h_dir
        self.direction=aad_props.direction
        self.size_2d=aad_props.size_2d
        self.grid_2d=aad_props.grid_2d
        self.disable_non_mesh_options=False
        for a in context.selected_objects:
            if a.type!='MESH':
                self.disable_non_mesh_options=True
                self.method="Origin"
                self.dmethod="Origin"
        return self.execute(context)
class AAD_OT_Randomize(bpy.types.Operator):
    bl_idname = "aad.randomize"
    bl_label = "Randomize"
    bl_description = "Randomize location of selected objects"
    bl_options = {"REGISTER","UNDO"}
    axis_x:bpy.props.BoolProperty(name="X")
    axis_y:bpy.props.BoolProperty(name="Y")
    axis_z:bpy.props.BoolProperty(name="Z")
    range_start:bpy.props.FloatProperty(default=0,name="Minimun Value")
    range_end:bpy.props.FloatProperty(default=10,name="Maximum Value")
    seed:bpy.props.IntProperty(default=1,name="Seed")
    @classmethod
    def poll(cls, context):
        return context.active_object 
    def draw(self, context):
        layout= self.layout
        layout.prop(self,"seed")
        layout.prop(self,"range_start")
        layout.prop(self,"range_end")
        row=layout.row(align=True)
        row.prop(self,'axis_x',toggle=True)
        row.prop(self,'axis_y',toggle=True)
        row.prop(self,'axis_z',toggle=True)
    def execute(self,context):
        random.seed(self.seed)
        if self.axis_x:
            for obj in context.selected_objects:
                obj.location[0]=round(random.uniform(self.range_start,self.range_end), 2)
        if self.axis_y:
            for obj in context.selected_objects:
                obj.location[1]=round(random.uniform(self.range_start,self.range_end), 2)
        if self.axis_z:
            for obj in context.selected_objects:
                obj.location[2]=round(random.uniform(self.range_start,self.range_end), 2)
        return {'FINISHED'}
class AAD_OT_Swap(bpy.types.Operator):
    bl_idname = "aad.swap"
    bl_label = "Swap Location"
    bl_description = "Swap location of 2 objects"
    bl_options = {"REGISTER","UNDO"}
    @classmethod
    def poll(cls, context):
        return len(context.selected_objects)==2
    def execute(self,context):
        a,b=context.selected_objects
        a_loc=a.location.copy()
        a.location=b.location.copy()
        b.location=a_loc.copy()
        return {'FINISHED'}
class aad_props(bpy.types.PropertyGroup):
    align:bpy.props.BoolProperty(name="Align")
    distribute:bpy.props.BoolProperty(name="Distribute")
    method:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    dmethod:bpy.props.EnumProperty(items=(("Origin","Origin","Origin"),("Bounding Box","Bounding Box","Bounding Box")),default=1,name="Method")
    direction:bpy.props.EnumProperty(items=(("R To L","R To L","Align Right(+ve) edge of the selected objects to the Left(-ve) edge of the Active Object"),("L To L","L To L","Align Left(-ve) edge of the selected objects to the Left(-ve) edge of the Active Object"),("Center","Center","Align Centers of the selected objects to the Center of the Active Object"),("R To R","R To R","Align Right(+ve) edge of the selected objects to the Right(+ve) edge of the Active Object"),("L To R","L To R","Align Left(-ve) edge of the selected objects to the Right(+ve) edge of the Active Object")))
    axis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))#,("-X","-X","-X"),("-Y","-Y","-Y"),("-Z","-Z","-Z")
    axis_x:bpy.props.BoolProperty(name="X")
    axis_y:bpy.props.BoolProperty(name="Y")
    axis_z:bpy.props.BoolProperty(name="Z")
    daxis_x:bpy.props.BoolProperty(name="X")
    daxis_y:bpy.props.BoolProperty(name="Y")
    daxis_z:bpy.props.BoolProperty(name="Z")
    distribute_pattern:bpy.props.EnumProperty(items=(("1D","1D","1D"),("2D","2D","2D")))#,("3D","3D","3D")
    daxis:bpy.props.EnumProperty(items=(("0","X","X"),("1","Y","Y"),("2","Z","Z")))
    plane:bpy.props.EnumProperty(items=(("X","X","X"),("Y","Y","Y"),("Z","Z","Z")))
    linear_method:bpy.props.EnumProperty(items=(("Equal Distance","Equal Distance","Equal Distance"),("Equal Gap","Equal Gap","Equal Gap")))
    grid_2d:bpy.props.IntVectorProperty(size=2,min=2,default=[2,2],name="Grid Size")
    size_2d:bpy.props.FloatVectorProperty(size=2,default=[1,1],name="Cell Size")
    h_dir:bpy.props.EnumProperty(items=(("RIGHT","RIGHT","RIGHT"),("LEFT","LEFT","LEFT")))
    v_dir:bpy.props.EnumProperty(items=(("DOWN","DOWN","DOWN"),("UP","UP","UP")))
classes = (AAD_PT_ALIGN_AND_DISTRIBUTE,AAD_OT_Align,aad_props,AAD_OT_Randomize,AAD_OT_Swap#,AAD_Temp
)

icon_collection={}
addon_keymaps = []

def register():
    from bpy.utils import register_class
    for cls in classes:
        register_class(cls)
    
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    kmaps = [
    ]

    km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
    if kc:
        for (op, k, sp) in kmaps:

            kmi = km.keymap_items.new(
                op,
                type=k,
                value="PRESS",
                alt="alt" in sp,
                shift="shift" in sp,
                ctrl="ctrl" in sp,
            )
            addon_keymaps.append((km, kmi))
    bpy.types.Scene.aad_props=bpy.props.PointerProperty(type=aad_props)
def unregister():

    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)
    for (km, kmi) in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.aad_props
if __name__ == "__main__":
    register()

