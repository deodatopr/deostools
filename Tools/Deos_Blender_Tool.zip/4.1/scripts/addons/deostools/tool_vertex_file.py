#------------------------------------------------
# TOOL EXPORTER MAPS
#------------------------------------------------

import bpy											# Python
import os												# Os
from bpy.types import Operator	# Operators
from mathutils import Vector		# Vectors

#------------------------------------------------
# DEFINITIONS
#------------------------------------------------

# region Axis Direction
def AxisDir_X(obj): 
    return obj.co.x  
def AxisDir_Y(obj): 
    return obj.co.y  
def AxisDir_Z(obj): 
    return obj.co.z 
# endregion

# region Axis Order
def AxisOrder_XYZ(obj): 
    return Vector((obj.x, obj.y, obj.z))

def AxisOrder_XZY(obj): 
    return Vector((obj.x, obj.z, obj.y))
# endregion


#------------------------------------------------
# ACTIONS
#------------------------------------------------

class DeosOperExportVertexFile (Operator):
  
  bl_idname = "deo.export_vertex_file"
  bl_label = ""
  bl_description = ""

  def execute(self, context) :
    
    # region GET UI FROM >> _INIT_
    picker_VertFile_Mesh 			= bpy.context.scene.my_tool.picker_VertFile_Mesh  			
    enum_VertFile_AxisDir   	= bpy.context.scene.my_tool.enum_VertFile_AxisDir
    enum_VertFile_AxisOrder  	= bpy.context.scene.my_tool.enum_VertFile_AxisOrder	
    enum_VertFile_SortVals   	= bpy.context.scene.my_tool.enum_VertFile_SortVals		
    str_VertFile_Name 				= bpy.context.scene.my_tool.str_VertFile_Name 
    str_VertFile_PathDir 			= bpy.context.scene.my_tool.str_VertFile_PathDir 
    # endregion

    if picker_VertFile_Mesh == None :
      self.report({'WARNING'}, "[There is No 'Mesh' Loaded]")
    else :
      
      # region GET/SET OPTIONS

      # Axis Direction 
      if bpy.context.scene.my_tool.enum_VertFile_AxisDir == "Op1" :
        vAxisDir = AxisDir_X
      elif bpy.context.scene.my_tool.enum_VertFile_AxisDir == "Op2" :
        vAxisDir = AxisDir_Y
      elif bpy.context.scene.my_tool.enum_VertFile_AxisDir == "Op3" :
        vAxisDir = AxisDir_Z

      # Axis Order 
      if bpy.context.scene.my_tool.enum_VertFile_AxisOrder == "Op1" :
        vAxisOrder = AxisOrder_XZY
      elif bpy.context.scene.my_tool.enum_VertFile_AxisOrder == "Op2" :
        vAxisOrder = AxisOrder_XYZ

      # Sort Values 
      if bpy.context.scene.my_tool.enum_VertFile_SortVals == "Op1" :
        vSortVal = False
      elif bpy.context.scene.my_tool.enum_VertFile_SortVals == "Op2" :
        vSortVal = True
      
      # Inver Forward 
      if bpy.context.scene.my_tool.enum_VertFile_InvertForward  == "Op1" :
        vForward = -1
      elif bpy.context.scene.my_tool.enum_VertFile_InvertForward == "Op2" :
        vForward = 1

      # PathLocation
      if str_VertFile_PathDir == 'Blender File Location' :
        vPathDir = ''
      else : 
        vPath_RelatToAbs = bpy.path.abspath(bpy.context.scene.my_tool.str_VertFile_PathDir)
        vPathDir = vPath_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

# endregion

      # region GET DATA MESH
      VertFile_Mesh = bpy.data.objects[picker_VertFile_Mesh.name]		

      # FILE
      if VertFile_Mesh and VertFile_Mesh.type == 'MESH':
        mesh = VertFile_Mesh.data             					# Mesh from Object
        vertices = mesh.vertices    										# Vertices from  mesh
          
        # Read File
        with open(f"{vPathDir}{str_VertFile_Name}", "w") as file:
            
            newverts = sorted(vertices, key=vAxisDir, reverse=vSortVal) # Direction + Sorting
            
            # Vertex Coordinates
            for vert in newverts:
                vFinalAxisOrder = vAxisOrder(vert.co)
                vXYZ = f"{vFinalAxisOrder.x: .3f}, {vFinalAxisOrder.y: .3f}, {(vFinalAxisOrder.z * vForward): .3f}"
                
                # Write File
                file.write(f"{vXYZ}\n")	
      
        # INFO
        self.report({'INFO'}, "VERTEX FILE EXPORTED")

      # endregion
      
    return {'FINISHED'}