#------------------------------------------------
# TOOL EXPORTER MAPS
#------------------------------------------------

import bpy											# Python
import os												# Os
import time											# Time
from bpy.types import Operator	# Operators

#------------------------------------------------


# Call: Bake Normal
def Call_ExporterMap_Normal() :
	bpy.ops.object.bake('INVOKE_DEFAULT', type='NORMAL')
	bpy.ops.object.select_all(action='DESELECT')
	
# Call: Bake Emit (Metallic)
def Call_ExporterMap_Emit() :
	bpy.ops.object.bake('INVOKE_DEFAULT', type='EMIT')
	bpy.ops.object.select_all(action='DESELECT')


# Operator: Exporter Batch
class DeosOperExporterMapBatch (Operator):
	
	bl_idname = "deo.exportermap_batch"
	bl_label = ""
	bl_description = "Export Maps [ Batch the Map(s) selected ]"
	
	def execute(self, context) :
	
		# Mesh Loaded
		v_ObjPickerHighSel = bpy.context.scene.my_tool.picker_ExporterMap_High  		# _init_

		if v_ObjPickerHighSel == None :
			self.report({'WARNING'}, "[There is No 'Mesh' Loaded]")
			
		else :
			# Mesh Loaded, mats?
			v_SelectedHighMesh = bpy.data.objects[bpy.context.scene.my_tool.picker_ExporterMap_High.name]
			bpy.context.view_layer.objects.active = v_SelectedHighMesh
		
			if len(bpy.context.active_object.data.materials) == 0:
				self.report({'WARNING'}, "[The loaded mesh has No 'Material']")
				
			else :

				# OBJETOS VALORES DE PASES SELECCIONADOS CON SUS NOMBRES
				BoolPassBaseColor = bpy.context.scene.my_tool.bool_ExporterMap_Color  		# _init_
				BoolPassMetallic = bpy.context.scene.my_tool.bool_ExporterMap_Metallic  	# _init_
				BoolPassRoughness = bpy.context.scene.my_tool.bool_ExporterMap_Roughness  # _init_
				BoolPassNormal = bpy.context.scene.my_tool.bool_ExporterMap_Normal  			# _init_
				BoolPassEmission = bpy.context.scene.my_tool.bool_ExporterMap_Emission  	# _init_

				# LIMPIAR SELECCIONES
				bpy.ops.object.select_all(action='DESELECT')

				# ACTIVAR OBJETO Y MATERIAL
				ObjExpMaps = bpy.context.scene.my_tool.picker_ExporterMap_High						# _init_
				bpy.data.objects[ObjExpMaps.name].select_set(True)
				MatObjExpMaps = ObjExpMaps.data.materials[0]

				# TAMAÑO DE TEXTURA
				if bpy.context.scene.my_tool.enum_ExporterMap_ImgSize == "Op1" :
					v_TextureSize = 256
				elif bpy.context.scene.my_tool.enum_ExporterMap_ImgSize == "Op2" :
					v_TextureSize = 512
				elif bpy.context.scene.my_tool.enum_ExporterMap_ImgSize == "Op3" :
					v_TextureSize = 1024
				elif bpy.context.scene.my_tool.enum_ExporterMap_ImgSize == "Op4" :
					v_TextureSize = 2048
				elif bpy.context.scene.my_tool.enum_ExporterMap_ImgSize == "Op5" :
					v_TextureSize = 4096
				elif bpy.context.scene.my_tool.enum_ExporterMap_ImgSize == "Op6" :
					v_TextureSize = 8192

				# FORMATO DE IMAGEN
				if bpy.context.scene.my_tool.enum_ExporterMap_ImgFormat == "Op1" :
					v_TextureFormatImg = 'JPEG'
					v_TxtExtension = ".jpg"
				elif bpy.context.scene.my_tool.enum_ExporterMap_ImgFormat == "Op2" :
					v_TextureFormatImg = 'PNG'
					v_TxtExtension = ".png"
				elif bpy.context.scene.my_tool.enum_ExporterMap_ImgFormat == "Op3" :
					v_TextureFormatImg = 'TARGA'
					v_TxtExtension = ".tga"

				# UV EDGE
				if bpy.context.scene.my_tool.enum_ExporterMap_edgePadding == "Op1" :
					v_EdgeMargin = 8192
				elif bpy.context.scene.my_tool.enum_ExporterMap_edgePadding == "Op2" :
					v_EdgeMargin = 128
				elif bpy.context.scene.my_tool.enum_ExporterMap_edgePadding == "Op3" :
					v_EdgeMargin = 64
				elif bpy.context.scene.my_tool.enum_ExporterMap_edgePadding == "Op4" :
					v_EdgeMargin = 32
				elif bpy.context.scene.my_tool.enum_ExporterMap_edgePadding == "Op5" :
					v_EdgeMargin = 16
				elif bpy.context.scene.my_tool.enum_ExporterMap_edgePadding == "Op6" :
					v_EdgeMargin = 8
				elif bpy.context.scene.my_tool.enum_ExporterMap_edgePadding == "Op7" :
					v_EdgeMargin = 4


				# ------------------
				# MAPAS A EXPORTAR
				# ------------------

				# BASE COLOR ------------------
				if BoolPassBaseColor :
					
					v_TxtPassName = '_Color'		# Nombre del pase a exportar
					v_BakeType = 'DIFFUSE'			# Nombre del Bake a procesar
					
					# Crear Image Texture
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=True )
					# bpy.context.scene.render.image_settings.compression = 75
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.colorspace_settings.name = 'sRGB'
					TxtImageNode.generated_color = [0,0,0,1]

					# Crear Image Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Mesh y Textturas Activas (Seleccionadas)
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode

					# [ BAKE ]

					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType

					bpy.context.scene.render.bake.use_pass_direct = False
					bpy.context.scene.render.bake.use_pass_indirect = False
					bpy.context.scene.render.bake.use_pass_color = True
					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True
					
					
					# Metallic -----------
					# ***************** Nota: Si existe Metallic el Base color sale negro, por lo cual se debe de quitar para calcular BC ******************
					# Obtener Material y Nodos especificos
					v_ActiveMaterial = bpy.context.active_object.active_material  							# Obtener Material Mesh
					v_GetMatBSD = v_ActiveMaterial.node_tree.nodes.get("Principled BSDF")				# Obtener Mat BSDF
					v_MetalRestoreConnection = ''
					v_MetalWire = False																					

					if v_GetMatBSD.inputs["Metallic"].links :																		# Si esta Conectado
						
						if v_GetMatBSD.inputs["Metallic"].links[0].is_muted :											# Esta en Mute
							v_GetMatBSD.inputs["Metallic"].default_value = 0
						else : 																																		# No esta Conectado
							v_MetalWire = v_GetMatBSD.inputs["Metallic"].links[0]									 	# Obtener la conexion
							v_MetalWire.is_muted = True																							# Conextion Mute
							v_GetMatBSD.inputs["Metallic"].default_value = 0												# Ahora Setar el Valor 
							
							v_MetalRestoreConnection = 'SiConectado'

					else : 																																			# No esta Conectado
							v_get_MetallicVal = v_GetMatBSD.inputs["Metallic"].default_value				# Guardar su valor
							v_GetMatBSD.inputs["Metallic"].default_value = 0												# Sin Metal para no afectar a BC
							v_MetalRestoreConnection = 'NoConectado'
							
					# *****************

					# Action
					bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
					bpy.ops.wm.redraw_timer()


					# Esperar hasta que termine el bake en la textura
					# while TxtImageNode.is_dirty :
						# break
					

					# [ SAVE ]

					# FileName
					if bpy.context.scene.my_tool.bool_ExporterMap_MeshName :
						v_TxtFileName = ObjExpMaps.name
					else :
						v_TxtFileName = bpy.context.scene.my_tool.str_ExporterMap_FileNameCustom

					# PathLocation
					if bpy.context.scene.my_tool.str_ExporterMap_PathDir == 'Blender File Location' :
						v_PathDir = ''
					else : 
						v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.my_tool.str_ExporterMap_PathDir)
						v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

					# Action
					TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
					bpy.ops.wm.redraw_timer()
					

					# [ CLEAN ]
					if v_MetalRestoreConnection == 'SiConectado': 
						v_MetalWire.is_muted = False												# Regresar la Conexion anterior
					
					elif v_MetalRestoreConnection == 'NoConectado': 
						v_GetMatBSD.inputs["Metallic"].default_value = v_get_MetallicVal								# Regresar el valor anterior

					bpy.data.images.remove(TxtImgShaNode.image)
					MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
					bpy.ops.wm.redraw_timer()

				# METALLIC ------------------
				if BoolPassMetallic :
					
					v_TxtPassName = '_Metallic'		# Nombre del pase a exportar
					v_BakeType = 'EMIT'						# Nombre del Bake a procesar

					# Obtener Material y Nodos especificos
					v_ActiveMaterial = bpy.context.active_object.active_material  						# Obtener Material Mesh
					v_GetMatOut = v_ActiveMaterial.node_tree.nodes.get("Material Output")				# Obtener Mat Output
					v_GetMatBSD = v_ActiveMaterial.node_tree.nodes.get("Principled BSDF")				# Obtener Mat BSDF
					
					# Validar si hay algo en si input y que tiene 'Conectado sin Mute/Conectado con Mute'
					if bool(v_GetMatBSD.inputs["Metallic"].links) == True and bool(v_GetMatBSD.inputs["Metallic"].links[0].is_muted) == False:

						v_GetMetallicInBSDF = v_GetMatBSD.inputs.get('Metallic').links[0].from_node		# Obtener Nodo en Metallic del BSDF
						# v_GetMetNodeOut = v_GetMetalNodeInBSDF.outputs[0].name						# Obtiene el 1er Output del nodo en Metallic
					
						# Iterar en el nodo de metallic para saber que Output es el del final y saber cual es el  conectado.
						for v_output_socket in v_GetMetallicInBSDF.outputs:
								if v_output_socket.is_linked:
									# Conectar: MetallicNode a MatOt
									v_ActiveMaterial.node_tree.links.new(v_GetMetallicInBSDF.outputs[v_output_socket.name], v_GetMatOut.inputs["Surface"])
									break
					

						# -----

						# Crear Image Texture Node
						TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
						TxtImageNode.file_format = v_TextureFormatImg
						TxtImageNode.generated_color = [0,0,0,1]
						TxtImageNode.colorspace_settings.name = 'Non-Color'
						TxtImageNode.colorspace_settings.is_data = True
						
						# Crear Image Shader Node
						TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
						TxtImgShaNode.name = 'Deos_ExporterMap_Node'
						TxtImgShaNode.image = TxtImageNode


						# Objeto y Texttura Activos
						bpy.context.view_layer.objects.active = ObjExpMaps
						MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode


						# -----
						
						# [ BAKE ]
						
						# Settings
						bpy.context.scene.cycles.bake_type = v_BakeType
						bpy.context.scene.render.bake.use_selected_to_active = False
						bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
						bpy.context.scene.render.bake.use_clear = True
						
						# Action
						bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
						bpy.ops.wm.redraw_timer()
						
						
						# Esperar hasta que termine el bake en la textura
						# while TxtImageNode.is_dirty :
							# break
						
						# -----


						# [ SAVE ]

						# FileName
						if bpy.context.scene.my_tool.bool_ExporterMap_MeshName :
							v_TxtFileName = ObjExpMaps.name
						else :
							v_TxtFileName = bpy.context.scene.my_tool.str_ExporterMap_FileNameCustom

						# PathLocation
						if bpy.context.scene.my_tool.str_ExporterMap_PathDir == 'Blender File Location' :
							v_PathDir = ''
						else : 
							v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.my_tool.str_ExporterMap_PathDir)
							v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'


						# SaveImg
						TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
						bpy.ops.wm.redraw_timer()
						
						# -----

						# [ CLEAN ]
						v_ActiveMaterial.node_tree.links.new(v_GetMatBSD.outputs['BSDF'], v_GetMatOut.inputs["Surface"])
						bpy.ops.wm.redraw_timer()
						bpy.data.images.remove(TxtImgShaNode.image)
						bpy.ops.wm.redraw_timer()
						MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
						bpy.ops.wm.redraw_timer()
					
					# No tiene nada conectado Metallic
					else :
							# SINO HAY NADA CONECTADO CREAR LA TEXTURA CON EL VALOR DEL METALLIC Y SOLO GUARDAR ESA TEXTURA
							
							v_rgb = v_GetMatBSD.inputs["Metallic"].default_value

							# Crear Image Texture Node
							TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
							TxtImageNode.file_format = v_TextureFormatImg
							TxtImageNode.colorspace_settings.name = 'Non-Color'
							TxtImageNode.generated_color = [v_rgb,v_rgb,v_rgb,1]
							
							# Crear Image Shader Node
							TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
							TxtImgShaNode.name = 'Deos_ExporterMap_Node'
							TxtImgShaNode.image = TxtImageNode

							# Objeto y Texttura Activos
							bpy.context.view_layer.objects.active = ObjExpMaps
							MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode
						
							# [ SAVE ]

							# FileName
							if bpy.context.scene.my_tool.bool_ExporterMap_MeshName :
								v_TxtFileName = ObjExpMaps.name
							else :
								v_TxtFileName = bpy.context.scene.my_tool.str_ExporterMap_FileNameCustom

							# PathLocation
							if bpy.context.scene.my_tool.str_ExporterMap_PathDir == 'Blender File Location' :
								v_PathDir = ''
							else : 
								v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.my_tool.str_ExporterMap_PathDir)
								v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

							# SaveImg
							TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
							bpy.ops.wm.redraw_timer()

							# Clean
							bpy.data.images.remove(TxtImgShaNode.image)
							MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
							bpy.ops.wm.redraw_timer()

				# ROUGHNESS ------------------
				if BoolPassRoughness :
					
					v_TxtPassName = '_Roughness'	# Nombre del pase a exportar
					v_BakeType = 'ROUGHNESS'		# Nombre del Bake a procesar

					# Crear Image Texture
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.generated_color = [0,0,0,1]
					TxtImageNode.colorspace_settings.name = 'Non-Color'
					TxtImageNode.colorspace_settings.is_data = True
					

					# Crear Image Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Objeto y Texttura Activos
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode


					# [ BAKE ]

					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType
					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True

					# Action
					bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
					bpy.ops.wm.redraw_timer()
					

					# Esperar hasta que termine el bake en la textura
					# while TxtImageNode.is_dirty :
						# break

					
					# [ SAVE ]

					# FileName
					if bpy.context.scene.my_tool.bool_ExporterMap_MeshName :
						v_TxtFileName = ObjExpMaps.name
					else :
						v_TxtFileName = bpy.context.scene.my_tool.str_ExporterMap_FileNameCustom

					# PathLocation
					if bpy.context.scene.my_tool.str_ExporterMap_PathDir == 'Blender File Location' :
						v_PathDir = ''
					else : 
						v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.my_tool.str_ExporterMap_PathDir)
						v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

					# Action
					TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
					bpy.ops.wm.redraw_timer()


					# [ CLEAN ]
					bpy.data.images.remove(TxtImgShaNode.image)
					MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
					bpy.ops.wm.redraw_timer()
				
				# NORMAL ------------------
				if BoolPassNormal :
					
					v_TxtPassName = '_Normal'	# Nombre del pase a exportar
					v_BakeType = 'NORMAL'		# Nombre del Bake a procesar

					# Crear Image Texture
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.generated_color = [0.5,0.5,1,1]
					TxtImageNode.colorspace_settings.name = 'Non-Color'
					TxtImageNode.colorspace_settings.is_data = True


					# Crear Image Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Activar: Objeto y Textura
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode

					# -----

					# [ BAKE ]
					
					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType

					bpy.context.scene.render.bake.normal_space = 'TANGENT'
					bpy.context.scene.render.bake.normal_r = 'POS_X'
					bpy.context.scene.render.bake.normal_g = 'POS_Y'
					bpy.context.scene.render.bake.normal_b = 'POS_Z'

					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True
					
					# Action
					bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
					bpy.ops.wm.redraw_timer()
					

					# Esperar hasta que termine el bake en la textura
					# while TxtImageNode.is_dirty :
						# break
					
					# -----

					# [ SAVE ]

					# FileName
					if bpy.context.scene.my_tool.bool_ExporterMap_MeshName :
						v_TxtFileName = ObjExpMaps.name
					else :
						v_TxtFileName = bpy.context.scene.my_tool.str_ExporterMap_FileNameCustom

					# PathLocation
					if bpy.context.scene.my_tool.str_ExporterMap_PathDir == 'Blender File Location' :
						v_PathDir = v_TxtFileName + v_TxtPassName + v_TxtExtension
					else : 
						v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.my_tool.str_ExporterMap_PathDir)
						v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

					# Action
					TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
					TxtImageNode.colorspace_settings
					bpy.ops.wm.redraw_timer()
					
					# -----
					
					# [ CLEAN ]
					bpy.data.images.remove(TxtImgShaNode.image)
					MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
					bpy.ops.wm.redraw_timer()
					
					"""
					"""
				
				# EMISSION ------------------
				if BoolPassEmission :
					
					v_TxtPassName = '_Emission'	# Nombre del pase a exportar
					v_BakeType = 'EMIT'			# Nombre del Bake a procesar

					# Crear Image Texture
					TxtImageNode = bpy.data.images.new(name='Deos_BakePass_Img', width=v_TextureSize, height=v_TextureSize, alpha=False )
					TxtImageNode.file_format = v_TextureFormatImg
					TxtImageNode.colorspace_settings.name = 'sRGB'
					TxtImageNode.generated_color = [0,0,0,1]
					
					# Crear Image Node
					TxtImgShaNode = MatObjExpMaps.node_tree.nodes.new(type='ShaderNodeTexImage')
					TxtImgShaNode.name = 'Deos_ExporterMap_Node'
					TxtImgShaNode.image = TxtImageNode

					# Objeto y Texttura Activos
					bpy.context.view_layer.objects.active = ObjExpMaps
					MatObjExpMaps.node_tree.nodes.active = TxtImgShaNode
					
					# [ BAKE ]
					
					# Settings
					bpy.context.scene.cycles.bake_type = v_BakeType
					bpy.context.scene.render.bake.use_selected_to_active = False
					bpy.context.scene.render.bake.target = 'IMAGE_TEXTURES'
					bpy.context.scene.render.bake.use_clear = True
					
					# Action
					bpy.ops.object.bake(type = v_BakeType, margin=v_EdgeMargin)
					bpy.ops.wm.redraw_timer()
					
					# Esperar hasta que termine el bake en la textura
					# while TxtImageNode.is_dirty :
						# break
					
					
					# [ SAVE ]

					# FileName
					if bpy.context.scene.my_tool.bool_ExporterMap_MeshName :
						v_TxtFileName = ObjExpMaps.name
					else :
						v_TxtFileName = bpy.context.scene.my_tool.str_ExporterMap_FileNameCustom

					# PathLocation
					if bpy.context.scene.my_tool.str_ExporterMap_PathDir == 'Blender File Location' :
						v_PathDir = v_TxtFileName + v_TxtPassName + v_TxtExtension
					else : 
						v_Path_RelatToAbs = bpy.path.abspath(bpy.context.scene.my_tool.str_ExporterMap_PathDir)
						v_PathDir = v_Path_RelatToAbs.replace('\\', '\\\\') #remplazar '\' por '\\'

					# Action
					TxtImageNode.save(filepath = v_PathDir + v_TxtFileName + v_TxtPassName + v_TxtExtension)
					bpy.ops.wm.redraw_timer()
					

					# [ CLEAN ]
					bpy.data.images.remove(TxtImgShaNode.image)
					MatObjExpMaps.node_tree.nodes.remove(TxtImgShaNode)
					bpy.ops.wm.redraw_timer()
					
					# -----------


				# No Selection mesh
				bpy.ops.object.select_all(action='DESELECT')
				
				# Info
				self.report({'INFO'}, "[Map(s) saved is done]")

		return {'FINISHED'}