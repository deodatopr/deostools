from . import (
    better_bone_extrude,
    flatten_chain,
    pie_bone_parenting,
    pie_bone_selection_ops,
    pie_bone_selection_ui,
    pie_bone_specials,
    pie_custom_shapes,
    symmetrize,
    toggle_action_constraints,
    toggle_metarig,
    copy_mirror_components,
    apply_bone_color_preset,
)

modules = [
    better_bone_extrude,
    pie_bone_selection_ops,
    pie_bone_selection_ui,
    flatten_chain,
    pie_bone_parenting,
    pie_bone_specials,
    symmetrize,
    toggle_action_constraints,
    toggle_metarig,
    copy_mirror_components,
    apply_bone_color_preset,
    pie_custom_shapes,
]
