# SPDX-License-Identifier: GPL-3.0-or-later

import bpy, os
from bpy.types import Object, Operator, Menu
from bpy.props import StringProperty
from . import versioning

# Global storage of available metarigs. List of UI name and object name tuples.
metarig_names: list[tuple[str, str]] = []
sample_names: list[tuple[str, str]] = []


class CLOUDRIG_OT_metarig_add(Operator):
    bl_idname = "object.cloudrig_metarig_add"
    bl_label = "Add CloudRig Meta-Rig"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    metarig_name: StringProperty()

    def execute(self, context):
        metarig = append_metarig(context, self.metarig_name)
        if not metarig:
            self.report({'ERROR'}, "Failed to load metarig: " + self.metarig_name)
            return {'CANCELLED'}

        self.report({'INFO'}, "Loaded Metarig: " + metarig.name)
        return {'FINISHED'}


class CLOUDRIG_OT_sample_add(Operator):
    bl_idname = "object.cloudrig_sample_add"
    bl_label = "Add CloudRig Sample"
    bl_options = {'REGISTER', 'UNDO', 'INTERNAL'}

    sample_name: StringProperty()

    def execute(self, context):
        if context.mode == 'EDIT_ARMATURE':
            sample_obj = add_sample_to_current_rig(context, self.sample_name)
        else:
            sample_obj = append_sample(context, self.sample_name)
        if not sample_obj:
            self.report({'ERROR'}, "Failed to load rig sample: " + self.sample_name)
            return {'CANCELLED'}

        self.report({'INFO'}, "Added rig sample: " + sample_obj.name)
        return {'FINISHED'}


class CLOUDRIG_MT_metarigs(Menu):
    bl_label = "CloudRig Metarigs"

    def draw(self, context):
        global metarig_names
        for ui_name, obj_name in metarig_names:
            self.layout.operator(
                CLOUDRIG_OT_metarig_add.bl_idname,
                icon='OUTLINER_OB_ARMATURE',
                text=ui_name,
            ).metarig_name = obj_name


class CLOUDRIG_MT_rig_samples(Menu):
    bl_label = "CloudRig Samples"

    def draw(self, context):
        global sample_names
        for ui_name, obj_name in sample_names:
            self.layout.operator(
                CLOUDRIG_OT_sample_add.bl_idname,
                icon='OUTLINER_OB_ARMATURE',
                text=ui_name,
            ).sample_name = obj_name


def get_available_object_name(obj_name: str) -> str:
    """Return an available suffixed name for the passed name.
    Eg., if "Cube" is passed, but that name is taken by an existing local object,
    return Cube.001, or if that's taken, Cube.002, and so on.

    Library objects are ignored, since they are in a separate name space.
    """
    number = 1
    numbered_name = obj_name
    while bpy.data.objects.get((numbered_name, None)):
        numbered_name = obj_name + "." + str(number).zfill(3)
        number += 1

    return numbered_name


def append_obj_from_file(
    context, blend_path, obj_name, link_to_scene=True, select=True, use_cursor=True
) -> Object:
    """Append an object from a .blend file and return it."""
    available_name = get_available_object_name(obj_name)

    # Loading object from file
    with bpy.data.libraries.load(blend_path) as (data_from, data_to):
        for o in data_from.objects:
            if o == obj_name:
                data_to.objects.append(o)

    new_obj = bpy.data.objects.get((available_name, None))

    assert new_obj, f"Object `{obj_name}` failed to append from `{blend_path}`."

    if link_to_scene:
        context.scene.collection.objects.link(new_obj)
    if select:
        context.view_layer.objects.active = new_obj
        new_obj.select_set(True)
    if use_cursor:
        new_obj.location = context.scene.cursor.location
    return new_obj


def append_metarig(context, metarig_name) -> Object | None:
    """Append a metarig from MetaRigs.blend."""
    bpy.ops.object.select_all(action='DESELECT')
    new_metarig = append_obj_from_file(context, get_metarig_blend_path(), metarig_name)

    return new_metarig


def append_sample(context, sample_name):
    """Append a sample from rig_samples.blend"""
    if "Sample_" not in sample_name:
        sample_name = "Sample_" + sample_name
    return append_obj_from_file(context, get_metarig_blend_path(), sample_name)


def add_sample_to_current_rig(context, sample_name: str) -> Object:
    """Append a rig sample from MetaRigs.blend, then join it into the currently active armature."""

    rig = context.active_object
    mode = rig.mode
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    sample_ob = append_sample(context, sample_name)

    rig.select_set(True)
    sample_ob.select_set(True)
    context.view_layer.objects.active = rig
    bpy.ops.object.join()
    bpy.ops.object.mode_set(mode=mode)


def get_metarig_blend_path() -> str:
    filedir = os.path.dirname(os.path.realpath(__file__))
    blend_path = os.sep.join([filedir, 'MetaRigs.blend'])
    return blend_path


def refresh_metarig_list():
    """Build a list of available metarigs by checking inside MetaRigs.blend."""

    global metarig_names
    metarig_names = []

    with bpy.data.libraries.load(get_metarig_blend_path()) as (data_from, data_to):
        for obj_name in data_from.objects:
            if obj_name.startswith("META-"):
                ui_name = obj_name.replace("META-", "").replace("_", " ")
                metarig_names.append((ui_name, obj_name))

    return metarig_names


def refresh_rig_sample_list():
    """Build a list of available rig sample by checking inside MetaRigs.blend."""

    global sample_names
    sample_names = []

    with bpy.data.libraries.load(get_metarig_blend_path()) as (data_from, data_to):
        for obj_name in data_from.objects:
            if obj_name.startswith("Sample_"):
                ui_name = obj_name.replace("Sample_", "").replace("_", " ").title()
                sample_names.append((ui_name, obj_name))

    return sample_names


def draw_cloudrig_metarig_menu(self, context):
    self.layout.menu('CLOUDRIG_MT_metarigs', icon='OUTLINER_OB_ARMATURE')
    self.layout.menu('CLOUDRIG_MT_rig_samples', icon='OUTLINER_OB_ARMATURE')


registry = [
    CLOUDRIG_OT_metarig_add,
    CLOUDRIG_OT_sample_add,
    CLOUDRIG_MT_metarigs,
    CLOUDRIG_MT_rig_samples,
]

modules = [versioning]

# Registering is a bit tricky because we need to load a resource .blend file,
# which is not allowed by bpy during registration, so we have to do it with a delay.
def delayed_refresh_metarig_list():
    refresh_metarig_list()
    refresh_rig_sample_list()


def register():
    bpy.app.timers.register(delayed_refresh_metarig_list)
    bpy.types.VIEW3D_MT_armature_add.append(draw_cloudrig_metarig_menu)
    versioning.update_all_metarigs()

def unregister():
    bpy.types.VIEW3D_MT_armature_add.remove(draw_cloudrig_metarig_menu)
