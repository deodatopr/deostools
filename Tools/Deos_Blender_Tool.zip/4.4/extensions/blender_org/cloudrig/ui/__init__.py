from . import (
    component_list,
    component_param_panels,
    menu_3dview,
    cloudrig_main_panel,
    actions_ui,
)

modules = [
    menu_3dview,
    cloudrig_main_panel,
    component_list,
    component_param_panels,
    actions_ui,
]
