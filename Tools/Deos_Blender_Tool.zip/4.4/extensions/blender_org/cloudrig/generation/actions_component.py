# SPDX-License-Identifier: GPL-3.0-or-later

# Originally designed and implemented by me (Demeter Dzadik),
# then re-written without functional changes for Rigify by Alexander Gavrilov.
# Then I threw away all my code, and modified his to fit into CloudRig again.

# The UI for these features are implemented in ui/actions_ui.py.

from bpy.types import Action, Mesh, Object

from bpy.utils import flip_name as mirror_name
from ..utils.external.naming import Side, get_name_side, change_name_side
from ..utils.external.mechanism import (
    driver_var_transform,
    quote_property,
    make_driver,
    make_constraint,
)
from ..rig_component_features.properties_ui import make_property


class MetarigError(Exception):
    pass


class ActionLayer:
    """An action constraint layer instance, applying an action to a symmetry side."""

    owner: 'ActionLayerComponent'
    slot: "ActionSlot"
    side: Side

    def __init__(self, owner, slot, side):
        self.owner = owner
        self.slot = slot
        self.side = side
        self.generator = owner.generator

        self.name = self._get_name()

        self.use_trigger = False

        if slot.is_corrective:
            trigger_a = self.owner.action_map[slot.trigger_slot_a]
            trigger_b = self.owner.action_map[slot.trigger_slot_b]

            self.trigger_a = trigger_a.get(side) or trigger_a.get(Side.MIDDLE)
            self.trigger_b = trigger_b.get(side) or trigger_b.get(Side.MIDDLE)

            self.trigger_a.use_trigger = True
            self.trigger_b.use_trigger = True

            self.bone_name = change_name_side(self.trigger_a.slot.subtarget, side)
        else:
            self.bone_name = change_name_side(slot.subtarget, side)

        self.bones = self._filter_bones()

        self.owner.layers.append(self)

    @property
    def use_property(self):
        return self.slot.is_corrective or self.use_trigger

    def _get_name(self):
        name = self.slot.action.name

        if self.side == Side.LEFT:
            name += ".L"
        elif self.side == Side.RIGHT:
            name += ".R"

        return name

    def _filter_bones(self):
        controls = self._control_bones()
        bones = [bone for bone in self.slot.keyed_bone_names if bone not in controls]

        if self.side != Side.MIDDLE:
            bones = [
                name
                for name in bones
                if get_name_side(name) in (self.side, Side.MIDDLE)
            ]

        return bones

    def _control_bones(self):
        if self.slot.is_corrective:
            return self.trigger_a._control_bones() | self.trigger_b._control_bones()
        elif self.slot.do_symmetry:
            return {self.bone_name, mirror_name(self.bone_name)}
        else:
            return {self.bone_name}

    def create_custom_property(self):
        if self.use_property:
            factor = self.slot.get_default_factor(self.side)

            owner = self.generator.target_rig.pose.bones.get(self.bone_name)

            make_property(
                owner=owner,
                name=self.name,
                default=float(factor),
            )

    def rig_bones_and_shape_keys(self):
        if self.slot.is_corrective and self.use_trigger:
            raise MetarigError(
                f"Corrective action used as trigger: {self.slot.action.name}"
            )

        if self.use_property:
            self.rig_input_driver(
                self.generator.target_rig.pose.bones.get(self.bone_name),
                quote_property(self.name),
            )

        for bone_name in self.bones:
            self.rig_bone(bone_name)

        self.rig_child_shape_keys()

    def rig_bone(self, bone_name):
        if bone_name not in self.generator.target_rig.pose.bones:
            self.generator.logger.log(
                "Action constraint failed",
                trouble_bone=bone_name,
                description=f'Bone "{bone_name}" was not found, so it cannot get an Action constraint for `{self.slot.action.name}`.',
            )
            return

        if self.side != Side.MIDDLE and get_name_side(bone_name) == Side.MIDDLE:
            influence = 0.5
        else:
            influence = 1.0

        con = make_constraint(
            self.generator.target_rig.pose.bones[bone_name],
            'ACTION',
            name=f'Action {self.name}',
            insert_index=0,
            use_eval_time=True,
            action=self.slot.action,
            frame_start=self.slot.frame_start,
            frame_end=self.slot.frame_end,
            mix_mode='BEFORE_SPLIT',
            influence=influence,
        )

        self.rig_output_driver(con, 'eval_time')

    def rig_output_driver(self, owner, prop_name):
        if self.use_property:
            make_driver(
                owner,
                prop_name,
                variables=[
                    (
                        self.generator.target_rig,
                        f'pose.bones["{self.bone_name}"]["{self.name}"]',
                    )
                ],
            )
        else:
            self.rig_input_driver(owner, prop_name)

    def rig_input_driver(self, owner, prop_name):
        if self.slot.is_corrective:
            self.rig_corrective_driver(owner, prop_name)
        else:
            self.rig_factor_driver(owner, prop_name)

    def rig_corrective_driver(self, owner, prop_name):
        make_driver(
            owner,
            prop_name,
            expression=self.slot.get_trigger_expression('a', 'b'),
            variables={
                'a': (
                    self.generator.target_rig,
                    f'pose.bones["{owner.name}"]["{self.trigger_a.name}"]',
                ),
                'b': (
                    self.generator.target_rig,
                    f'pose.bones["{self.trigger_b.bone_name}"]["{self.trigger_b.name}"]',
                ),
            },
        )

    def rig_factor_driver(self, owner, prop_name):
        if self.side != Side.MIDDLE:
            control_name = change_name_side(self.slot.subtarget, self.side)
        else:
            control_name = self.slot.subtarget

        if control_name not in self.generator.target_rig.pose.bones:
            raise MetarigError(
                f"Control bone '{control_name}' for action '{self.slot.action.name}' not found"
            )

        channel = self.slot.transform_channel.replace("LOCATION", "LOC").replace(
            "ROTATION", "ROT"
        )

        make_driver(
            owner,
            prop_name,
            expression=self.slot.get_factor_expression('var', side=self.side),
            variables=[
                driver_var_transform(
                    self.generator.target_rig,
                    control_name,
                    type=channel,
                    space=self.slot.target_space,
                    rotation_mode='SWING_TWIST_Y',
                )
            ],
        )

    def rig_child_shape_keys(self):
        for child in self.owner.child_meshes:
            mesh: Mesh = child.data

            if mesh.shape_keys:
                for key_block in mesh.shape_keys.key_blocks[1:]:
                    if key_block.name == self.name:
                        self.rig_shape_key(key_block)

    def rig_shape_key(self, key_block):
        self.rig_output_driver(key_block, 'value')


class ActionLayerComponent:
    """
    An internal component
    Implements centralized generation of action layer constraints.
    """

    slot_list: list["ActionSlot"]
    layers: list[ActionLayer]
    action_map: dict["ActionSlot", dict[Side, ActionLayer]]
    child_meshes: list[Object]

    def __init__(self, generator):
        self.slot_list = generator.params.action_slots
        self.layers = []
        self.generator = generator

        if self.slot_list:
            self.action_map = {}

            # Generate layers for active valid slots
            action_slots = [
                slot for slot in self.slot_list if slot.enabled and slot.action
            ]

            # Constraints will be added in reverse order because each one is added to the top
            # of the stack when created. However, Before Original reverses the effective
            # order of transformations again, restoring the original sequence.
            for act_slot in self.sort_slots(action_slots):
                self.spawn_slot_layers(act_slot)

        self.child_meshes = self.get_child_meshes()

    def get_child_meshes(self):
        if self.layers and self.generator.params.target_rig:
            return [
                child
                for child in self.generator.params.target_rig.children_recursive
                if child.type == 'MESH'
            ]
        return []

    @staticmethod
    def sort_slots(slots: list["ActionSlot"]):
        indices = {slot.action.name: i for i, slot in enumerate(slots)}

        def action_key(action: Action):
            return indices.get(action.name, -1) if action else -1

        def slot_key(slot: "ActionSlot"):
            # Ensure corrective actions are added after their triggers.
            if slot.is_corrective:
                return max(
                    action_key(slot.action),
                    action_key(slot.trigger_action_a) + 0.5,
                    action_key(slot.trigger_action_b) + 0.5,
                )
            else:
                return action_key(slot.action)

        return sorted(slots, key=slot_key)

    def get_slots_by_action(self, action: Action) -> list["ActionSlot"]:
        for slot in self.slot_list:
            if slot.action == action:
                yield slot

    def spawn_slot_layers(self, act_slot):
        name = act_slot.action.name

        if act_slot.is_corrective:
            if not act_slot.trigger_action_a or not act_slot.trigger_action_b:
                raise MetarigError(f"Action slot has missing trigger action: {name}")

            trigger_a = act_slot.trigger_slot_a
            trigger_b = act_slot.trigger_slot_b

            if not trigger_a or not trigger_b:
                raise MetarigError(
                    f"Action slot references missing trigger slot: {name}"
                )

            symmetry = trigger_a.do_symmetry or trigger_b.do_symmetry

        else:
            symmetry = act_slot.do_symmetry

        if symmetry:
            self.action_map[act_slot] = {
                Side.LEFT: ActionLayer(self, act_slot, Side.LEFT),
                Side.RIGHT: ActionLayer(self, act_slot, Side.RIGHT),
            }
        else:
            self.action_map[act_slot] = {
                Side.MIDDLE: ActionLayer(self, act_slot, Side.MIDDLE)
            }
