# This module contains copy-pasted code from Rigify.
# TODO: At some point, these should be simplified to CloudRig's needs.