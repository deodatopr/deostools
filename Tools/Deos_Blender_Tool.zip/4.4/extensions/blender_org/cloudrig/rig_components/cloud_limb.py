# SPDX-License-Identifier: GPL-3.0-or-later

from bpy.props import BoolProperty, EnumProperty
from bpy.types import PropertyGroup
from mathutils import Vector
from math import radians as rad
from math import pow
from copy import deepcopy
from mathutils import Vector

from ..rig_component_features.bone_info import BoneInfo
from .cloud_ik_chain import Component_Chain_IKFK


class Component_Limb(Component_Chain_IKFK):
    """IK chain with extra features such as Auto-Rubberhose for a simple limb like an arm."""

    ui_name = "Limb: Generic"
    forced_params = {
        'chain.sharp': True,
        'fk_chain.root': True,
        'fk_chain.position_along_bone': 0,
        'ik_chain.at_tip': False,
    }

    required_chain_length = 3

    def initialize(self):
        super().initialize()
        """Gather and validate data about the rig."""

        if not self.params.chain.smooth_spline:
            self.params.limb.auto_hose = False

        # IK values
        self.ik_pole_direction = 1

        self.check_correct_chain_length()

    def check_correct_chain_length(self):
        req_len = type(self).required_chain_length
        if self.bone_count != req_len:
            self.raise_generation_error(
                f"Chain must be exactly {req_len} connected bones."
            )

    def create_bone_infos(self, context):
        super().create_bone_infos(context)
        self.tweak_str_limb()
        segments = self.params.chain.segments
        if self.params.limb.auto_hose and segments > 1:
            upper_section = self.main_str_bones[0].sub_bones
            lower_section = self.main_str_bones[1].sub_bones
            self.setup_rubber_hose(
                self.bones_org[0], self.bones_org[1], upper_section, lower_section
            )

    ##############################
    # Override some inherited functionality

    def create_properties_bone(self) -> BoneInfo:
        """Overrides cloud_base.
        Place the properties bone near the end of the limb, parented to the last ORG bone.
        """
        source = self.bones_org[0]
        if self.params.custom_props.props_storage == 'GENERATED':
            source = self.bones_org[-1]
        return super().create_properties_bone(source=source)

    def get_num_segments_of_section(self, org_bone: BoneInfo) -> int:
        """Override cloud_chain, force 1 segment on the wrist."""
        if org_bone == self.bones_org[-1]:
            return 1
        return self.params.chain.segments

    def make_fk_chain(self, org_chain) -> list[BoneInfo]:
        fk_chain = super().make_fk_chain(org_chain)
        if self.params.limb.limit_elbow_axes:
            # Locking the FK elbow/knee's Y/Z rotation is necessary for accurate
            # IK/FK snapping. But it might be an annoying limitation for more cartoony
            # characters.
            fk_elbow = fk_chain[1]
            fk_elbow.lock_rotation = [False, True, True]
        return fk_chain

    def make_ik_setup(self):
        """Override cloud_ik_chain."""
        super().make_ik_setup()

        # Parent control
        if self.params.limb.double_ik:
            old_name = self.ik_mstr.name
            self.ik_mstr.name = self.naming.add_prefix(self.ik_mstr, "C")
            double_control = self.create_parent_bone(
                self.ik_mstr, self.bone_sets['IK Child Controls']
            )
            self.ik_controls.append(double_control)
            double_control.name = old_name
            double_control.collections, self.ik_mstr.collections = (
                self.ik_mstr.collections,
                double_control.collections,
            )

        self.add_counterrotate_constraint(self.str_chain[: self.params.chain.segments])

        # Lock IK axes
        if self.params.limb.limit_elbow_axes:
            if self.pole_angle_deg in {180, 0}:
                self.add_log(
                    "Locked IK must bend on X",
                    description=f'To use the "Limit Elbow Axes" parameter, the bone rolls of this limb should be rotated 90 degrees, so it bends on X instead of Z axis. Currently, this limbn will not bend properly.',
                )
            ik_elbow = self.ik_chain[1]
            ik_elbow.lock_ik_z = ik_elbow.lock_ik_y = True

    def create_ik_master(self, bone_set, source_bone, bone_name="", shape_name=""):
        """Override."""
        if shape_name == "":
            shape_name = "Hyperbola"
        ik_master = super().create_ik_master(
            bone_set, source_bone, bone_name, shape_name
        )
        ik_master.custom_shape_scale = 0.8

        return ik_master

    def apply_parent_switching(
        self,
        parent_slots,
        *,
        child_bone=None,
        prop_bone=None,
        prop_name="",
        panel_name="IK",
        row_name="",
        label_name="Parent Switching",
        entry_name="",
    ):
        """Overrides cloud_ik_chain."""

        if self.params.limb.double_ik:
            child_bone = self.ik_mstr.parent

        super().apply_parent_switching(
            parent_slots,
            child_bone=child_bone,
            prop_bone=prop_bone,
            prop_name=prop_name,
            panel_name=panel_name,
            row_name=row_name,
            label_name=label_name,
            entry_name=entry_name,
        )

    def setup_ik_pole_parent_switch(self, ik_pole, ik_mstr):
        """Overrides cloud_ik_chain."""
        if self.params.limb.double_ik:
            ik_mstr = ik_mstr.parent

        super().setup_ik_pole_parent_switch(ik_pole, ik_mstr)

    def create_fkik_switch_ui_data(self, fk_chain, ik_chain, ik_mstr, ik_pole):
        """Overrides cloud_ik_chain."""
        ui_data = super().create_fkik_switch_ui_data(
            fk_chain, ik_chain, ik_mstr, ik_pole
        )

        if self.params.limb.double_ik:
            # Need to insert IK master parent->last FK bone switching BEFORE IK master parent.
            ui_data['op_kwargs']['map_ik_to_fk'].insert(
                0, (ik_mstr.parent.name, fk_chain[-1].name)
            )

        return ui_data

    ##############################
    # End of overrides

    def tweak_str_limb(self):
        # Make changes to the STR chain to make it behave more like a limb.

        # Disable first Copy Rotation constraint on the upperarm
        if self.params.chain.segments > 1:
            for b in self.main_str_bones[0].sub_bones:
                str_h_bone = b.parent
                str_h_bone.constraint_infos[2].mute = True

    def add_counterrotate_constraint(self, str_chain: list[BoneInfo]):
        """Counter-Rotate constraint for the first main STR bone.
        This is so that the twisting fades in starting at the shoulder, towards the elbow.
        """
        str_bone = str_chain[0]
        trans_con = str_bone.add_constraint(
            'TRANSFORM',
            name="Transformation (Counter-Rotate)",
            subtarget=str_bone.source.name,
            influence=0.9,
            map_to='ROTATION',
        )
        trans_con.drivers.append(
            {
                'prop': f'to_min_y_rot',
                'expression': "-var",
                'variables': [
                    {
                        'type': 'TRANSFORMS',
                        'targets': [
                            {
                                'bone_target': str_bone.source.name,
                                'transform_space': 'LOCAL_SPACE',
                                'transform_type': 'ROT_Y',
                                'rotation_mode': 'SWING_TWIST_Y',
                            }
                        ],
                    }
                ],
            }
        )

    def setup_rubber_hose(
        self,
        org_upper: BoneInfo,
        org_lower: BoneInfo,
        str_upper_section: list[BoneInfo],
        str_lower_section: list[BoneInfo],
    ):
        """Add translating Transformation constraints to str_upper_section and
        str_lower_section controls, driven by org_lower, which would be the
        elbow or the knee.
        """

        prop_name = "auto_rubber_hose_" + self.limb_name_props

        control_bone = None
        if self.params.limb.auto_hose_control:
            # Create control bone
            control_bone = self.make_rubber_hose_control(org_lower)
            self.properties_bone.custom_props[prop_name] = {'default': 0.0}
            self.properties_bone.drivers.append(
                {
                    'prop': f'["{prop_name}"]',
                    'expression': "var-1",
                    'variables': [
                        {
                            'type': 'TRANSFORMS',
                            'targets': [
                                {
                                    'bone_target': control_bone.name,
                                    'transform_space': 'LOCAL_SPACE',
                                    'transform_type': 'SCALE_Y',
                                }
                            ],
                        }
                    ],
                }
            )
        else:
            # Don't create a control bone, instead just add a slider in the UI.
            self.add_bone_property_with_ui(
                prop_bone=self.properties_bone,
                prop_id=prop_name,
                panel_name="Auto Rubber Hose",
                custom_prop_settings={
                    'default': 0.0,
                    'description': f'Automatically smoothen the curvature of the limb and avoid sharp angles, for a cartoony effect',
                },
                row_name=self.limb_name,
                slider_name=self.limb_ui_name,
            )

        self.make_rubber_hose_constraints(
            org_upper,
            org_lower,
            str_upper_section,
            str_lower_section,
            prop_name,
            hose_type=self.params.limb.auto_hose_type,
        )

    def make_rubber_hose_control(self, org_lower: BoneInfo) -> BoneInfo:
        control_bone = self.bone_sets['FK Controls Extra'].new(
            name=self.naming.add_prefix(org_lower, "RubberHose"),
            source=org_lower,
            parent=org_lower,
            custom_shape_name='Arrow_Two-way',
        )

        # Shift it towards the IK pole or where it would be.
        new_loc = (
            control_bone.head
            + self.pole_vector.normalized() * org_lower.bbone_width * self.scale * 6
        )
        control_bone.head = new_loc
        control_bone.vector = org_lower.vector * 0.3
        control_bone.custom_shape_scale = 0.4
        control_bone.roll_type = 'ALIGN'
        control_bone.roll_bone = org_lower
        control_bone.roll = rad(90)
        self.lock_transforms(control_bone, scale=[True, False, True])
        control_bone.add_constraint(
            'LIMIT_SCALE', use_max_y=True, max_y=2, use_min_y=True, min_y=1
        )

        dsp_bone = self.create_dsp_bone(control_bone)
        dsp_bone.add_constraint(
            'ARMATURE',
            use_deform_preserve_volume=True,
            targets=[
                {"subtarget": self.bones_def[self.params.chain.segments - 1].name},
                {"subtarget": self.bones_def[self.params.chain.segments].name},
            ],
        )
        dsp_bone.add_constraint('COPY_SCALE', subtarget=control_bone.name)

        return control_bone

    def make_rubber_hose_constraints(
        self,
        org_upper: BoneInfo,
        org_lower: BoneInfo,
        str_upper_section: list[BoneInfo],
        str_lower_section: list[BoneInfo],
        prop_name: str,
        hose_type: str,
    ):
        # TODO: This function is too big!
        driver_influence = {
            'prop': 'influence',
            'expression': 'var',
            'variables': [
                (self.properties_bone.name, prop_name),
            ],
        }

        for i, str_list in enumerate([str_upper_section, str_lower_section]):
            org_bone = [org_upper, org_lower][i]
            for str_bone in str_list:
                offset = org_bone.length / 2.5

                # Inverse of distance from center divided by half of bone length
                # This results in 1.0 at the center of the bone and 0.0 at the head or tail of the bone.
                distance_to_org_center = (str_bone.head - org_bone.center).length
                centeredness = 1 - (distance_to_org_center / (org_bone.length / 2))

                total_offset = offset * pow(centeredness, 0.5)

                trans_con = str_bone.add_constraint(
                    'TRANSFORM',
                    name="Transformation (Rubber Hose STR)",
                    subtarget=org_lower.name,
                    map_from='ROTATION',
                    map_to_x_from='Z',
                    map_to_z_from='X',
                )

                # Influence driver
                driver = deepcopy(driver_influence)
                if hose_type == 'ELBOW_IN':
                    # For the alternate auto hose type, the shifting just needs to be reduced by half.
                    driver['expression'] += "/2"

                trans_con.drivers.append(driver)

                # Translation drivers
                driver_to_min_x = {
                    'prop': 'to_min_x',
                    'expression': f"(var/pi) * {total_offset}",
                    'variables': [
                        {
                            'type': 'TRANSFORMS',
                            'targets': [
                                {
                                    'bone_target': org_lower.name,
                                    'transform_space': 'LOCAL_SPACE',
                                    'transform_type': 'ROT_Z',
                                    'rotation_mode': 'SWING_TWIST_Y',
                                }
                            ],
                        }
                    ],
                }

                trans_con.drivers.append(driver_to_min_x)

                driver_to_min_z = deepcopy(driver_to_min_x)
                driver_to_min_z['prop'] = 'to_min_z'
                driver_to_min_z['expression'] += " * -1"
                driver_to_min_z['variables'][0]['targets'][0][
                    'transform_type'
                ] = 'ROT_X'
                trans_con.drivers.append(driver_to_min_z)

            # Scale the main STR bone on local Y to get a smooth curve
            # in spite of Sharp Sections parameter being enabled.
            if i == 1:
                main_str = str_list[0].prev
                # Scale constraint
                scale_con = main_str.add_constraint(
                    'TRANSFORM',
                    name="Transformation (Rubber Hose Elbow Scale)",
                    subtarget=org_lower.name,
                    map_to='SCALE',
                )

                # Influence driver
                scale_con.drivers.append(deepcopy(driver_influence))

                # Scale driver
                scale_con.drivers.append(
                    {
                        'prop': 'to_min_y_scale',
                        'expression': "1 + pow( (abs(rot_x) + abs(rot_z)) / pi, 0.5 ) * 1.5",
                        'variables': {
                            'rot_x': {
                                'type': 'TRANSFORMS',
                                'targets': [
                                    {
                                        'bone_target': org_lower.name,
                                        'transform_space': 'LOCAL_SPACE',
                                        'transform_type': 'ROT_X',
                                        'rotation_mode': 'SWING_TWIST_Y',
                                    }
                                ],
                            },
                            'rot_z': {
                                'type': 'TRANSFORMS',
                                'targets': [
                                    {
                                        'bone_target': org_lower.name,
                                        'transform_space': 'LOCAL_SPACE',
                                        'transform_type': 'ROT_Z',
                                        'rotation_mode': 'SWING_TWIST_Y',
                                    }
                                ],
                            },
                        },
                    }
                )

                if not hose_type == 'ELBOW_IN':
                    return

                ### Additional constraints for alternate, "Long" rubberhose type
                # Translation constraint
                trans_con = main_str.add_constraint(
                    'TRANSFORM',
                    name="Transformation (Rubber Hose Elbow Translate)",
                    subtarget=org_lower.name,
                )

                # Influence driver
                trans_con.drivers.append(deepcopy(driver_influence))

                # Translation drivers
                var_x = {
                    'type': 'TRANSFORMS',
                    'targets': [
                        {
                            'bone_target': org_lower.name,
                            'transform_space': 'LOCAL_SPACE',
                            'transform_type': 'ROT_X',
                            'rotation_mode': 'SWING_TWIST_Y',
                        }
                    ],
                }
                var_z = deepcopy(var_x)
                var_z['targets'][0]['transform_type'] = 'ROT_Z'
                driver_to_min_y = {
                    'prop': 'to_min_y',
                    'expression': f"(abs(x + z)/pi) * {org_lower.length/4}",
                    'variables': {
                        'x': var_x,
                        'z': var_z,
                    },
                }

                trans_con.drivers.append(driver_to_min_y)

                driver_to_min_z = deepcopy(driver_to_min_y)
                driver_to_min_z['prop'] = 'to_min_z'
                driver_to_min_z['expression'] = f"(x/pi) * {org_lower.length/4}"
                trans_con.drivers.append(driver_to_min_z)

                driver_to_min_x = deepcopy(driver_to_min_y)
                driver_to_min_x['prop'] = 'to_min_x'
                driver_to_min_x['expression'] = f"(-z/pi) * {org_lower.length/4}"
                trans_con.drivers.append(driver_to_min_x)

    ##############################
    # Parameters

    @classmethod
    def define_bone_sets(cls):
        """Create parameters for this rig's bone sets."""
        super().define_bone_sets()
        cls.define_bone_set(
            'IK Child Controls', color_palette='THEME09', collections=['IK Secondary']
        )

    @classmethod
    def draw_control_params(cls, layout, context, params):
        """Create the ui for the rig parameters."""
        super().draw_control_params(layout, context, params)

        cls.draw_prop(context, layout, params.limb, 'double_ik')
        cls.draw_prop(context, layout, params.limb, 'limit_elbow_axes')

        layout.separator()
        cls.draw_control_label(layout, "Limb")

        row = cls.draw_prop(context, layout, params.limb, 'auto_hose')
        row.enabled = params.chain.segments > 1 and params.chain.smooth_spline
        if row.enabled and params.limb.auto_hose:
            split = layout.split(factor=0.1)
            split.row()
            cls.draw_prop(context, split.row(), params.limb, 'auto_hose_control')
            split = layout.split(factor=0.1)
            split.row()
            cls.draw_prop(
                context, split.row(), params.limb, 'auto_hose_type', expand=True
            )

    ##############################
    # Overlay
    @classmethod
    def draw_overlay(cls, context, buffer) -> list[tuple[Vector, Vector]]:
        active_pb = context.active_pose_bone
        rig_chain = cls.find_component_chain_of_pbone(active_pb)

        _pole_angle, _pole_vector, pole_location = cls.calculate_ik_info_static(
            rig_chain[0], rig_chain[1]
        )

        buffer.draw_line_3d(rig_chain[0].tail, pole_location)


class Params(PropertyGroup):
    auto_hose: BoolProperty(
        name="Rubber Hose",
        description="Add an Auto Rubber Hose setting which can be enabled to automatically add curvature to limbs as they bend. Stretch Segments parameter must be >1 and Smooth Spline must be enabled",
        default=False,
    )
    auto_hose_control: BoolProperty(
        name="With Control",
        description="Instead of controlling the Auto Rubber Hose property from the rig UI, create a control bone on the FK Extras layer",
        default=False,
    )
    auto_hose_type: EnumProperty(
        name="Type",
        description="The rubber hosing effect can be achieved in different ways. This lets you pick which one you prefer",
        items=[
            (
                'MIDDLE_OUT',
                "Long",
                "Shift mid-limb STR bones away from the elbow bending direction. As a result, the limb becomes longer",
            ),
            (
                'ELBOW_IN',
                "Short",
                "Shift the elbow STR bone towards the elbow bending direction, and counter-shift the mid-limb STR bones so they stay roughly in place. As a result, the limb becomes shorter",
            ),
        ],
    )

    limit_elbow_axes: BoolProperty(
        name="Limit Elbow Axes",
        description="Lock the Y and Z rotation of the elbow/knee bone, only allowing realistic rotations. This is limiting for cartoony characters, but it's necessary for accurate FK->IK snapping. For realistic characters, this should be enabled. This also requires that the elbow bends along its local X axis",
        default=True
    )

    double_ik: BoolProperty(
        name="Duplicate IK Master",
        description="The IK control has a parent control. Having two controls for the same thing can help avoid interpolation issues when the common pose in animation is far from the rest pose",
        default=False,
    )


RIG_COMPONENT_CLASS = Component_Limb
