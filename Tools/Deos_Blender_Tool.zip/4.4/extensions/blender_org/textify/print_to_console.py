import bpy
import builtins
import sys


class CONSOLE_PG_properties(bpy.types.PropertyGroup):
    enable_console_output: bpy.props.BoolProperty(
        name="Enable Console Output",
        default=False,
    )


# Original print function
original_print = print


# Custom print function that writes to the Blender console or the system console
def console_print(*args, sep=' ', end='\n', file=None):
    try:
        if bpy.context.scene.console_output_settings.enable_console_output:
            text = sep.join(map(str, args)) + end
            console_write(text)
        else:
            # Print to the system console when enable_console_output is disabled
            sys.stdout.write(sep.join(map(str, args)) + end)
    except Exception as e:
        original_print(f"Error in console_print: {e}")


def console_get():
    try:
        for area in bpy.context.screen.areas:
            if area.type == 'CONSOLE':
                for space in area.spaces:
                    if space.type == 'CONSOLE':
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                return area, space, region
    except Exception as e:
        original_print(f"Error in console_get: {e}")
    return None, None, None


def console_write(text):
    try:
        area, space, region = console_get()
        if space is None:
            return

        context_override = bpy.context.copy()
        context_override.update({
            "space": space,
            "area": area,
            "region": region,
        })
        with bpy.context.temp_override(**context_override):
            for line in text.split("\n"):
                bpy.ops.console.scrollback_append(text=line, type='OUTPUT')
    except Exception as e:
        original_print(f"Error in console_write: {e}")


def draw_console_header(self, context):
    layout = self.layout
    prefs = context.preferences.addons[__package__].preferences

    if prefs.enable_print_to_console:
        layout.prop(context.scene.console_output_settings, "enable_console_output", text="Print to Console")


def update_print(self, contex):
    prefs = bpy.context.preferences.addons[__package__].preferences

    try:
        if not prefs.enable_print_to_console:
            bpy.context.scene.console_output_settings.enable_console_output = False
    except:
        pass


def register():
    bpy.utils.register_class(CONSOLE_PG_properties)
    bpy.types.Scene.console_output_settings = bpy.props.PointerProperty(type=CONSOLE_PG_properties)

    # Replace the built-in print function with the custom console_print function
    builtins.print = console_print

    # Add the draw function to the console header
    bpy.types.CONSOLE_HT_header.append(draw_console_header)


def unregister():
    # Restore the original print function
    builtins.print = original_print

    # Remove the draw function from the console header
    bpy.types.CONSOLE_HT_header.remove(draw_console_header)

    bpy.utils.unregister_class(CONSOLE_PG_properties)
    del bpy.types.Scene.console_output_settings
