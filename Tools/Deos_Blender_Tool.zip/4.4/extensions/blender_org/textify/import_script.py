import bpy
import os

def register():
    pass

def unregister():
    pass

if bpy.app.version >= (4, 1, 0):
    class TEXTIFY_FH_import_scripts(bpy.types.FileHandler):
        bl_idname = "TEXTIFY_FH_import_scripts"
        bl_label = "Import Script"
        bl_import_operator = "textify.import_script"
        bl_file_extensions = ".py;.txt;.json"

        @classmethod
        def poll_drop(cls, context):
            return True

    class TEXTIFY_OT_import_script(bpy.types.Operator):
        bl_idname = "textify.import_script"
        bl_label = "Import Script"
        bl_description = "Import Script"
        bl_options = {'INTERNAL'}

        files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement, options={'SKIP_SAVE'})
        directory: bpy.props.StringProperty(subtype='DIR_PATH')

        def execute(self, context):
            for file in self.files:
                filepath = os.path.join(self.directory, file.name)
                text = bpy.data.texts.load(filepath)
                if text:
                    self.report({'INFO'}, f"{file.name} Imported script successfully")
                else:
                    self.report({'ERROR'}, "Failed to import script")
            
            return {'FINISHED'}

    def register():
        bpy.utils.register_class(TEXTIFY_FH_import_scripts)
        bpy.utils.register_class(TEXTIFY_OT_import_script)

    def unregister():
        bpy.utils.unregister_class(TEXTIFY_FH_import_scripts)
        bpy.utils.unregister_class(TEXTIFY_OT_import_script)
