
bl_info = {
    "name" : "Motion-path pro",
    "author" : "Hamdi Amer", 
    "description" : "Update motion path in real time from graph editor and viewport",
    "blender" : (4, 2, 0),
    "version" : (2, 0, 1),
    "location" : "Graph Editor",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Graph" 
}

import bpy
import bpy_extras
import bpy_extras.view3d_utils
import mathutils









#### ------------------------------ UI ------------------------------ ####

class AutoMOTIONPATHSPanel(bpy.types.Panel):
    bl_label = 'Motion Paths'
    bl_idname = 'SNA_PT_MOTION_PATHS_8176B'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Motion-Path_Pro'

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager

        # Section 1: Path Operations
        box = layout.box()
        box.label(text="Path Operations")
        row = box.row(align=False)
        row.operator('object.paths_calculate', text='Path Object', icon='OBJECT_DATA')
        row.operator('pose.paths_calculate', text='Path Bone', icon='BONE_DATA')

        row = box.row(align=False)
        row.operator('sna.delet_path_6e947', text='', icon='CANCEL')
        row.operator('object.paths_update_visible', text='Update Path', icon='FILE_REFRESH')
        row.operator('sna.delet_allpath_b6bbf', text='', icon='X')

        layout.separator()

        # Section 2: Auto Update
        box = layout.box()
        box.label(text="Auto Update Settings")
        wm = context.window_manager
        box.prop(wm, "update_mode", text="Update Mode")
        
        if wm.update_mode == 'TIMER':
            box.prop(wm, "auto_update_timer_interval", text="Timer Interval")

        row = box.row(align=True)
        if not wm.auto_update_active:
            row.operator("amth.auto_update_activate", text="Activate Auto Update", icon='PLAY')
        else:
            row.operator("amth.auto_update_deactivate", text="Deactivate Auto Update", icon='PAUSE')

        row = box.row(align=True)
        if wm.generic_auto_update_active:
            row.operator("new_amth.generic_auto_update_deactivate", text="Deactivate Generic Auto Update", icon='PAUSE')
        else:
            row.operator("new_amth.generic_auto_update_activate", text="Activate Generic Auto Update", icon='PLAY')



        
#### ------------------------------ OPERATORS ------------------------------ ####

class SNA_OT_Delet_Path_6E947(bpy.types.Operator):
    bl_idname = "sna.delet_path_6e947"
    bl_label = "delet_path"
    bl_description = "delete all path from selected bone or object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        # Check if there is an active object and it is in pose mode
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            # Clear paths in pose mode
            bpy.ops.pose.paths_clear(only_selected=True)
        # Check if there is an active object
        if bpy.context.active_object:
            # Clear paths in object mode   
            bpy.ops.object.paths_clear(only_selected=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Delet_Allpath_B6Bbf(bpy.types.Operator):
    bl_idname = "sna.delet_allpath_b6bbf"
    bl_label = "Delet_All-path"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        # Check if there is an active object and it is in pose mode
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            # Clear paths in pose mode
            bpy.ops.pose.paths_clear(only_selected=False)
        # Check if there is an active object
        if bpy.context.active_object:
            # Clear paths in object mode
            bpy.ops.object.paths_clear(only_selected=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)

class AMTH_OT_AutoUpdateMotionPaths(bpy.types.Operator):
    """Auto-update motion paths after keyframe or handle movement"""
    bl_idname = "amth.auto_update_motion_paths"
    bl_label = "Auto Update Motion Paths (Improved)"
    bl_description = "Update motion path in real time in graph editor"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _last_active_keyframe_values = None  
    _needs_update = False  

    @classmethod
    def poll(cls, context):
        return context.area.type == 'GRAPH_EDITOR'

    def invoke(self, context, event):
        wm = context.window_manager
        self._last_active_keyframe_values = self._get_active_keyframe_values(context)
        self._needs_update = False  

        if wm.update_mode == 'TIMER':
            self._timer = wm.event_timer_add(wm.auto_update_timer_interval, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        wm = context.window_manager

        active_keyframe_values = self._get_active_keyframe_values(context)
        if wm.update_mode == 'TIMER' and event.type == 'TIMER':
            if active_keyframe_values != self._last_active_keyframe_values:
                self._needs_update = True
        elif wm.update_mode == 'EVENT':
            if active_keyframe_values != self._last_active_keyframe_values:
                self._needs_update = True

        if self._needs_update:
            try:
                bpy.ops.object.paths_update_visible() 
            except Exception as e:
                print("Error updating motion paths:", e)
            self._last_active_keyframe_values = active_keyframe_values
            self._needs_update = False  

        if not wm.auto_update_active:
            self.cancel(context)
            return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None

    def _get_active_keyframes(self, context):
        active_object = context.active_object
        active_action = active_object.animation_data.action if active_object and active_object.animation_data else None
        if not active_action:
            return []

        active_keyframes = []
        for fcurve in active_action.fcurves:
            for keyframe in fcurve.keyframe_points:
                if keyframe.select_control_point or keyframe.handle_left_type != 'AUTO' or keyframe.handle_right_type != 'AUTO':
                    active_keyframes.append(keyframe)
        return active_keyframes

    def _get_active_keyframe_values(self, context):
        active_keyframes = self._get_active_keyframes(context)
        if active_keyframes:
            return [(keyframe.co[0], keyframe.co[1], keyframe.handle_left[0], keyframe.handle_left[1], keyframe.handle_right[0], keyframe.handle_right[1]) for keyframe in active_keyframes]
        return None


class AMTH_OT_AutoUpdateActivate(bpy.types.Operator):
    bl_idname = "amth.auto_update_activate"
    bl_label = "Activate Auto Update"
    bl_description = "Activate Update motion path operator in real time in Grapg editor"

    bl_icon = 'PLAY'

    def execute(self, context):
        context.window_manager.auto_update_active = True
        bpy.ops.amth.auto_update_motion_paths('INVOKE_DEFAULT')
        return {'FINISHED'}


class AMTH_OT_AutoUpdateDeactivate(bpy.types.Operator):
    bl_idname = "amth.auto_update_deactivate"
    bl_label = "Deactivate Auto Update"
    bl_description = "Deactivate Update motion path operator in real time in Grapg editor"
    bl_icon = 'PAUSE'
    
    def execute(self, context):
        context.window_manager.auto_update_active = False
        return {'FINISHED'}





class SNA_OT_Delet_Path001_C28Ef(bpy.types.Operator):
    bl_idname = "sna.delet_path001_c28ef"
    bl_label = "delet_path.001"
    bl_description = "delete all path from selected bone or object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            bpy.ops.pose.paths_clear(only_selected=True)
        if bpy.context.active_object:
            bpy.ops.object.paths_clear(only_selected=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Delet_Allpath001_C61F5(bpy.types.Operator):
    bl_idname = "sna.delet_allpath001_c61f5"
    bl_label = "Delet_All-path.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            bpy.ops.pose.paths_clear(only_selected=False)
        if bpy.context.active_object:
            bpy.ops.object.paths_clear(only_selected=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)




class GenericAutoUpdateKeyframesOperator(bpy.types.Operator):
    """Operator to auto-update keyframes in various windows based on Viewport changes"""
    bl_idname = "anim.generic_auto_update_keyframes"
    bl_label = "Generic Auto Update Keyframes"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    last_location = None
    last_rotation = None
    last_rotation_quaternion = None
    last_scale = None
    interval = 0.1  

    def modal(self, context, event):
        if context.window_manager.generic_auto_update_active:
            if event.type == 'TIMER':
                if not context.screen.is_animation_playing:
                    obj = context.active_object
                    
                    if obj:
                        if obj.mode == 'POSE':
                            bone = context.active_pose_bone
                            if bone:
                                self.update_bone_keyframes(context, bone)
                        else:
                            self.update_object_keyframes(context, obj)
                return {'RUNNING_MODAL'}  
            return {'PASS_THROUGH'}  
        else:
            self.cancel(context)
            return {'CANCELLED'}


    def update_bone_keyframes(self, context, bone):
        """Update keyframes for a bone if it has changed"""
        current_location = bone.location.copy()
        current_rotation = bone.rotation_euler.copy()
        current_rotation_quaternion = bone.rotation_quaternion.copy()
        current_scale = bone.scale.copy()

        if self.last_location is None or current_location != self.last_location:
            self.update_keyframes(context, bone, 'location', current_location)
            self.last_location = current_location

        if self.last_rotation is None or current_rotation != self.last_rotation:
            self.update_keyframes(context, bone, 'rotation_euler', current_rotation)
            self.last_rotation = current_rotation

        if self.last_rotation_quaternion is None or current_rotation_quaternion != self.last_rotation_quaternion:
            self.update_keyframes(context, bone, 'rotation_quaternion', current_rotation_quaternion)
            self.last_rotation_quaternion = current_rotation_quaternion

        if self.last_scale is None or current_scale != self.last_scale:
            self.update_keyframes(context, bone, 'scale', current_scale)
            self.last_scale = current_scale

    def update_object_keyframes(self, context, obj):
        """Update keyframes for an object if it has changed"""
        current_location = obj.location.copy()
        current_rotation = obj.rotation_euler.copy()
        current_rotation_quaternion = obj.rotation_quaternion.copy()
        current_scale = obj.scale.copy()

        if self.last_location is None or current_location != self.last_location:
            self.update_keyframes(context, obj, 'location', current_location)
            self.last_location = current_location

        if self.last_rotation is None or current_rotation != self.last_rotation:
            self.update_keyframes(context, obj, 'rotation_euler', current_rotation)
            self.last_rotation = current_rotation

        if self.last_rotation_quaternion is None or current_rotation_quaternion != self.last_rotation_quaternion:
            self.update_keyframes(context, obj, 'rotation_quaternion', current_rotation_quaternion)
            self.last_rotation_quaternion = current_rotation_quaternion

        if self.last_scale is None or current_scale != self.last_scale:
            self.update_keyframes(context, obj, 'scale', current_scale)
            self.last_scale = current_scale

    def update_keyframes(self, context, obj_or_bone, transform_type, current_transform):
        """Update existing keyframes if present"""
        current_frame = context.scene.frame_current
        action = obj_or_bone.id_data.animation_data.action

        if action:
            for fcurve in action.fcurves:
                if transform_type in fcurve.data_path:
                    if isinstance(obj_or_bone, bpy.types.PoseBone) and obj_or_bone.name not in fcurve.data_path:
                        continue

                    for keyframe in fcurve.keyframe_points:
                        if keyframe.co.x == current_frame:
                            keyframe.co.y = current_transform[fcurve.array_index]
                            fcurve.update()
                            break  

    def execute(self, context):
        self._timer = context.window_manager.event_timer_add(self.interval, window=context.window)
        context.window_manager.modal_handler_add(self)
        context.window_manager.generic_auto_update_active = True
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
        context.window_manager.generic_auto_update_active = False
        return {'CANCELLED'}




class GenericAutoUpdateKeyframesActivate(bpy.types.Operator):
    bl_idname = "new_amth.generic_auto_update_activate"
    bl_label = "Activate Generic Auto Update"
    bl_description = "Activate Update motion path operator in real time in ViewPort"

    bl_icon = 'PLAY'

    def execute(self, context):
        context.window_manager.generic_auto_update_active = True
        bpy.ops.anim.generic_auto_update_keyframes('INVOKE_DEFAULT')
        return {'FINISHED'}

class GenericAutoUpdateKeyframesDeactivate(bpy.types.Operator):
    bl_idname = "new_amth.generic_auto_update_deactivate"
    bl_label = "Deactivate Generic Auto Update"
    bl_description = "Deactivate Update motion path operator in real time in ViewPort"
    bl_icon = 'PAUSE'
    
    def execute(self, context):
        context.window_manager.generic_auto_update_active = False
        return {'FINISHED'}




#### ------------------------------ UI ------------------------------ ####

class MotionPathPanel(bpy.types.Panel):
    """UI Panel for activating and deactivating the keyframe operator"""
    bl_idname = "VIEW3D_PT_motion_path"
    bl_label = "Motion Path Pro"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Motion Path'

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager

        box = layout.box()
        if wm.anim_deactivate_keyframe_operator:
            box.operator("anim.deactivate_keyframe_operator", text="Deactivate Advanced", icon="PAUSE")
        else:
            box.operator("anim.insert_keyframe_selected_fcurves", text="Activate Advanced", icon="PLAY")



        # Direct Pose Mode Section
        direct_pose_box = layout.box()
        direct_pose_box.scale_y = 3.0
        direct_pose_box.label(text="Direct Pose Mode", icon='MOD_ARMATURE')

        # Activate/Deactivate Button
        row = direct_pose_box.row(align=True)
        
        if not wm.direct_pose_active:
            row.operator("amth.direct_pose_activate", text="Activate", icon_value= 48)
        else:
            row.operator("amth.direct_pose_deactivate", text="Deactivate", icon_value= 436)

        # Timer Interval Control
        #direct_pose_box.prop(wm, "direct_pose_timer_interval", text="Timer Interval")




#### ------------------------------ OPERATORS ------------------------------ ####


class InsertKeyframeOnSelectedFcurves(bpy.types.Operator):

    """add keyframe on the selected fcurves when you click on any motion path point""" 
    bl_idname = "anim.insert_keyframe_selected_fcurves"
    bl_label = "Insert and Move Keyframe on Selected F-Curves"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    active = False
    operator_ref = None
    mouse_start = None  
    inserted_keyframes = {} 
    is_moving_keyframes = False  

    def modal(self, context, event):
        if self.active:
            mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))

            obj = context.active_object
            if obj and obj.mode == 'POSE':
                bone = context.active_pose_bone
                if bone and bone.motion_path:
                    motion_path = bone.motion_path
                    frame_start = motion_path.frame_start

                    for index, point in enumerate(motion_path.points):
                        frame_num = frame_start + index
                        world_pos = obj.matrix_world @ point.co
                        screen_pos = bpy_extras.view3d_utils.location_3d_to_region_2d(
                            context.region, context.space_data.region_3d, world_pos)

                        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not self.is_moving_keyframes:
                            if screen_pos and (mouse_pos - screen_pos).length < 5:  # If mouse is near a frame

                                if obj.animation_data and obj.animation_data.action:
                                    action = obj.animation_data.action

                                    self.inserted_keyframes.clear()

                                    for fcurve in action.fcurves:
                                        # Check if the F-Curve is for location, rotation (Euler or quaternion), or scale
                                        if fcurve.data_path.endswith(("location", "rotation_euler", "rotation_quaternion", "scale")) and fcurve.select:
                                            for kp in fcurve.keyframe_points:
                                                kp.select_control_point = False
                                                kp.select_left_handle = False
                                                kp.select_right_handle = False

                                            # Check if a keyframe already exists at the target frame
                                            existing_keyframe = next((kp for kp in fcurve.keyframe_points if kp.co[0] == frame_num), None)
                                            if existing_keyframe:
                                                print(f"Keyframe exists at frame {frame_num}. Selecting it.")
                                                existing_keyframe.select_control_point = True
                                                continue

                                            # Insert a new keyframe if one doesn't exist
                                            key = fcurve.keyframe_points.insert(
                                                frame_num, fcurve.evaluate(frame_num), options={'FAST'}
                                            )
                                            key.select_control_point = True
                                            self.inserted_keyframes[fcurve] = [(key, key.co[0], key.co[1])]
                                            fcurve.update()

                                    context.scene.frame_current = frame_num
                                    context.view_layer.update()
                                    return {'RUNNING_MODAL'}

                            context.area.tag_redraw()  

                        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE' and self.is_moving_keyframes:
                            self.is_moving_keyframes = False
                            return {'RUNNING_MODAL'}

        return {'PASS_THROUGH'}

    def execute(self, context):
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        self.active = True
        InsertKeyframeOnSelectedFcurves.operator_ref = self  
        context.window_manager.anim_deactivate_keyframe_operator = True  
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)  
        self.active = False
        InsertKeyframeOnSelectedFcurves.operator_ref = None
        self.is_moving_keyframes = False
        context.window_manager.anim_deactivate_keyframe_operator = False  
        return {'CANCELLED'}


class DeactivateKeyframeOperator(bpy.types.Operator):
    """Deactivate Keyframe Insertion Operator"""
    bl_idname = "anim.deactivate_keyframe_operator"
    bl_label = "Deactivate Keyframe Operator"

    def execute(self, context):
        operator = InsertKeyframeOnSelectedFcurves.operator_ref
        if operator and operator.active:
            operator.cancel(context)
            self.report({'INFO'}, "Keyframe operator deactivated.")
        else:
            self.report({'INFO'}, "No active keyframe operator to deactivate.")
        return {'FINISHED'}
    

class AMTH_OT_DirectPoseActivate(bpy.types.Operator):
    bl_idname = "amth.direct_pose_activate"
    bl_label = "Activate Direct Pose Mode"
    bl_description = "Activate direct inter-to-pose mode when selecting any bone"

    def execute(self, context):
        context.window_manager.direct_pose_active = True
        bpy.app.timers.register(update_timer, first_interval=context.window_manager.direct_pose_timer_interval)
        bpy.context.scene.tool_settings.lock_object_mode = False

        return {'FINISHED'}


class AMTH_OT_DirectPoseDeactivate(bpy.types.Operator):
    bl_idname = "amth.direct_pose_deactivate"
    bl_label = "Deactivate Direct Pose Mode"
    bl_description = "Deactivate direct inter-to-pose mode when selecting any bone"
    
    def execute(self, context):
        context.window_manager.direct_pose_active = False
        bpy.app.timers.unregister(update_timer)
        return {'FINISHED'}

def check_selected_object():
    obj = bpy.context.active_object
    if obj and obj.type == 'ARMATURE':
        bpy.ops.object.mode_set(mode='POSE')

def update_timer():
    if bpy.context.window_manager.direct_pose_active:
        check_selected_object()
        return bpy.context.window_manager.direct_pose_timer_interval
    return None












classes = (

    SNA_OT_Delet_Path_6E947,
    SNA_OT_Delet_Allpath_B6Bbf,    
    SNA_OT_Delet_Path001_C28Ef,
    SNA_OT_Delet_Allpath001_C61F5,    
    AMTH_OT_AutoUpdateMotionPaths,
    AMTH_OT_AutoUpdateActivate,
    AMTH_OT_AutoUpdateDeactivate,
    DeactivateKeyframeOperator,
    GenericAutoUpdateKeyframesOperator,
    GenericAutoUpdateKeyframesActivate,
    GenericAutoUpdateKeyframesDeactivate,    
    InsertKeyframeOnSelectedFcurves,
    AMTH_OT_DirectPoseActivate,
    AMTH_OT_DirectPoseDeactivate,
    AutoMOTIONPATHSPanel,
    MotionPathPanel,

)



def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.auto_update_active = bpy.props.BoolProperty(default=False)
    bpy.types.WindowManager.auto_update_timer_interval = bpy.props.FloatProperty(
        name="Timer Interval",
        description="Interval in seconds for the auto-update timer",
        default=0.1,
        min=0.1,
        max=1.0
    )
    bpy.types.WindowManager.update_mode = bpy.props.EnumProperty(
        name="Update Mode",
        description="Choose between timer-based and event-based update modes",
        items=[
            ('TIMER', "Real_Time", "Update motion paths in real time Suitable for medium or powerful devices"),
            ('EVENT', "After_Change", "Update motion paths after moving the keyframes Suitable for weak devices")
        ],
        default='EVENT'
    )

    bpy.types.WindowManager.new_auto_update_active = bpy.props.BoolProperty(default=False)
    bpy.types.WindowManager.new_auto_update_timer_interval = bpy.props.FloatProperty(
        name="Timer Interval",
        description="Interval in seconds for the new auto-update timer",
        default=0.1,
        min=0.1,
        max=1.0
    )
    bpy.types.WindowManager.new_update_mode = bpy.props.EnumProperty(
        name="Update Mode",
        description="Choose between timer-based and event-based update modes",
        items=[
            ('TIMER', "Real_Time", "Update motion paths in real time Suitable for medium or powerful devices"),
            ('EVENT', "After_Change", "Update motion paths after moving the keyframes Suitable for weak devices")
        ],
        default='EVENT'
    )




    bpy.types.WindowManager.direct_pose_active = bpy.props.BoolProperty(default=False)
    bpy.types.WindowManager.direct_pose_timer_interval = bpy.props.FloatProperty(
        name="Timer Interval",
        description="Interval in seconds for the timer to check the selected object",
        default=0.1,
        min=0.1
    )

    bpy.types.WindowManager.generic_auto_update_active = bpy.props.BoolProperty(default=False)

    bpy.types.WindowManager.anim_deactivate_keyframe_operator = bpy.props.BoolProperty(
        name="Deactivate Keyframe Operator", default=False)

def unregister():

    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.WindowManager.generic_auto_update_active
    del bpy.types.WindowManager.auto_update_active
    del bpy.types.WindowManager.auto_update_timer_interval
    del bpy.types.WindowManager.update_mode
    del bpy.types.WindowManager.new_auto_update_active
    del bpy.types.WindowManager.new_auto_update_timer_interval
    del bpy.types.WindowManager.new_update_mode            
    del bpy.types.WindowManager.anim_deactivate_keyframe_operator

