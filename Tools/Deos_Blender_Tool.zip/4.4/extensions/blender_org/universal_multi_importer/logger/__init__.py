from .logger import LoggerProgress as Logger
from .logger_base import LoggerColors, MessageType

LOG = Logger(log_name='UMI')