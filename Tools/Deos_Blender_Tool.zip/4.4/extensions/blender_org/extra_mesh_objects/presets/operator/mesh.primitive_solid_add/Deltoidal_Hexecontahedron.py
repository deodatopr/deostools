import bpy
op = bpy.context.active_operator

op.source = "12"
op.vTrunc = 1.1338
op.eTrunc = 1
op.dual = 1
op.snub = "None"