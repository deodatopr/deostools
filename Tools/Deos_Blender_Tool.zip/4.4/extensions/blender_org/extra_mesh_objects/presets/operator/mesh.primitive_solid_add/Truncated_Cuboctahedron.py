import bpy
op = bpy.context.active_operator

op.source = "6"
op.vTrunc = 1.0572
op.eTrunc = 0.585786
op.dual = 0
op.snub = "None"