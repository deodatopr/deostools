import bpy
op = bpy.context.active_operator

op.source = "6"
op.vTrunc = 1.0875
op.eTrunc = 0.704
op.dual = 1
op.snub = "Left"