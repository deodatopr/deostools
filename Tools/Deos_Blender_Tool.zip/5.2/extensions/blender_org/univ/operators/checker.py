# SPDX-FileCopyrightText: 2026 Oxicid
# SPDX-License-Identifier: GPL-3.0-or-later


import bpy

from .. import utypes
from .. import utils
from ..preferences import prefs, checker_generated_types


# Patterns for future
# _ARS-10.5  # Arrow Scale
# _C(1,2,3)-FFFFFF_  # Color
# _P1-10.5   # Pattern 1
# _LW-2     # Line Width PX
# _SC-2     # Scale
# _SHP      # Shape
# UniV_ColorGrid_2K_
# UniV_Grid_2Kx512_


class UNIV_OT_Checker(bpy.types.Operator):
    bl_idname = "mesh.univ_checker"
    bl_label = "Checker"
    bl_description = "Used as a texture for testing UV maps"
    bl_options = {'REGISTER', 'UNDO'}

    def draw(self, context):
        layout = self.layout
        pref = prefs()

        row = layout.row(align=True, heading='Texture Type')
        row.scale_x = 0.92
        row.prop(pref, 'checker_generated_type', expand=True)

        row = layout.row(align=True, heading='Apply Method')
        row.scale_x = 0.92
        row.prop(pref, 'checker_toggle', expand=True)


        row = layout.row(align=True, heading='Size')
        row.prop(pref, 'size_x', text='')
        row.prop(pref, 'lock_size', text='', icon='LOCKED' if pref.lock_size else 'UNLOCKED')
        row.prop(pref, 'size_y', text='')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.full_pattern_name: str = ''
        self.shader = None
        self.batch = None

    def execute(self, context):
        self.checker_default(prefs().checker_toggle == 'TOGGLE')
        return {'FINISHED'}

    def checker_default(self, toggle):
        if self.sanitize_generated_textures():
            return

        self.full_pattern_name = self.get_full_image_name()

        mtl = self.get_exist_material_or_create()

        node_group = self.get_checker_node_group()
        for obj in bpy.context.selected_objects:
            utils.remove_univ_duplicate_modifiers(obj, 'UniV Checker', toggle_enable=toggle)

        def set_active_image():
            area = bpy.context.area
            if area and area.type == 'IMAGE_EDITOR':
                for node in mtl.node_tree.nodes:
                    if node.bl_idname == 'ShaderNodeTexImage':
                        if node.image:
                            assert node.image.name.startswith(self.full_pattern_name)
                            space_data = area.spaces.active
                            space_data.image = node.image
                            break

        if toggle:
            if self.all_has_enable_gn_checker_modifier():
                self.disable_all_gn_checker_modifier()
            else:
                set_active_image()
                self.enable_and_set_gn_checker_modifier(node_group, mtl)
        else:
            # TODO: Add Overwrite with toggle
            set_active_image()
            self.create_gn_checker_modifier(node_group, mtl)
        self.update_views()

    def get_exist_texture_or_create(self) -> bpy.types.Image:
        for image in reversed(bpy.data.images):
            image_name = image.name
            if image_name.startswith(self.full_pattern_name):
                if self.has_x_after_resolution(image_name) or tuple(image.size) != prefs().glob_size:
                    if image.users == 0:
                        bpy.data.images.remove(image)
                        print(f"UniV: Checker Image '{image_name}' was removed")
                    continue

                return image
        return self.generate_checker_texture()

    def material_is_changed_by_context(self, mtl):
        if getattr(mtl, 'use_nodes', True):
            nodes = mtl.node_tree.nodes
            if len(nodes) == 3:
                # TODO: Log it.
                output_node = [n for n in nodes if n.bl_idname == 'ShaderNodeOutputMaterial']
                if output_node:
                    if output_node[0].target == 'ALL' and output_node[0].inputs[0].links:
                        diffuse = output_node[0].inputs[0].links[0].from_node
                        if not diffuse.mute and diffuse.bl_idname == 'ShaderNodeBsdfDiffuse':
                            if diffuse.inputs[0].links:
                                img_node = diffuse.inputs[0].links[0].from_node
                                if not img_node.mute and img_node.bl_idname == 'ShaderNodeTexImage':
                                    img = img_node.image
                                    if img and img.name.startswith(self.full_pattern_name) and not self.has_x_after_resolution(img.name):
                                        if tuple(img.size) == prefs().glob_size:
                                            return False
        return True

    def get_exist_material_or_create(self) -> bpy.types.Material | None:
        for mtl in reversed(bpy.data.materials):
            mtl_name = mtl.name
            if mtl_name.startswith(self.full_pattern_name):
                if self.has_x_after_resolution(mtl_name) or self.material_is_changed_by_context(mtl):
                    if mtl.users == 0:
                        bpy.data.materials.remove(mtl)
                        print(f"UniV: Checker Material '{mtl_name}' was removed")
                else:
                    return mtl

        # Create Material
        img = self.get_exist_texture_or_create()

        area = bpy.context.area
        if area and area.type == 'IMAGE_EDITOR':
            space_data = area.spaces.active
            if space_data:
                if space_data.image != img:
                    space_data.image = img
                    area.tag_redraw()

        mtl = bpy.data.materials.new(name=self.full_pattern_name)
        if hasattr(mtl, 'use_nodes'):
            mtl.use_nodes = True

        nodes = mtl.node_tree.nodes
        nodes.clear()

        output = nodes.new(type="ShaderNodeOutputMaterial")
        diffuse = nodes.new(type="ShaderNodeBsdfDiffuse")
        node_image = nodes.new(type="ShaderNodeTexImage")

        output.location = (200, 0)
        diffuse.location = (0, 0)
        node_image.location = (-300, 0)

        mtl.node_tree.links.new(diffuse.outputs[0], output.inputs[0])
        mtl.node_tree.links.new(node_image.outputs[0], diffuse.inputs[0])

        node_image.image = img

        nodes.active = node_image
        return mtl

    @staticmethod
    def checker_node_group_is_changed(node_group):
        if not node_group:
            return True
        nodes = node_group.nodes
        if len(nodes) != 3:
            return True
        # Output node check.
        output_node = [n for n in nodes if n.bl_idname == 'NodeGroupOutput']
        if output_node and output_node[0].inputs:  # Check output node exist and exist inputs.
            output_links = output_node[0].inputs[0].links
            if output_links:  # Check links exist.

                # Material node check.
                set_mtl_node = output_links[0].from_node
                if set_mtl_node.bl_idname == 'GeometryNodeSetMaterial':
                    geom_link_to_input_node = set_mtl_node.inputs[0].links
                    if not geom_link_to_input_node:
                        return True

                    # Input node check.
                    input_node = geom_link_to_input_node[0].from_node
                    if input_node.bl_idname == 'NodeGroupInput':
                        if len(input_node.outputs) != 3:
                            return True

                        mtl_link_to_input_node = set_mtl_node.inputs[2].links
                        if mtl_link_to_input_node and mtl_link_to_input_node[0].from_node == input_node:
                            return False
        return True

    def get_checker_node_group(self):
        """Get exist checker node group"""
        for ng in reversed(bpy.data.node_groups):
            if ng.name.startswith('UniV Checker'):
                if self.checker_node_group_is_changed(ng):
                    if ng.users == 0:
                        bpy.data.node_groups.remove(ng)
                else:
                    return ng
        return self._create_checker_node_group()

    def sanitize_generated_textures(self):
        pass

    @staticmethod
    def _create_checker_node_group():
        node_group = bpy.data.node_groups.new(name='UniV Checker', type='GeometryNodeTree')

        input_node = node_group.nodes.new(type="NodeGroupInput")
        output_node = node_group.nodes.new(type="NodeGroupOutput")

        input_node.location = (-200, 0)
        output_node.location = (200, 0)

        iface = getattr(node_group, 'interface', None)
        if iface:
            iface.new_socket('Input', description="", in_out='INPUT', socket_type='NodeSocketGeometry')
            iface.new_socket('Checker Material', description="", in_out='INPUT', socket_type='NodeSocketMaterial')
            iface.new_socket('Output', description="", in_out='OUTPUT', socket_type='NodeSocketGeometry')
        else:
            node_group.inputs.new('NodeSocketGeometry', 'Input')
            node_group.inputs.new('NodeSocketMaterial', 'Checker Material')
            node_group.outputs.new('NodeSocketGeometry', 'Output')

        set_material_node = node_group.nodes.new(type="GeometryNodeSetMaterial")
        set_material_node.location = (0, 0)

        mtl_socket = [s for s in set_material_node.inputs if s.bl_idname == 'NodeSocketMaterial'][0]

        node_group.links.new(input_node.outputs['Input'], set_material_node.inputs['Geometry'])
        node_group.links.new(set_material_node.outputs['Geometry'], output_node.inputs['Output'])
        node_group.links.new(input_node.outputs['Checker Material'], mtl_socket)

        return node_group

    @staticmethod
    def create_gn_checker_modifier(node_group, mtl):
        for obj in bpy.context.selected_objects:
            if not obj.type == 'MESH':
                continue
            has_checker_modifier = False
            for m in obj.modifiers:
                if not isinstance(m, bpy.types.NodesModifier):
                    continue
                if m.name.startswith('UniV Checker'):
                    has_checker_modifier = True
                    if m.node_group != node_group:
                        m.node_group = node_group

                    gn_mod = utils.GN(m, print_missed_socket=True)
                    if 'Socket_1' in gn_mod:
                        if gn_mod['Socket_1'] != mtl:
                            gn_mod['Socket_1'] = mtl
                    obj.update_tag()  # TODO: No update when not changed (check).
                    break
            if not has_checker_modifier:
                m = obj.modifiers.new(name='UniV Checker', type='NODES')
                m.node_group = node_group
                m.show_render = False
                gn_mod = utils.GN(m, print_missed_socket=True)
                if 'Socket_1' in gn_mod:
                    gn_mod['Socket_1'] = mtl

    @staticmethod
    def all_has_enable_gn_checker_modifier():
        counter = 0
        selected_objects = [obj_ for obj_ in bpy.context.selected_objects if obj_.type == 'MESH']
        for obj in selected_objects:
            for m in obj.modifiers:
                if isinstance(m, bpy.types.NodesModifier):
                    if m.name.startswith('UniV Checker'):
                        counter += (m.show_in_editmode and m.show_viewport)
                        break
        return len(selected_objects) == counter

    @staticmethod
    def enable_and_set_gn_checker_modifier(node_group, mtl):
        for obj in bpy.context.selected_objects:
            if not obj.type == 'MESH':
                continue
            has_checker_modifier = False
            for m in obj.modifiers:
                if not isinstance(m, bpy.types.NodesModifier):
                    continue
                if m.name.startswith('UniV Checker'):
                    if not m.show_in_editmode:
                        m.show_in_editmode = True
                    if not m.show_viewport:
                        m.show_viewport = True

                    # Set fixed node groups.
                    if m.node_group != node_group:
                        print(f"UniV: Checker: Restored {node_group.name!r} Node Group for {m.name!r} modifier for {obj.name!r} object.")
                        m.node_group = node_group

                    # Set fixed materials.
                    gn_mod = utils.GN(m, print_missed_socket=True)
                    if 'Socket_1' in gn_mod:
                        if not gn_mod['Socket_1']:
                            gn_mod['Socket_1'] = mtl
                            print(f"UniV: Checker: Restored {mtl.name!r} material for {m.name!r} modifier for {obj.name!r} object.")


                    has_checker_modifier = True
                    obj.update_tag()
                    break
            if not has_checker_modifier:
                m = obj.modifiers.new(name='UniV Checker', type='NODES')
                m.node_group = node_group
                m.show_render = False

                gn_mod = utils.GN(m, print_missed_socket=True)
                if 'Socket_1' in gn_mod:
                    gn_mod['Socket_1'] = mtl

    @staticmethod
    def disable_all_gn_checker_modifier():
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH':
                for m in obj.modifiers:
                    if isinstance(m, bpy.types.NodesModifier):
                        if m.name.startswith('UniV Checker'):
                            m.show_in_editmode = False
                            m.show_viewport = False
                            break


    @staticmethod
    def get_name_from_gen_type_idname(name):
        for gt in checker_generated_types:
            if gt[0] == name:
                return gt[1].replace(' ', '')
        raise NotImplementedError(f'Texture {name} not implement')

    @staticmethod
    def get_color_name(tex_name):
        return ''.join([name.capitalize() for name in tex_name.split('_')])

    @classmethod
    def get_full_image_name(cls):
        idname = cls.get_name_from_gen_type_idname(prefs().checker_generated_type)
        res_name = utils.glob_resolutions_to_name()

        match prefs().checker_generated_type:
            case 'UV_GRID' | 'COLOR_GRID':
                return f"UniV_{idname}_{res_name}"
            case _:
                raise NotImplementedError(f'Texture {idname} not implement')


    def generate_checker_texture(self):
        full_image_name = self.get_full_image_name()

        if prefs().checker_generated_type in ('UV_GRID', 'COLOR_GRID'):
            before = set(bpy.data.images)
            bpy.ops.image.new(
                name=full_image_name,
                width=int(prefs().size_x),
                height=int(prefs().size_y),
                alpha=False,
                generated_type=prefs().checker_generated_type)
            return tuple(set(bpy.data.images) - before)[0]
        else:
            raise NotImplementedError(f'Texture {prefs().checker_generated_type} not implement')

    @staticmethod
    def update_views():
        changed = False
        for area in utils.get_areas_by_type('VIEW_3D'):
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    if space.shading.type == 'SOLID':
                        if space.shading.color_type != 'TEXTURE':
                            space.shading.color_type = 'TEXTURE'
                            changed = True
                    elif space.shading.type == 'WIREFRAME':
                        space.shading.type = 'SOLID'
                        space.shading.color_type = 'TEXTURE'
                        changed = True
        if changed:
            bpy.context.view_layer.update()

    def has_x_after_resolution(self, name):
        x_idx = len(self.full_pattern_name)
        return len(name) > x_idx and name[x_idx] == 'x'


class UNIV_OT_CheckerCleanup(bpy.types.Operator):
    bl_idname = "wm.univ_checker_cleanup"
    bl_label = "Checker Map Cleanup"
    bl_description = "Cleanup textures, materials, nodes and modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        self.remove_modifiers()
        self.remove_node_group()
        self.remove_materials()
        # TODO: Close img from selected meshes
        for a in utils.get_areas_by_type('IMAGE_EDITOR'):
            space = a.spaces.active
            img = space.image
            if img and img.name.startswith('UniV_'):
                space.image = None
        self.remove_images()
        return {'FINISHED'}

    @staticmethod
    def remove_modifiers():
        if bpy.context.mode == 'EDIT_MESH':
            selected_objects = utypes.UMeshes.loop_for_object_mode_processing(without_selection=True)
        else:
            selected_objects = bpy.context.selected_objects
        # mod_counter = 0
        for obj in selected_objects:
            if obj.type == 'MESH':
                for m in reversed(obj.modifiers):
                    if isinstance(m, bpy.types.NodesModifier):
                        if m.name.startswith('UniV Checker'):
                            obj.modifiers.remove(m)

    @staticmethod
    def remove_node_group():
        for ng in reversed(bpy.data.node_groups):
            if ng.name.startswith('UniV Checker'):
                if not ng.users:
                    bpy.data.node_groups.remove(ng)

    @staticmethod
    def remove_materials():
        for mtl in reversed(bpy.data.materials):
            if mtl.name.startswith('UniV_') and not mtl.users:
                bpy.data.materials.remove(mtl)

    @staticmethod
    def remove_images():
        for img in reversed(bpy.data.images):
            if img.name.startswith('UniV_') and not img.users:
                bpy.data.images.remove(img)



