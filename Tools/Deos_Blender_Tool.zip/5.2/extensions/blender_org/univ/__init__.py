# SPDX-FileCopyrightText: 2025 Oxicid
# SPDX-License-Identifier: GPL-3.0-or-later

bl_info = {
    "name": "UniV",
    "description": "Smart UV tools",
    "author": "Oxicid",
    "version": (4, 0, 0),
    "blender": (3, 2, 0),
    "category": "UV",
    "location": "N-panel in 2D and 3D view"
}

import bpy
import typing
import traceback

from . import utypes        # noqa: F401 # pylint:disable=unused-import
from . import preferences  # noqa: F401 # pylint:disable=unused-import
from .utils import bench   # noqa: F401 # pylint:disable=unused-import
from .utils import other   # noqa: F401 # pylint:disable=unused-import
from .utils import ubm     # noqa: F401 # pylint:disable=unused-import
from .utils import umath   # noqa: F401 # pylint:disable=unused-import
from .utypes import bbox    # noqa: F401 # pylint:disable=unused-import
from .utypes import btypes  # noqa: F401 # pylint:disable=unused-import
from .utypes import island  # noqa: F401 # pylint:disable=unused-import
from .utypes import mesh_island  # noqa: F401 # pylint:disable=unused-import
from .operators import checker
from .operators import inspect
from .operators import misc
from .operators import project
from .operators import quadrify
from .operators import quick_snap
from .operators import relax
from .operators import mark
from .operators import select
from .operators import stitch_and_weld
from .operators import stack
from .operators import straight
from .operators import symmetrize
from .operators import texel
from .operators import toggle
from .operators import transform
from .operators import unwrap
from . import ui
from . import draw
from . import icons
from . import keymaps
# from . import fastapi
from . import preferences



classes: list[bpy.types.Operator | bpy.types.Panel | bpy.types.Macro | typing.Any] = []
classes_workspace = []


def load_register_types():
    global classes
    try:
        classes.extend([
            preferences.UNIV_UV_Layers,
            preferences.UNIV_TexelPreset,
            preferences.UNIV_AddonPreferences,
            preferences.UNIV_OT_ShowAddonPreferences,
            # Checker System
            checker.UNIV_OT_CheckerCleanup,
            # Inspect
            inspect.UNIV_OT_BatchInspectFlags,
            inspect.UNIV_OT_BatchInspect,
            inspect.UNIV_OT_Check_Zero,
            inspect.UNIV_OT_Check_Flipped,
            inspect.UNIV_OT_Check_Non_Splitted,
            inspect.UNIV_OT_Check_Overlap,
            inspect.UNIV_OT_Check_Over,
            inspect.UNIV_OT_Check_Other,
            # Stitch and Weld
            stitch_and_weld.UNIV_OT_Weld_VIEW3D,
            stitch_and_weld.UNIV_OT_Weld,
            stitch_and_weld.UNIV_OT_Stitch_VIEW3D,
            stitch_and_weld.UNIV_OT_Stitch,
            # Transforms
            transform.UNIV_OT_Orient_VIEW3D,
            transform.UNIV_OT_Orient,
            transform.UNIV_OT_Gravity_VIEW3D,
            transform.UNIV_OT_Gravity_VIEW2D,
            transform.UNIV_OT_Align,
            transform.UNIV_OT_Align_pie,
            transform.UNIV_OT_Fill,
            transform.UNIV_OT_Fit,
            transform.UNIV_OT_SnapToPixels,
            transform.UNIV_OT_Flip,
            transform.UNIV_OT_Flip_VIEW3D,
            transform.UNIV_OT_Rotate,
            transform.UNIV_OT_Rotate_VIEW3D,
            transform.UNIV_OT_Sort,
            transform.UNIV_OT_Distribute,
            transform.UNIV_OT_Break,
            transform.UNIV_OT_Home_VIEW3D,
            transform.UNIV_OT_Home,
            transform.UNIV_OT_Shift_VIEW3D,
            transform.UNIV_OT_Shift,
            transform.UNIV_OT_Random_VIEW3D,
            transform.UNIV_OT_Random,
            transform.UNIV_OT_Pack,
            # Texel
            texel.UNIV_OT_ResetScale_VIEW3D,
            texel.UNIV_OT_ResetScale,
            texel.UNIV_OT_AdjustScale,
            texel.UNIV_OT_AdjustScale_VIEW3D,
            texel.UNIV_OT_Normalize,
            texel.UNIV_OT_Normalize_VIEW3D,
            texel.UNIV_OT_TexelDensitySet,
            texel.UNIV_OT_TexelDensitySet_VIEW3D,
            texel.UNIV_OT_TexelDensityGet,
            texel.UNIV_OT_TexelDensityGet_VIEW3D,
            texel.UNIV_OT_TexelDensityFromPhysicalSize,
            texel.UNIV_OT_CalcUDIMsFrom_3DArea_VIEW3D,
            texel.UNIV_OT_CalcUDIMsFrom_3DArea,
            texel.UNIV_OT_Calc_UV_Area_VIEW3D,
            texel.UNIV_OT_Calc_UV_Area,
            texel.UNIV_OT_Calc_UV_Coverage_VIEW3D,
            texel.UNIV_OT_Calc_UV_Coverage,
            # Symmetrize
            symmetrize.UNIV_OT_Symmetrize,
            # Quadrify
            quadrify.UNIV_OT_Quadrify,
            # Straight
            straight.UNIV_OT_Straight,
            # Relax
            relax.UNIV_OT_Relax,
            relax.UNIV_OT_Relax_VIEW3D,
            # Unwrap
            unwrap.UNIV_OT_Unwrap_VIEW3D,
            # Toggles
            toggle.UNIV_OT_SplitUVToggle,
            toggle.UNIV_OT_TogglePivot,
            toggle.UNIV_OT_TogglePanelsByCursor,
            toggle.UNIV_OT_SyncUVToggle,
            toggle.UNIV_OT_StretchUVToggle,
            toggle.UNIV_OT_ShowModifiedUVEdgeToggle,
            toggle.UNIV_OT_WorkspaceToggle,
            # Modifier Toggle
            toggle.UNIV_OT_ModifiersToggle,

            # Selects
            select.UNIV_OT_SelectLinked,
            select.UNIV_OT_SelectLinked_VIEW3D,
            select.UNIV_OT_Select_By_Cursor,
            select.UNIV_OT_Select_Square_Island,
            select.UNIV_OT_Select_Border,
            select.UNIV_OT_Select_Pick,
            select.UNIV_OT_SelectLinkedPick_VIEW3D,
            select.UNIV_OT_DeselectLinkedPick_VIEW3D,
            select.UNIV_OT_Select_Grow_VIEW3D,
            select.UNIV_OT_Select_Grow,
            select.UNIV_OT_Select_Edge_Grow_VIEW2D,
            select.UNIV_OT_Select_Edge_Grow_VIEW3D,
            select.UNIV_OT_SelectTexelDensity,
            select.UNIV_OT_SelectTexelDensity_VIEW3D,
            select.UNIV_OT_SelectByArea,
            select.UNIV_OT_Stacked,
            select.UNIV_OT_SelectByVertexCount_VIEW2D,
            select.UNIV_OT_SelectByVertexCount_VIEW3D,
            select.UNIV_OT_SelectMode,
            # QuickSnap
            quick_snap.UNIV_OT_QuickSnap,
            # UI
            ui.UNIV_PT_TD_LayersManager,
            ui.UNIV_UL_TD_PresetsManager,
            ui.UNIV_PT_TD_PresetsManager,
            ui.UNIV_PT_TD_PresetsManager_VIEW3D,
            ui.UNIV_UL_UV_LayersManager,
            ui.UNIV_UL_UV_LayersManagerV2,
            ui.UNIV_PT_General_VIEW_3D,
            ui.UNIV_PT_General,
            ui.UNIV_PT_GlobalSettings,
            ui.UNIV_PT_PackSettings,
            ui.UNIV_PT_BatchInspectSettings,
            # Pie Menus
            ui.IMAGE_MT_PIE_univ_inspect,
            ui.IMAGE_MT_PIE_univ_align,
            ui.IMAGE_MT_PIE_univ_misc,
            ui.VIEW3D_MT_PIE_univ_misc,
            ui.VIEW3D_MT_PIE_univ_obj,
            ui.IMAGE_MT_PIE_univ_edit,
            ui.VIEW3D_MT_PIE_univ_edit,
            ui.VIEW3D_MT_PIE_univ_favorites_edit,
            ui.IMAGE_MT_PIE_univ_favorites_edit,
            ui.VIEW3D_MT_PIE_univ_projection,
            ui.IMAGE_MT_PIE_univ_texel,
            ui.VIEW3D_MT_PIE_univ_texel,
            ui.IMAGE_MT_PIE_univ_transform,
            # Seam
            mark.UNIV_OT_Pin,
            mark.UNIV_OT_Mark_VIEW2D,
            mark.UNIV_OT_Mark_VIEW3D,
            mark.UNIV_OT_Cut_VIEW2D,
            mark.UNIV_OT_Cut_VIEW3D,
            mark.UNIV_OT_Angle,
            mark.UNIV_OT_SeamBorder,
            mark.UNIV_OT_SeamBorder_VIEW3D,
            # Project
            project.UNIV_OT_Normal,
            project.UNIV_OT_ViewProject,
            project.UNIV_OT_SmartProject,
            # Misc
            misc.UNIV_OT_RandomColor,
            misc.UNIV_OT_LinearGradient,
            misc.UNIV_OT_Hide,
            misc.UNIV_OT_Focus,
            misc.UNIV_OT_SetCursor2D,
            misc.UNIV_OT_TD_PresetsProcessing,
            misc.UNIV_OT_FixUVs,
            misc.UNIV_OT_Join,
            misc.UNIV_OT_Add,
            misc.UNIV_OT_Remove,
            misc.UNIV_OT_MoveUp,
            misc.UNIV_OT_MoveDown,
            misc.UNIV_OT_CopyToLayer,
            misc.UNIV_OT_SetActiveRender,
            misc.UNIV_OT_SmartScaleApply,
            misc.UNIV_OT_AlignBorderVerts,
            # Mesh
            misc.UNIV_OT_Flatten,
            misc.UNIV_OT_FlattenCleanup,
        ])

        if True:
            classes.extend((
                # Checker System
                checker.UNIV_OT_Checker,
                # Project
                project.UNIV_OT_BoxProject,
                # Stack
                stack.UNIV_OT_Stack,
                stack.UNIV_OT_Stack_VIEW3D,
                # Unwrap
                unwrap.UNIV_OT_Unwrap
            ))

    except AttributeError:
        traceback.print_exc()
        classes = []


load_register_types()


def load_workspace_types():
    classes_workspace.extend([
        ui.UNIV_WT_edit_VIEW3D,
        ui.UNIV_WT_object_VIEW3D]
    )


load_workspace_types()

is_enabled = False


def univ_load_post_for_timer():
    """For avoid context restrict"""
    # TODO: Add to inspect
    draw.shaders.Shaders.init_shaders()
    misc.UNIV_OT_UV_Layers_Manager.uv_layers_watcher_append_handler()


@bpy.app.handlers.persistent
def univ_load_post(_):
    univ_load_post_for_timer()


def register():
    if bpy.app.background:
        print("UniV: Skipping registration in background mode")
        return

    global is_enabled
    if is_enabled or not classes:

        if not classes:
            load_register_types()
            if not classes:
                raise AttributeError('UniV: Failed to load operators, try re-enabling or restarting Blender')

        if not classes_workspace:
            load_workspace_types()
            if not classes_workspace:
                raise AttributeError('UniV: Failed to load workspace tool, try re-enabling or restarting Blender')

    is_enabled = True

    for c in classes:
        try:
            bpy.utils.register_class(c)

            # Register Macros
            if c.__name__ == 'UNIV_OT_SelectLinkedPick_VIEW3D':
                item = c.define("MESH_OT_select_linked_pick")
                item.properties.deselect = False
            elif c.__name__ == 'UNIV_OT_DeselectLinkedPick_VIEW3D':
                item = c.define("MESH_OT_select_linked_pick")
                item.properties.deselect = True

        except Exception:  # noqa
            print(f"UniV: Failed to register a class {c.__name__}")
            traceback.print_exc()

    for c in classes_workspace:
        try:
            bpy.utils.register_tool(c)
        except Exception:  # noqa
            print(f"UniV: Failed to register a class {c.__name__}")
            traceback.print_exc()

    # Icons register.
    try:
        icons.icons.register_ws_icons_()
        icons.icons.register_icons_()  # NOTE: Need registered AddonPreferences.
    except:  # noqa
        print('UniV: Icons not loaded.')
        traceback.print_exc()


    # WARNING: When modules are reloaded, classes are overwritten and have no registration.
    # To avoid this, it is necessary to use initially registered classes.
    # Perhaps it does not allow to reload operators in a normal way.
    # bpy.types.WindowManager.univ_settings = bpy.props.PointerProperty(type=classes[3])

    # TODO: Add checks to inspect
    # After restarting the add-on, it doesn't work, but older versions of Blender don't have context-restricted mode,
    # so you can load it without any delay
    # bpy.app.handlers.load_post.append(univ_load_post)
    from bpy.app.timers import register
    register(univ_load_post_for_timer, first_interval = 0.0, persistent = True)

    bpy.types.VIEW3D_HT_header.prepend(toggle.univ_header_split_btn)
    bpy.types.IMAGE_HT_header.prepend(toggle.univ_header_sync_btn)
    bpy.types.IMAGE_HT_header.prepend(toggle.univ_header_split_btn)

    bpy.types.VIEW3D_MT_object_apply.prepend(misc.draw_smart_scale_menu)


    try:
        keymaps.add_keymaps()
        keymaps.add_keymaps_ws()
    except AttributeError:
        traceback.print_exc()

    preferences.update_panel(None, None)
    toggle.ToggleHandlers.register_handler()


def unregister():
    if bpy.app.background:
        return

    keymaps.remove_keymaps()
    keymaps.remove_keymaps_ws()
    icons.icons.unregister_icons_()
    # icons.icons.unregister_ws_icons_()


    for handle in reversed(bpy.app.handlers.depsgraph_update_post):
        if handle.__name__.startswith('univ_'):
            bpy.app.handlers.depsgraph_update_post.remove(handle)

    # del bpy.types.WindowManager.univ_settings  # noqa
    # for scene in bpy.data.scenes:
    #     if "univ_settings" in scene:
    #         del scene["univ_settings"]

    for c in reversed(classes_workspace):
        try:
            bpy.utils.unregister_tool(c)
        except RuntimeError:
            # if not hasattr(c, 'rna_type'):
            #     continue
            traceback.print_exc()

    for c in reversed(classes):
        try:
            bpy.utils.unregister_class(c)
        except RuntimeError:
            if not hasattr(c, 'rna_type'):
                continue
            traceback.print_exc()

    bpy.types.VIEW3D_HT_header.remove(toggle.univ_header_split_btn)
    bpy.types.IMAGE_HT_header.remove(toggle.univ_header_split_btn)
    bpy.types.IMAGE_HT_header.remove(toggle.univ_header_sync_btn)
    bpy.types.VIEW3D_MT_object_apply.remove(misc.draw_smart_scale_menu)


    toggle.ToggleHandlers.unregister_handler()

    for handler in reversed(bpy.app.handlers.load_post):
        if handler.__name__ == univ_load_post.__name__:
            bpy.app.handlers.load_post.remove(handler)

if __name__ == "__main__":
    register()
