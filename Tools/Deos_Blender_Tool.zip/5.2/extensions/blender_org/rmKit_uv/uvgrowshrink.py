import bpy, mathutils
import rmlib

def uv_border_edge( uvlayer, loop ):
	if loop.edge.is_boundary:
		return True
	
	uvcoord = mathutils.Vector( loop[uvlayer].uv.copy() )
	for n_l in loop.vert.link_loops:
		if n_l == loop:
			continue
		n_uvcoord = mathutils.Vector( n_l[uvlayer].uv.copy() )
		if not rmlib.AlmostEqual_v2( uvcoord, n_uvcoord ):
			return True
		
	return False
		

def shrink_face_loop( uvlayer, loops ):
	included_faces = set( [ l.face for l in loops ] )
		
	fully_selected_faces = set()
	for f in included_faces:
		count = 0
		for l in f.loops:
			if l.uv_select_vert:
				count += 1
		if count == len( f.loops ):
			fully_selected_faces.add( f )
			
	if len( fully_selected_faces ) == len( included_faces ):
		#shrink to next sequence of loops
		excluded_faces = set()
		for l in loops:
			uvcoord = mathutils.Vector( l[uvlayer].uv )
			deselect = False
			deselect_loops = set()
			for n_l in l.vert.link_loops:
				n_uvcoord = mathutils.Vector( n_l[uvlayer].uv )
				if rmlib.AlmostEqual_v2( uvcoord, n_uvcoord ):
					deselect_loops.add( n_l )
					if not n_l.uv_select_vert:
						deselect = True
			if deselect:
				excluded_faces.add( l.face )
				for d_l in deselect_loops:
					d_l.uv_select_vert = False	
		for f in excluded_faces:
			for l in f.loops:
				l.uv_select_edge = False		
	else:
		#shrink to only fully_selected_faces
		for l in loops:
				l.uv_select_vert = False
				l.uv_select_edge = False
		for f in fully_selected_faces:
			for l in f.loops:
				l.uv_select_vert = True
				l.uv_select_edge = True
				
				
def grow_face_loop( uvlayer, loops ):
	included_faces = set( [ l.face for l in loops ] )
	fully_selected_faces = set()
	for f in included_faces:
		count = 0
		for l in f.loops:
			if l.uv_select_vert:
				count += 1
		if count == len( f.loops ):
			fully_selected_faces.add( f )
			
	if len( fully_selected_faces ) == len( included_faces ):
		#get next sequence of loops
		for l in loops:
			uvcoord = mathutils.Vector( l[uvlayer].uv )
			for n_l in l.vert.link_loops:
				if n_l.uv_select_vert or l == n_l:
					continue
				n_uvcoord = mathutils.Vector( n_l[uvlayer].uv )
				if rmlib.AlmostEqual_v2( uvcoord, n_uvcoord ):
					n_l.uv_select_vert = True
	else:
		#fill loop selection
		for f in included_faces:
			for l in f.loops:
				l.uv_select_vert = True
				l.uv_select_edge = True


class MESH_OT_uvgrowshrink( bpy.types.Operator ):
	"""Grow or shrink uv selection."""
	bl_idname = 'mesh.rm_uvgrowshrink'
	bl_label = 'Grow / Shrink'
	bl_options = { 'UNDO' }

	mode: bpy.props.EnumProperty(
		items=[ ( "GROW", "Grow", "", 1 ),
				( "SHRINK", "Shrink", "", 2 ) ],
		name="Mode",
		default="GROW"
	)

	@classmethod
	def poll( cls, context ):
		return ( context.area.type == 'IMAGE_EDITOR' and
				context.active_object is not None and
				context.active_object.type == 'MESH' and
				context.object.data.is_editmode )

	def execute( self, context ):
		rmmesh = rmlib.rmMesh.GetActive( context )
		if rmmesh is None:
			return { 'CANCELLED' }
				
		sel_sync = context.tool_settings.use_uv_select_sync
		sel_mode_uv = context.tool_settings.uv_select_mode	
		if sel_sync:
			if self.mode == 'GROW':
				bpy.ops.uv.select_more()
			else:
				bpy.ops.uv.select_less()
		else:				
			if self.mode == 'GROW':
				if sel_mode_uv == 'FACE':
					with rmmesh as rmmesh:
						rmmesh.readonly = True
						uvlayer = rmmesh.active_uv
						loop_selection = rmlib.rmUVLoopSet.from_selection( rmmesh=rmmesh, uvlayer=uvlayer )
						grow_face_loop( uvlayer, loop_selection )
				else:
					bpy.ops.uv.select_more()
			else:
				if sel_mode_uv == 'FACE':
					with rmmesh as rmmesh:
						rmmesh.readonly = True
						uvlayer = rmmesh.active_uv
						loop_selection = rmlib.rmUVLoopSet.from_selection( rmmesh=rmmesh, uvlayer=uvlayer )
						shrink_face_loop( uvlayer, loop_selection )
				else:
					bpy.ops.uv.select_less()

		return { 'FINISHED' }


def register():
	bpy.utils.register_class( MESH_OT_uvgrowshrink )
	

def unregister():
	bpy.utils.unregister_class( MESH_OT_uvgrowshrink )