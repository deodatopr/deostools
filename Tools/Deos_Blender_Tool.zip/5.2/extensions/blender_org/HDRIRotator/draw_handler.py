import bpy
import blf
import time
import math

# Store the current drawing data
draw_data = {
    "text": "",
    "start_time": 0,
    "duration": 2.0,  # Display duration in seconds
    "fade_duration": 0.5,  # Fade out duration in seconds
    "color": [1.0, 1.0, 1.0, 1.0],  # RGBA
    "size": 20,
    "position": (100, 100),  # Default position
    "vertical_position": 85.0,  # Default vertical position (percentage from bottom)
    "horizontal_position": 50.0,  # Default horizontal position (percentage from left)
    "handler": None,
    "is_enabled": False,
    "timer": None,  # Timer for continuous redraws
    "value": None,  # Current rotation value
}

def draw_callback_px():
    """Draw the text in the viewport"""
    # If we have a value to display or we're in the fade-out period
    if draw_data["value"] is not None or time.time() < draw_data["start_time"] + draw_data["duration"] + draw_data["fade_duration"]:
        # Calculate time elapsed since start
        elapsed = time.time() - draw_data["start_time"]
        
        # Calculate alpha based on fade timing
        if elapsed > draw_data["duration"]:
            # Fade out phase
            fade_progress = (elapsed - draw_data["duration"]) / draw_data["fade_duration"]
            alpha = 1.0 - fade_progress
        else:
            alpha = 1.0
        
        # Set text properties
        font_id = 0  # Default font
        blf.position(font_id, draw_data["position"][0], draw_data["position"][1], 0)
        blf.size(font_id, draw_data["size"])
        
        # Set color with current alpha
        color = draw_data["color"].copy()
        color[3] = alpha * color[3]
        blf.color(font_id, *color)
        
        # Draw the text
        blf.draw(font_id, draw_data["text"])
    else:
        # If there's no value to display and we're outside the fade duration, remove handler
        _remove_handler()

def timer_update():
    """Timer callback to force redraw during fading"""
    # Force a redraw of all 3D VIEW regions
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        region.tag_redraw()
    
    # Calculate time elapsed
    elapsed = time.time() - draw_data["start_time"]
    
    # Stop the timer if we're done fading and not showing continuously
    if elapsed > draw_data["duration"] + draw_data["fade_duration"] and draw_data["value"] is None:
        _remove_timer()
        return None
    
    return 0.01  # 100 fps refresh rate

def _remove_handler():
    """Internal function to remove the draw handler if it exists"""
    if draw_data["handler"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(draw_data["handler"], 'WINDOW')
        draw_data["handler"] = None
        draw_data["is_enabled"] = False
    
    # Also remove the timer
    _remove_timer()
    
    # Reset the value
    draw_data["value"] = None

def _remove_timer():
    """Internal function to remove the timer if it exists"""
    if draw_data["timer"] is not None:
        bpy.app.timers.remove(draw_data["timer"])
        draw_data["timer"] = None

def remove_handler():
    """Public function to remove the draw handler, for use by other modules"""
    _remove_handler()

def format_rotation_value(mode, value, sun_axis=None):
    """Format the rotation value based on the mode"""
    if mode == 'SHADOW_ROTATION':
        # Show X/Y angles derived from light direction vector
        # value is a Vector3D representing light direction
        if hasattr(value, 'x') and hasattr(value, 'y') and hasattr(value, 'z'):
            # Calculate azimuth (horizontal rotation around Z axis)
            azimuth = math.degrees(math.atan2(value.y, value.x))
            # Calculate elevation (vertical angle from XY plane)
            horizontal_dist = math.sqrt(value.x**2 + value.y**2)
            elevation = math.degrees(math.atan2(-value.z, horizontal_dist))
            return f"Shadow Direction: X: {azimuth:.1f}°  Y: {elevation:.1f}°"
        return None
    
    elif mode == 'STUDIO_WORLD_SPACE_LIGHTING_ROTATION':
        # For studio lighting
        degrees = value
        return f"Studio Light Rotation: {degrees:.2f}°"
    
    elif mode == 'HDRI_ROTATION':
        # For built-in HDRI
        degrees = value
        return f"Built-in HDRI Rotation: {degrees:.2f}°"
    
    elif mode in ('CUSTOM_HDRI_ROTATION', 'MAPPING_NODE_ROTATION'):
        if hasattr(value, 'z'):  # Vector or Euler
            degrees = math.degrees(value.z)
        else:
            degrees = value
        return f"World HDRI Rotation: {degrees:.2f}°"
    
    elif mode == 'MAPPING_Z_LOCATION':
        # For mapping node Z location (Blender units, not degrees)
        return f"HDRI Height: {value:.4f}"
    
    elif mode == 'SKY_TEXTURE_ROTATION':
        # For sky texture, format as degrees
        degrees = math.degrees(value)
        return f"Sky Rotation: {degrees:.2f}°"
    
    elif mode == 'SKY_TEXTURE_ELEVATION':
        # For sky texture elevation (sun_elevation), format as degrees
        degrees = math.degrees(value)
        return f"Sky Height: {degrees:.2f}°"
    
    elif mode == 'SUN_ROTATION':
        degrees = value
        axis = sun_axis or 'Z'
        return f"Sun {axis} Rotation: {degrees:.2f}°"
    
    elif mode == 'POWER_BUILTIN':
        return f"Built-in HDRI Strength: {value:.3f}"
    
    elif mode == 'POWER_CUSTOM_EV':
        return f"HDRI Strength (EVs): {value:.2f}"
    
    elif mode == 'POWER_WORLD_BACKGROUND':
        return f"World Background Strength: {value:.3f}"
    
    elif mode == 'POWER_LIGHT':
        return f"Light Strength: {value:.3f}"
    
    else:
        # Default fallback
        return f"Rotation: {value:.2f}°"

def update_rotation_value(mode, value, sun_axis=None):
    """Update the rotation value to be displayed in the viewport"""
    # Check if viewport overlay is enabled in preferences
    try:
        addon_prefs = bpy.context.preferences.addons[__package__].preferences
        if not addon_prefs.display_rotation_overlay:
            # Rotation overlay is disabled, don't show
            return
    except (AttributeError, KeyError):
        # If we can't access preferences, default to enabled
        pass
    
    # Format the text based on the mode and value
    formatted_text = format_rotation_value(mode, value, sun_axis=sun_axis)
    if not formatted_text:
        return
    
    draw_data["value"] = value
    draw_data["text"] = formatted_text
    
    # Update the start time for fading
    draw_data["start_time"] = time.time()
    
    # Get the region dimensions
    region = bpy.context.region
    if region:
        # Calculate vertical position based on preference (percentage from bottom)
        vertical_pos = int(region.height * (draw_data["vertical_position"] / 100.0))
        
        # Calculate horizontal position based on preference (percentage from left)
        # Use blf.dimensions() for accurate text width measurement
        font_id = 0
        blf.size(font_id, draw_data["size"])
        text_width, _ = blf.dimensions(font_id, draw_data["text"])
        horizontal_pos = int(region.width * (draw_data["horizontal_position"] / 100.0)) - int(text_width / 2)
        
        draw_data["position"] = (horizontal_pos, vertical_pos)
    
    # Add the draw handler if not already enabled
    if not draw_data["is_enabled"]:
        draw_data["handler"] = bpy.types.SpaceView3D.draw_handler_add(
            draw_callback_px, (), 'WINDOW', 'POST_PIXEL')
        draw_data["is_enabled"] = True
    
    # Start the timer for continuous redraws if not already running
    if draw_data["timer"] is None:
        draw_data["timer"] = bpy.app.timers.register(timer_update)
    
    # Force initial redraw of all 3D VIEW regions
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        region.tag_redraw()

def unregister():
    # Make sure to remove any active handlers on addon unregister
    _remove_handler()
