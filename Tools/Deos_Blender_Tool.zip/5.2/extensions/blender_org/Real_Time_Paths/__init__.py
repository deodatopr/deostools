
bl_info = {
    "name" : "Motion-path pro",
    "author" : "Hamdi Amer", 
    "description" : "Update motion path in real time from graph editor and viewport",
    "blender" : (5, 0, 0),
    "version" : (2, 0, 1),
    "location" : "Graph Editor",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "Graph" 
}



import bpy
import bpy_extras
import bpy_extras.view3d_utils
import mathutils
import re
import math
import gpu
import blf
from gpu_extras.batch import batch_for_shader
from bpy_extras import view3d_utils  


class MotionPathState:
    def __init__(self):
        self.is_dragging = False
        self.drag_start_mouse = None
        self.drag_start_3d = None
        self.drag_start_item_pos = None
        self.selected_path_point = None
        self.selected_frame = None
        self.selected_handle_side = None
        self.selected_bone = None
        self.handle_points = []
        self.selected_handle_point = None
        self.handle_dragging = False
        self.position_cache = {}
        self.draw_handler = None
        
    def reset(self):
        self.__init__()


_state = MotionPathState()


HANDLE_SIZE = 10
HANDLE_SELECT_RADIUS = 20

def get_fcurves(action):
    try:
        if not action.layers or not action.slots:
            return []
        layer = action.layers[0]
        if not layer.strips:
            return []
        strip = layer.strips[0]
        slot = action.slots[0]
        channelbag = strip.channelbag(slot, ensure=True)
        return channelbag.fcurves
    except:
        return []

def get_billboard_basis(context):
    rv3d = context.space_data.region_3d
    right = rv3d.view_rotation @ mathutils.Vector((1, 0, 0))
    up = rv3d.view_rotation @ mathutils.Vector((0, 1, 0))
    return right, up

def get_pixel_scale(context, pos, pixel_size):
    region = context.region
    rv3d = context.space_data.region_3d
    co2d = view3d_utils.location_3d_to_region_2d(region, rv3d, pos)
    right = rv3d.view_rotation @ mathutils.Vector((1, 0, 0))
    offset_pos = pos + right * 0.001
    co2d_offset = view3d_utils.location_3d_to_region_2d(region, rv3d, offset_pos)
    pixel_dist = (co2d - co2d_offset).length
    world_per_pixel = 0.001 / pixel_dist if pixel_dist > 0 else 0.001
    return pixel_size * world_per_pixel

def draw_billboard_circle(context, pos, radius_in_pixels, color, shader):
    right, up = get_billboard_basis(context)
    scale = get_pixel_scale(context, pos, radius_in_pixels)
    if scale == 0:
        return
    segments = 16
    vertices = [pos]
    for i in range(segments + 1):
        angle = 2 * math.pi * i / segments
        v = pos + scale * (math.cos(angle) * right + math.sin(angle) * up)
        vertices.append(v)
    batch = batch_for_shader(shader, 'TRI_FAN', {"pos": vertices})
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)

def draw_billboard_square(context, pos, half_size_in_pixels, color, shader):
    right, up = get_billboard_basis(context)
    scale = get_pixel_scale(context, pos, half_size_in_pixels)
    if scale == 0:
        return
    vertices = (
        pos + scale * (right - up),
        pos + scale * (right + up),
        pos + scale * (-right + up),
        pos + scale * (-right - up),
    )
    indices = ((0, 1, 2), (0, 2, 3))
    batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)
    shader.bind()
    shader.uniform_float("color", color)
    batch.draw(shader)

def is_location_fcurve(fcurve, bone_name=None):
    """Check if fcurve is a location fcurve for an object or a specific bone."""
    if bone_name:
        return f'pose.bones["{bone_name}"].location' in fcurve.data_path
    return 'location' in fcurve.data_path

def is_keyframe_at_frame(fcurves, frame_num, bone_name=None):
    """Check if there's a keyframe at the given frame for location fcurves."""
    for fcurve in fcurves:
        if is_location_fcurve(fcurve, bone_name):
            for keyframe in fcurve.keyframe_points:
                if abs(keyframe.co[0] - frame_num) < 0.5:
                    return True
    return False

def build_position_cache(context):
    """Build cache of 3D positions for keyframes without using motion paths."""
    global _state
    _state.position_cache = {}
    obj = context.active_object
    if not obj or not obj.animation_data or not obj.animation_data.action:
        return
    
    
    if hasattr(bpy.context.window_manager, 'skip_motion_path_cache'):
        if bpy.context.window_manager.skip_motion_path_cache:
            return
    
    action = obj.animation_data.action
    view_layer = context.view_layer
    current_frame = context.scene.frame_current
    frame_start = context.scene.frame_start
    frame_end = context.scene.frame_end
    
    if obj.mode == 'POSE':
        bones_to_cache = set(context.selected_pose_bones or [])
        if context.active_pose_bone:
            bones_to_cache.add(context.active_pose_bone)
        for bone in bones_to_cache:
            bone_name = bone.name
            fcurves = [fc for fc in get_fcurves(action) if is_location_fcurve(fc, bone_name)]
            frames = set(int(kp.co[0]) for fc in fcurves for kp in fc.keyframe_points
                         if frame_start <= kp.co[0] <= frame_end)
            _state.position_cache[bone_name] = {}
            for frame in frames:
                context.scene.frame_current = frame
                view_layer.update()
                pos = (obj.matrix_world @ bone.head).copy()  
                _state.position_cache[bone_name][frame] = pos
    else:
        fcurves = [fc for fc in get_fcurves(action) if is_location_fcurve(fc)]
        frames = set(int(kp.co[0]) for fc in fcurves for kp in fc.keyframe_points
                     if frame_start <= kp.co[0] <= frame_end)
        _state.position_cache[None] = {}
        for frame in frames:
            context.scene.frame_current = frame
            view_layer.update()
            pos = obj.matrix_world.translation.copy()
            _state.position_cache[None][frame] = pos
    
    context.scene.frame_current = current_frame
    view_layer.update()

def draw_motion_path_overlay(context):
    """Drawing advanced motion path overlays"""
    try:
        wm = context.window_manager
        if not wm.direct_manipulation_active:
            return
        
        global _state
        _state.handle_points = []
        obj = context.active_object
        if not obj:
            return
        
        if obj.mode == 'POSE':
            bones_to_draw = list(context.selected_pose_bones or [])
            active_bone = context.active_pose_bone
            if active_bone and active_bone not in bones_to_draw:
                bones_to_draw.append(active_bone)
            for bone in bones_to_draw:
                draw_enhanced_bone_path(context, obj, bone)
        else:
            draw_enhanced_object_path(context, obj)
    except Exception as e:
        print(f"Error in motion path overlay: {e}")
        

def draw_enhanced_object_path(context, obj):
    """Drawing advanced motion paths for object"""
    global _state
    if None not in _state.position_cache:
        return
    action = obj.animation_data.action if obj.animation_data else None
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    for frame_num, point_3d in _state.position_cache[None].items():
        is_keyframe_point = True
        is_selected_keyframe = False
        keyframes_for_location = {}
        if action:
            for fcurve in get_fcurves(action):
                if is_location_fcurve(fcurve):
                    for keyframe in fcurve.keyframe_points:
                        if abs(keyframe.co[0] - frame_num) < 0.5:
                            keyframes_for_location[fcurve.array_index] = keyframe
                            if keyframe.select_control_point:
                                is_selected_keyframe = True
                            break
        draw_motion_path_point(
            context, point_3d, frame_num,
            is_keyframe_point, is_selected_keyframe,
            keyframes_for_location, action,
            shader
        )
        wm = context.window_manager
        draw_handles = False
        if wm.show_all_handles:
            draw_handles = True
        elif wm.show_only_selected_handles and is_selected_keyframe:
            draw_handles = True
        if draw_handles and is_keyframe_point and action and keyframes_for_location:
            draw_motion_path_handles(context, point_3d, keyframes_for_location, shader, frame_num)

def debug_handle_selection(context):
    """Debug function to print handle information"""
    global _state
    print(f"Total handle points: {len(_state.handle_points)}")
    for i, handle in enumerate(_state.handle_points):
        print(f"Handle {i}: {handle['position']}, side: {handle['side']}, frame: {handle['frame']}")

def draw_enhanced_bone_path(context, obj, bone):
    """Drawing advanced motion paths for armature"""
    global _state
    if bone.name not in _state.position_cache:
        return
    action = obj.animation_data.action if obj.animation_data else None
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    for frame_num, point_3d in _state.position_cache[bone.name].items():
        is_keyframe_point = True
        is_selected_keyframe = False
        keyframes_for_location = {}
        if action:
            for fcurve in get_fcurves(action):
                if is_location_fcurve(fcurve, bone.name):
                    for keyframe in fcurve.keyframe_points:
                        if abs(keyframe.co[0] - frame_num) < 0.5:
                            keyframes_for_location[fcurve.array_index] = keyframe
                            if keyframe.select_control_point:
                                is_selected_keyframe = True
                            break
        draw_motion_path_point(
            context, point_3d, frame_num,
            is_keyframe_point, is_selected_keyframe,
            keyframes_for_location, action,
            shader, bone=bone
        )

def draw_motion_path_point(context, point_3d, frame_num,
                           is_keyframe_point, is_selected_keyframe,
                           keyframes_for_location, action,
                           shader, bone=None):
    """Draw motion path points, with handles if needed"""
    global _state
    wm = context.window_manager
    obj = context.active_object
    
    if _state.is_dragging and frame_num == _state.selected_frame:
        color = (1.0, 0.5, 0.3, 1.0)  
        size = 10
    elif is_selected_keyframe:
        color = (0.8, 0.5, 0.9, 1.0)  
        size = 10
    elif frame_num == context.scene.frame_current:
        color = (0.3, 0.7, 1.0, 1.0)  
        size = 8
    elif is_keyframe_point:
        color = (0.4, 0.9, 0.5, 1.0)  
        size = 10
    else:
        return  
    
    
    if is_selected_keyframe or frame_num == context.scene.frame_current or (_state.is_dragging and frame_num == _state.selected_frame):
        
        for i in range(1, 4):
            glow_size = size + i * 2
            glow_alpha = 0.3 * (4 - i)
            
            glow_color = (
                min(1.0, color[0] + 0.3),
                min(1.0, color[1] + 0.3),
                min(1.0, color[2] + 0.3),
                glow_alpha
            )
            draw_billboard_circle(context, point_3d, glow_size / 2, glow_color, shader)
    
    
    draw_billboard_circle(context, point_3d, size / 2, color, shader)
    
    if wm.show_all_handles or (wm.show_only_selected_handles and is_selected_keyframe):
        if is_keyframe_point and keyframes_for_location:
            draw_motion_path_handles(context, point_3d, keyframes_for_location, shader, frame_num, bone=bone)

def draw_motion_path_handles(context, point_3d, keyframes_for_location, shader, frame_num, bone=None):
    """Draw motion path handles with individual control points"""
    global _state
    wm = context.window_manager
    global_scale = wm.global_handle_visual_scale
    obj = context.active_object
    handle_vector_left = mathutils.Vector((0.0, 0.0, 0.0))
    handle_vector_right = mathutils.Vector((0.0, 0.0, 0.0))
    
    for array_index in range(3):
        if array_index in keyframes_for_location:
            keyframe = keyframes_for_location[array_index]
            if hasattr(keyframe, 'handle_left') and hasattr(keyframe, 'handle_right'):
                diff = keyframe.co[1] - keyframe.handle_left[1]
                if array_index == 0: 
                    handle_vector_left.x = diff
                elif array_index == 1: 
                    handle_vector_left.y = diff
                elif array_index == 2: 
                    handle_vector_left.z = diff
                diff = keyframe.handle_right[1] - keyframe.co[1]
                if array_index == 0: 
                    handle_vector_right.x = diff
                elif array_index == 1: 
                    handle_vector_right.y = diff
                elif array_index == 2: 
                    handle_vector_right.z = diff
    
    
    if context.mode == 'POSE' and bone is not None:
        try:
            bone_matrix = obj.matrix_world @ bone.matrix
            rotation_matrix = bone_matrix.to_3x3()
        except:
            rotation_matrix = mathutils.Matrix.Identity(3)
    else:
        rotation_matrix = mathutils.Matrix.Identity(3)
    
    handle_points = []
    handle_colors = []
    handle_vector_left_world = rotation_matrix @ handle_vector_left
    handle_left_pos = point_3d - handle_vector_left_world * global_scale
    handle_points.extend([point_3d, handle_left_pos])
    _state.handle_points.append({
        'position': handle_left_pos,
        'side': 'left',
        'frame': frame_num,
        'bone': bone
    })
    
    is_selected = (_state.selected_handle_point == len(_state.handle_points) - 1 and 
                  _state.handle_dragging)
    
    line_color = (0.4, 0.6, 0.9, 0.8) if not is_selected else (0.6, 0.8, 1.0, 0.9)
    handle_colors.extend([line_color, line_color])
    
    handle_vector_right_world = rotation_matrix @ handle_vector_right
    handle_right_pos = point_3d + handle_vector_right_world * global_scale
    handle_points.extend([point_3d, handle_right_pos])
    _state.handle_points.append({
        'position': handle_right_pos,
        'side': 'right',
        'frame': frame_num,
        'bone': bone
    })
    
    is_selected = (_state.selected_handle_point == len(_state.handle_points) - 1 and 
                  _state.handle_dragging)
    line_color = (0.4, 0.6, 0.9, 0.8) if not is_selected else (0.6, 0.8, 1.0, 0.9)
    handle_colors.extend([line_color, line_color])
    
    if handle_points:
        gpu.state.line_width_set(2.5)
        shader_lines = gpu.shader.from_builtin('SMOOTH_COLOR')
        batch_lines = batch_for_shader(shader_lines, 'LINES', 
                                      {"pos": handle_points, "color": handle_colors})
        shader_lines.bind()
        batch_lines.draw(shader_lines)
        
        
        for i, point in enumerate(_state.handle_points[-2:]):  
            is_selected = (len(_state.handle_points)-2 + i == _state.selected_handle_point and _state.handle_dragging)
            if is_selected:
                
                color = (0.5, 1.0, 1.0, 1.0)
                
                for j in range(1, 4):
                    glow_size = HANDLE_SIZE + j * 2
                    glow_alpha = 0.3 * (4 - j)
                    glow_color = (
                        min(1.0, color[0] + 0.2),
                        min(1.0, color[1] + 0.2),
                        min(1.0, color[2] + 0.2),
                        glow_alpha
                    )
                    draw_billboard_square(context, point['position'], glow_size / 2, glow_color, shader)
            else:
                
                color = (1.0, 0.8, 0.4, 1.0)
            draw_billboard_square(context, point['position'], HANDLE_SIZE / 2, color, shader)

def enable_draw_handler(context):
    """Enable draw handler"""
    global _state
    if _state.draw_handler is None:
        _state.draw_handler = bpy.types.SpaceView3D.draw_handler_add(
            draw_motion_path_overlay, (context,), 'WINDOW', 'POST_VIEW')

def disable_draw_handler():
    """Disable custom drawing"""
    global _state
    if _state.draw_handler is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_state.draw_handler, 'WINDOW')
        _state.draw_handler = None

class MOTIONPATH_AutoUpdateMotionPaths(bpy.types.Operator):
    """Auto update motion paths when change keyframes"""
    bl_idname = "motion_path.auto_update_motion_paths"
    bl_label = "Auto Update Motion Paths"
    bl_description = "Real time update motion paths"
    bl_options = {'REGISTER', 'UNDO'}
    
    _timer = None
    _last_keyframe_values = None
    _needs_update = False
    
    @classmethod
    def poll(cls, context):
        return True
    
    def invoke(self, context, event):
        wm = context.window_manager
        self._last_keyframe_values = self._get_keyframe_values(context)
        self._needs_update = False
        if wm.update_hamdionz == 'TIMER':
            self._timer = wm.event_timer_add(wm.auto_midawq_timer_interval, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}
    
    def modal(self, context, event):
        wm = context.window_manager
        current_values = self._get_keyframe_values(context)
        
        if wm.update_hamdionz == 'TIMER' and event.type == 'TIMER':
            if current_values != self._last_keyframe_values:
                self._needs_update = True
        elif wm.update_hamdionz == 'EVENT':
            if current_values != self._last_keyframe_values or self._has_selected_keyframes_changed(context):
                self._needs_update = True
        
        if self._needs_update:
            try:
                build_position_cache(context)
            except Exception as e:
                print("Error updating position cache:", e)
            self._last_keyframe_values = current_values
            self._needs_update = False
            if context.area and context.area.type == 'VIEW_3D':
                context.area.tag_redraw()
        
        if not wm.auto_sapty_active:
            self.cancel(context)
            return {'CANCELLED'}
        
        return {'PASS_THROUGH'}
    
    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None
    
    def _get_keyframe_values(self, context):
        active_object = context.active_object
        if not active_object or not active_object.animation_data:
            return None
        action = active_object.animation_data.action
        if not action:
            return None
        values = []
        for fcurve in get_fcurves(action):
            for keyframe in fcurve.keyframe_points:
                values.append((keyframe.co[0], keyframe.co[1],
                                 keyframe.handle_left[0], keyframe.handle_left[1],
                                 keyframe.handle_right[0], keyframe.handle_right[1],
                                 keyframe.select_control_point))
        return tuple(values) if values else None
    
    def _has_selected_keyframes_changed(self, context):
        """Check the status of selected keyframe"""
        current_selection_state = self._get_selected_keyframes_state(context)
        if not hasattr(self, '_last_selection_state'):
            self._last_selection_state = current_selection_state
            return False
        if current_selection_state != self._last_selection_state:
            self._last_selection_state = current_selection_state
            return True
        return False
    
    def _get_selected_keyframes_state(self, context):
        """Select all the keyframes status"""
        active_object = context.active_object
        if not active_object or not active_object.animation_data or not active_object.animation_data.action:
            return None
        action = active_object.animation_data.action
        if not action:
            return None
        selected_keyframes = []
        for fcurve in get_fcurves(action):
            for keyframe in fcurve.keyframe_points:
                if keyframe.select_control_point:
                    selected_keyframes.append((fcurve.data_path, fcurve.array_index, keyframe.co[0]))
        return tuple(sorted(selected_keyframes))

class MOTIONPATH_SetHandleType(bpy.types.Operator):
    """Set handle type for selected keyframes"""
    bl_idname = "motion_path.set_handle_type"
    bl_label = "Set Handle Type"
    bl_options = {'REGISTER', 'UNDO'}
    
    handle_type: bpy.props.StringProperty()
    
    def execute(self, context):
        set_handle_type(context, self.handle_type)
        build_position_cache(context)
        return {'FINISHED'}

class MOTIONPATH_ToggleSnap(bpy.types.Operator):
    """Toggle snapping for handles"""
    bl_idname = "motion_path.toggle_snap"
    bl_label = "Toggle Snap"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        wm = context.window_manager
        wm.handle_snap = not wm.handle_snap
        status = "enabled" if wm.handle_snap else "disabled"
        self.report({'INFO'}, f"Snapping {status}")
        return {'FINISHED'}

class MOTIONPATH_DirectManipulationToggle(bpy.types.Operator):
    """Enable/Disable Motion Path Editing"""
    bl_idname = "motion_path.direct_manipulation_toggle"
    bl_label = "Toggle Direct Manipulation"
    bl_description = "Enable/Disable Motion Path Editing"
    
    def execute(self, context):
        global _state
        wm = context.window_manager
        
        if not wm.direct_manipulation_active:
            wm.direct_manipulation_active = True
            bpy.ops.motion_path.direct_manipulation('INVOKE_DEFAULT')
            wm.auto_sapty_active = True
            bpy.ops.motion_path.auto_update_motion_paths('INVOKE_DEFAULT')
            self.report({'INFO'}, "Enable Direct Path Editing")
        else:
            wm.direct_manipulation_active = False
            wm.auto_sapty_active = False
            if context.area:
                context.area.tag_redraw()
            self.report({'INFO'}, "Disable Direct Path Editing")
        
        return {'FINISHED'}

class MOTIONPATH_DirectManipulation(bpy.types.Operator):
    """Directly manipulate points on motion paths"""
    bl_idname = "motion_path.direct_manipulation"
    bl_label = "Direct Motion Path Manipulation"
    bl_options = {'REGISTER', 'UNDO'}
    
    _timer = None
    _mouse_pos = None
    _is_active = False
    _redraw_count = 0
    _last_frame = None
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._timer = None
        self._mouse_pos = None
        self._is_active = False
        self._redraw_count = 0
        self._last_frame = None
    
    def convert_vector_handles_to_free(self, keyframes_for_location):
        """Convert vector handles to free handles to allow editing"""
        for array_index, keyframe in keyframes_for_location.items():
            if (keyframe.handle_left_type == 'VECTOR' and 
                keyframe.handle_right_type == 'VECTOR'):
                
                original_left = keyframe.handle_left.copy()
                original_right = keyframe.handle_right.copy()
                
                
                keyframe.handle_left_type = 'FREE'
                keyframe.handle_right_type = 'FREE'
                
                
                keyframe.handle_left = original_left
                keyframe.handle_right = original_right
    
    def modal(self, context, event):
        global _state
        
        wm = context.window_manager
        if not wm.direct_manipulation_active or not self._is_active:
            return self.cancel(context)
        
        obj = context.active_object
        if obj and obj.type == 'ARMATURE' and obj.mode == 'OBJECT' and wm.direct_manipulation_active:
            self.report({'INFO'}, "Motion Path Editing disabled in Object Mode for armature")
            wm.direct_manipulation_active = False
            wm.auto_sapty_active = False
            self.cancel(context)
            return {'CANCELLED'}
        
        if event.type == 'MOUSEMOVE':
            self._mouse_pos = (event.mouse_region_x, event.mouse_region_y)
            
            if _state.is_dragging:
                region = context.region
                rv3d = context.space_data.region_3d
                mouse_coord = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
                new_3d_pos = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse_coord, _state.drag_start_3d)
                offset = new_3d_pos - _state.drag_start_3d
                
                if _state.selected_handle_side is None:
                    self.move_selected_points(context, offset)
                else:
                    new_handle_pos = _state.drag_start_item_pos + offset
                    self.move_selected_handles(context, new_handle_pos, _state.selected_handle_side)
                
                _state.drag_start_3d = new_3d_pos
                self._redraw_count += 1
                
                if self._redraw_count % 3 == 0 and context.area and context.area.type == 'VIEW_3D':
                    context.area.tag_redraw()
                    
            elif _state.handle_dragging and _state.selected_handle_point is not None:
                region = context.region
                rv3d = context.space_data.region_3d
                mouse_coord = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
                handle_point_data = _state.handle_points[_state.selected_handle_point]
                keyframe_3d_pos = self.get_keyframe_position_for_handle(context, handle_point_data)
                new_3d_pos = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse_coord, keyframe_3d_pos)
                
                handle_point = _state.handle_points[_state.selected_handle_point]
                self.move_handle_point(context, new_3d_pos, handle_point)
                
                self._redraw_count += 1
                if self._redraw_count % 3 == 0 and context.area and context.area.type == 'VIEW_3D':
                    context.area.tag_redraw()
                    
            return {'PASS_THROUGH'}
        
        elif event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                if not event.shift:
                    _state.selected_handle_point = None
                    _state.selected_path_point = None
                    _state.selected_frame = None
                
                handle_index, handle_point = get_handle_point_at_mouse(context, event)
                if handle_index is not None:
                    _state.selected_handle_point = handle_index
                    _state.handle_dragging = True
                    _state.drag_start_3d = handle_point['position']
                    _state.drag_start_item_pos = handle_point['position']
                    _state.drag_start_mouse = (event.mouse_region_x, event.mouse_region_y)
                    
                    obj = context.active_object
                    if obj and obj.animation_data and obj.animation_data.action:
                        action = obj.animation_data.action
                        bone_name = handle_point['bone'].name if handle_point['bone'] else None
                        frame = handle_point['frame']
                        
                        if not event.shift:
                            for fc in get_fcurves(action):
                                for kp in fc.keyframe_points:
                                    kp.select_control_point = False
                        
                        for fc in get_fcurves(action):
                            if is_location_fcurve(fc, bone_name):
                                for kp in fc.keyframe_points:
                                    if abs(kp.co[0] - frame) < 0.5:
                                        kp.select_control_point = True
                                        break
                    
                    if context.area and context.area.type == 'VIEW_3D':
                        context.area.tag_redraw()
                    return {'RUNNING_MODAL'}
                
                hit_point, hit_frame, hit_bone = self.get_motion_path_point_at_mouse(context, event)
                if hit_frame is not None:
                    _state.selected_path_point = hit_point
                    _state.selected_frame = hit_frame
                    _state.selected_handle_side = None  
                    _state.drag_start_3d = hit_point
                    _state.drag_start_item_pos = hit_point
                    _state.drag_start_mouse = (event.mouse_region_x, event.mouse_region_y)
                    
                    if context.mode == 'POSE':
                        _state.selected_bone = hit_bone
                    
                    obj = context.active_object
                    if obj and obj.animation_data and obj.animation_data.action:
                        action = obj.animation_data.action
                        bone_name = _state.selected_bone.name if context.mode == 'POSE' and _state.selected_bone else None
                        
                        if not event.shift and not event.ctrl:
                            for fc in get_fcurves(action):
                                for kp in fc.keyframe_points:
                                    kp.select_control_point = False
                        
                        if event.ctrl:
                            selected_frames = []
                            for fc in get_fcurves(action):
                                if is_location_fcurve(fc, bone_name):
                                    for kp in fc.keyframe_points:
                                        if kp.select_control_point:
                                            selected_frames.append(kp.co[0])
                            selected_frames.append(hit_frame)
                            if len(selected_frames) >= 2:
                                min_f = min(selected_frames)
                                max_f = max(selected_frames)
                                for fc in get_fcurves(action):
                                    if is_location_fcurve(fc, bone_name):
                                        for kp in fc.keyframe_points:
                                            if min_f <= kp.co[0] <= max_f:
                                                kp.select_control_point = True
                        else:
                            for fc in get_fcurves(action):
                                if is_location_fcurve(fc, bone_name):
                                    for kp in fc.keyframe_points:
                                        if abs(kp.co[0] - hit_frame) < 0.5:
                                            kp.select_control_point = True
                                            break
                    
                    _state.is_dragging = True
                    if context.area and context.area.type == 'VIEW_3D':
                        context.area.tag_redraw()
                    return {'RUNNING_MODAL'}
                
                hit_side, hit_handle_pos, hit_frame, point_3d, hit_bone = self.get_motion_path_handle_at_mouse(context, event)
                if hit_frame is not None:
                    _state.selected_path_point = point_3d
                    _state.selected_frame = hit_frame
                    _state.selected_handle_side = hit_side
                    _state.drag_start_3d = point_3d  
                    _state.drag_start_item_pos = hit_handle_pos
                    _state.drag_start_mouse = (event.mouse_region_x, event.mouse_region_y)
                    
                    if context.mode == 'POSE':
                        _state.selected_bone = hit_bone
                    
                    obj = context.active_object
                    if obj and obj.animation_data and obj.animation_data.action:
                        action = obj.animation_data.action
                        bone_name = _state.selected_bone.name if context.mode == 'POSE' and _state.selected_bone else None
                        
                        for fc in get_fcurves(action):
                            if is_location_fcurve(fc, bone_name):
                                for kp in fc.keyframe_points:
                                    if abs(kp.co[0] - hit_frame) < 0.5:
                                        kp.select_control_point = True
                                        break
                    
                    _state.is_dragging = True
                    if context.area and context.area.type == 'VIEW_3D':
                        context.area.tag_redraw()
                    return {'RUNNING_MODAL'}
                    
            elif event.value == 'RELEASE':
                if _state.is_dragging:
                    _state.is_dragging = False
                    _state.selected_path_point = None
                    _state.selected_frame = None
                    _state.selected_handle_side = None
                    _state.drag_start_item_pos = None
                    
                    try:
                        build_position_cache(context)
                    except:
                        pass
                    
                    if context.area and context.area.type == 'VIEW_3D':
                        context.area.tag_redraw()
                    return {'RUNNING_MODAL'}
                elif _state.handle_dragging:
                    _state.handle_dragging = False
                    _state.selected_handle_point = None
                    _state.drag_start_item_pos = None
                    
                    try:
                        build_position_cache(context)
                    except:
                        pass
                    
                    if context.area and context.area.type == 'VIEW_3D':
                        context.area.tag_redraw()
                    return {'RUNNING_MODAL'}
        
        elif event.type == 'ESC':
            return {'PASS_THROUGH'}
        
        elif event.type == 'TIMER':
            if context.area and context.area.type == 'VIEW_3D':
                context.area.tag_redraw()
            return {'PASS_THROUGH'}
        
        elif event.type == 'D' and event.ctrl and event.value == 'PRESS':
            debug_handle_selection(context)
            return {'RUNNING_MODAL'}
        
        return {'PASS_THROUGH'}
    
    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            build_position_cache(context)
            self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
            context.window_manager.modal_handler_add(self)
            self._is_active = True
            enable_draw_handler(context)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}
    
    def cancel(self, context):
        global _state
        
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        
        _state.reset()
        self._is_active = False
        disable_draw_handler()
        
        if context.area:
            context.area.tag_redraw()
        
        return {'CANCELLED'}
    
    def move_selected_points(self, context, offset):
        obj = context.active_object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        
        bpy.ops.ed.undo_push(message="Move Motion Path Points")
        
        action = obj.animation_data.action
        bone = _state.selected_bone
        bone_name = bone.name if bone else None
        
        if obj.mode == 'POSE' and bone:
            armature_matrix = obj.matrix_world
            bone_matrix = bone.matrix
            bone_local_offset = bone_matrix.inverted().to_3x3() @ armature_matrix.inverted().to_3x3() @ offset
        else:
            bone_local_offset = obj.matrix_world.inverted().to_3x3() @ offset
        
        selected_frames = set()
        for fcurve in get_fcurves(action):
            if 'location' not in fcurve.data_path:
                continue
            if bone_name and not is_location_fcurve(fcurve, bone_name):
                continue
            for kp in fcurve.keyframe_points:
                if kp.select_control_point:
                    selected_frames.add(int(kp.co[0]))
        
        for frame in selected_frames:
            for fcurve in get_fcurves(action):
                if 'location' not in fcurve.data_path:
                    continue
                if bone_name and not is_location_fcurve(fcurve, bone_name):
                    continue
                
                axis = fcurve.array_index
                for kp in fcurve.keyframe_points:
                    if abs(kp.co[0] - frame) < 0.5:
                        kp.co[1] += bone_local_offset[axis]
                        kp.handle_left[1] += bone_local_offset[axis]
                        kp.handle_right[1] += bone_local_offset[axis]
                        break
        
        for fcurve in get_fcurves(action):
            if 'location' in fcurve.data_path and (not bone_name or is_location_fcurve(fcurve, bone_name)):
                fcurve.update()
    
    def move_selected_handles(self, context, new_handle_pos, side):
        obj = context.active_object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        
        bpy.ops.ed.undo_push(message="Move Motion Path Handles")
        
        action = obj.animation_data.action
        point_3d = _state.selected_path_point
        frame = _state.selected_frame
        global_scale = context.window_manager.global_handle_visual_scale
        bone = _state.selected_bone
        bone_name = bone.name if bone else None
        wm = context.window_manager
        
        if wm.handle_snap:
            snap_increment = wm.handle_snap_increment
            new_handle_pos.x = round(new_handle_pos.x / snap_increment) * snap_increment
            new_handle_pos.y = round(new_handle_pos.y / snap_increment) * snap_increment
            new_handle_pos.z = round(new_handle_pos.z / snap_increment) * snap_increment
        
        if side == 'left':
            handle_vector_world = point_3d - new_handle_pos
        else:
            handle_vector_world = new_handle_pos - point_3d
        
        if obj.mode == 'POSE' and bone:
            bone_matrix = obj.matrix_world @ bone.matrix
            rotation_matrix = bone_matrix.to_3x3()
            handle_vector_local = rotation_matrix.inverted() @ handle_vector_world
        else:
            handle_vector_local = obj.matrix_world.inverted().to_3x3() @ handle_vector_world
        
        handle_vector_local /= global_scale
        
        keyframes_for_location = {}
        for fcurve in get_fcurves(action):
            if not is_location_fcurve(fcurve, bone_name):
                continue
            for keyframe in fcurve.keyframe_points:
                if abs(keyframe.co[0] - frame) < 0.5:
                    keyframes_for_location[fcurve.array_index] = keyframe
                    break
        
        
        self.convert_vector_handles_to_free(keyframes_for_location)
        
        for array_index, keyframe in keyframes_for_location.items():
            original_left_type = keyframe.handle_left_type
            original_right_type = keyframe.handle_right_type
            
            if side == 'left':
                keyframe.handle_left[1] = keyframe.co[1] - handle_vector_local[array_index]
            else:
                keyframe.handle_right[1] = keyframe.co[1] + handle_vector_local[array_index]
            
            self.update_opposite_handle(keyframe, side, handle_vector_local, array_index)
            keyframe.handle_left_type = original_left_type
            keyframe.handle_right_type = original_right_type
        
        for fcurve in get_fcurves(action):
            if is_location_fcurve(fcurve, bone_name):
                fcurve.update()
    
    def update_opposite_handle(self, keyframe, moved_handle_side, handle_vector_local, array_index):
        """Update the opposite handle based on the moved handle and handle type"""
        if keyframe.handle_left_type == 'FREE' and keyframe.handle_right_type == 'FREE':
            return
        
        if keyframe.handle_left_type == 'VECTOR' or keyframe.handle_right_type == 'VECTOR':
            if moved_handle_side == 'left':
                keyframe.handle_right[1] = keyframe.co[1]
            else:
                keyframe.handle_left[1] = keyframe.co[1]
            return
        
        if (keyframe.handle_left_type in {'ALIGNED', 'AUTO', 'AUTO_CLAMPED'} or 
            keyframe.handle_right_type in {'ALIGNED', 'AUTO', 'AUTO_CLAMPED'}):
            if moved_handle_side == 'left':
                left_direction = keyframe.co[1] - keyframe.handle_left[1]
                keyframe.handle_right[1] = keyframe.co[1] + left_direction
            else:
                right_direction = keyframe.handle_right[1] - keyframe.co[1]
                keyframe.handle_left[1] = keyframe.co[1] - right_direction
            return
    
    def move_handle_point(self, context, new_pos, handle_point):
        """Move a handle control point while preserving handle types"""
        obj = context.active_object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return
        
        
        bpy.ops.ed.undo_push(message="Move Handle Point")
        
        action = obj.animation_data.action
        frame = handle_point['frame']
        side = handle_point['side']
        bone = handle_point['bone']
        bone_name = bone.name if bone else None
        point_3d = self.get_keyframe_position_for_handle(context, handle_point)
        global_scale = context.window_manager.global_handle_visual_scale
        wm = context.window_manager
        
        if wm.handle_snap:
            snap_increment = wm.handle_snap_increment
            new_pos.x = round(new_pos.x / snap_increment) * snap_increment
            new_pos.y = round(new_pos.y / snap_increment) * snap_increment
            new_pos.z = round(new_pos.z / snap_increment) * snap_increment
        
        if side == 'left':
            handle_vector_world = point_3d - new_pos
        else:
            handle_vector_world = new_pos - point_3d
        
        if obj.mode == 'POSE' and bone:
            bone_matrix = obj.matrix_world @ bone.matrix
            rotation_matrix = bone_matrix.to_3x3()
            handle_vector_local = rotation_matrix.inverted() @ handle_vector_world
        else:
            handle_vector_local = obj.matrix_world.inverted().to_3x3() @ handle_vector_world
        
        handle_vector_local /= global_scale
        
        keyframes_for_location = {}
        for fcurve in get_fcurves(action):
            if not is_location_fcurve(fcurve, bone_name):
                continue
            for keyframe in fcurve.keyframe_points:
                if abs(keyframe.co[0] - frame) < 0.5:
                    keyframes_for_location[fcurve.array_index] = keyframe
                    break
        
        
        self.convert_vector_handles_to_free(keyframes_for_location)
        
        for array_index, keyframe in keyframes_for_location.items():
            original_left_type = keyframe.handle_left_type
            original_right_type = keyframe.handle_right_type
            
            if original_left_type in {'AUTO', 'AUTO_CLAMPED'} or original_right_type in {'AUTO', 'AUTO_CLAMPED'}:
                keyframe.handle_left_type = 'ALIGNED'
                keyframe.handle_right_type = 'ALIGNED'
            
            if side == 'left':
                if hasattr(keyframe, 'handle_left'):
                    keyframe.handle_left[1] = keyframe.co[1] - handle_vector_local[array_index]
            else:
                if hasattr(keyframe, 'handle_right'):
                    keyframe.handle_right[1] = keyframe.co[1] + handle_vector_local[array_index]
            
            self.update_opposite_handle(keyframe, side, handle_vector_local, array_index)
            
            if original_left_type in {'VECTOR', 'FREE'}:
                keyframe.handle_left_type = original_left_type
            if original_right_type in {'VECTOR', 'FREE'}:
                keyframe.handle_right_type = original_right_type
        
        for fcurve in get_fcurves(action):
            if is_location_fcurve(fcurve, bone_name):
                fcurve.update()
    
    def get_keyframe_position_for_handle(self, context, handle_point):
        """Helper function to get the 3D position of the keyframe associated with a handle point."""
        global _state
        obj = context.active_object
        frame = handle_point['frame']
        bone = handle_point['bone']
        bone_name = bone.name if bone else None
        
        if bone_name in _state.position_cache:
            return _state.position_cache[bone_name].get(frame, mathutils.Vector((0, 0, 0)))
        elif None in _state.position_cache:
            return _state.position_cache[None].get(frame, mathutils.Vector((0, 0, 0)))
        
        return mathutils.Vector((0, 0, 0))
    
    def get_motion_path_handle_at_mouse(self, context, event):
        """Check if the mouse is over a handle end on the motion path"""
        mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
        obj = context.active_object
        
        if not obj or not obj.animation_data or not obj.animation_data.action:
            return None, None, None, None, None
        
        action = obj.animation_data.action
        region = context.region
        rv3d = context.space_data.region_3d
        
        if obj.mode == 'POSE':
            
            for selected_bone in context.selected_pose_bones:
                bone_name = selected_bone.name
                if bone_name not in _state.position_cache:
                    continue
                
                global_scale = context.window_manager.global_handle_visual_scale
                
                for frame_num, point_3d in _state.position_cache[bone_name].items():
                    if not is_keyframe_at_frame(get_fcurves(action), frame_num, bone_name):
                        continue
                    
                    keyframes_for_location = {}
                    for fcurve in get_fcurves(action):
                        if is_location_fcurve(fcurve, bone_name):
                            for keyframe in fcurve.keyframe_points:
                                if abs(keyframe.co[0] - frame_num) < 0.5:
                                    keyframes_for_location[fcurve.array_index] = keyframe
                                    break
                    
                    if not keyframes_for_location:
                        continue
                    
                    handle_vector_left = mathutils.Vector((0.0, 0.0, 0.0))
                    handle_vector_right = mathutils.Vector((0.0, 0.0, 0.0))
                    
                    for array_index, keyframe in keyframes_for_location.items():
                        diff = keyframe.co[1] - keyframe.handle_left[1]
                        handle_vector_left[array_index] = diff
                        diff = keyframe.handle_right[1] - keyframe.co[1]
                        handle_vector_right[array_index] = diff
                    
                    parent_world_matrix = mathutils.Matrix.Identity(4)
                    parent = selected_bone.parent
                    if parent:
                        parent_world_matrix = obj.matrix_world @ parent.matrix
                    else:
                        parent_world_matrix = obj.matrix_world
                    
                    rotation_matrix = parent_world_matrix.to_3x3()
                    
                    if handle_vector_left.length > 0.0001:
                        handle_vector_left_world = rotation_matrix @ handle_vector_left
                        handle_left_pos = point_3d - handle_vector_left_world * global_scale
                        screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_left_pos)
                        if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                            return 'left', handle_left_pos, frame_num, point_3d, selected_bone
                    
                    if handle_vector_right.length > 0.0001:
                        handle_vector_right_world = rotation_matrix @ handle_vector_right
                        handle_right_pos = point_3d + handle_vector_right_world * global_scale
                        screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_right_pos)
                        if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                            return 'right', handle_right_pos, frame_num, point_3d, selected_bone
            
            
            active_bone = context.active_pose_bone
            if active_bone and active_bone not in context.selected_pose_bones:
                bone_name = active_bone.name
                if bone_name not in _state.position_cache:
                    return None, None, None, None, None
                
                global_scale = context.window_manager.global_handle_visual_scale
                
                for frame_num, point_3d in _state.position_cache[bone_name].items():
                    if not is_keyframe_at_frame(get_fcurves(action), frame_num, bone_name):
                        continue
                    
                    keyframes_for_location = {}
                    for fcurve in get_fcurves(action):
                        if is_location_fcurve(fcurve, bone_name):
                            for keyframe in fcurve.keyframe_points:
                                if abs(keyframe.co[0] - frame_num) < 0.5:
                                    keyframes_for_location[fcurve.array_index] = keyframe
                                    break
                    
                    if not keyframes_for_location:
                        continue
                    
                    handle_vector_left = mathutils.Vector((0.0, 0.0, 0.0))
                    handle_vector_right = mathutils.Vector((0.0, 0.0, 0.0))
                    
                    for array_index, keyframe in keyframes_for_location.items():
                        diff = keyframe.co[1] - keyframe.handle_left[1]
                        handle_vector_left[array_index] = diff
                        diff = keyframe.handle_right[1] - keyframe.co[1]
                        handle_vector_right[array_index] = diff
                    
                    parent_world_matrix = mathutils.Matrix.Identity(4)
                    parent = active_bone.parent
                    if parent:
                        parent_world_matrix = obj.matrix_world @ parent.matrix
                    else:
                        parent_world_matrix = obj.matrix_world
                    
                    rotation_matrix = parent_world_matrix.to_3x3()
                    
                    if handle_vector_left.length > 0.0001:
                        handle_vector_left_world = rotation_matrix @ handle_vector_left
                        handle_left_pos = point_3d - handle_vector_left_world * global_scale
                        screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_left_pos)
                        if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                            return 'left', handle_left_pos, frame_num, point_3d, active_bone
                    
                    if handle_vector_right.length > 0.0001:
                        handle_vector_right_world = rotation_matrix @ handle_vector_right
                        handle_right_pos = point_3d + handle_vector_right_world * global_scale
                        screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_right_pos)
                        if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                            return 'right', handle_right_pos, frame_num, point_3d, active_bone
            
            return None, None, None, None, None
        else:
            
            if None not in _state.position_cache:
                return None, None, None, None, None
            
            global_scale = context.window_manager.global_handle_visual_scale
            
            for frame_num, point_3d in _state.position_cache[None].items():
                if not is_keyframe_at_frame(get_fcurves(action), frame_num):
                    continue
                
                keyframes_for_location = {}
                for fcurve in get_fcurves(action):
                    if is_location_fcurve(fcurve):
                        for keyframe in fcurve.keyframe_points:
                            if abs(keyframe.co[0] - frame_num) < 0.5:
                                keyframes_for_location[fcurve.array_index] = keyframe
                                break
                
                if not keyframes_for_location:
                    continue
                
                handle_vector_left = mathutils.Vector((0.0, 0.0, 0.0))
                handle_vector_right = mathutils.Vector((0.0, 0.0, 0.0))
                
                for array_index, keyframe in keyframes_for_location.items():
                    diff = keyframe.co[1] - keyframe.handle_left[1]
                    handle_vector_left[array_index] = diff
                    diff = keyframe.handle_right[1] - keyframe.co[1]
                    handle_vector_right[array_index] = diff
                
                rotation_matrix = mathutils.Matrix.Identity(3)
                
                if handle_vector_left.length > 0.0001:
                    handle_vector_left_world = rotation_matrix @ handle_vector_left
                    handle_left_pos = point_3d - handle_vector_left_world * global_scale
                    screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_left_pos)
                    if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                        return 'left', handle_left_pos, frame_num, point_3d, None
                
                if handle_vector_right.length > 0.0001:
                    handle_vector_right_world = rotation_matrix @ handle_vector_right
                    handle_right_pos = point_3d + handle_vector_right_world * global_scale
                    screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_right_pos)
                    if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                        return 'right', handle_right_pos, frame_num, point_3d, None
        
        return None, None, None, None, None
    
    def get_motion_path_point_at_mouse(self, context, event):
        """Check if the mouse is over a motion path point"""
        mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
        obj = context.active_object
        
        if not obj:
            return None, None, None
        
        region = context.region
        rv3d = context.space_data.region_3d
        
        if obj.mode == 'POSE':
            for bone in context.selected_pose_bones:
                if bone.name not in _state.position_cache:
                    continue
                
                for frame_num, world_pos in _state.position_cache[bone.name].items():
                    screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                    if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                        return world_pos, frame_num, bone
            
            active_bone = context.active_pose_bone
            if active_bone:
                if active_bone.name not in _state.position_cache:
                    return None, None, None
                
                for frame_num, world_pos in _state.position_cache[active_bone.name].items():
                    screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                    if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                        return world_pos, frame_num, active_bone
            
            return None, None, None
        else:
            if None not in _state.position_cache:
                return None, None, None
            
            for frame_num, world_pos in _state.position_cache[None].items():
                screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, world_pos)
                if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
                    return world_pos, frame_num, None
        
        return None, None, None

def get_handle_point_at_mouse(context, event):
    """Check if the mouse is over a handle control point"""
    global _state
    mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
    region = context.region
    rv3d = context.space_data.region_3d
    for i, handle_point in enumerate(_state.handle_points):
        screen_pos = view3d_utils.location_3d_to_region_2d(region, rv3d, handle_point['position'])
        if screen_pos and (mouse_pos - screen_pos).length < HANDLE_SELECT_RADIUS:
            return i, handle_point
    return None, None

def set_handle_type(context, handle_type):
    """Set handle type for selected keyframes and apply interactions"""
    obj = context.active_object
    if not obj or not obj.animation_data or not obj.animation_data.action:
        return
    action = obj.animation_data.action
    bone_name = None
    if obj.mode == 'POSE':
        bone = context.active_pose_bone
        if bone:
            bone_name = bone.name
    for fcurve in get_fcurves(action):
        if not is_location_fcurve(fcurve, bone_name):
            continue
        for keyframe in fcurve.keyframe_points:
            if keyframe.select_control_point:
                keyframe.handle_left_type = handle_type
                keyframe.handle_right_type = handle_type
                if handle_type == 'ALIGNED' or handle_type in {'AUTO', 'AUTO_CLAMPED'}:
                    left_direction = keyframe.co[1] - keyframe.handle_left[1]
                    keyframe.handle_right[1] = keyframe.co[1] + left_direction
                elif handle_type == 'VECTOR':
                    keyframe.handle_left[1] = keyframe.co[1]
                    keyframe.handle_right[1] = keyframe.co[1]
        fcurve.update()






class AutoMOTIONPATHSPanel(bpy.types.Panel):
    bl_label = 'Motion Paths'
    bl_idname = 'FRO_PT_MOTION_PATHS_8176B'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Motion Path Pro'
    bl_order = 1

 

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        
        
        box = layout.box()
        row = box.row()
        row.label(text="Operations", icon='ANIM_DATA')
        
        flow = box.grid_flow(align=True)
        flow.operator('object.paths_calculate', text="Object", icon='OBJECT_DATA')
        flow.operator('pose.paths_calculate', text="Bone", icon='BONE_DATA')
        
        row = box.row(align=True)
        row.operator('kro.delet_path_6e947', text="", icon='X')
        row.operator('object.paths_update_visible', text="Update", icon='FILE_REFRESH')
        row.operator('kro.delet_allpath_b6bbf', text="", icon='TRASH')

        
        box = layout.box()
        row = box.row()
        row.label(text="Auto Update", icon='TIME')
        
        
        col = box.column()
        col.use_property_split = True
        col.use_property_decorate = False
        col.prop(wm, "update_mode", text="Mode")
        
        if wm.update_mode == 'TIMER':
            col.prop(wm, "auto_update_timer_interval", text="Interval")
        
        
        row = box.row(align=True)
        row.label(text="Update From Graph Editor")
        icon = 'PAUSE' if wm.auto_update_active else 'PLAY'
        text = "Stop" if wm.auto_update_active else "Start"
        row.operator("amth.auto_update_activate" if not wm.auto_update_active else "amth.auto_update_deactivate", 
                     text=text, icon=icon)
        
        row = box.row(align=True)
        row.label(text="Update From Viewport")
        icon = 'PAUSE' if wm.generic_auto_update_active else 'PLAY'
        text = "Stop" if wm.generic_auto_update_active else "Start"
        row.operator("new_amth.generic_auto_update_activate" if not wm.generic_auto_update_active else "new_amth.generic_auto_update_deactivate", 
                     text=text, icon=icon)
        
        row = box.row(align=True)
        row.label(text="Smart Offset")
        icon = 'PAUSE' if wm.generic_offest_active else 'PLAY'
        text = "Stop" if wm.generic_offest_active else "Start"
        row.operator("new_amth.generic_offest_activate" if not wm.generic_offest_active else "new_amth.generic_offest_deactivate", 
                     text=text, icon=icon)

        


class FRO_OT_Delet_Path_6E947(bpy.types.Operator):
    bl_idname = "kro.delet_path_6e947"
    bl_label = "delet_path"
    bl_description = "delete all path from selected bone or object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            
            bpy.ops.pose.paths_clear(only_selected=True)
        
        if bpy.context.active_object:
            
            bpy.ops.object.paths_clear(only_selected=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class FRO_OT_Delet_Allpath_B6Bbf(bpy.types.Operator):
    bl_idname = "kro.delet_allpath_b6bbf"
    bl_label = "Delet_All-path"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            
            bpy.ops.pose.paths_clear(only_selected=False)
        
        if bpy.context.active_object:
            
            bpy.ops.object.paths_clear(only_selected=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)

class AMTH_OT_AutoUpdateMotionPaths(bpy.types.Operator):
    """Auto-update motion paths after keyframe or handle movement"""
    bl_idname = "amth.auto_update_motion_paths"
    bl_label = "Auto Update Motion Paths (Improved)"
    bl_description = "Update motion path in real time in graph editor"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _last_active_keyframe_values = None  
    _needs_update = False  

    @classmethod
    def poll(cls, context):
        return context.area.type == 'GRAPH_EDITOR'

    def invoke(self, context, event):
        wm = context.window_manager
        self._last_active_keyframe_values = self._get_active_keyframe_values(context)
        self._needs_update = False  

        if wm.update_mode == 'TIMER':
            self._timer = wm.event_timer_add(wm.auto_update_timer_interval, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        wm = context.window_manager

        active_keyframe_values = self._get_active_keyframe_values(context)
        if wm.update_mode == 'TIMER' and event.type == 'TIMER':
            if active_keyframe_values != self._last_active_keyframe_values:
                self._needs_update = True
        elif wm.update_mode == 'EVENT':
            if active_keyframe_values != self._last_active_keyframe_values:
                self._needs_update = True

        if self._needs_update:
            try:
                bpy.ops.object.paths_update_visible() 
            except Exception as e:
                print("Error updating motion paths:", e)
            self._last_active_keyframe_values = active_keyframe_values
            self._needs_update = False  

        if not wm.auto_update_active:
            self.cancel(context)
            return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def cancel(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None

    def _get_active_keyframes(self, context):
        active_object = context.active_object
        active_action = active_object.animation_data.action if active_object and active_object.animation_data else None
        if not active_action:
            return []

        active_keyframes = []
        for fcurve in get_fcurves(active_action):
            for keyframe in fcurve.keyframe_points:
                if keyframe.select_control_point or keyframe.handle_left_type != 'AUTO' or keyframe.handle_right_type != 'AUTO':
                    active_keyframes.append(keyframe)
        return active_keyframes

    def _get_active_keyframe_values(self, context):
        active_keyframes = self._get_active_keyframes(context)
        if active_keyframes:
            return [(keyframe.co[0], keyframe.co[1], keyframe.handle_left[0], keyframe.handle_left[1], keyframe.handle_right[0], keyframe.handle_right[1]) for keyframe in active_keyframes]
        return None


class AMTH_OT_AutoUpdateActivate(bpy.types.Operator):
    bl_idname = "amth.auto_update_activate"
    bl_label = "Activate Auto Update"
    bl_description = "Activate Update motion path operator in real time in Grapg editor"

    bl_icon = 'PLAY'

    def execute(self, context):
        context.window_manager.auto_update_active = True
        bpy.ops.amth.auto_update_motion_paths('INVOKE_DEFAULT')
        return {'FINISHED'}


class AMTH_OT_AutoUpdateDeactivate(bpy.types.Operator):
    bl_idname = "amth.auto_update_deactivate"
    bl_label = "Deactivate Auto Update"
    bl_description = "Deactivate Update motion path operator in real time in Grapg editor"
    bl_icon = 'PAUSE'
    
    def execute(self, context):
        context.window_manager.auto_update_active = False
        return {'FINISHED'}




class FRO_OT_Delet_Path001_C28Ef(bpy.types.Operator):
    bl_idname = "kro.delet_path001_c28ef"
    bl_label = "delet_path.001"
    bl_description = "delete all path from selected bone or object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            bpy.ops.pose.paths_clear(only_selected=True)
        if bpy.context.active_object:
            bpy.ops.object.paths_clear(only_selected=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class FRO_OT_Delet_Allpath001_C61F5(bpy.types.Operator):
    bl_idname = "kro.delet_allpath001_c61f5"
    bl_label = "Delet_All-path.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return not False

    def execute(self, context):
        if bpy.context.active_object and bpy.context.active_object.mode == 'POSE':
            bpy.ops.pose.paths_clear(only_selected=False)
        if bpy.context.active_object:
            bpy.ops.object.paths_clear(only_selected=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)




class GenericAutoUpdateKeyframesOperator(bpy.types.Operator):
    """Operator to auto-update keyframes in various windows based on Viewport changes"""
    bl_idname = "anim.generic_auto_update_keyframes"
    bl_label = "Generic Auto Update Keyframes"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    last_location = None
    last_rotation = None
    last_rotation_quaternion = None
    last_scale = None


    def modal(self, context, event):
        if context.window_manager.generic_auto_update_active:
            if event.type == 'TIMER':
                if not context.screen.is_animation_playing:
                    obj = context.active_object
                    
                    if obj:
                        if obj.mode == 'POSE':
                            bone = context.active_pose_bone
                            if bone:
                                self.update_bone_keyframes(context, bone)
                        else:
                            self.update_object_keyframes(context, obj)
                return {'RUNNING_MODAL'}  
            return {'PASS_THROUGH'}  
        else:
            self.cancel(context)
            return {'CANCELLED'}


    def update_bone_keyframes(self, context, bone):
        """Update keyframes for a bone if it has changed"""
        current_location = bone.location.copy()
        current_rotation = bone.rotation_euler.copy()
        current_rotation_quaternion = bone.rotation_quaternion.copy()
        current_scale = bone.scale.copy()

        if self.last_location is None or current_location != self.last_location:
            self.update_keyframes(context, bone, 'location', current_location)
            self.last_location = current_location

        if self.last_rotation is None or current_rotation != self.last_rotation:
            self.update_keyframes(context, bone, 'rotation_euler', current_rotation)
            self.last_rotation = current_rotation

        if self.last_rotation_quaternion is None or current_rotation_quaternion != self.last_rotation_quaternion:
            self.update_keyframes(context, bone, 'rotation_quaternion', current_rotation_quaternion)
            self.last_rotation_quaternion = current_rotation_quaternion

        if self.last_scale is None or current_scale != self.last_scale:
            self.update_keyframes(context, bone, 'scale', current_scale)
            self.last_scale = current_scale

    def update_object_keyframes(self, context, obj):
        """Update keyframes for an object if it has changed"""
        current_location = obj.location.copy()
        current_rotation = obj.rotation_euler.copy()
        current_rotation_quaternion = obj.rotation_quaternion.copy()
        current_scale = obj.scale.copy()

        if self.last_location is None or current_location != self.last_location:
            self.update_keyframes(context, obj, 'location', current_location)
            self.last_location = current_location

        if self.last_rotation is None or current_rotation != self.last_rotation:
            self.update_keyframes(context, obj, 'rotation_euler', current_rotation)
            self.last_rotation = current_rotation

        if self.last_rotation_quaternion is None or current_rotation_quaternion != self.last_rotation_quaternion:
            self.update_keyframes(context, obj, 'rotation_quaternion', current_rotation_quaternion)
            self.last_rotation_quaternion = current_rotation_quaternion

        if self.last_scale is None or current_scale != self.last_scale:
            self.update_keyframes(context, obj, 'scale', current_scale)
            self.last_scale = current_scale

    def update_keyframes(self, context, obj_or_bone, transform_type, current_transform):
        """Update existing keyframes if present"""
        current_frame = context.scene.frame_current
        action = obj_or_bone.id_data.animation_data.action

        if action:
            for fcurve in get_fcurves(action):
                if transform_type in fcurve.data_path:
                    if isinstance(obj_or_bone, bpy.types.PoseBone) and obj_or_bone.name not in fcurve.data_path:
                        continue

                    for keyframe in fcurve.keyframe_points:
                        if keyframe.co.x == current_frame:
                            keyframe.co.y = current_transform[fcurve.array_index]
                            fcurve.update()
                            break  

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(
            wm.auto_update_timer_interval,  
            window=context.window
        )
        wm.modal_handler_add(self)
        wm.generic_auto_update_active = True
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
        context.window_manager.generic_auto_update_active = False
        return {'CANCELLED'}




class GenericAutoUpdateKeyframesActivate(bpy.types.Operator):
    bl_idname = "new_amth.generic_auto_update_activate"
    bl_label = "Activate Generic Auto Update"
    bl_description = "Activate Update motion path operator in real time in ViewPort"

    bl_icon = 'PLAY'

    def execute(self, context):
        context.window_manager.generic_auto_update_active = True
        bpy.ops.anim.generic_auto_update_keyframes('INVOKE_DEFAULT')
        return {'FINISHED'}

class GenericAutoUpdateKeyframesDeactivate(bpy.types.Operator):
    bl_idname = "new_amth.generic_auto_update_deactivate"
    bl_label = "Deactivate Generic Auto Update"
    bl_description = "Deactivate Update motion path operator in real time in ViewPort"
    bl_icon = 'PAUSE'
    
    def execute(self, context):
        context.window_manager.generic_auto_update_active = False
        return {'FINISHED'}


class GenericOffestKeyframesOperator(bpy.types.Operator):
    """smart offest all the keyframes in the selected fcurve"""
    bl_idname = "anim.generic_offest_keyframes"
    bl_label = "Generic Auto Update Keyframes"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    last_location = None
    last_rotation = None
    last_rotation_quaternion = None
    last_scale = None
    interval = 0.1  

    def modal(self, context, event):
        if context.window_manager.generic_offest_active:
            if event.type == 'TIMER':
                if context.screen.is_animation_playing:
                    self.last_location = None
                    self.last_rotation = None
                    self.last_rotation_quaternion = None
                    self.last_scale = None
                    return {'RUNNING_MODAL'}
                
                obj = context.active_object

                if obj:
                    if obj.mode == 'POSE':
                        bone = context.active_pose_bone
                        if bone:
                            self.update_bone_keyframes(context, bone)
                    else:
                        self.update_object_keyframes(context, obj)
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}
        else:
            self.cancel(context)
            return {'CANCELLED'}

    def update_bone_keyframes(self, context, bone):
        """Update keyframes for a bone if it has changed"""
        current_location = bone.location.copy()
        current_rotation = bone.rotation_euler.copy()
        current_rotation_quaternion = bone.rotation_quaternion.copy()
        current_scale = bone.scale.copy()

        if self.last_location is None:
            self.last_location = current_location.copy()
        else:
            if (abs(current_location[0] - self.last_location[0]) > 0.0001 or
                abs(current_location[1] - self.last_location[1]) > 0.0001 or
                abs(current_location[2] - self.last_location[2]) > 0.0001):
                delta = [current_location[i] - self.last_location[i] for i in range(3)]
                self.update_bone_keyframes_selective(context, bone, 'location', delta)
                self.last_location = current_location.copy()

        if self.last_rotation is None:
            self.last_rotation = current_rotation.copy()
        else:
            if (abs(current_rotation[0] - self.last_rotation[0]) > 0.0001 or
                abs(current_rotation[1] - self.last_rotation[1]) > 0.0001 or
                abs(current_rotation[2] - self.last_rotation[2]) > 0.0001):
                delta = [current_rotation[i] - self.last_rotation[i] for i in range(3)]
                self.update_bone_keyframes_selective(context, bone, 'rotation_euler', delta)
                self.last_rotation = current_rotation.copy()

        if self.last_rotation_quaternion is None:
            self.last_rotation_quaternion = current_rotation_quaternion.copy()
        else:
            if (abs(current_rotation_quaternion[0] - self.last_rotation_quaternion[0]) > 0.0001 or
                abs(current_rotation_quaternion[1] - self.last_rotation_quaternion[1]) > 0.0001 or
                abs(current_rotation_quaternion[2] - self.last_rotation_quaternion[2]) > 0.0001 or
                abs(current_rotation_quaternion[3] - self.last_rotation_quaternion[3]) > 0.0001):
                delta = [current_rotation_quaternion[i] - self.last_rotation_quaternion[i] for i in range(4)]
                self.update_bone_keyframes_selective(context, bone, 'rotation_quaternion', delta)
                self.last_rotation_quaternion = current_rotation_quaternion.copy()

        if self.last_scale is None:
            self.last_scale = current_scale.copy()
        else:
            if (abs(current_scale[0] - self.last_scale[0]) > 0.0001 or
                abs(current_scale[1] - self.last_scale[1]) > 0.0001 or
                abs(current_scale[2] - self.last_scale[2]) > 0.0001):
                delta = [current_scale[i] - self.last_scale[i] for i in range(3)]
                self.update_bone_keyframes_selective(context, bone, 'scale', delta)
                self.last_scale = current_scale.copy()

    def update_object_keyframes(self, context, obj):
        """Update keyframes for an object if it has changed"""
        current_location = obj.location.copy()
        current_rotation = obj.rotation_euler.copy()
        current_rotation_quaternion = obj.rotation_quaternion.copy()
        current_scale = obj.scale.copy()

        if self.last_location is None:
            self.last_location = current_location.copy()
        else:
            if (abs(current_location[0] - self.last_location[0]) > 0.0001 or
                abs(current_location[1] - self.last_location[1]) > 0.0001 or
                abs(current_location[2] - self.last_location[2]) > 0.0001):
                delta = [current_location[i] - self.last_location[i] for i in range(3)]
                self.update_keyframes(context, obj, 'location', delta)
                self.last_location = current_location.copy()

        if self.last_rotation is None:
            self.last_rotation = current_rotation.copy()
        else:
            if (abs(current_rotation[0] - self.last_rotation[0]) > 0.0001 or
                abs(current_rotation[1] - self.last_rotation[1]) > 0.0001 or
                abs(current_rotation[2] - self.last_rotation[2]) > 0.0001):
                delta = [current_rotation[i] - self.last_rotation[i] for i in range(3)]
                self.update_keyframes(context, obj, 'rotation_euler', delta)
                self.last_rotation = current_rotation.copy()

        if self.last_rotation_quaternion is None:
            self.last_rotation_quaternion = current_rotation_quaternion.copy()
        else:
            if (abs(current_rotation_quaternion[0] - self.last_rotation_quaternion[0]) > 0.0001 or
                abs(current_rotation_quaternion[1] - self.last_rotation_quaternion[1]) > 0.0001 or
                abs(current_rotation_quaternion[2] - self.last_rotation_quaternion[2]) > 0.0001 or
                abs(current_rotation_quaternion[3] - self.last_rotation_quaternion[3]) > 0.0001):
                delta = [current_rotation_quaternion[i] - self.last_rotation_quaternion[i] for i in range(4)]
                self.update_keyframes(context, obj, 'rotation_quaternion', delta)
                self.last_rotation_quaternion = current_rotation_quaternion.copy()

        if self.last_scale is None:
            self.last_scale = current_scale.copy()
        else:
            if (abs(current_scale[0] - self.last_scale[0]) > 0.0001 or
                abs(current_scale[1] - self.last_scale[1]) > 0.0001 or
                abs(current_scale[2] - self.last_scale[2]) > 0.0001):
                delta = [current_scale[i] - self.last_scale[i] for i in range(3)]
                self.update_keyframes(context, obj, 'scale', delta)
                self.last_scale = current_scale.copy()

    def update_bone_keyframes_selective(self, context, bone, transform_type, delta):
        """Offset keyframes for bone F-Curves with more selective matching"""
        if not bone.id_data.animation_data or not bone.id_data.animation_data.action:
            return
            
        action = bone.id_data.animation_data.action
        bone_name = bone.name
        
        for fcurve in get_fcurves(action):
            if (transform_type in fcurve.data_path and 
                f'pose.bones["{bone_name}"]' in fcurve.data_path):
             
                index = fcurve.array_index
                if index < len(delta):
                    delta_value = delta[index]
                    
                    for keyframe in fcurve.keyframe_points:
                        keyframe.co.y += delta_value
                    
                    fcurve.update()

    def update_keyframes(self, context, obj, transform_type, delta):
        """Offset keyframes for object F-Curves"""
        if not obj.animation_data or not obj.animation_data.action:
            return
            
        action = obj.animation_data.action
        
        for fcurve in get_fcurves(action):
            if transform_type in fcurve.data_path:
                index = fcurve.array_index
                if index < len(delta):
                    delta_value = delta[index]
                    for keyframe in fcurve.keyframe_points:
                        keyframe.co.y += delta_value
                    fcurve.update()

    def execute(self, context):
        self.last_location = None
        self.last_rotation = None
        self.last_rotation_quaternion = None
        self.last_scale = None
        
        self._timer = context.window_manager.event_timer_add(self.interval, window=context.window)
        context.window_manager.modal_handler_add(self)
        context.window_manager.generic_offest_active = True
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
        context.window_manager.generic_offest_active = False
        return {'CANCELLED'}


class GenericOffestKeyframesActivate(bpy.types.Operator):
    bl_idname = "new_amth.generic_offest_activate"
    bl_label = "Activate Generic Auto Update"
    bl_description = "Activate smart offest to offest all the keyframes in the selected fcurve"

    bl_icon = 'PLAY'

    def execute(self, context):
        context.window_manager.generic_offest_active = True
        bpy.ops.anim.generic_offest_keyframes('INVOKE_DEFAULT')
        return {'FINISHED'}

class GenericOffestKeyframesDeactivate(bpy.types.Operator):
    bl_idname = "new_amth.generic_offest_deactivate"
    bl_label = "Deactivate Generic Auto Update"
    bl_description = "Deactivate smart offest to offest all the keyframes in the selected fcurve"
    bl_icon = 'PAUSE'
    
    def execute(self, context):
        context.window_manager.generic_offest_active = False
        return {'FINISHED'}






class MotionPathPanel(bpy.types.Panel):
    """UI Panel for activating and deactivating the keyframe operator"""
    bl_idname = "VIEW3D_PT_motion_path"
    bl_label = "Motion Path Pro"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Motion Path'

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager




        row = layout.row(align=True)
        row.prop(wm, "show_handles_expanded", text="", 
                 icon='TRIA_DOWN' if wm.show_handles_expanded else 'TRIA_RIGHT',
                 emboss=False)
        row.label(text="Keyframe Handles")        
        if not wm.show_handles_expanded:
            return
        box = layout.box()
        box.label(text="Handles Controls", icon='HANDLE_AUTO')
        row = box.row()
        row.prop(wm, "handle_type", text="Type")
        row.operator("motion_path.set_handle_type", text="Apply").handle_type = wm.handle_type
        row = box.row()
        row.operator("motion_path.set_handle_type_all", text="Apply to All Keyframes").handle_type = wm.handle_type
        row = box.row()
        row.prop(wm, "show_all_handles")
        row.prop(wm, "show_only_selected_handles")
        row = box.row()        
        if not wm.direct_manipulation_active:
            row.operator("motion_path.direct_manipulation_toggle", text="Start_H", icon='PLAY')
        else:
            row.operator("motion_path.direct_manipulation_toggle", text="Stop_H", icon='PAUSE')

        if wm.anim_deactivate_keyframe_operator:
            row.operator("anim.deactivate_keyframe_operator", text="Deactivate Advanced", icon="PAUSE")
        else:
            row.operator("anim.insert_keyframe_selected_fcurves", text="Activate Advanced", icon="PLAY")





class InsertKeyframeOnSelectedFcurves(bpy.types.Operator):
    """add keyframe on the selected fcurves when you click on any motion path point"""
    bl_idname = "anim.insert_keyframe_selected_fcurves"
    bl_label = "Insert and Move Keyframe on Selected F-Curves"
    bl_options = {'REGISTER', 'UNDO'}
    _timer = None
    active = False
    operator_ref = None
    mouse_start = None
    inserted_keyframes = {}
    is_moving_keyframes = False
    def modal(self, context, event):
        if self.active:
            mouse_pos = mathutils.Vector((event.mouse_region_x, event.mouse_region_y))
            obj = context.active_object
            motion_path = None
            is_pose_mode = False
            if obj:
                if obj.mode == 'POSE':
                    bone = context.active_pose_bone
                    if bone and bone.motion_path:
                        motion_path = bone.motion_path
                        is_pose_mode = True
                elif obj.mode == 'OBJECT' and obj.motion_path:
                    motion_path = obj.motion_path
            if motion_path:
                frame_start = motion_path.frame_start
                for index, point in enumerate(motion_path.points):
                    frame_num = frame_start + index
                    if is_pose_mode:
                        world_pos = obj.matrix_world @ point.co
                    else:
                        world_pos = point.co
                    screen_pos = bpy_extras.view3d_utils.location_3d_to_region_2d(
                        context.region, context.space_data.region_3d, world_pos)
                    if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not self.is_moving_keyframes:
                        if screen_pos and (mouse_pos - screen_pos).length < 5: 
                            if obj.animation_data and obj.animation_data.action:
                                action = obj.animation_data.action
                                self.inserted_keyframes.clear()
                                for fcurve in get_fcurves(action):
                                    
                                    if fcurve.data_path.endswith(("location", "rotation_euler", "rotation_quaternion", "scale")) and fcurve.select:
                                        for kp in fcurve.keyframe_points:
                                            kp.select_control_point = False
                                            kp.select_left_handle = False
                                            kp.select_right_handle = False
                                        
                                        existing_keyframe = next((kp for kp in fcurve.keyframe_points if kp.co[0] == frame_num), None)
                                        if existing_keyframe:
                                            print(f"Keyframe exists at frame {frame_num}. Selecting it.")
                                            existing_keyframe.select_control_point = True
                                            continue
                                        
                                        key = fcurve.keyframe_points.insert(
                                            frame_num, fcurve.evaluate(frame_num), options={'FAST'}
                                        )
                                        key.select_control_point = True
                                        self.inserted_keyframes[fcurve] = [(key, key.co[0], key.co[1])]
                                        fcurve.update()
                                
                                context.view_layer.update()
                                return {'RUNNING_MODAL'}
                        context.area.tag_redraw()
                    elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE' and self.is_moving_keyframes:
                        self.is_moving_keyframes = False
                        return {'RUNNING_MODAL'}
        return {'PASS_THROUGH'}
    def execute(self, context):
        obj = context.active_object
        if obj:
            if obj.mode == 'POSE':
                bone = context.active_pose_bone
                if bone and not bone.motion_path:
                    bpy.ops.pose.paths_calculate(display_type='RANGE', range='SCENE')
            elif obj.mode == 'OBJECT' and not obj.motion_path:
                bpy.ops.object.paths_calculate(display_type='RANGE', range='SCENE')
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        self.active = True
        InsertKeyframeOnSelectedFcurves.operator_ref = self
        context.window_manager.anim_deactivate_keyframe_operator = True
        return {'RUNNING_MODAL'}
    def cancel(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
        self.active = False
        InsertKeyframeOnSelectedFcurves.operator_ref = None
        self.is_moving_keyframes = False
        context.window_manager.anim_deactivate_keyframe_operator = False
        return {'CANCELLED'}
class DeactivateKeyframeOperator(bpy.types.Operator):
    """Deactivate Keyframe Insertion Operator"""
    bl_idname = "anim.deactivate_keyframe_operator"
    bl_label = "Deactivate Keyframe Operator"
    def execute(self, context):
        operator = InsertKeyframeOnSelectedFcurves.operator_ref
        if operator and operator.active:
            operator.cancel(context)
            self.report({'INFO'}, "Keyframe operator deactivated.")
        else:
            self.report({'INFO'}, "No active keyframe operator to deactivate.")
        return {'FINISHED'}




class MOTIONPATH_SetHandleTypeAll(bpy.types.Operator):
    """Set handle type for all control points in the animation"""
    bl_idname = "motion_path.set_handle_type_all"
    bl_label = "Set Handle Type For All"
    bl_description = "Set the handle type for all keyframes in the animation"
    bl_options = {'REGISTER', 'UNDO'}
    
    handle_type: bpy.props.StringProperty()
    
    def execute(self, context):
        obj = context.active_object
        if not obj or not obj.animation_data or not obj.animation_data.action:
            self.report({'WARNING'}, "No animation data found")
            return {'CANCELLED'}
        
        action = obj.animation_data.action
        bone_name = None
        if obj.mode == 'POSE':
            bone = context.active_pose_bone
            if bone:
                bone_name = bone.name
        
        modified_count = 0
        for fcurve in get_fcurves(action):
            if not is_location_fcurve(fcurve, bone_name):
                continue
            for keyframe in fcurve.keyframe_points:
                keyframe.handle_left_type = self.handle_type
                keyframe.handle_right_type = self.handle_type
                if self.handle_type == 'ALIGNED':
                    left_direction = keyframe.co[1] - keyframe.handle_left[1]
                    keyframe.handle_right[1] = keyframe.co[1] + left_direction
                elif self.handle_type == 'VECTOR':
                    keyframe.handle_left[1] = keyframe.co[1]
                    keyframe.handle_right[1] = keyframe.co[1]
                elif self.handle_type in {'AUTO', 'AUTO_CLAMPED'}:
                    pass
                modified_count += 1
            fcurve.update()
        
        build_position_cache(context)
        self.report({'INFO'}, f"Set {modified_count} keyframes to {self.handle_type} handles")
        return {'FINISHED'}


class MOTIONPATH_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    
    compatibility_mode: bpy.props.BoolProperty(
        name="Compatibility Mode",
        description="Enable compatibility mode to work better with other addons (may reduce performance)",
        default=True,
    )
    
    skip_cache_building: bpy.props.BoolProperty(
        name="Skip Cache Building",
        description="Skip building position cache when other animation addons are detected",
        default=False,
    )
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Compatibility Settings:")
        layout.prop(self, "compatibility_mode")
        layout.prop(self, "skip_cache_building")




classes = (
    FRO_OT_Delet_Path_6E947,
    FRO_OT_Delet_Allpath_B6Bbf,    
    FRO_OT_Delet_Path001_C28Ef,
    FRO_OT_Delet_Allpath001_C61F5,                
    AMTH_OT_AutoUpdateMotionPaths,
    AMTH_OT_AutoUpdateActivate,
    AMTH_OT_AutoUpdateDeactivate,
    DeactivateKeyframeOperator,
    GenericAutoUpdateKeyframesOperator,
    GenericAutoUpdateKeyframesActivate,
    GenericAutoUpdateKeyframesDeactivate,   
    GenericOffestKeyframesOperator,
    GenericOffestKeyframesActivate,
    GenericOffestKeyframesDeactivate,
    InsertKeyframeOnSelectedFcurves,

    
    MOTIONPATH_DirectManipulation,
    MOTIONPATH_DirectManipulationToggle,
    MOTIONPATH_AutoUpdateMotionPaths,
    MOTIONPATH_SetHandleType,
    MOTIONPATH_SetHandleTypeAll,
    MOTIONPATH_ToggleSnap,
    MOTIONPATH_AddonPreferences,    
    
    
    AutoMOTIONPATHSPanel,
    MotionPathPanel,

)



def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.auto_update_active = bpy.props.BoolProperty(default=False)
    bpy.types.WindowManager.auto_update_timer_interval = bpy.props.FloatProperty(
        name="Timer Interval",
        description="Interval in seconds for the auto-update timer",
        default=0.1,
        min=0.1,
        max=1.0
    )
    bpy.types.WindowManager.update_mode = bpy.props.EnumProperty(
        name="Update Mode",
        description="Choose between timer-based and event-based update modes",
        items=[
            ('TIMER', "Real_Time", "Update motion paths in real time Suitable for medium or powerful devices"),
            ('EVENT', "After_Change", "Update motion paths after moving the keyframes Suitable for weak devices")
        ],
        default='TIMER'
    )

    bpy.types.WindowManager.new_auto_update_active = bpy.props.BoolProperty(default=False)
    bpy.types.WindowManager.new_auto_update_timer_interval = bpy.props.FloatProperty(
        name="Timer Interval",
        description="Interval in seconds for the new auto-update timer",
        default=0.1,
        min=0.1,
        max=1.0
    )
    bpy.types.WindowManager.new_update_mode = bpy.props.EnumProperty(
        name="Update Mode",
        description="Choose between timer-based and event-based update modes",
        items=[
            ('TIMER', "Real_Time", "Update motion paths in real time Suitable for medium or powerful devices"),
            ('EVENT', "After_Change", "Update motion paths after moving the keyframes Suitable for weak devices")
        ],
        default='TIMER'
    )




   

    bpy.types.WindowManager.generic_auto_update_active = bpy.props.BoolProperty(default=False)
    bpy.types.WindowManager.generic_offest_active = bpy.props.BoolProperty(default=False)
    
    bpy.types.WindowManager.anim_deactivate_keyframe_operator = bpy.props.BoolProperty(
        name="Deactivate Keyframe Operator", default=False)




    bpy.types.WindowManager.direct_manipulation_active = bpy.props.BoolProperty(
        name="Direct Manipulation Active",
        description="Enable direct manipulation of points on motion paths",
        default=False
    )
    bpy.types.WindowManager.auto_sapty_active = bpy.props.BoolProperty(
        name="Auto Update Active",
        default=False
    )
    bpy.types.WindowManager.auto_midawq_timer_interval = bpy.props.FloatProperty(
        name="Timer Interval",
        description="Interval in seconds for auto-update timer",
        default=0.1,
        min=0.05,
        max=1.0
    )
    bpy.types.WindowManager.update_hamdionz = bpy.props.EnumProperty(
        name="Update Mode",
        description="Update mode",
        items=[
            ('TIMER', "Real-time", "Update continuously (resource intensive)"),
            ('EVENT', "On Change", "Update only when keyframes change")
        ],
        default='TIMER'
    )
    bpy.types.WindowManager.handle_type = bpy.props.EnumProperty(
        name="Handle Type",
        description="Default handle type for new keyframes",
        items=[
            ('FREE', "Free", "Handles can be adjusted independently"),
            ('ALIGNED', "Aligned", "Handles are aligned to maintain smoothness"),
            ('VECTOR', "Vector", "Creates linear interpolation"),
            ('AUTO', "Auto", "Automatic smooth handles"),
            ('AUTO_CLAMPED', "Auto Clamped", "Automatic handles with clamped values"),
        ],
        default='AUTO'
    )
    bpy.types.WindowManager.handle_snap = bpy.props.BoolProperty(
        name="Snap Handles",
        description="Snap handles to grid or other elements",
        default=False
    )
    bpy.types.WindowManager.handle_snap_increment = bpy.props.FloatProperty(
        name="Snap Increment",
        description="Distance to snap handles",
        default=0.1,
        min=0.01,
        max=10.0
    )
    bpy.types.WindowManager.show_all_handles = bpy.props.BoolProperty(
        name="Show All Handles",
        description="Show handles for all keyframe points",
        default=True
    )
    bpy.types.WindowManager.show_only_selected_handles = bpy.props.BoolProperty(
        name="Show Only Selected Handles",
        description="Show handles only for selected keyframe points",
        default=False
    )
    bpy.types.WindowManager.global_handle_visual_scale = bpy.props.FloatProperty(
        name="Global Handle Visual Scale",
        description="Scale factor for handle visualization",
        default=1.0,
        min=0.1,
        max=10.0
    )
    bpy.types.WindowManager.show_handles_expanded = bpy.props.BoolProperty(
        name="Show Handles Expanded",
        description="Expand or collapse the handles controls",
        default=True
    )




def unregister():

    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.WindowManager.generic_auto_update_active
    del bpy.types.WindowManager.generic_offest_active
    
    del bpy.types.WindowManager.auto_update_timer_interval
    del bpy.types.WindowManager.update_mode
    del bpy.types.WindowManager.new_auto_update_active
    del bpy.types.WindowManager.new_auto_update_timer_interval
    del bpy.types.WindowManager.new_update_mode            
    del bpy.types.WindowManager.anim_deactivate_keyframe_operator

    del bpy.types.WindowManager.direct_manipulation_active
    del bpy.types.WindowManager.auto_sapty_active
    del bpy.types.WindowManager.show_all_handles
    del bpy.types.WindowManager.show_only_selected_handles
    del bpy.types.WindowManager.global_handle_visual_scale
    del bpy.types.WindowManager.show_handles_expanded
