import bpy

# TOOL --------------------------------

bl_info = {
    "name": "Deo's Copy name to Data",
    "version": (1, 0),
    "blender": (4, 4, 0),
    "location": "View3D > Sidebar > Tool Tab",
    "description": "Copy Objec's name to Data's name",
    "category": "Object",
}

# UI  -----------------------------------
class VIEW3D_PT_CopyNameToData(bpy.types.Panel):
    bl_idname = "DEOS_PT_copynametodata_tool"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ".objectmode"
    bl_category = "Deo's Tools"
    bl_label = "DEO's Copy Name to Data"

    def draw(self, context):
        layout = self.layout
        
        layout.operator("object.copy_name_to_data", text="[ A P P L Y ]", icon='FILE_REFRESH')


# ACTION --------------------------------
class OBJECT_OT_CopyNameToData(bpy.types.Operator):
    bl_idname = "object.copy_name_to_data"
    bl_label = "Deo's Copy Name to Data"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}
        
        # Bucle for each para recorrer todos los objetos seleccionados
        contador = 0
        for obj in context.selected_objects:
            if obj.type == 'MESH' and obj.data:
                # Copiar el nombre del objeto al bloque de datos (data)
                obj.data.name = obj.name
                contador += 1
            else:
                print(f"Ignored object (no Mesh type): {obj.name}")
        
        self.report({'INFO'}, f"{contador} objects data renamed.")
        return {'FINISHED'}




# REGISTER ------------------------------
classes = (
    VIEW3D_PT_CopyNameToData,
    OBJECT_OT_CopyNameToData,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()