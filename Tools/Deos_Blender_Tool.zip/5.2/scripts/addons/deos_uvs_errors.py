import bpy
import bmesh


# TOOL --------------------------------
bl_info = {
    "name": "DEO's UV Issues",
    "version": (1, 0),
    "blender": (4, 4, 0),
    "location": "View3D > Sidebar > Tool Tab",
    "description":"Select 'Flipped' or 'Collapsed' UV's",
    "category": "edit",
}


# UI  -----------------------------------
class VIEW3D_PT_uv_checker_sidebar(bpy.types.Panel):
    bl_idname = "DEOS_PT_uv_issues"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "Deo's Tools"
    bl_label = "DEO's UV Issues"

    @classmethod
    def poll(cls, context):
        # Solo muestra el panel si hay un objeto activo, es de tipo MESH y está en EDITMODE
        obj = context.active_object
        return obj is not None and obj.type == 'MESH' and context.mode == 'EDIT_MESH'

    def draw(self, context):
        layout = self.layout
        box = layout.box()

        row = box.row(align=True)
        row.operator("wm.open_select_flipped_uvs", text="Flipped", icon='UV_SYNC_SELECT')
        row.operator("wm.open_select_zero_area_uvs", text="No Region", icon='RESTRICT_SELECT_OFF')


# ACTIONS --------------------------------


# Auxiliar --------------------------------
def is_uv_face_flipped(uv_layer, face):
    """Comprueba si el orden de vértices en el UV Editor está invertido (área firmada negativa)."""
    loops = face.loops
    if len(loops) < 3:
        return False

    uv_area = 0.0
    for i in range(len(loops)):
        uv_curr = loops[i][uv_layer].uv
        uv_next = loops[(i + 1) % len(loops)][uv_layer].uv
        uv_area += (uv_curr.x * uv_next.y) - (uv_next.x * uv_curr.y)

    return uv_area < 0.0

def get_uv_face_area(uv_layer, face):
    """Calcula el área 2D real de la cara en espacio UV (Shoelace algorithm)."""
    loops = face.loops
    if len(loops) < 3:
        return 0.0

    signed_area = 0.0
    for i in range(len(loops)):
        uv_curr = loops[i][uv_layer].uv
        uv_next = loops[(i + 1) % len(loops)][uv_layer].uv
        signed_area += (uv_curr.x * uv_next.y) - (uv_next.x * uv_curr.y)

    return abs(signed_area) * 0.5


# Operators
class VIEW3D_OT_select_flipped_uvs(bpy.types.Operator):
    bl_idname = "wm.open_select_flipped_uvs"
    bl_label = "Flipped UVs"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None and 
                context.active_object.type == 'MESH' and 
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()

        context.scene.tool_settings.mesh_select_mode = (False, False, True)

        for face in bm.faces:
            face.select = False

        flipped_count = 0
        for face in bm.faces:
            if is_uv_face_flipped(uv_layer, face):
                face.select = True
                flipped_count += 1

        bmesh.update_edit_mesh(obj.data)
        context.scene.tool_settings.use_uv_select_sync = True

        if flipped_count == 0:
            self.report({'INFO'}, "NO FLIPPED UVS FOUND IT.")
        else:
            self.report({'WARNING'}, f"FOUNDED #{flipped_count} UV Flipped.")

        return {'FINISHED'}

class VIEW3D_OT_select_zero_area_uvs(bpy.types.Operator):
    bl_idname = "wm.open_select_zero_area_uvs"
    bl_label = "No Region (Zero Area)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.active_object is not None and 
                context.active_object.type == 'MESH' and 
                context.mode == 'EDIT_MESH')

    def execute(self, context):
        obj = context.active_object
        bm = bmesh.from_edit_mesh(obj.data)
        uv_layer = bm.loops.layers.uv.verify()

        context.scene.tool_settings.mesh_select_mode = (False, False, True)

        for face in bm.faces:
            face.select = False

        count = 0
        epsilon = 1e-6

        for face in bm.faces:
            area = get_uv_face_area(uv_layer, face)
            if area < epsilon:
                face.select = True
                count += 1

        bmesh.update_edit_mesh(obj.data)
        context.scene.tool_settings.use_uv_select_sync = True

        if count == 0:
            self.report({'INFO'}, "No UV's Collpsed.")
        else:
            self.report({'WARNING'}, f"Founded #{count} UVs faces collapsed!")

        return {'FINISHED'}


# REGISTER ------------------------------
classes = (
    VIEW3D_OT_select_flipped_uvs,
    VIEW3D_OT_select_zero_area_uvs,
    VIEW3D_PT_uv_checker_sidebar,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()