import bpy
import os
import subprocess

# TOOL -------------------------------------------------------------------------
bl_info = {
    "name": "DEO's Splitter Colliders",
    "version": (1, 1),
    "blender": (4, 4, 0),
    "location": "View3D > Sidebar > Tool Tab",
    "description": "Export selected collection instances combined into GLB with custom paths and names",
    "category": "Object",
}

COLLIDER_KEYWORDS = ["COLONLY", "CONVCOLONLY", "UCP_", "MCPP_", "COLLIDER", "COL_", "_COL"]
MESH_SUFFIX = "MSH"
COL_SUFFIX = "COL"

# UI PROPERTIES -------------------------------------------------------------------
def register_properties():
    bpy.types.Scene.deo_export_path = bpy.props.StringProperty(
        name="Export Path",
        description="Folder where the exported GLB files will be saved",
        default="",
        subtype='DIR_PATH'
    )
    bpy.types.Scene.deo_export_base_name = bpy.props.StringProperty(
        name="Base Name",
        description="Base name for exported files",
        default=""
    )

def unregister_properties():
    del bpy.types.Scene.deo_export_path
    del bpy.types.Scene.deo_export_base_name



# UI ---------------------------------------------------------------------------
class VIEW3D_PT_deo_export_panel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_deo_export_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ".objectmode"
    bl_category = "Deo's Tools"
    bl_label = "DEO'S SPLIT COLLIDERS"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Output Configuration Section
        box = layout.box()
        box.prop(scene, "deo_export_base_name", text="Name")
        box.prop(scene, "deo_export_path", text="Path")

        # Button to open the folder in the file explorer
        row_folder = box.row(align=True)
        row_folder.scale_y = 1.2
        row_folder.operator("wm.open_export_folder", text="Open Folder", icon='FILE_FOLDER')

        layout.separator()

        # Main Execution Button
        row = layout.row()
        row.scale_y = 1.5
        row.operator("object.export_selected_props_combined_glb", text="EXPORT SELECTED MSH(ES)", icon='EXPORT')




# ACTIONS / OPERATORS ----------------------------------------------------------
class WM_OT_open_export_folder(bpy.types.Operator):
    bl_idname = "wm.open_export_folder"
    bl_label = "Open Folder Location"
    bl_options = {'REGISTER'}

    def execute(self, context):
        path_str = context.scene.deo_export_path.strip()

        if not path_str:
            self.report({'ERROR'}, "There is no specific path.")
            return {'CANCELLED'}

        folder_path = bpy.path.abspath(path_str)

        if not os.path.exists(folder_path):
            try:
                os.makedirs(folder_path)
            except Exception as e:
                self.report({'ERROR'}, "There is no valid path or it could not be created.")
                return {'CANCELLED'}

        try:
            if os.name == 'nt':  # Windows
                os.startfile(folder_path)
            elif sys.platform == 'darwin':  # macOS
                subprocess.Popen(['open', folder_path])
            else:  # Linux
                subprocess.Popen(['xdg-open', folder_path])
            self.report({'INFO'}, f"Folder Opened: {folder_path}")
        except Exception as e:
            self.report({'ERROR'}, f"Error to open folder: {str(e)}")
            return {'CANCELLED'}

        return {'FINISHED'}


class OBJECT_OT_export_selected_props_combined_glb(bpy.types.Operator):
    bl_idname = "object.export_selected_props_combined_glb"
    bl_label = "Export Combined Props"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        path_str = scene.deo_export_path.strip()
        base_name = scene.deo_export_base_name.strip()

        selected_objects = context.selected_objects

        if not selected_objects:
            self.report({'ERROR'}, "Please select at least one prop in the scene.")
            return {'CANCELLED'}

        if not path_str:
            self.report({'ERROR'}, "There is no valid export route.")
            return {'CANCELLED'}

        if not base_name:
            self.report({'ERROR'}, "No valid name is specified for the files.")
            return {'CANCELLED'}

        output_folder = bpy.path.abspath(path_str)

        current_collection = context.collection
        all_mesh_objects = []
        all_collider_objects = []
        temp_spawned_objects = []

        print(f"--- Processing {len(selected_objects)} selected props ---")

        # 1. Iterate through each selected instance
        for sel_obj in selected_objects:
            if not sel_obj.instance_collection:
                print(f"⚠️ Skip '{sel_obj.name}': It is not a collection instance.")
                continue

            collection = sel_obj.instance_collection
            world_matrix = sel_obj.matrix_world.copy()

            for obj in collection.objects:
                if obj.type == 'MESH':
                    mesh_copy = obj.data.copy()
                    new_obj = bpy.data.objects.new(obj.name, mesh_copy)
                    current_collection.objects.link(new_obj)
                    new_obj.matrix_world = world_matrix @ obj.matrix_world
                    temp_spawned_objects.append(new_obj)

                    obj_name_upper = obj.name.upper()
                    if any(key in obj_name_upper for key in COLLIDER_KEYWORDS):
                        all_collider_objects.append(new_obj)
                    else:
                        all_mesh_objects.append(new_obj)

        if not os.path.exists(output_folder):
            try:
                os.makedirs(output_folder)
            except Exception:
                self.report({'ERROR'}, "There is no valid path, or the destination directory could not be created.")
                return {'CANCELLED'}

        def export_combined_group(objects_list, suffix):
            if not objects_list:
                print(f"No elements were found for {suffix}.")
                return

            bpy.ops.object.select_all(action='DESELECT')
            for obj in objects_list:
                obj.select_set(True)
                context.view_layer.objects.active = obj

            filepath = os.path.join(output_folder, f"{base_name}_{suffix}.glb")

            bpy.ops.export_scene.gltf(
                filepath=filepath,
                export_format='GLB',
                export_image_format='NONE',
                export_texture_dir='',
                export_keep_originals=True,
                export_texcoords=True,
                export_normals=True,
                export_gn_mesh=True,
                export_draco_mesh_compression_enable=False,
                export_draco_mesh_compression_level=6,
                export_draco_position_quantization=14,
                export_draco_normal_quantization=10,
                export_draco_texcoord_quantization=12,
                export_draco_color_quantization=10,
                export_draco_generic_quantization=12,
                export_tangents=False,
                export_materials='EXPORT',
                export_unused_images=False,
                export_unused_textures=False,
                export_vertex_color='ACTIVE',
                export_vertex_color_name='Color',
                export_all_vertex_colors=True,
                export_active_vertex_color_when_no_material=True,
                export_attributes=True,
                use_mesh_edges=False,
                use_mesh_vertices=False,
                export_cameras=False,
                use_selection=True,
                use_visible=False,
                use_renderable=False,
                export_extras=False,
                export_yup=True,
                export_apply=True,
                export_animations=True,
                export_frame_range=False,
                export_frame_step=1,
                export_force_sampling=True,
                export_sampling_interpolation_fallback='LINEAR',
                export_animation_mode='ACTIONS',
                export_def_bones=False,
                export_hierarchy_flatten_bones=False,
                export_hierarchy_flatten_objs=False,
                export_armature_object_remove=False,
                export_leaf_bone=False,
                export_optimize_animation_size=True,
                export_optimize_animation_keep_anim_armature=True,
                export_optimize_animation_keep_anim_object=False,
                export_negative_frame='SLIDE',
                export_anim_slide_to_zero=False,
                export_bake_animation=False,
                export_merge_animation='ACTION',
                export_anim_single_armature=True,
                export_reset_pose_bones=True,
                export_current_frame=False,
                export_rest_position_armature=True,
                export_anim_scene_split_object=True,
                export_skins=True,
                export_influence_nb=4,
                export_all_influences=False,
                export_morph=True,
                export_morph_normal=True,
                export_morph_tangent=False,
                export_morph_animation=True,
                export_morph_reset_sk_data=True,
                export_lights=False,
                export_try_sparse_sk=True,
                export_try_omit_sparse_sk=False,
                export_gpu_instances=False,
                export_action_filter=False,
                export_convert_animation_pointer=False,
                export_nla_strips=True,
                export_original_specular=False
            )
            print(f"✅ Exported {len(objects_list)} object(s) unified in: {filepath}")

        # 2. Export meshes and colliders
        export_combined_group(all_mesh_objects, MESH_SUFFIX)
        export_combined_group(all_collider_objects, COL_SUFFIX)

        # 3. Clean up temporary objects
        bpy.ops.object.select_all(action='DESELECT')
        for obj in temp_spawned_objects:
            obj.select_set(True)
            mesh_data = obj.data
            bpy.data.objects.remove(obj, do_unlink=True)
            if mesh_data.users == 0:
                bpy.data.meshes.remove(mesh_data)

        # 4. Restore original user selection
        bpy.ops.object.select_all(action='DESELECT')
        for sel_obj in selected_objects:
            sel_obj.select_set(True)

        self.report({'INFO'}, "✨ Unified export successfully completed.")
        return {'FINISHED'}


# REGISTER ---------------------------------------------------------------------
classes = (
    WM_OT_open_export_folder,
    OBJECT_OT_export_selected_props_combined_glb,
    VIEW3D_PT_deo_export_panel,
)

def register():
    register_properties()
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    unregister_properties()

if __name__ == "__main__":
    register()