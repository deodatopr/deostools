import bpy
import subprocess
import sys
import os


# TOOL --------------------------------

bl_info = {
    "name": "DEO's EDIT LIBRARY",
    "version": (1, 0),
    "blender": (4, 4, 0),
    "location": "View3D > Sidebar > Tool Tab",
    "description": "Select a library file and edit the reference in other Blender Instance",
    "category": "Object",
}

# UI  -----------------------------------
class VIEW3D_PT_linked_library_panel(bpy.types.Panel):
    bl_idname = "DEOS_PT_linked_library_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ".objectmode"
    bl_category = "Deo's Tools"
    bl_label = "DEO's EDIT LIBRARY"
    


    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        if not obj:
            layout.label(text="Select an Object", icon='INFO')
            return

        lib_path = get_linked_library_path(obj)

        if lib_path:
            file_name = os.path.basename(lib_path)
            box = layout.box()
            # box.label(text=f"Prop linked:", icon='LINKED')
            box.label(text=file_name, icon='FILE_BLEND')
            
            row = layout.row()
            row.scale_y = 1.4
            row.operator("wm.open_linked_library", text="GO TO EDIT ASSET", icon='EXTERNAL_DRIVE')
        else:
            box = layout.box()
            box.label(text="Asset is not a library", icon='OBJECT_DATA')


# ACTION --------------------------------
def get_linked_library_path(obj):
    # Get the file from the library linked

    if obj is None:
        return None

    # Verify linked asset 
    if obj.library:
        return bpy.path.abspath(obj.library.filepath)

    # Verify if data (Mesh, Curve, etc.) is a library
    if obj.data and getattr(obj.data, "library", None):
        return bpy.path.abspath(obj.data.library.filepath)

    # Verify if the asset is library override or instance collection
    if obj.override_library and obj.override_library.reference:
        ref_obj = obj.override_library.reference
        if ref_obj.library:
            return bpy.path.abspath(ref_obj.library.filepath)
            
    if obj.instance_collection and obj.instance_collection.library:
        return bpy.path.abspath(obj.instance_collection.library.filepath)

    return None


class WM_OT_open_linked_library(bpy.types.Operator):
    """Abre el archivo de librería del objeto seleccionado en una nueva instancia de Blender"""
    bl_idname = "wm.open_linked_library"
    bl_label = "Deo's Asset Editor in other Blender"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and get_linked_library_path(obj) is not None

    def execute(self, context):
        obj = context.active_object
        lib_path = get_linked_library_path(obj)

        if not lib_path or not os.path.exists(lib_path):
            self.report({'ERROR'}, f"No library file found it: {lib_path}")
            return {'CANCELLED'}

        # Obtener la ruta ejecutable de la instancia actual de Blender
        blender_executable = bpy.app.binary_path

        # Lanzar una nueva instancia independiente de Blender
        try:
            subprocess.Popen([blender_executable, lib_path])
            self.report({'INFO'}, f"Opening File: {os.path.basename(lib_path)}")
        except Exception as e:
            self.report({'ERROR'}, f"Error to opening Blender instance: {str(e)}")
            return {'CANCELLED'}

        return {'FINISHED'}


# REGISTER ------------------------------
classes = (
    WM_OT_open_linked_library,
    VIEW3D_PT_linked_library_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()