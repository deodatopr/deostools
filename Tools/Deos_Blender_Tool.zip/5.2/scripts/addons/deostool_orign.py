import bpy

# TOOL --------------------------------

bl_info = {
    "name": "Deo's Origin",
    "version": (1, 0),
    "blender": (4, 4, 0),
    "location": "View3D > Sidebar > Tool Tab",
    "description": "Move origin of selected mesh objects to the bottom center of their bounding box",
    "category": "Object",
}


# UI  -----------------------------------
class VIEW3D_PT_OriginToolsPanel(bpy.types.Panel):
    bl_idname = "DEOS_PT_origin_tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ".objectmode"
    bl_category = "Deo's Tools"
    bl_label = "DEO's ORIGIN"

    def draw(self, context):
        layout = self.layout
        layout.operator("object.origin_to_bottom_center_all", text='Origin to Bottom Center', icon='ANCHOR_BOTTOM')


# ACTION --------------------------------
class OBJECT_OT_OriginToBottomCenterAll(bpy.types.Operator):
    bl_idname = "object.origin_to_bottom_center_all"
    bl_label = "Deo's Origin to Bottom Center"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected.")
            return {'CANCELLED'}

        valid_objects = [obj for obj in selected_objects if obj.type == 'MESH']

        if not valid_objects:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}

        for obj in valid_objects:
            # Apply all Transform
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

            # Center and toggle to Ori
            mesh = obj.data
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            bpy.context.scene.tool_settings.use_transform_data_origin = True


            # Get Dimensions
            dz = bpy.context.object.dimensions.z

            # Move Ori
            bpy.ops.transform.translate(
                value=(0.0, 0.0, -dz / 2.0),
                orient_type='GLOBAL',
                constraint_axis=(False, False, True),
            )

            # Turn off Ori
            bpy.context.scene.tool_settings.use_transform_data_origin = False


        return {'FINISHED'}


# REGISTER ------------------------------
classes = (
    VIEW3D_PT_OriginToolsPanel,
    OBJECT_OT_OriginToBottomCenterAll,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()