import bpy

# TOOL --------------------------------
bl_info = {
    "name": "DEO's GEO SIZE ON DISK",
    "version": (1, 4),
    "blender": (4, 4, 0),
    "location": "View3D > Sidebar > Deo's Tools",
    "description": "Estimates GLB & FBX geometry file sizes and selection statistics on demand",
    "category": "3D View",
}

# CACHE DE RESULTADOS (Para no recalcular en cada redraw)
CALCULATED_STATS = None


# AUXILIAR / METRICS -------------------
def calculate_selection_stats(context, selected_objects):
    depsgraph = context.evaluated_depsgraph_get()
    mesh_objects = [obj for obj in selected_objects if obj.type == 'MESH']
    
    total_objects = len(selected_objects)
    total_mesh_objs = len(mesh_objects)
    
    total_blender_verts = 0
    total_exported_verts = 0
    total_polys = 0
    total_tris = 0
    total_loops = 0
    
    for obj in mesh_objects:
        obj_eval = obj.evaluated_get(depsgraph)
        
        try:
            mesh = obj_eval.to_mesh()
        except RuntimeError:
            continue
            
        total_blender_verts += len(mesh.vertices)
        total_polys += len(mesh.polygons)
        
        # Conteo de triángulos reales y loops
        num_loops = len(mesh.loops)
        total_loops += num_loops
        
        for poly in mesh.polygons:
            total_tris += max(1, len(poly.vertices) - 2)
            
        exported_verts = num_loops if num_loops > 0 else len(mesh.vertices)
        total_exported_verts += exported_verts
        
        obj_eval.to_mesh_clear()

    # POSITION (12B) + NORMAL (12B) + TEXCOORD_0 (8B) = 32 Bytes
    bytes_per_vertex_glb = 32
    
    # Indices Size
    bytes_per_index_glb = 4 if total_exported_verts > 65535 else 2
    total_indices_glb = total_tris * 3 * bytes_per_index_glb
    
    # Overhead » JSON » GLB standard (~600 a 800 Bytes)
    glb_json_overhead = 700 if total_mesh_objs > 0 else 0
    
    glb_bytes = (total_exported_verts * bytes_per_vertex_glb) + total_indices_glb + glb_json_overhead

    # Overhead » FBX » Binary estimated
    fbx_header_overhead = 3000 if total_mesh_objs > 0 else 0
    fbx_raw_geom = (total_blender_verts * 12) + (total_loops * 16) + (total_tris * 3 * 4)
    fbx_bytes = int(fbx_raw_geom * 0.62) + fbx_header_overhead

    return {
        "total_objects": total_objects,
        "mesh_objects": total_mesh_objs,
        "blender_verts": total_blender_verts,
        "exported_verts": total_exported_verts,
        "polygons": total_polys,
        "triangles": total_tris,
        "glb_bytes": glb_bytes,
        "fbx_bytes": fbx_bytes,
    }


def format_size(bytes_value):
    """Format de lectura dinámico: Bytes, KB o MB."""
    if bytes_value < 1024:
        return f"{bytes_value} Bytes"
    elif bytes_value < (1024 * 1024):
        return f"{bytes_value / 1024.0:.2f} KB"
    else:
        return f"{bytes_value / (1024.0 * 1024.0):.3f} MB"


# OPERATORS (Cálculo y Limpieza) ------
class VIEW3D_OT_calculate_geom_size(bpy.types.Operator):
    bl_idname = "wm.calculate_geom_size"
    bl_label = "Calculate Size"
    bl_description = "Calculates GLB & FBX sizes for current selection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global CALCULATED_STATS
        selected_objs = context.selected_objects
        
        if selected_objs:
            CALCULATED_STATS = calculate_selection_stats(context, selected_objs)
            self.report({'INFO'}, "Geometry Size Calculated!")
        else:
            CALCULATED_STATS = None
            self.report({'WARNING'}, "No objects selected.")
            
        return {'FINISHED'}


class VIEW3D_OT_clean_geom_size(bpy.types.Operator):
    bl_idname = "wm.clean_geom_size"
    bl_label = "Clean"
    bl_description = "Clears the calculated geometry stats"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        global CALCULATED_STATS
        CALCULATED_STATS = None
        self.report({'INFO'}, "Geometry Stats Cleared.")
        return {'FINISHED'}


# UI -----------------------------------
class VIEW3D_PT_geometry_estimator_sidebar(bpy.types.Panel):
    bl_idname = "DEOS_PT_geometry_estimator"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Deo's Tools"
    bl_label = "DEO's GEOM. ON-DISK"

    def draw(self, context):
        layout = self.layout
        selected_objs = context.selected_objects

        if not selected_objs:
            box = layout.box()
            box.label(text="No objects selected", icon='INFO')
            return

        # Fila alineada con los dos botones: Calculate y Clean
        row_buttons = layout.row(align=True)
        row_buttons.operator("wm.calculate_geom_size", text="Calculate", icon='FILE_REFRESH')
        row_buttons.operator("wm.clean_geom_size", text="Clean", icon='TRASH')

        if CALCULATED_STATS is None:
            box_info = layout.box()
            box_info.label(text="Click 'Calculate' to evaluate", icon='INFO')
            return

        stats = CALCULATED_STATS

        # Statistics
        box = layout.box()
        box.label(text="SUMMARY", icon='OBJECT_DATA')
        
        col = box.column(align=True)
        col.label(text=f"Selected: {stats['total_objects']} ")
#       col.label(text=f"Vertices (Blender): {stats['blender_verts']:,}")
#       col.label(text=f"Vertices (Exported): {stats['exported_verts']:,}")
        col.label(text=f"Triangles: {stats['triangles']:,}")

        # Estimated GLB & FBX Files
        box_mb = layout.box()
#       box_mb.label(text="Estimated GLB Size", icon='FILE_BACKUP')
        
        col_sizes = box_mb.column(align=True)
        
        # GLB
        row_glb = col_sizes.row(align=True)
        row_glb.label(text="GLB:", icon='DISK_DRIVE')
        row_glb.label(text=f"~ {format_size(stats['glb_bytes'])}")
        
        # FBX
        row_fbx = col_sizes.row(align=True)
        row_fbx.label(text="FBX:", icon='FILE_3D')
        row_fbx.label(text=f"~ {format_size(stats['fbx_bytes'])}")


# REGISTER ------------------------------
classes = (
    VIEW3D_OT_calculate_geom_size,
    VIEW3D_OT_clean_geom_size,
    VIEW3D_PT_geometry_estimator_sidebar,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()